'use strict';
// ── Sdílený stav + společné funkce ───────────────────────────────────
const SD = window.SD = {
  state: {
    devices: [], serial: null, platform: 'android',
    info: null, reading: false, lastResult: null, testRunning: false,
    iosAvailable: false,
  },
  settings: null,
};

SD.$ = id => document.getElementById(id);

SD.log = msg => {
  const el = SD.$('log'); if (!el) return;
  const t = new Date().toLocaleTimeString('cs-CZ');
  el.textContent += `[${t}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
};

SD.toast = (title, body) => {
  const wrap = SD.$('toasts');
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<b></b><small></small>`;
  el.querySelector('b').textContent = title || '';
  el.querySelector('small').textContent = body || '';
  wrap.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 4200);
};

SD.copy = async text => {
  if (!text || text === '—' || text === 'N/A') return;
  try { await navigator.clipboard.writeText(text); SD.toast('Zkopírováno', text); } catch (_) {}
};

SD.fileLabel = () => {
  const mesice = ['Leden','Únor','Březen','Duben','Květen','Červen','Červenec','Srpen','Září','Říjen','Listopad','Prosinec'];
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  SD.$('fileLabel').textContent = `Soubor: ${mm}_${d.getFullYear()}.xlsx (${mesice[d.getMonth()]} ${d.getFullYear()})`;
};

// ── navigace tabů ──
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.pane').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    SD.$('pane-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'settings' && SD.populateWallpapers) SD.populateWallpapers();
  });
});

// ── vykreslení stavu připojení ze seznamu (z main watcheru i z ručního scanu) ──
function applyDeviceList(list) {
  SD.state.devices = list || [];
  const ready = SD.state.devices.filter(d => d.state === 'device');
  const other = SD.state.devices.filter(d => d.state !== 'device');
  const dot = SD.$('connDot'), txt = SD.$('connText'), sel = SD.$('deviceSelect');

  if (ready.length) {
    sel.innerHTML = ready.map(d =>
      `<option value="${d.id}" data-platform="${d.platform}">${d.platform === 'ios' ? '🍏 ' : '🤖 '}${d.label || d.id}</option>`).join('');
    // udržet vybrané, jinak první
    const cur = ready.find(d => d.id === SD.state.serial) || ready[0];
    SD.state.serial = cur.id; SD.state.platform = cur.platform;
    sel.value = cur.id;
    dot.className = 'dot ok';
    txt.textContent = `Připojeno: ${ready.length}× (${ready.map(d => d.platform === 'ios' ? 'iPhone' : 'Android').join(', ')})`;
  } else {
    sel.innerHTML = '';
    if (!SD.state.testRunning) { SD.state.serial = null; }
    if (other.length) {
      const st = other[0].state;
      const isIos = other[0].platform === 'ios';
      dot.className = 'dot';
      txt.textContent =
        st === 'unauthorized' ? (isIos
          ? 'iPhone připojen, ale NEDŮVĚŘOVÁNO – odemkni telefon a potvrď „Důvěřovat"'
          : 'Telefon připojen, ale NEAUTORIZOVÁNO – potvrď „Důvěřovat tomuto počítači"') :
        st === 'offline' ? 'Zařízení offline – odpoj a znovu připoj USB' :
        `Zařízení ve stavu „${st}"`;
    } else {
      dot.className = 'dot bad';
      txt.textContent = SD.state.iosAvailable
        ? 'Žádné zařízení – připoj telefon (USB ladění / u iPhonu „Důvěřovat")'
        : 'Žádné Android zařízení (iOS nástroje nenalezeny – viz Nastavení)';
    }
  }
}

// ruční scan
async function manualScan() {
  try {
    const r = await window.api.devicesList();
    SD.state.iosAvailable = !!(r && r.iosAvailable);
    applyDeviceList((r && r.list) || []);
  } catch (_) {}
}

SD.$('btnScan').addEventListener('click', manualScan);
SD.$('deviceSelect').addEventListener('change', e => {
  const opt = e.target.selectedOptions[0];
  SD.state.serial = e.target.value;
  SD.state.platform = opt ? opt.dataset.platform : 'android';
});

// ── události z main procesu ──
window.api.onNotify(({ title, body }) => SD.toast(title, body));
window.api.onDevicesList(list => applyDeviceList(list));
window.api.onDeviceInfo(info => {
  SD.state.serial = info.serial || info.udid;
  SD.state.platform = info.platform || 'android';
  if (typeof SD.renderInfo === 'function') SD.renderInfo(info);
});
window.api.onDeviceGone(({ id }) => {
  // vyčtené drží dokud se neodpojí – teď se odpojilo
  if (SD.state.info && (SD.state.info.serial === id || SD.state.info.udid === id)) {
    if (typeof SD.resetRead === 'function') SD.resetRead();
    SD.log('🔌 Telefon odpojen – údaje vymazány.');
  }
});
window.api.onRecordSaved(({ phase }) => {
  SD.$('phaseConfirm').textContent = `✔ uloženo jako ${phase}`;
  SD.log(`✓ [${phase}] uloženo z notifikace`);
});

// ── tapeta + automatické tmavé/světlé písmo podle jasu tapety ──
SD.applyWallpaper = (res) => {
  const wp = SD.$('wallpaper');
  if (!wp) return;
  const url = res && res.url;
  wp.style.backgroundImage = url ? `url("${url}")` : '';
  document.body.classList.toggle('light-wallpaper', !!(res && res.light));
};

// ── init ──
(async function init() {
  SD.fileLabel();
  SD.settings = await window.api.getSettings();
  if (typeof SD.applySettings === 'function') SD.applySettings();
  if (SD.settings.wallpaper) {
    const res = await window.api.tapetaUrl(SD.settings.wallpaper);
    SD.applyWallpaper(res);
  }
  manualScan();
  SD.log('Aplikace spuštěna.');
})();
