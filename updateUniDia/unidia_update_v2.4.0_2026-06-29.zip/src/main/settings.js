'use strict';
// ── Nastavení (JSON v userData) ──────────────────────────────────────
const fs = require('fs');
const path = require('path');

let FILE = null;
const DEFAULTS = {
  startupWindows: false,
  startMinimized: false,
  autoUpdate: true,
  autoUpdateMidnight: true,
  autoLoadOnConnect: true,
  disableDevModeAfterTest: false,
  uploadScanPath: 'M:\\UploadScan',
  wallpaper: '',
  advancedActions: false,
};

function initSettings(userDataDir) {
  FILE = path.join(userDataDir, 'settings.json');
}

function load() {
  try { return Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(FILE, 'utf8'))); }
  catch (_) { return Object.assign({}, DEFAULTS); }
}

function save(patch) {
  const next = Object.assign(load(), patch || {});
  try { fs.writeFileSync(FILE, JSON.stringify(next, null, 2), 'utf8'); } catch (_) {}
  return next;
}

module.exports = { initSettings, load, save, DEFAULTS };
