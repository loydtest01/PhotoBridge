Sem dej testovací APK (unidia-test.apk) PŘED buildem.
Co je v této složce při buildu, zabalí se do aplikace (resources\apk\)
a půjde nainstalovat přímo z UniDia (Akce → Nainstalovat).
