Sem dej výchozí tapety (PNG/JPG) PŘED buildem – zabalí se do aplikace.
Uživatel může další tapety přidávat i po instalaci do složky tapety\
vedle aplikace (u portable) nebo přes Nastavení → Otevřít složku.
