@echo off
chcp 65001 >nul
title UniDia - Build (instalacni + portable)

echo ============================================================
echo  UniDia - sestaveni instalacniho a portable buildu
echo ============================================================
echo.
echo DULEZITE: tento build zabali VSE, co je prave ted ve slozce
echo   ios\   (nastroje pro iPhone)  a   PATH\  (ADB pro Android).
echo Spoustej build z teto slozky, kde uz mas "Najit a nastavit"
echo hotove, aby se nastroje pro iPhone dostaly dovnitr.
echo.
pause

echo.
echo [1/2] Instaluji zavislosti (vcetne electron-builder)...
call npm install
if errorlevel 1 (
    echo CHYBA: npm install selhal. Zkontroluj pripojeni k internetu.
    pause
    exit /b 1
)

echo.
echo [2/2] Builduji instalacni (Setup) i portable .exe...
call npm run build
if errorlevel 1 (
    echo.
    echo === BUILD SELHAL - viz chyba vyse ===
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  HOTOVO. Vystup najdes ve slozce  dist\
echo    - UniDia-Setup-x.x.x.exe      (instalacni, jde do C:\UniDia)
echo    - UniDia-portable-x.x.x.exe   (portable)
echo  Oba uz maji nastroje pro iPhone i ADB v sobe.
echo ============================================================
explorer dist
pause
