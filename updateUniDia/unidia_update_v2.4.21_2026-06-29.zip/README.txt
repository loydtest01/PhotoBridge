UniDia v2.1 – Univerzální diagnostika telefonu (Android + iPhone)
=================================================================
Electron aplikace pro čtení SW a diagnostiku telefonů přes USB.
  • Android (jakákoli značka) … přes ADB – plné čtení i spouštění testů
  • iPhone / iOS … přes libimobiledevice – čtení identity, baterie, úložiště,
                   zámků; funkční testy (kamera, repro…) jsou ruční.

POŽADAVKY
---------
- Node.js 18+ (https://nodejs.org)
- ANDROID na telefonu: Vývojářský režim + USB ladění
    Samsung: Nastavení → O telefonu → 7× na "Číslo sestavení"
             → Vývojářské možnosti → USB ladění = ZAP
    Po připojení potvrď "Důvěřovat tomuto počítači".
- iPHONE:
    1) Nainstaluj Apple Mobile Device ovladače (iTunes z apple.com).
    2) Do složky  ios\  nebo  PATH\  zkopíruj binárky libimobiledevice:
         idevice_id.exe, ideviceinfo.exe, idevicediagnostics.exe + .dll
       (podrobně viz ios\README_iOS.txt)
    3) Na iPhonu potvrď "Důvěřovat" a odemkni ho.
    Bez nástrojů aplikace pro Android funguje normálně, u iPhonu jen
    zobrazí hlášku, že nástroje chybí.

SPUŠTĚNÍ
--------
Dvakrát klikni na SPUSTIT.bat (první spuštění nainstaluje závislosti).

ČERNÁ NOTIFIKACE (po připojení telefonu)
----------------------------------------
  • ukáže "SW AP" (u iPhonu iOS verzi) – KLIK = zkopíruje do schránky.
  • tlačítka OLD SW / NEW SW = uloží záznam do měsíčního xlsx.
  • ✕ = neukládat do Excelu.
  • DVOJKLIK na notifikaci = otevře program s vyčteným telefonem.
  • vyčtené údaje zůstanou, dokud telefon neodpojíš.

FÁZE
----
  OLD SW = stav PŘED přehráním SW
  NEW SW = stav PO přehrání (stejná verze je v pořádku)

DIAGNOSTIKA – princip
---------------------
  AUTOMATICKY se spouští jen testy, které OPRAVDU změří funkci:
    Android: Baterie · Nabíjení · Displej · Jas · RAM · Úložiště · CPU
             · Bezpečnost · Síť/WiFi · SIM · GPS
    iPhone:  Baterie (starší iOS) · Úložiště · Systém/zámky (Find My)

  RUČNĚ (průvodce) se ověřuje vše, co lze poznat jen přítomností:
    • KAŽDÁ kamera zvlášť (telefon i s 5+ kamerami – detekuje se počet i typ)
    • displej (bílá/barvy/tmavá), dotyk/multitouch
    • reproduktor, sluchátko, mikrofon, vibrace, tlačítka
    • senzory (akcelerometr, gyro, kompas, proximity, světlo…)
    • Bluetooth, NFC, čtečka otisků / Face ID, konektor nabíjení
  U Androidu umí průvodce přímo spustit kameru/svítilnu/vibraci…,
  u iPhonu test odklikneš ručně na telefonu (iOS to přes USB nedovolí).

PROTOKOL
--------
  PDF · tisk · uložení do zakázky (M:\UploadScan, dle Nastavení).

ZÁZNAMY
-------
  Měsíční soubory  zaznamy\MM_RRRR.xlsx

SESTAVENÍ .EXE (instalační + portable)
--------------------------------------
1) Nejdřív v aplikaci nastav iPhone nástroje (Nastavení → Najít a nastavit),
   ať jsou ve složce ios\ – ty se zabalí do buildu.
2) Spusť build.bat (ve stejné složce). Vyrobí OBA buildy do dist\:
     - UniDia-Setup-x.x.x.exe     (instalační – nainstaluje do PC, vytvoří zástupce)
     - UniDia-portable-x.x.x.exe  (portable – jeden soubor, nic neinstaluje)
   Oba už mají v sobě ADB i nástroje pro iPhone, nic se nehledá znovu.

Kam se ukládají data:
   - portable: záznamy/tapety vedle portable .exe
   - instalační: %APPDATA%\UniDia (Program Files není zapisovatelný)
   Tlačítka „Otevřít složku" v Nastavení vždy otevřou tu správnou složku.
