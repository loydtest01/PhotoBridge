'use strict';
// ── ADB wrapper (pouze USB) ───────────────────────────────────────────
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

let ADB_PATH = null;

function resolveAdb(baseDirs) {
  const exe = process.platform === 'win32' ? 'adb.exe' : 'adb';
  for (const base of baseDirs) {
    for (const cand of [path.join(base, 'PATH', exe), path.join(base, exe)]) {
      try { if (fs.existsSync(cand)) return cand; } catch (_) {}
    }
  }
  return exe;
}

function initAdb(baseDirs) {
  ADB_PATH = resolveAdb(baseDirs);
  return ADB_PATH;
}

function adb(args, timeoutMs = 12000) {
  return new Promise((resolve) => {
    let out = '', err = '', done = false;
    let child;
    try { child = spawn(ADB_PATH, args, { windowsHide: true }); }
    catch (e) { return resolve({ code: -1, stdout: '', stderr: String(e) }); }
    const timer = setTimeout(() => { if (!done) { try { child.kill('SIGKILL'); } catch (_) {} } }, timeoutMs);
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', e => { if (done) return; done = true; clearTimeout(timer); resolve({ code: -1, stdout: out, stderr: String(e) }); });
    child.on('close', code => { if (done) return; done = true; clearTimeout(timer); resolve({ code, stdout: out.trim(), stderr: err.trim() }); });
  });
}

async function startServer() { await adb(['start-server']); }

async function shell(serial, ...cmd) {
  const r = await adb(['-s', serial, 'shell', ...cmd]);
  return r.code === 0 || r.stdout ? r.stdout : '';
}

async function getprop(serial, key) {
  return ((await shell(serial, 'getprop', key)) || '').trim();
}

async function devices() {
  await startServer();
  const r = await adb(['devices']);
  const res = [];
  if (!r.stdout) return res;
  for (const l of r.stdout.split('\n').slice(1)) {
    const parts = l.trim().split('\t');
    if (parts.length === 2) res.push({ serial: parts[0].trim(), state: parts[1].trim() });
  }
  return res;
}

async function deviceSerials() {
  return (await devices()).filter(d => d.state === 'device').map(d => d.serial);
}

// restart do režimu: '' (normální) | 'download' (Odin) | 'recovery' | 'bootloader'
async function reboot(serial, mode) {
  const args = ['-s', serial, 'reboot'];
  if (mode) args.push(mode);
  const r = await adb(args, 15000);
  return r.code === 0;
}

// připojení telefonu k Wi-Fi (Android 10+: cmd wifi connect-network)
async function wifiConnect(serial, ssid, pass) {
  await shell(serial, 'svc', 'wifi', 'enable').catch(() => {});
  const sec = pass ? 'wpa2' : 'open';
  const args = pass
    ? ['cmd', 'wifi', 'connect-network', ssid, sec, pass]
    : ['cmd', 'wifi', 'connect-network', ssid, sec];
  const out = (await shell(serial, ...args)) || '';
  // některé buildy potřebují uvozovky / jiný příkaz – vrátíme výstup k vyhodnocení
  return out;
}

// instalace APK do telefonu
async function installApk(serial, apkPath) {
  const r = await adb(['-s', serial, 'install', '-r', '-g', apkPath], 120000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: /success/i.test(txt), out: txt.trim() };
}

// odinstalace balíčku z telefonu
async function uninstallApk(serial, pkg) {
  const r = await adb(['-s', serial, 'uninstall', pkg], 30000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: /success/i.test(txt), out: txt.trim() };
}

// seznam uložených Wi-Fi sítí → [{ id, ssid }]
async function wifiList(serial) {
  const out = (await shell(serial, 'cmd', 'wifi', 'list-networks')) || '';
  const nets = [];
  for (const line of out.split('\n')) {
    const l = line.trim();
    if (!l || /network\s*id/i.test(l) || /no\s+networks/i.test(l)) continue;
    // formát: <id>  <SSID>  <security>
    const m = l.match(/^(\d+)\s+(.+?)\s{2,}\S+\s*$/) || l.match(/^(\d+)\s+(.+)$/);
    if (m) nets.push({ id: m[1], ssid: m[2].trim() });
  }
  return nets;
}

// zapomenout uloženou Wi-Fi podle SSID (smaže i heslo z telefonu)
async function wifiForget(serial, ssid) {
  const nets = await wifiList(serial);
  const match = nets.filter(n => n.ssid === ssid);
  let removed = 0;
  for (const n of match) {
    const r = (await shell(serial, 'cmd', 'wifi', 'forget-network', n.id)) || '';
    if (!/fail|error|usage/i.test(r)) removed++;
  }
  return { removed, total: nets.length, found: match.length };
}

// spustit nainstalovanou aplikaci (component = "pkg/.Activity")
async function launchApp(serial, component) {
  const r = await adb(['-s', serial, 'shell', 'am', 'start', '-n', component], 15000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: !/error|does not exist|unable/i.test(txt), out: txt.trim() };
}

// stáhnout result.json z testovací APK (zkusí run-as i app-specific úložiště)
async function pullTestJson(serial, pkg) {
  // 1) interní přes run-as (debug APK)
  let out = (await shell(serial, 'run-as', pkg, 'cat', 'files/result.json')) || '';
  if (out.includes('"app"')) return out;
  // 2) app-specific externí úložiště
  out = (await shell(serial, 'cat', `/sdcard/Android/data/${pkg}/files/result.json`)) || '';
  if (out.includes('"app"')) return out;
  return '';
}

function adbPath() { return ADB_PATH; }
module.exports = { initAdb, adbPath, adb, shell, getprop, devices, deviceSerials, startServer, reboot, wifiConnect, installApk, uninstallApk, wifiList, wifiForget, launchApp, pullTestJson };
