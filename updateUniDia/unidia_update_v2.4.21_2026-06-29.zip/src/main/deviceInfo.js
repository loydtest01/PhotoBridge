'use strict';
// ── Čtení základních údajů (IMEI, S/N, AP/BL/CP/CSC, SW) ─────────────
const adb = require('./adb');
const ios = require('./ios');
const iphoneModels = require('./iphoneModels');

function formatOneUi(raw) {
  if (!raw || raw === 'N/A') return 'N/A';
  const v = parseInt(raw, 10);
  if (isNaN(v)) return raw;
  const major = Math.floor(v / 10000);
  const minor = Math.floor((v % 10000) / 100);
  return `${major}.${minor}`;
}

const BRAND_TABLE = [
  ['Samsung', ['samsung']],
  ['Xiaomi', ['xiaomi', 'redmi', 'poco']],
  ['Google', ['google', 'pixel']],
  ['OnePlus', ['oneplus']],
  ['Oppo', ['oppo']],
  ['Realme', ['realme']],
  ['Vivo', ['vivo']],
  ['Motorola', ['motorola', 'moto']],
  ['Honor', ['honor']],
  ['Huawei', ['huawei']],
  ['Nothing', ['nothing']],
  ['Asus', ['asus']],
  ['Sony', ['sony']],
  ['Alcatel', ['alcatel']],
  ['TCL', ['tcl']],
  ['Nokia', ['nokia', 'hmd']],
  ['Ulefone', ['ulefone']],
  ['Doogee', ['doogee']],
  ['Cubot', ['cubot']],
  ['Blackview', ['blackview']],
  ['Oukitel', ['oukitel']],
  ['ZTE', ['zte']],
  ['Lenovo', ['lenovo']],
  ['Tecno', ['tecno']],
  ['Infinix', ['infinix']],
  ['Sharp', ['sharp']],
  ['Fairphone', ['fairphone']],
  ['LG', ['lge', 'lg electronics']],
  ['HTC', ['htc']],
];

// jen platná (neprázdná) hodnota
function valid(v) { return v && v !== 'N/A' && v !== ''; }

// adaptivní seznam polí pro hlavní obrazovku – jen co model opravdu hlásí
function assembleFields(o, sysLabel, sysValue) {
  const f = [];
  const push = (label, value) => { if (valid(value)) f.push({ label, value }); };
  push('Model', o.model);
  push(sysLabel || 'Systém', sysValue);
  push(o.lbl_oneui, o.oneui);
  push(o.lbl_bl, o.bl);
  push(o.lbl_cp, o.cp);
  push(o.lbl_csc, o.csc);
  if (o.imei2) push('IMEI2', o.imei2);
  return f;
}

async function getDeviceInfo(serial) {
  const prop = async (k) => (await adb.getprop(serial, k)) || 'N/A';
  const first = async (...keys) => {
    for (const k of keys) {
      const v = await prop(k);
      if (v && v !== 'N/A') return v;
    }
    return 'N/A';
  };

  // IMEI
  let imei = 'N/A';
  const raw = await adb.shell(serial, 'service', 'call', 'iphonesubinfo', '1', 's16', 'com.android.shell');
  if (raw) {
    const parts = [];
    for (const chunk of raw.split("'")) {
      const cl = chunk.replace(/\./g, '').replace(/\s/g, '');
      if (/^\d+$/.test(cl)) parts.push(cl);
    }
    const j = parts.join('');
    if (j.length >= 15) imei = j.slice(0, 15);
  }
  if (imei === 'N/A') {
    const dump = await adb.shell(serial, 'dumpsys', 'telephony.registry');
    for (const line of (dump || '').split('\n')) {
      if (line.includes('mImei=')) {
        const v = line.split('mImei=')[1].trim().split(/\s/)[0];
        if (v && v !== 'null') { imei = v; break; }
      }
    }
  }

  // S/N – posbírej víc kandidátů (staré/Samsung kusy mají S/N v různých klíčích;
  // ro.serialno bývá někdy sériovka čipu/eMMC, ne to, co píše Samsung)
  const gp = async (k) => { const v = await adb.getprop(serial, k); return (v && v !== 'N/A') ? v.trim() : ''; };
  const cand = {
    'ro.serialno': await gp('ro.serialno'),
    'ro.boot.serialno': await gp('ro.boot.serialno'),
    'ril.serialnumber': await gp('ril.serialnumber'),
    'sys.serialnumber': await gp('sys.serialnumber'),
    'vendor.gsm.serial': await gp('vendor.gsm.serial'),
    'gsm.serial': await gp('gsm.serial'),
  };
  let snTransport = '';
  try { const r = await adb.adb(['-s', serial, 'get-serialno']); snTransport = (r.stdout || '').trim(); } catch (_) {}
  cand['get-serialno'] = (snTransport && snTransport !== 'unknown') ? snTransport : '';
  // Výběr správného S/N:
  //  - Samsung štítkové S/N vypadá jako "R39K60C0DN" / "R5CWB1QP4HH"
  //    (začíná písmenem, velká alfanumerika, obsahuje i jiná písmena než A–F).
  //  - "23a29ca405017ece" je 16místné malé hex = interní/USB id čipu, NE štítek.
  const order = ['ro.serialno', 'get-serialno', 'ro.boot.serialno', 'ril.serialnumber', 'sys.serialnumber', 'vendor.gsm.serial', 'gsm.serial'];
  const vals = order.map(k => cand[k]).filter(Boolean);
  const isHexId = s => /^[0-9a-f]{16,}$/.test(s);                       // interní/USB hex id
  const looksLabel = s => /^[A-Z][0-9A-Z]{6,13}$/.test(s) && !/^[0-9A-F]{16,}$/i.test(s);
  let sn = vals.find(looksLabel)                 // 1) vypadá jako štítkové S/N
        || vals.find(s => !isHexId(s))           // 2) jinak první ne-hex kandidát
        || cand['ro.serialno'] || vals[0] || 'N/A';
  if (!sn) sn = 'N/A';
  const snDebug = cand;

  // značka
  const brandStr = ((await prop('ro.product.manufacturer')) + ' ' + (await prop('ro.product.brand'))).toLowerCase();
  let brand = null;
  for (const [name, keys] of BRAND_TABLE) {
    if (keys.some(k => brandStr.includes(k))) { brand = name; break; }
  }
  if (!brand) {
    const man = await prop('ro.product.manufacturer');
    brand = (man && man !== 'N/A') ? man.charAt(0).toUpperCase() + man.slice(1) : 'Android';
  }

  const model = await first('ro.product.model', 'ro.product.vendor.model', 'ro.product.device');
  const android = await prop('ro.build.version.release');
  const bootloader = await first('ro.boot.bootloader', 'ro.bootloader');
  let baseband = await first('gsm.version.baseband', 'ro.baseband');
  if (baseband !== 'N/A' && baseband.includes(',')) {
    const seen = new Set(); const uniq = [];
    for (const p of baseband.split(',')) {
      const t = p.trim();
      if (t && !seen.has(t)) { seen.add(t); uniq.push(t); }
    }
    baseband = uniq.join(', ');
  }
  const build = await first('ro.build.display.id', 'ro.build.id');
  const incr = await first('ro.build.version.incremental');
  const secpatch = await first('ro.build.version.security_patch');

  // výchozí univerzální profil
  let ap = build, lbl_ap = 'Build SW';
  let bl = bootloader, lbl_bl = 'Bootloader';
  let cp = baseband, lbl_cp = 'Baseband';
  let csc = secpatch, lbl_csc = 'Security patch';
  let rom = incr, lbl_rom = 'Verze ROM';

  if (brand === 'Samsung') {
    ap = await first('ro.build.PDA', 'ro.build.display.id'); lbl_ap = 'AP SW';
    lbl_bl = 'BL SW'; lbl_cp = 'CP SW';
    const csc_sw = await first('ril.official_cscver', 'ro.build.official_cscver');
    const sales = await first('ril.sales_code', 'ro.csc.sales_code', 'ro.boot.sales_code');
    if (csc_sw !== 'N/A' && sales !== 'N/A') csc = `${csc_sw} / ${sales}`;
    else if (csc_sw !== 'N/A') csc = csc_sw; else csc = sales;
    lbl_csc = 'CSC';
    rom = formatOneUi(await prop('ro.build.version.oneui')); lbl_rom = 'One UI';
  } else if (brand === 'Xiaomi') {
    lbl_ap = 'Build SW';
    rom = await first('ro.mi.os.version.name', 'ro.miui.ui.version.name', 'ro.miui.version.code_name');
    lbl_rom = 'HyperOS / MIUI';
    const region = await first('ro.miui.region', 'ro.miui.build.region');
    if (region !== 'N/A') { csc = region; lbl_csc = 'Region'; }
  } else if (['OnePlus', 'Oppo', 'Realme'].includes(brand)) {
    lbl_ap = 'Build SW';
    rom = await first('ro.build.version.oplusrom', 'ro.build.version.opporom', 'ro.oxygen.version', 'ro.rom.version', 'ro.build.version.ota');
    if (rom === 'N/A') rom = incr;
    lbl_rom = 'OxygenOS / ColorOS';
  } else if (brand === 'Vivo') {
    lbl_ap = 'Build SW';
    rom = await first('ro.vivo.os.version', 'ro.vivo.os.name', 'ro.build.version.bbk');
    if (rom === 'N/A') rom = incr;
    lbl_rom = 'OriginOS / Funtouch';
  } else if (['Honor', 'Huawei'].includes(brand)) {
    lbl_ap = 'Build SW';
    rom = await first('ro.build.version.emui', 'ro.build.version.magic');
    if (rom === 'N/A') rom = incr;
    lbl_rom = 'EMUI / MagicOS';
  } else if (brand === 'Google') {
    lbl_ap = 'Build'; rom = incr; lbl_rom = 'Build inc.';
  }

  const out = {
    platform: 'android',
    serial, sn, imei, ap, bl, cp, csc, model, android, oneui: rom, brand, snDebug,
    lbl_ap, lbl_bl, lbl_cp, lbl_csc, lbl_oneui: lbl_rom,
    cameras: null, // doplní diagnostics (dynamická enumerace)
  };
  out.fields = assembleFields(out, 'Systém', android && android !== 'N/A' ? 'Android ' + android : null);
  return out;
}

// ── iOS (iPhone) přes libimobiledevice ───────────────────────────────
async function getIosInfo(udid) {
  const g = async (k, domain) => (await ios.info(udid, k, domain)) || 'N/A';

  const productType = await g('ProductType');
  const map = iphoneModels.lookup(productType !== 'N/A' ? productType : '');

  const iosVer = await g('ProductVersion');     // 17.5.1
  const build = await g('BuildVersion');        // 21F90
  const serial = await g('SerialNumber');
  const udidFull = await g('UniqueDeviceID');
  let imei = await g('InternationalMobileEquipmentIdentity');
  const imei2 = await g('InternationalMobileEquipmentIdentity2');
  const deviceName = await g('DeviceName');
  const regionInfo = await g('RegionInfo');
  const fwVer = await g('FirmwareVersion');
  const basebandVer = await g('BasebandVersion');

  if (imei === 'N/A' && udidFull !== 'N/A') imei = ''; // iPady bez modemu

  // primární „AP SW" ekvivalent pro iPhone = iOS verze (build)
  const ap = iosVer !== 'N/A'
    ? `iOS ${iosVer}${build !== 'N/A' ? ' (' + build + ')' : ''}`
    : 'N/A';

  // CSC ekvivalent = region/model part
  const modelNumber = await g('ModelNumber');
  const csc = [modelNumber, regionInfo].filter(v => v && v !== 'N/A').join(' / ') || 'N/A';

  const out = {
    platform: 'ios',
    serial: serial !== 'N/A' ? serial : udidFull,
    sn: serial !== 'N/A' ? serial : udidFull,
    udid: udidFull,
    imei: imei || 'N/A',
    imei2: imei2 !== 'N/A' ? imei2 : null,
    ap, lbl_ap: 'iOS verze (AP SW)',
    bl: fwVer, lbl_bl: 'iBoot / firmware',
    cp: basebandVer, lbl_cp: 'Baseband (CP)',
    csc, lbl_csc: 'Model / region',
    model: map.name,
    android: iosVer !== 'N/A' ? 'iOS ' + iosVer : 'iOS',
    oneui: build, lbl_oneui: 'Build',
    brand: 'Apple',
    deviceName: deviceName !== 'N/A' ? deviceName : null,
    cameras: map.cameras, // statická sestava dle modelu
  };
  out.fields = assembleFields(out, 'Systém', out.android);
  return out;
}

// dispatcher podle platformy
async function readDevice(id, platform) {
  if (platform === 'ios') return getIosInfo(id);
  return getDeviceInfo(id);
}

module.exports = { getDeviceInfo, getIosInfo, readDevice, formatOneUi };
