'use strict';
// ── Nastavení (JSON v userData) ──────────────────────────────────────
const fs = require('fs');
const path = require('path');

let FILE = null;
const DEFAULTS = {
  startupWindows: false,
  startMinimized: false,
  autoUpdate: true,
  autoUpdateMidnight: true,
  themeMode: 'manual',
  lang: 'cs',
  lightWallpaper: '',
  darkWallpaper: '',
  lightFrom: '06:00',
  lightTo: '18:00',
  autoLoadOnConnect: true,
  disableDevModeAfterTest: false,
  uploadScanPath: 'M:\\UploadScan',
  wallpaper: '',
  advancedActions: false,
};

function initSettings(dir, legacyDir) {
  FILE = path.join(dir, 'settings.json');
  // migrace ze starého umístění (userData), když nové ještě neexistuje –
  // ať se po přesunu/aktualizaci nastavení neztratí
  try {
    if (legacyDir && !fs.existsSync(FILE)) {
      const old = path.join(legacyDir, 'settings.json');
      if (fs.existsSync(old)) { fs.mkdirSync(dir, { recursive: true }); fs.copyFileSync(old, FILE); }
    }
  } catch (_) {}
}

function load() {
  try { return Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(FILE, 'utf8'))); }
  catch (_) { return Object.assign({}, DEFAULTS); }
}

function save(patch) {
  const next = Object.assign(load(), patch || {});
  try {
    if (FILE) fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(next, null, 2), 'utf8');
  } catch (_) {}
  return next;
}

module.exports = { initSettings, load, save, DEFAULTS };
