'use strict';
// ── Doplnění chybějících součástí (ADB / iOS nástroje / testovací APK) ──
// Stáhne je ze sdíleného disku (když je nastaven) nebo z GitHubu ze složky
//   updateUniDia/tools/
// a rozbalí/zkopíruje do zapisovatelné datové složky aplikace (ne do Program Files).
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const { spawn } = require('child_process');

const GH_RAW = 'https://raw.githubusercontent.com/loydtest01/PhotoBridge/main/updateUniDia/UniDia-distribuce/';

// kind → soubor, rozbalit?, cílová podsložka v datové složce
const MAP = {
  adb: { file: 'adb.zip', unzip: true, sub: 'PATH', label: 'ADB (Android)' },
  ios: { file: 'ios.zip', unzip: true, sub: 'ios', label: 'iOS nástroje (libimobiledevice)' },
  apk: { file: 'unidia-test.apk', unzip: false, sub: 'apk', label: 'Testovací APK' },
  samsungdrv: {
    file: 'samsung-usb-driver.exe', unzip: false, sub: 'drivers', label: 'Samsung USB ovladač', run: true,
    // velký soubor (>25 MB) nejde do repa přes web → bere se z GitHub Release;
    // když tam není, otevře se oficiální Samsung stránka
    url: 'https://github.com/loydtest01/PhotoBridge/releases/download/drivers/samsung-usb-driver.exe',
    officialUrl: 'https://developer.samsung.com/android-usb-driver',
  },
};

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'UniDia-Tools' } }, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307) && res.headers.location) {
        res.resume(); return httpsGet(res.headers.location).then(resolve, reject);
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const ch = []; res.on('data', d => ch.push(d)); res.on('end', () => resolve(Buffer.concat(ch)));
    }).on('error', reject);
  });
}

function expandZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    try { fs.mkdirSync(destDir, { recursive: true }); } catch (_) {}
    const ps = `Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${destDir}' -Force`;
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true });
    let err = ''; p.stderr.on('data', d => err += d);
    p.on('error', reject);
    p.on('close', c => c === 0 ? resolve() : reject(new Error('rozbalení selhalo: ' + err)));
  });
}

// dataDirFn = funkce sub→absolutní zapisovatelná cesta (z main.js)
async function fetchTool(kind, dataDirFn, diskPath) {
  const m = MAP[kind];
  if (!m) return { ok: false, error: 'Neznámá součást.' };
  const targetDir = dataDirFn(m.sub);
  try { fs.mkdirSync(targetDir, { recursive: true }); } catch (_) {}

  // 1) sdílený disk (když je nastaven a soubor tam je)
  if (diskPath) {
    const src = path.join(diskPath, m.file);
    try {
      if (fs.existsSync(src)) {
        if (m.unzip) { await expandZip(src, targetDir); }
        else { fs.copyFileSync(src, path.join(targetDir, m.file)); }
        return { ok: true, source: 'disk', label: m.label, dir: targetDir };
      }
    } catch (e) { /* spadne na GitHub */ }
  }

  // 2) GitHub (Release asset přes m.url, jinak updateUniDia/UniDia-distribuce/)
  const dlUrl = m.url || (GH_RAW + encodeURIComponent(m.file));
  let buf;
  try { buf = await httpsGet(dlUrl); }
  catch (e) {
    // když je k dispozici oficiální stránka (ovladač), otevři ji v prohlížeči
    if (m.officialUrl) {
      try { require('electron').shell.openExternal(m.officialUrl); } catch (_) {}
      return { ok: false, opened: true, official: m.officialUrl, label: m.label,
        error: 'Soubor nebyl nalezen na GitHubu – otevřel jsem oficiální stránku ke stažení.' };
    }
    return { ok: false, error: 'Nepodařilo se stáhnout: ' + (e.message || e), label: m.label };
  }
  try {
    if (m.unzip) {
      const tmp = path.join(os.tmpdir(), m.file);
      fs.writeFileSync(tmp, buf);
      await expandZip(tmp, targetDir);
      try { fs.rmSync(tmp, { force: true }); } catch (_) {}
    } else {
      const dest = path.join(targetDir, m.file);
      fs.writeFileSync(dest, buf);
      if (m.run) { try { require('electron').shell.openPath(dest); } catch (_) {} }
    }
    return { ok: true, source: 'github', label: m.label, dir: targetDir };
  } catch (e) { return { ok: false, error: String(e.message || e), label: m.label }; }
}

module.exports = { fetchTool, MAP };
