'use strict';
// ── Diagnostika telefonu (Android přes ADB / iOS přes libimobiledevice) ──
const adb = require('./adb');
const ios = require('./ios');
const iphoneModels = require('./iphoneModels');

function kv(text) {
  const d = {};
  for (const line of (text || '').split('\n')) {
    const i = line.indexOf(':');
    if (i > -1) d[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
  }
  return d;
}

async function readSysfs(serial, paths) {
  for (const p of paths) {
    const v = await adb.shell(serial, 'cat', p);
    if (v && !/No such file|Permission denied/.test(v)) {
      const t = v.trim();
      if (t) return t;
    }
  }
  return null;
}

const BATT_STATUS = { '1': 'Neznámý', '2': 'Nabíjí se', '3': 'Vybíjí se', '4': 'Nenabíjí se', '5': 'Plně nabito' };
const BATT_HEALTH = { '1': 'Neznámé', '2': 'Dobré', '3': 'Přehřátí', '4': 'Mrtvá', '5': 'Přepětí', '6': 'Neznámá závada', '7': 'Studená' };

async function diagBattery(serial) {
  const rows = [];
  const d = kv(await adb.shell(serial, 'dumpsys', 'battery'));
  const lvl = parseInt(d['level'], 10), scale = parseInt(d['scale'] || '100', 10) || 100;
  if (!isNaN(lvl)) {
    const pct = Math.round(lvl * 100 / scale);
    rows.push(['Nabití', `${pct} %`, pct >= 20 ? 'OK' : 'WARN']);
  }
  const plugged = [];
  if ((d['ac powered'] || '').toLowerCase() === 'true') plugged.push('AC');
  if ((d['usb powered'] || '').toLowerCase() === 'true') plugged.push('USB');
  if ((d['wireless powered'] || '').toLowerCase() === 'true') plugged.push('bezdrát');
  rows.push(['Stav', (BATT_STATUS[d['status']] || d['status'] || '—') + (plugged.length ? ` (${plugged.join(', ')})` : ''), 'INFO']);

  const h = d['health'];
  rows.push(['Kondice (flag)', BATT_HEALTH[h] || h || '—', h === '2' ? 'OK' : (h === '4' ? 'FAIL' : (h ? 'WARN' : 'INFO'))]);

  const temp = parseInt(d['temperature'], 10);
  if (!isNaN(temp)) {
    const t = temp / 10;
    rows.push(['Teplota', `${t.toFixed(1)} °C`, t < 40 ? 'OK' : (t < 45 ? 'WARN' : 'FAIL')]);
  }
  const mv = parseInt(d['voltage'], 10);
  if (!isNaN(mv)) rows.push(['Napětí', `${(mv / 1000).toFixed(3)} V`, 'INFO']);
  if (d['technology']) rows.push(['Technologie', d['technology'], 'INFO']);

  // USB odběr přes sysfs
  const cur = await readSysfs(serial, [
    '/sys/class/power_supply/battery/current_now',
    '/sys/class/power_supply/Battery/current_now',
    '/sys/class/power_supply/usb/current_now',
  ]);
  if (cur && !isNaN(parseInt(cur, 10))) {
    const ma = parseInt(cur, 10) / 1000;
    const absMa = Math.abs(ma);
    // kladné = nabíjí, záporné = vybíjí (závisí na výrobci)
    const charging = ma > 0 || (d['status'] === '2');
    rows.push(['Proud (USB)', `${ma >= 0 ? '+' : ''}${ma.toFixed(0)} mA`,
      charging && absMa > 50 ? 'OK' : (!charging && absMa > 50 ? 'INFO' : 'INFO')]);
  }

  const full = await readSysfs(serial, ['/sys/class/power_supply/battery/charge_full', '/sys/class/power_supply/Battery/charge_full']);
  const design = await readSysfs(serial, ['/sys/class/power_supply/battery/charge_full_design', '/sys/class/power_supply/Battery/charge_full_design']);
  if (full && design && parseInt(design, 10) > 0) {
    const health = parseInt(full, 10) * 100 / parseInt(design, 10);
    rows.push(['Zdraví kapacity', `${health.toFixed(1)} %  (${Math.round(parseInt(full, 10) / 1000)} / ${Math.round(parseInt(design, 10) / 1000)} mAh)`,
      health >= 85 ? 'OK' : (health >= 75 ? 'WARN' : 'FAIL')]);
  }
  // ── Počet nabíjecích cyklů (kolik už má baterie za sebou) ──
  // Samsung (Galaxy/Fold) používá uzel battery_cycle; ostatní cycle_count.
  let cy = null;
  const cyc = await readSysfs(serial, [
    '/sys/class/power_supply/battery/cycle_count',
    '/sys/class/power_supply/Battery/cycle_count',
    '/sys/class/power_supply/battery/battery_cycle',   // Samsung
    '/sys/class/power_supply/Battery/battery_cycle',
    '/sys/class/power_supply/bms/cycle_count',
  ]);
  if (cyc && /^\d+$/.test(cyc.trim())) cy = parseInt(cyc.trim(), 10);

  // fallback: dumpsys battery někdy obsahuje řádek s "cycle"
  if (cy === null) {
    const dump = await adb.shell(serial, 'dumpsys', 'battery') || '';
    const m = dump.match(/cycle\s*count[^0-9]*(\d+)/i) || dump.match(/charge\s*cycle[^0-9]*(\d+)/i);
    if (m) cy = parseInt(m[1], 10);
  }

  if (cy !== null) {
    // některé Samsung reportují hodnotu ×100 (např. 5300 = 53 cyklů)
    let note = '';
    if (cy > 5000) { note = ` (raw ${cy})`; cy = Math.round(cy / 100); }
    rows.push(['Nabíjecí cykly', `${cy}×${note}`, cy < 400 ? 'OK' : (cy < 800 ? 'WARN' : 'FAIL')]);
  } else {
    rows.push(['Nabíjecí cykly', 'Telefon počet cyklů nezveřejňuje', 'INFO']);
  }
  if (!rows.length) rows.push(['Baterie', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagCharging(serial) {
  // Specifický test nabíjení přes USB - čte proud a stav vícekrát
  const rows = [];
  const d = kv(await adb.shell(serial, 'dumpsys', 'battery'));
  const status = d['status'];
  const usbPowered = (d['usb powered'] || '').toLowerCase() === 'true';
  const acPowered = (d['ac powered'] || '').toLowerCase() === 'true';

  rows.push(['USB napájení', usbPowered ? 'Ano' : 'Ne', usbPowered ? 'OK' : 'INFO']);
  rows.push(['AC nabíjení', acPowered ? 'Ano' : 'Ne', acPowered ? 'OK' : 'INFO']);
  rows.push(['Stav nabíjení', BATT_STATUS[status] || status || '—', status === '2' ? 'OK' : (status === '5' ? 'OK' : 'WARN')]);

  const cur = await readSysfs(serial, [
    '/sys/class/power_supply/battery/current_now',
    '/sys/class/power_supply/Battery/current_now',
    '/sys/class/power_supply/usb/current_now',
  ]);
  if (cur && !isNaN(parseInt(cur, 10))) {
    const ma = parseInt(cur, 10) / 1000;
    const absMa = Math.abs(ma);
    rows.push(['Nabíjecí proud', `${ma >= 0 ? '+' : ''}${ma.toFixed(0)} mA`,
      absMa > 100 ? 'OK' : (absMa > 0 ? 'WARN' : 'FAIL')]);
    if (absMa > 0) {
      const power = (ma >= 0 ? ma : -ma) * (parseInt(d['voltage'], 10) || 3700) / 1000000;
      rows.push(['Odhadovaný příkon', `${power.toFixed(2)} W`, 'INFO']);
    }
  } else {
    rows.push(['Nabíjecí proud', 'Sysfs nedostupné – viz stav nabíjení výše', 'INFO']);
  }

  const lvl = parseInt(d['level'], 10), scale = parseInt(d['scale'] || '100', 10) || 100;
  if (!isNaN(lvl)) rows.push(['Aktuální nabití', `${Math.round(lvl * 100 / scale)} %`, 'INFO']);

  return rows;
}

const FEATURE_MAP = [
  ['android.hardware.sensor.accelerometer', 'Akcelerometr', true],
  ['android.hardware.sensor.gyroscope', 'Gyroskop', true],
  ['android.hardware.sensor.compass', 'Kompas (magnetometr)', false],
  ['android.hardware.sensor.proximity', 'Přiblížení (proximity)', true],
  ['android.hardware.sensor.light', 'Světelný senzor', true],
  ['android.hardware.sensor.barometer', 'Barometr', false],
  ['android.hardware.sensor.stepcounter', 'Krokoměr', false],
  ['android.hardware.fingerprint', 'Čtečka otisků', false],
  ['android.hardware.biometrics.face', 'Rozpoznání obličeje', false],
];

async function diagSensors(serial) {
  const out = await adb.shell(serial, 'pm', 'list', 'features');
  const set = new Set((out || '').split('\n').filter(l => l.startsWith('feature:')).map(l => l.slice(8).trim()));
  const rows = [];
  for (const [feat, name, critical] of FEATURE_MAP) {
    const present = [...set].some(f => f === feat || f.startsWith(feat));
    rows.push(present ? [name, 'Přítomen', 'OK'] : [name, 'Chybí', critical ? 'WARN' : 'INFO']);
  }
  if (!set.size) rows.push(['Senzory', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

// ── Enumerace VŠECH fyzických kamer (Android) ─────────────────────────
// Vrací [{ id, facing:'back'|'front'|'ext'|'?', label }] – telefon může mít 5+ kamer.
async function enumerateCamerasAndroid(serial) {
  const cams = [];
  const dump = await adb.shell(serial, 'dumpsys', 'media.camera') || '';

  // 1) celkový počet
  let count = null;
  for (const line of dump.split('\n')) {
    const m = line.match(/Number of camera devices:\s*(\d+)/i) ||
              line.match(/device count[^:]*:\s*(\d+)/i);
    if (m) { count = parseInt(m[1], 10); break; }
  }

  // 2) rozparsovat bloky "Camera N information:" a hledat facing
  const blocks = dump.split(/Camera\s+(\d+)\s+information/i);
  const facingById = {};
  for (let i = 1; i < blocks.length; i += 2) {
    const id = blocks[i];
    const body = (blocks[i + 1] || '').slice(0, 1500);
    let facing = '?';
    if (/facing[^a-z]*back/i.test(body) || /lens.facing[^0-9]*1/i.test(body)) facing = 'back';
    else if (/facing[^a-z]*front/i.test(body) || /lens.facing[^0-9]*0/i.test(body)) facing = 'front';
    else if (/facing[^a-z]*external/i.test(body)) facing = 'ext';
    facingById[id] = facing;
  }

  // počet z bloků, pokud chybí číselný údaj
  if (count === null) {
    const ids = Object.keys(facingById);
    if (ids.length) count = ids.length;
  }
  // fallback: zkusit camera2 přes cmd
  if (count === null) {
    const ids = (await adb.shell(serial, 'cmd', 'media.camera', 'list') || '').match(/\d+/g);
    if (ids) count = new Set(ids).size;
  }
  if (count === null || count < 1) {
    const feats = await adb.shell(serial, 'pm', 'list', 'features') || '';
    count = feats.includes('android.hardware.camera.front') ? 2 : (feats.includes('android.hardware.camera') ? 1 : 0);
  }

  let nBack = 0, nFront = 0;
  for (let id = 0; id < count; id++) {
    const f = facingById[String(id)] || '?';
    let label;
    if (f === 'back')      label = `Zadní kamera #${++nBack}`;
    else if (f === 'front') label = `Přední kamera #${++nFront}`;
    else if (f === 'ext')   label = `Externí kamera (ID ${id})`;
    else                    label = `Kamera ID ${id}`;
    cams.push({ id: String(id), facing: f, label });
  }
  return cams;
}

// presence baterie/blesku pro info (neslouží jako funkční verdikt)
async function cameraFeaturesAndroid(serial) {
  const out = await adb.shell(serial, 'pm', 'list', 'features') || '';
  return {
    flash: out.includes('android.hardware.camera.flash'),
    autofocus: out.includes('android.hardware.camera.autofocus'),
  };
}

async function diagDisplay(serial) {
  const rows = [];
  const size = await adb.shell(serial, 'wm', 'size');
  let m = (size || '').match(/:\s*(\d+x\d+)/);
  if (m) rows.push(['Rozlišení', m[1], 'INFO']);
  const dens = await adb.shell(serial, 'wm', 'density');
  m = (dens || '').match(/:\s*(\d+)/);
  if (m) rows.push(['Hustota', `${m[1]} dpi`, 'INFO']);
  const disp = await adb.shell(serial, 'dumpsys', 'display');
  m = (disp || '').match(/fps=([\d.]+)/) || (disp || '').match(/refreshRate=([\d.]+)/);
  if (m) rows.push(['Obnovovací frekvence', `${Math.round(parseFloat(m[1]))} Hz`, 'INFO']);
  if (!rows.length) rows.push(['Displej', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagMemory(serial) {
  const rows = [];
  const mem = await adb.shell(serial, 'cat', '/proc/meminfo');
  let total = null, avail = null;
  for (const line of (mem || '').split('\n')) {
    if (line.startsWith('MemTotal:')) total = parseInt(line.replace(/\D/g, ''), 10);
    else if (line.startsWith('MemAvailable:')) avail = parseInt(line.replace(/\D/g, ''), 10);
  }
  if (total) {
    let txt = `${(total / 1024 / 1024).toFixed(1)} GB`;
    if (avail) txt += `  (volné ${(avail / 1024 / 1024).toFixed(1)} GB)`;
    rows.push(['RAM', txt, 'INFO']);
  }
  const dfout = await adb.shell(serial, 'df', '/data');
  const lines = (dfout || '').split('\n').filter(l => l.trim());
  if (lines.length >= 2) {
    const p = lines[lines.length - 1].split(/\s+/);
    const sizekb = parseInt(p[1], 10), availkb = parseInt(p[3], 10);
    if (!isNaN(sizekb)) rows.push(['Úložiště (/data)', `${(sizekb / 1024 / 1024).toFixed(1)} GB  (volné ${(availkb / 1024 / 1024).toFixed(1)} GB)`, 'INFO']);
  }
  if (!rows.length) rows.push(['Paměť', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagCpu(serial) {
  const rows = [];
  const abi = (await adb.getprop(serial, 'ro.product.cpu.abi')).trim();
  if (abi) rows.push(['Architektura', abi, 'INFO']);
  const cpuinfo = await adb.shell(serial, 'cat', '/proc/cpuinfo');
  const cores = (cpuinfo || '').split('\n').filter(l => /^processor/i.test(l)).length;
  if (cores) rows.push(['Počet jader', String(cores), 'INFO']);
  const hw = (await adb.getprop(serial, 'ro.board.platform')).trim() || (await adb.getprop(serial, 'ro.hardware')).trim();
  if (hw) rows.push(['Platforma / čip', hw, 'INFO']);
  if (!rows.length) rows.push(['CPU', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagSecurity(serial) {
  const rows = [];
  const gp = k => adb.getprop(serial, k);
  const vbs = (await gp('ro.boot.verifiedbootstate')).trim();
  if (vbs) {
    rows.push(vbs === 'green' ? ['Bootloader', 'Zamčený (green)', 'OK'] : ['Bootloader', `Odemčený / upravený (${vbs})`, 'WARN']);
  } else {
    const fl = (await gp('ro.boot.flash.locked')).trim();
    if (fl === '0' || fl === '1') rows.push(['Bootloader', fl === '1' ? 'Zamčený' : 'Odemčený', fl === '1' ? 'OK' : 'WARN']);
  }
  const su = (await adb.shell(serial, 'which', 'su')).trim();
  rows.push(su.includes('su') ? ['Root', 'Detekováno su (rootnuto)', 'FAIL'] : ['Root', 'Nedetekováno', 'OK']);
  const wb = (await gp('ro.boot.warranty_bit')).trim() || (await gp('ro.warranty_bit')).trim();
  if (wb === '0' || wb === '1') rows.push(['Samsung warranty bit', wb === '0' ? '0 (netripnuto)' : '1 (TRIPNUTO – Knox)', wb === '0' ? 'OK' : 'FAIL']);
  const cr = (await gp('ro.crypto.state')).trim();
  if (cr) rows.push(['Šifrování', cr, cr === 'encrypted' ? 'OK' : 'WARN']);
  const sp = (await gp('ro.build.version.security_patch')).trim();
  if (sp) rows.push(['Bezpečnostní záplata', sp, 'INFO']);

  // ── Účty / FRP (jen čtení – informace, ne obejití) ──
  try {
    const acc = (await adb.shell(serial, 'dumpsys', 'account')) || '';
    const types = [];
    const re = /Account\s*\{[^}]*type=([a-zA-Z0-9._]+)/g; let m;
    while ((m = re.exec(acc)) !== null) types.push(m[1]);
    const hasGoogle = types.some(t => /google/i.test(t));
    const uniq = [...new Set(types)];
    if (acc.includes('Accounts:') || types.length) {
      rows.push(['Přihlášené účty', uniq.length ? uniq.join(', ') : 'žádné', 'INFO']);
      rows.push(['FRP (po resetu)', hasGoogle
        ? 'AKTIVNÍ – přihlášený Google účet, po resetu vyžádá ověření'
        : 'Neaktivní – žádný Google účet', hasGoogle ? 'WARN' : 'OK']);
    }
  } catch (_) {}

  if (!rows.length) rows.push(['Bezpečnost', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagNetwork(serial) {
  const rows = [];

  // ── SIM / mobilní síť ──
  const op = (await adb.getprop(serial, 'gsm.operator.alpha')).trim();
  if (op) rows.push(['Operátor', op, 'INFO']);
  const sim = (await adb.getprop(serial, 'gsm.sim.state')).trim();
  if (sim) rows.push(['Stav SIM', sim, sim.includes('READY') ? 'OK' : (sim.includes('ABSENT') ? 'INFO' : 'WARN')]);

  // ── WiFi – stav připojení (přes USB ADB, bez tcpip) ──
  const wifiState = (await adb.getprop(serial, 'wifi.interface')).trim();
  const wifiEnabled = (await adb.shell(serial, 'settings', 'get', 'global', 'wifi_on')).trim();
  rows.push(['Wi-Fi hardware', wifiState ? 'Ano' : 'Ne', wifiState ? 'OK' : 'INFO']);
  rows.push(['Wi-Fi zapnuto', wifiEnabled === '1' ? 'Ano' : 'Ne', wifiEnabled === '1' ? 'OK' : 'INFO']);

  if (wifiEnabled === '1') {
    // SSID a stav spojení
    const wifiDump = await adb.shell(serial, 'dumpsys', 'wifi');
    let ssid = null, wifiConnected = false, rssi = null, freq = null, speed = null, ip = null;

    for (const line of (wifiDump || '').split('\n')) {
      const l = line.trim();
      // různé verze Androidu – hledáme SSID a stav
      if (!ssid) {
        let m = l.match(/SSID:\s*"?([^",\s]+)"?/) || l.match(/mWifiInfo.*SSID:\s*"?([^",\s]+)"?/);
        if (m && m[1] && m[1] !== '<unknown ssid>') ssid = m[1];
      }
      if (/getConnectionInfo/.test(l) || /mNetworkInfo.*CONNECTED/.test(l)) wifiConnected = true;
      if (!rssi) { const m = l.match(/RSSI:\s*(-?\d+)/); if (m) rssi = parseInt(m[1], 10); }
      if (!freq) { const m = l.match(/[Ff]requency:\s*(\d+)/); if (m) freq = parseInt(m[1], 10); }
      if (!speed) { const m = l.match(/[Ll]ink[Ss]peed:\s*(\d+)/); if (m) speed = parseInt(m[1], 10); }
    }

    // IP adresa wlan0
    const ipOut = await adb.shell(serial, 'ip', '-f', 'inet', 'addr', 'show', 'wlan0');
    const ipM = (ipOut || '').match(/inet\s+(\d+\.\d+\.\d+\.\d+)/);
    if (ipM) ip = ipM[1];

    // alternativní detekce připojení
    if (!wifiConnected && ip) wifiConnected = true;
    if (!wifiConnected) {
      const netinfo = await adb.shell(serial, 'dumpsys', 'connectivity');
      wifiConnected = /WIFI.*CONNECTED/i.test(netinfo || '');
    }

    rows.push(['Wi-Fi připojení', wifiConnected ? 'Připojeno' : 'Nepřipojeno', wifiConnected ? 'OK' : 'WARN']);
    if (ssid) rows.push(['SSID sítě', ssid, 'INFO']);
    if (ip)   rows.push(['IP adresa (wlan0)', ip, 'INFO']);
    if (rssi !== null) {
      const quality = rssi >= -55 ? 'Výborný' : rssi >= -70 ? 'Dobrý' : rssi >= -80 ? 'Slabý' : 'Velmi slabý';
      rows.push(['Síla signálu (RSSI)', `${rssi} dBm (${quality})`, rssi >= -70 ? 'OK' : rssi >= -80 ? 'WARN' : 'FAIL']);
    }
    if (freq !== null) rows.push(['Frekvence', freq >= 5000 ? `${freq} MHz (5 GHz)` : `${freq} MHz (2.4 GHz)`, 'INFO']);
    if (speed !== null) rows.push(['Rychlost linky', `${speed} Mbps`, 'INFO']);
  }

  // ── ostatní hardware ──
  const features = await adb.shell(serial, 'pm', 'list', 'features');
  for (const [feat, name] of [
    ['android.hardware.bluetooth', 'Bluetooth'],
    ['android.hardware.nfc', 'NFC'],
    ['android.hardware.location.gps', 'GPS'],
  ]) {
    rows.push([name, features.includes(feat) ? 'Ano' : 'Ne', features.includes(feat) ? 'OK' : 'INFO']);
  }

  return rows;
}

// mapování technologie sítě na generaci (2G/3G/4G/5G)
function ratGeneration(type) {
  const t = String(type || '').toUpperCase();
  if (/\bNR\b|5G/.test(t)) return `5G (${type})`;
  if (/LTE|4G/.test(t)) return `4G (${type})`;
  if (/HSPA|HSDPA|HSUPA|UMTS|WCDMA|CDMA|EVDO|TD.?SCDMA|3G/.test(t)) return `3G (${type})`;
  if (/EDGE|GPRS|GSM|2G/.test(t)) return `2G (${type})`;
  return type;
}

// ── SIM detailně ──────────────────────────────────────────────────────
async function diagSim(serial) {
  const rows = [];
  const gp = k => adb.getprop(serial, k);

  // počet SIM slotů
  const slots = parseInt(await gp('ro.telephony.sim.count') || await gp('persist.radio.multisim.config') === 'dsds' ? '2' : '1', 10) || 1;
  rows.push(['Počet SIM slotů', String(slots), 'INFO']);

  for (let i = 0; i < Math.min(slots, 2); i++) {
    const suffix = i === 0 ? '' : String(i + 1);
    const state = (await adb.shell(serial, 'getprop', `gsm.sim.state${suffix ? ',' + suffix : ''}`)).trim().split(',')[i] ||
                  (await gp(`gsm.sim.state${suffix}`)).trim();
    const op    = (await gp(`gsm.operator.alpha${suffix ? '.' + suffix : ''}`)).trim() ||
                  (await gp(`gsm.operator.alpha`)).trim();
    const imsi  = (await gp(`ril.iccid.sim${i + 1}`)).trim() ||
                  (await adb.shell(serial, 'service', 'call', 'iphonesubinfo', String(11 + i * 5))).replace(/[^0-9]/g, '').slice(0, 19);
    const type  = (await gp(`gsm.network.type${suffix ? '.' + suffix : ''}`)).trim();
    const label = slots > 1 ? `SIM ${i + 1}` : 'SIM';
    const stOk  = state.includes('READY');
    rows.push([`${label} stav`, state || 'Neznámý', stOk ? 'OK' : state.includes('ABSENT') ? 'INFO' : 'WARN']);
    if (op)   rows.push([`${label} operátor`, op, 'INFO']);
    if (imsi && imsi.length > 6) rows.push([`${label} ICCID`, imsi, 'INFO']);
    if (type) rows.push([`${label} datová síť`, ratGeneration(type), 'INFO']);
  }

  // LTE / 5G signál
  const dump = await adb.shell(serial, 'dumpsys', 'telephony.registry');
  for (const line of (dump || '').split('\n')) {
    const m = line.match(/mSignalStrength.*lte.*rsrp=(-?\d+)/i);
    if (m) { const v = parseInt(m[1], 10); rows.push(['LTE RSRP', `${v} dBm`, v >= -90 ? 'OK' : v >= -105 ? 'WARN' : 'FAIL']); break; }
  }
  const roaming = (await gp('gsm.operator.isroaming')).trim();
  if (roaming) rows.push(['Roaming', roaming === 'true' ? 'Ano' : 'Ne', roaming === 'true' ? 'WARN' : 'OK']);

  if (!rows.length) rows.push(['SIM', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

// ── SD karta / eMMC / úložiště ────────────────────────────────────────
async function diagStorage(serial) {
  const rows = [];

  // eMMC verze a výrobce
  const cid = await readSysfs(serial, ['/sys/block/mmcblk0/device/cid']);
  if (cid) {
    const manuf = cid.slice(0, 2).toUpperCase();
    const manufMap = { '15': 'Samsung', '45': 'Sandisk', '02': 'Kingston', '70': 'Kingston', 'CE': 'Micron', 'FE': 'Micron', 'AD': 'Hynix', '11': 'Toshiba' };
    rows.push(['eMMC výrobce', manufMap[manuf] || `ID ${manuf}`, 'INFO']);
  }
  const name = await readSysfs(serial, ['/sys/block/mmcblk0/device/name']);
  if (name) rows.push(['eMMC model', name.trim(), 'INFO']);
  const fwrev = await readSysfs(serial, ['/sys/block/mmcblk0/device/fwrev']);
  if (fwrev) rows.push(['eMMC FW', fwrev.trim(), 'INFO']);

  // velikost eMMC
  const size = await readSysfs(serial, ['/sys/block/mmcblk0/size']);
  if (size) {
    const gb = parseInt(size.trim(), 10) * 512 / 1024 / 1024 / 1024;
    rows.push(['eMMC velikost', `${gb.toFixed(1)} GB`, 'INFO']);
  }

  // /data a /sdcard přes df
  for (const [mount, label] of [['/data', 'Interní úložiště (/data)'], ['/sdcard', 'Sdcard / emulovaná']]) {
    const df = await adb.shell(serial, 'df', mount);
    const lines = (df || '').split('\n').filter(l => l.trim());
    if (lines.length >= 2) {
      const p = lines[lines.length - 1].split(/\s+/);
      const tot = parseInt(p[1], 10), avl = parseInt(p[3], 10);
      if (!isNaN(tot) && tot > 0) rows.push([label, `${(tot / 1024 / 1024).toFixed(1)} GB celkem · ${(avl / 1024 / 1024).toFixed(1)} GB volně`, 'INFO']);
    }
  }

  // SD karta fyzická (mmcblk1)
  const sdSize = await readSysfs(serial, ['/sys/block/mmcblk1/size']);
  if (sdSize && parseInt(sdSize.trim(), 10) > 0) {
    const gb = parseInt(sdSize.trim(), 10) * 512 / 1024 / 1024 / 1024;
    const sdName = await readSysfs(serial, ['/sys/block/mmcblk1/device/name']);
    rows.push(['SD karta', `${gb.toFixed(1)} GB${sdName ? ' · ' + sdName.trim() : ''}`, 'OK']);
    const sdCid = await readSysfs(serial, ['/sys/block/mmcblk1/device/cid']);
    if (sdCid) {
      const m = { '03': 'SanDisk', '27': 'Phison', '74': 'Transcend', '02': 'Kingston' };
      const k = sdCid.slice(0, 2).toUpperCase();
      if (m[k]) rows.push(['SD výrobce', m[k], 'INFO']);
    }
  } else {
    rows.push(['SD karta', 'Není vložena', 'INFO']);
  }

  // /external_sd přes df
  const extDf = await adb.shell(serial, 'df', '/external_sd');
  if (extDf && !extDf.includes('No such') && !extDf.includes('Permission')) {
    const lines = extDf.split('\n').filter(l => l.trim());
    if (lines.length >= 2) {
      const p = lines[lines.length - 1].split(/\s+/);
      const tot = parseInt(p[1], 10);
      if (!isNaN(tot) && tot > 0) rows.push(['SD karta (/external_sd)', `${(tot / 1024 / 1024).toFixed(1)} GB`, 'INFO']);
    }
  }

  if (!rows.length) rows.push(['Úložiště', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

// ── Bluetooth scan ────────────────────────────────────────────────────
async function diagBluetooth(serial) {
  const rows = [];
  const features = await adb.shell(serial, 'pm', 'list', 'features');
  const hasbt = features.includes('android.hardware.bluetooth');
  rows.push(['Bluetooth hardware', hasbt ? 'Přítomen' : 'Chybí', hasbt ? 'OK' : 'FAIL']);
  if (!hasbt) return rows;

  const addr = (await adb.getprop(serial, 'ro.boot.btmacaddr')).trim() ||
               (await adb.getprop(serial, 'ro.bt.bdaddr_path')).trim();
  if (addr && addr.includes(':')) rows.push(['BT MAC adresa', addr, 'INFO']);

  // stav adaptéru přes dumpsys
  const dump = await adb.shell(serial, 'dumpsys', 'bluetooth_manager');
  const enabled = /enabled\s*=\s*true/i.test(dump || '') || /STATE_ON/i.test(dump || '');
  rows.push(['Bluetooth zapnuto', enabled ? 'Ano' : 'Ne', enabled ? 'OK' : 'INFO']);

  if (enabled) {
    // spárovaná zařízení
    let paired = 0;
    for (const line of (dump || '').split('\n')) {
      if (/bonded\s+devices/i.test(line)) { paired++; }
      if (/Bond\s+State/i.test(line) && /BONDED/i.test(line)) paired++;
    }
    // počet z jiného formátu
    const bondedLines = (dump || '').split('\n').filter(l => /name=.+addr=/i.test(l));
    if (bondedLines.length) rows.push(['Spárovaná zařízení', String(bondedLines.length), 'INFO']);

    // BLE podpora
    const hasBle = features.includes('android.hardware.bluetooth_le');
    rows.push(['Bluetooth LE', hasBle ? 'Podporováno' : 'Ne', hasBle ? 'OK' : 'INFO']);
  }
  return rows;
}

// ── GPS ───────────────────────────────────────────────────────────────
async function diagGps(serial) {
  const rows = [];
  const features = await adb.shell(serial, 'pm', 'list', 'features');
  const hasGps = features.includes('android.hardware.location.gps');
  rows.push(['GPS hardware', hasGps ? 'Přítomen' : 'Chybí', hasGps ? 'OK' : 'WARN']);

  const locMode = (await adb.shell(serial, 'settings', 'get', 'secure', 'location_mode')).trim();
  const locEnabled = locMode !== '0' && locMode !== '';
  rows.push(['Lokace zapnuta', locEnabled ? `Ano (režim ${locMode})` : 'Ne', locEnabled ? 'OK' : 'INFO']);

  // provider dostupnost
  const providers = (await adb.shell(serial, 'settings', 'get', 'secure', 'location_providers_allowed')).trim();
  if (providers) rows.push(['Aktivní providery', providers, 'INFO']);

  // GNSS stav
  const dump = await adb.shell(serial, 'dumpsys', 'location');
  let sats = null;
  for (const line of (dump || '').split('\n')) {
    const m = line.match(/(\d+)\s+satellites?\s+used/i) || line.match(/usedInFix=(\d+)/i);
    if (m) { sats = parseInt(m[1], 10); break; }
  }
  if (sats !== null) rows.push(['Satelity (poslední fix)', String(sats), sats > 0 ? 'OK' : 'INFO']);

  // A-GPS server
  const agps = (await adb.getprop(serial, 'ro.config.agps_server')).trim() ||
               (await adb.getprop(serial, 'persist.config.agps_url')).trim();
  if (agps) rows.push(['A-GPS server', agps, 'INFO']);

  return rows;
}

// ── Stmívání / jas ────────────────────────────────────────────────────
async function diagBrightness(serial) {
  const rows = [];
  const autoBright = (await adb.shell(serial, 'settings', 'get', 'system', 'screen_brightness_mode')).trim();
  rows.push(['Auto-brightness', autoBright === '1' ? 'Zapnuto' : 'Vypnuto', autoBright === '1' ? 'OK' : 'INFO']);

  const bright = (await adb.shell(serial, 'settings', 'get', 'system', 'screen_brightness')).trim();
  if (bright && !isNaN(parseInt(bright, 10))) {
    const pct = Math.round(parseInt(bright, 10) / 255 * 100);
    rows.push(['Aktuální jas', `${pct} % (${bright}/255)`, 'INFO']);
  }

  // světelný senzor - hodnota
  const sensorDump = await adb.shell(serial, 'dumpsys', 'sensorservice');
  for (const line of (sensorDump || '').split('\n')) {
    if (/light/i.test(line) && /lux|value/i.test(line)) {
      const m = line.match(/([\d.]+)\s*(lux)?/i);
      if (m) { rows.push(['Světelný senzor', `${m[1]} lux`, 'INFO']); break; }
    }
  }

  // timeout obrazovky
  const timeout = (await adb.shell(serial, 'settings', 'get', 'system', 'screen_off_timeout')).trim();
  if (timeout && !isNaN(parseInt(timeout, 10))) {
    rows.push(['Timeout displeje', `${Math.round(parseInt(timeout, 10) / 1000)} s`, 'INFO']);
  }

  // adaptivní jas Samsung
  const adapSamsung = (await adb.getprop(serial, 'ro.config.auto_brightness')).trim();
  if (adapSamsung) rows.push(['Adaptivní jas (prop)', adapSamsung, 'INFO']);

  return rows;
}

// ══════════════════════════════════════════════════════════════════════
// iOS DIAGNOSTIKA (libimobiledevice) – jen co lze opravdu vyčíst
// ══════════════════════════════════════════════════════════════════════
function parsePlistNumbers(text) {
  // idevicediagnostics ioregentry vrací XML plist; vytáhneme <key>..</key><integer>..
  const d = {};
  const re = /<key>([^<]+)<\/key>\s*<(integer|real|string|true|false)\s*\/?>(?:([^<]*)<\/\2>)?/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const k = m[1].trim();
    if (m[2] === 'true' || m[2] === 'false') d[k] = (m[2] === 'true');
    else d[k] = m[3] != null ? m[3].trim() : '';
  }
  return d;
}

async function diagBatteryIos(udid) {
  const rows = [];
  const xml = await ios.diagnostics(udid, 'IOPMPowerSource') ||
              await ios.diagnostics(udid, 'AppleSmartBattery');
  if (xml && xml.includes('<key>')) {
    const d = parsePlistNumbers(xml);
    const cur = parseInt(d['CurrentCapacity'], 10);
    if (!isNaN(cur)) rows.push(['Nabití', `${cur} %`, cur >= 20 ? 'OK' : 'WARN']);
    const max = parseInt(d['AppleRawMaxCapacity'] || d['MaxCapacity'], 10);
    const des = parseInt(d['DesignCapacity'], 10);
    if (!isNaN(max) && !isNaN(des) && des > 0) {
      const h = max * 100 / des;
      rows.push(['Zdraví baterie', `${h.toFixed(1)} %  (${max}/${des} mAh)`, h >= 85 ? 'OK' : h >= 75 ? 'WARN' : 'FAIL']);
    }
    const cyc = parseInt(d['CycleCount'], 10);
    if (!isNaN(cyc)) rows.push(['Cykly nabití', String(cyc), cyc < 400 ? 'OK' : cyc < 800 ? 'WARN' : 'FAIL']);
    const temp = parseInt(d['Temperature'], 10);
    if (!isNaN(temp)) { const t = temp / 100; rows.push(['Teplota', `${t.toFixed(1)} °C`, t < 40 ? 'OK' : 'WARN']); }
    const charging = d['IsCharging'];
    if (charging != null) rows.push(['Nabíjí se', charging ? 'Ano' : 'Ne', 'INFO']);
  }
  if (!rows.length) {
    rows.push(['Baterie (iOS)', 'Novější iOS blokuje čtení baterie přes USB – nutno ověřit ručně v Nastavení → Baterie', 'INFO']);
  }
  return rows;
}

async function diagStorageIos(udid) {
  const rows = [];
  const d = await ios.infoAll(udid, 'com.apple.disk_usage');
  const total = parseInt(d['TotalDiskCapacity'], 10);
  const avail = parseInt(d['TotalDataAvailable'], 10);
  if (!isNaN(total)) {
    let txt = `${(total / 1e9).toFixed(1)} GB celkem`;
    if (!isNaN(avail)) txt += ` · ${(avail / 1e9).toFixed(1)} GB volně`;
    rows.push(['Úložiště', txt, 'INFO']);
  }
  if (!rows.length) rows.push(['Úložiště (iOS)', 'Nepodařilo se vyčíst', 'WARN']);
  return rows;
}

async function diagSystemIos(udid) {
  const rows = [];
  const actState = await ios.info(udid, 'ActivationState');
  if (actState) rows.push(['Aktivace', actState, /Activated/i.test(actState) ? 'OK' : 'WARN']);
  const passcode = await ios.info(udid, 'PasswordProtected');
  if (passcode) rows.push(['Kódový zámek', passcode === 'true' ? 'Zapnut' : 'Vypnut', 'INFO']);

  // Find My / aktivační zámek (klíč nemusí být dostupný)
  const fmip = await ios.info(udid, 'FindMyiPhone', 'com.apple.fmip') ||
               await ios.info(udid, 'IsAssociatedWithAppleAccount', 'com.apple.fmip');
  if (fmip) rows.push(['Find My / aktivační zámek', fmip === 'true' ? 'AKTIVNÍ (nutno odhlásit Apple ID!)' : 'Vypnuto', fmip === 'true' ? 'FAIL' : 'OK']);

  // WiFi/BT MAC
  const wifiMac = await ios.info(udid, 'WiFiAddress');
  if (wifiMac) rows.push(['Wi-Fi MAC', wifiMac, 'INFO']);
  const btMac = await ios.info(udid, 'BluetoothAddress');
  if (btMac) rows.push(['Bluetooth MAC', btMac, 'INFO']);
  return rows;
}

// ══════════════════════════════════════════════════════════════════════
// KATEGORIE – klasifikace: 'functional' = opravdu měří/ověří funkci.
//   Pouze functional kategorie běží automaticky a dávají Pass/Fail/Info.
//   Přítomnostní věci (senzory, kamery, BT…) → ruční testy (viz detect()).
// ══════════════════════════════════════════════════════════════════════
const ANDROID_AUTO = [
  ['🔋 Baterie',            diagBattery],
  ['🔌 Nabíjení (USB)',     diagCharging],
  ['🖥 Displej',            diagDisplay],
  ['🔆 Jas / stmívání',     diagBrightness],
  ['💾 Paměť (RAM)',        diagMemory],
  ['💿 Úložiště / MMC / SD', diagStorage],
  ['⚙ Procesor',           diagCpu],
  ['🔐 Bezpečnost',         diagSecurity],
  ['📶 Síť / WiFi',         diagNetwork],
  ['📡 SIM karta',          diagSim],
  ['🛰 GPS',                diagGps],
];

const IOS_AUTO = [
  ['🔋 Baterie',     diagBatteryIos],
  ['💿 Úložiště',    diagStorageIos],
  ['🍏 Systém / zámky', diagSystemIos],
];

function autoCategoriesFor(platform) {
  return platform === 'ios' ? IOS_AUTO : ANDROID_AUTO;
}
// jen názvy (pro skip panel v rendereru)
function autoNamesFor(platform) {
  return autoCategoriesFor(platform).map(c => c[0]);
}

// ── DETEKCE pro sestavení RUČNÍCH testů (kamery, senzory, BT, NFC…) ────
// Nevrací Pass/Fail – jen co existuje, aby technik mohl funkci ověřit ručně.
async function detectManual(id, platform) {
  if (platform === 'ios') {
    const productType = await ios.info(id, 'ProductType');
    const map = iphoneModels.lookup(productType);
    const cameras = map.cameras.map((label, i) => ({ id: String(i), label, facing: /předn/i.test(label) ? 'front' : 'back' }));
    return {
      cameras,
      sensors: ['Akcelerometr', 'Gyroskop', 'Kompas', 'Proximity', 'Světelný senzor', 'Barometr'],
      bluetooth: true, nfc: /iPhone1[1-9]|iPhone[2-9]/.test(productType) || true, hasFlash: true,
    };
  }
  // Android
  let cameras = [];
  try { cameras = await enumerateCamerasAndroid(id); } catch (_) {}
  const feats = (await adb.shell(id, 'pm', 'list', 'features') || '');
  const has = f => feats.includes(f);
  const camFeat = await cameraFeaturesAndroid(id).catch(() => ({ flash: false }));
  const sensorList = [
    ['android.hardware.sensor.accelerometer', 'Akcelerometr'],
    ['android.hardware.sensor.gyroscope', 'Gyroskop'],
    ['android.hardware.sensor.compass', 'Kompas (magnetometr)'],
    ['android.hardware.sensor.proximity', 'Proximity (přiblížení)'],
    ['android.hardware.sensor.light', 'Světelný senzor'],
    ['android.hardware.sensor.barometer', 'Barometr'],
    ['android.hardware.sensor.stepcounter', 'Krokoměr'],
    ['android.hardware.fingerprint', 'Čtečka otisků'],
  ].filter(([f]) => has(f)).map(([, name]) => name);
  return {
    cameras,
    sensors: sensorList,
    bluetooth: has('android.hardware.bluetooth'),
    nfc: has('android.hardware.nfc'),
    hasFlash: camFeat.flash,
  };
}

// ── spuštění funkčních AUTO testů ─────────────────────────────────────
async function runAuto({ id, serial, platform, onProgress, onResult, shouldAbort, skip = [] }) {
  platform = platform || 'android';
  const devId = id || serial;
  const result = {};
  const skipSet = new Set(skip);
  const cats = autoCategoriesFor(platform);
  const total = cats.length;
  for (let i = 0; i < total; i++) {
    if (shouldAbort && shouldAbort()) { result.__aborted = true; break; }
    const [name, fn] = cats[i];
    if (onProgress) onProgress(i + 1, total, name);
    if (skipSet.has(name)) {
      result[name] = [['Přeskočeno', 'Uživatel přeskočil', 'SKIP']];
      if (onResult) onResult(name, result[name]);
      continue;
    }
    try {
      const rows = await fn(devId);
      result[name] = rows;
      if (onResult) onResult(name, rows);
    } catch (e) {
      result[name] = [['Chyba', String(e).slice(0, 80), 'FAIL']];
      if (onResult) onResult(name, result[name]);
    }
  }
  return result;
}

module.exports = {
  runAuto, detectManual, autoCategoriesFor, autoNamesFor,
  enumerateCamerasAndroid,
  diagBattery, diagCharging,
};
