'use strict';
// ── Report: HTML → PDF / tisk / uložení do zakázky ───────────────────
const { BrowserWindow } = require('electron');
const fs = require('fs');
const path = require('path');

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

const STATUS_LABEL = { OK: 'Pass', WARN: 'Varování', FAIL: 'Fail', INFO: 'Info', SKIP: 'Skip' };
const STATUS_COLOR = { OK: '#1f9e63', WARN: '#c98a14', FAIL: '#cc3b3b', INFO: '#3a7fbf', SKIP: '#888' };
const STATUS_ICON  = { OK: '✓', WARN: '⚠', FAIL: '✗', INFO: 'ℹ', SKIP: '—' };

// payload = { info, phase, categories, interactive:[{name,status,note}], summary }
function buildReportHtml(p) {
  const info = p.info || {};
  const now = new Date().toLocaleString('cs-CZ');
  const s = p.summary || {};

  // ── souhrn chips ──
  const chips = [
    ['Celkem', s.total || 0, '#444'],
    ['Pass',   s.ok   || 0, STATUS_COLOR.OK],
    ['Warn',   s.warn || 0, STATUS_COLOR.WARN],
    ['Fail',   s.fail || 0, STATUS_COLOR.FAIL],
    ['Skip',   s.skip || 0, STATUS_COLOR.SKIP],
  ].map(([l, v, c]) => `<span class="chip" style="border-color:${c};color:${c}"><b>${v}</b> ${esc(l)}</span>`).join(' ');

  // ── ruční testy – tabulka ──
  let manualTable = '';
  if (p.interactive && p.interactive.length) {
    const ok   = p.interactive.filter(r => r.status === 'OK').length;
    const fail = p.interactive.filter(r => r.status === 'FAIL').length;
    const skip = p.interactive.filter(r => r.status === 'SKIP').length;
    manualTable = `
      <h2>🖐 Ruční testy
        <span style="font-size:11px;font-weight:400;margin-left:10px">
          <span style="color:${STATUS_COLOR.OK}">✓ ${ok} Pass</span> &nbsp;
          <span style="color:${STATUS_COLOR.FAIL}">✗ ${fail} Fail</span> &nbsp;
          <span style="color:${STATUS_COLOR.SKIP}">— ${skip} Skip</span>
        </span>
      </h2>
      <table>
        <thead><tr><th>Test</th><th>Poznámka</th><th style="width:80px;text-align:center">Výsledek</th></tr></thead>
        <tbody>`;
    for (const it of p.interactive) {
      const c = STATUS_COLOR[it.status] || '#444';
      manualTable += `<tr>
        <td>${esc(it.name)}</td>
        <td style="color:#666;font-size:11px">${esc(it.note || '')}</td>
        <td style="text-align:center;color:${c};font-weight:700">${STATUS_ICON[it.status] || ''} ${STATUS_LABEL[it.status] || it.status}</td>
      </tr>`;
    }
    manualTable += `</tbody></table>`;
  }

  // ── automatické kategorie ──
  let autoCats = '';
  for (const [cat, items] of Object.entries(p.categories || {})) {
    if (cat.startsWith('__')) continue;
    autoCats += `<h2>${esc(cat)}</h2><table><tbody>`;
    for (const [item, val, st] of items) {
      const c = STATUS_COLOR[st] || '#444';
      autoCats += `<tr>
        <td>${esc(item)}</td><td>${esc(val)}</td>
        <td style="text-align:right;color:${c};font-weight:700;width:90px">${STATUS_ICON[st] || ''} ${STATUS_LABEL[st] || st}</td>
      </tr>`;
    }
    autoCats += `</tbody></table>`;
  }

  // ── výsledky z telefonu (UniDia Test APK) ──
  let apkTable = '';
  if (p.apk && p.apk.tests && p.apk.tests.length) {
    const cmap = { pass: ['#1f9e63', 'PASS'], fail: ['#d23', 'FAIL'], skip: ['#888', 'SKIP'], info: ['#0a84c4', 'INFO'] };
    const ok = p.apk.tests.filter(t => t.status === 'pass').length;
    const fail = p.apk.tests.filter(t => t.status === 'fail').length;
    const skip = p.apk.tests.filter(t => t.status === 'skip').length;
    apkTable = `<h2>📱 Testy z telefonu (UniDia Test)
      <span style="font-size:11px;font-weight:400;margin-left:10px">
        <span style="color:#1f9e63">✓ ${ok} Pass</span> &nbsp;
        <span style="color:#d23">✗ ${fail} Fail</span> &nbsp;
        <span style="color:#888">— ${skip} Skip</span></span></h2>
      <table><thead><tr><th>Test</th><th>Detail</th><th style="width:80px;text-align:center">Výsledek</th></tr></thead><tbody>`;
    for (const t of p.apk.tests) {
      const m = cmap[t.status] || ['#444', String(t.status || '').toUpperCase()];
      apkTable += `<tr><td>${esc(t.name || t.id)}</td><td style="color:#666;font-size:11px">${esc(t.details || '')}</td><td style="text-align:center;color:${m[0]};font-weight:700">${esc(m[1])}</td></tr>`;
    }
    apkTable += `</tbody></table>`;
  }

  return `<!DOCTYPE html><html lang="cs"><head><meta charset="utf-8">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, "Segoe UI", sans-serif; color: #1a1a1a; margin: 22px 28px; font-size: 12px; }
  h1 { font-size: 19px; margin-bottom: 2px; }
  h2 { font-size: 12.5px; margin: 14px 0 4px; color: #1f9e63; border-bottom: 1px solid #ddd; padding-bottom: 3px; }
  .sub { color: #666; font-size: 11px; margin-bottom: 8px; }
  .meta { display: flex; flex-wrap: wrap; gap: 4px 20px; margin: 8px 0 10px; font-size: 11px; }
  .meta div b { color: #333; }
  .chips { margin: 8px 0 12px; }
  .chip { display: inline-block; border: 1.5px solid; border-radius: 18px; padding: 2px 9px; margin-right: 5px; font-size: 11px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 4px; }
  th { text-align: left; padding: 4px 6px; font-size: 10.5px; text-transform: uppercase; color: #888; border-bottom: 1.5px solid #ddd; }
  td { padding: 4px 6px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
  td:first-child { width: 42%; color: #333; }
  .logo { color: #1f9e63; }
  @media print { body { margin: 12px 18px; } }
</style></head><body>
  <h1><span class="logo">◈</span> Uni<b>Dia</b> – protokol testu</h1>
  <div class="sub">Vytištěno: ${esc(now)}${p.phase ? ' &nbsp;·&nbsp; Fáze: <b>' + esc(p.phase) + '</b>' : ''}</div>
  <div class="meta">
    <div><b>Model:</b> ${esc(info.model)}</div>
    <div><b>Značka:</b> ${esc(info.brand)}</div>
    <div><b>IMEI:</b> ${esc(info.imei)}</div>
    <div><b>S/N:</b> ${esc(info.sn)}</div>
    <div><b>${esc(info.lbl_ap || 'AP SW')}:</b> ${esc(info.ap)}</div>
    <div><b>Android:</b> ${esc(info.android)}</div>
    <div><b>${esc(info.lbl_oneui || 'One UI')}:</b> ${esc(info.oneui)}</div>
    <div><b>CSC:</b> ${esc(info.csc)}</div>
  </div>
  <div class="chips">${chips}</div>
  ${manualTable}
  ${autoCats}
  ${apkTable}
</body></html>`;
}

async function renderHidden(html) {
  const win = new BrowserWindow({ show: false, webPreferences: { offscreen: false } });
  await win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  return win;
}

async function exportPdf(payload, outPath) {
  const win = await renderHidden(buildReportHtml(payload));
  try {
    const data = await win.webContents.printToPDF({
      printBackground: true, pageSize: 'A4',
      margins: { marginType: 'default' },
    });
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, data);
    return { ok: true, path: outPath };
  } catch (e) {
    return { ok: false, error: String(e) };
  } finally {
    win.destroy();
  }
}

async function printReport(payload) {
  const win = await renderHidden(buildReportHtml(payload));
  return new Promise(resolve => {
    win.webContents.print({ silent: false, printBackground: true }, (success, reason) => {
      win.destroy();
      resolve({ ok: success, reason });
    });
  });
}

async function saveToZakazka(payload, jobNumber, uploadScanPath) {
  const job = String(jobNumber || '').trim().replace(/[^0-9A-Za-z]/g, '');
  if (!job) return { ok: false, error: 'Prázdné číslo zakázky.' };
  const fileName = `VT_${job}A.pdf`;
  const outPath = path.join(uploadScanPath, fileName);
  const res = await exportPdf(payload, outPath);
  if (res.ok) res.fileName = fileName;
  return res;
}

module.exports = { buildReportHtml, exportPdf, printReport, saveToZakazka };
