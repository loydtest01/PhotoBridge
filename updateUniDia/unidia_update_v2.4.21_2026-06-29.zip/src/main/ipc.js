'use strict';
const { ipcMain, app, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const updater = require('./updater');

// průměrný jas tapety → rozhodne, jestli použít tmavé písmo (světlá tapeta)
function wallpaperIsLight(fp) {
  try {
    const img = nativeImage.createFromPath(fp);
    if (img.isEmpty()) return false;
    const small = img.resize({ width: 32, height: 32 });
    const buf = small.toBitmap(); // BGRA
    let sum = 0, n = 0;
    for (let i = 0; i + 3 < buf.length; i += 4) {
      const b = buf[i], g = buf[i + 1], r = buf[i + 2];
      sum += 0.299 * r + 0.587 * g + 0.114 * b;
      n++;
    }
    return n ? (sum / n) > 150 : false;
  } catch (_) { return false; }
}

const adb = require('./adb');
const ios = require('./ios');
const iosSetup = require('./iosSetup');
const devices = require('./devices');
const deviceInfo = require('./deviceInfo');
const diag = require('./diagnostics');
const excel = require('./excel');
const report = require('./report');
const settings = require('./settings');
const usbid = require('./usbid');

let mainWin = null;
let ctx = { notify: () => {}, dataDir: s => s };
function setMainWindow(w) { mainWin = w; }

function send(channel, payload) {
  if (mainWin && !mainWin.isDestroyed()) mainWin.webContents.send(channel, payload);
}

let test = null;

function summarize(categories, interactive) {
  let total = 0, ok = 0, warn = 0, fail = 0, skip = 0;
  const bump = st => { total++; if (st === 'OK') ok++; else if (st === 'WARN') warn++; else if (st === 'FAIL') fail++; else if (st === 'SKIP') skip++; };
  for (const [k, rows] of Object.entries(categories || {})) {
    if (k.startsWith('__')) continue;
    for (const r of rows) bump(r[2]);
  }
  for (const it of (interactive || [])) bump(it.status);
  return { total, ok, warn, fail, skip };
}

function registerIpc(context) {
  ctx = Object.assign(ctx, context || {});

  // ── sjednocený seznam zařízení (Android + iOS) ──
  ipcMain.handle('devices:list', async () => {
    const list = await devices.list();
    return { list, iosAvailable: ios.isAvailable() };
  });

  // ── načtení (ruční / re-read) ──
  ipcMain.handle('device:read', async (_e, arg) => {
    let id, platform;
    if (typeof arg === 'string') { id = arg; platform = 'android'; }
    else { id = arg && arg.id; platform = (arg && arg.platform) || 'android'; }
    if (!id) {
      const r = await devices.ready();
      if (!r.length) return { ok: false, error: 'Žádné připojené zařízení.' };
      id = r[0].id; platform = r[0].platform;
    }
    try { return { ok: true, info: await deviceInfo.readDevice(id, platform) }; }
    catch (e) { return { ok: false, error: String(e) }; }
  });

  ipcMain.handle('record:save', async (_e, { info, phase }) => {
    try {
      const fp = await excel.saveRecord(info, phase);
      ctx.notify('Záznam uložen', `${phase} · ${info.model || ''} · ${info.imei || ''}`);
      return { ok: true, path: fp };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  ipcMain.handle('search', async (_e, query) => {
    try { return { ok: true, results: await excel.searchAll(query) }; }
    catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── názvy auto-kategorií dle platformy (pro skip panel) ──
  ipcMain.handle('diag:autoNames', async (_e, platform) => diag.autoNamesFor(platform || 'android'));

  // ── DETEKCE pro ruční testy (kamery, senzory, BT, NFC) ──
  ipcMain.handle('diag:detect', async (_e, { id, platform }) => {
    try { return { ok: true, detect: await diag.detectManual(id, platform || 'android') }; }
    catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── funkční AUTO testy ──
  ipcMain.handle('diag:auto', async (_e, opts) => {
    opts = opts || {};
    const platform = opts.platform || 'android';
    const id = opts.id || opts.serial;
    test = { abort: false };

    const categories = await diag.runAuto({
      id, platform,
      skip: opts.skip || [],
      onProgress: (i, total, name) => send('diag:progress', { i, total, name }),
      onResult: (name, rows) => send('diag:result', { name, rows }),
      shouldAbort: () => test.abort,
    });

    if (test.abort) categories.__aborted = true;
    const summary = summarize(categories, opts.interactive || []);

    // volitelné vypnutí vývojářského režimu po testu (pouze Android)
    const st = settings.load();
    if (platform === 'android' && st.disableDevModeAfterTest && !test.abort) {
      try {
        await adb.shell(id, 'settings', 'put', 'global', 'development_settings_enabled', '0');
        await adb.shell(id, 'settings', 'put', 'global', 'adb_enabled', '0');
      } catch (_) {}
    }
    test = null;
    return { ok: true, categories, summary };
  });

  ipcMain.handle('diag:cancel', async () => { if (test) test.abort = true; return { ok: true }; });

  // spustit akci na telefonu pro ruční test
  ipcMain.handle('diag:trigger', async (_e, { id, serial, platform, action }) => {
    const dev = id || serial;
    if (platform === 'ios') {
      // iOS neumožní vzdálené spuštění kamery/repro – jen informace
      return { ok: false, ios: true, error: 'iOS nepodporuje vzdálené spuštění – proveď test ručně přímo na telefonu.' };
    }
    try {
      if (action === 'camera' || action === 'camera-back')
        await adb.shell(dev, 'am', 'start', '-a', 'android.media.action.STILL_IMAGE_CAMERA');
      else if (action === 'camera-front')
        await adb.shell(dev, 'am', 'start', '-a', 'android.media.action.IMAGE_CAPTURE', '--ei', 'android.intent.extras.CAMERA_FACING', '1');
      else if (action === 'flashlight')
        await adb.shell(dev, 'cmd', 'flashlight', 'set', '1').catch(() => {});
      else if (action === 'vibrate')
        await adb.shell(dev, 'cmd', 'vibrator', 'vibrate', '800');
      else if (action === 'dialer')
        await adb.shell(dev, 'am', 'start', '-a', 'android.intent.action.DIAL');
      else if (action === 'sound')
        await adb.shell(dev, 'media', 'volume', '--show', '--stream', '3', '--set', '15').catch(() => {});
      else if (action === 'settings-display')
        await adb.shell(dev, 'am', 'start', '-a', 'android.settings.DISPLAY_SETTINGS');
      else if (action === 'screen-bright')
        await adb.shell(dev, 'settings', 'put', 'system', 'screen_brightness', '255');
      else if (action === 'screen-dim')
        await adb.shell(dev, 'settings', 'put', 'system', 'screen_brightness', '1');
      else if (action === 'screen-restore')
        await adb.shell(dev, 'settings', 'put', 'system', 'screen_brightness_mode', '1');
      return { ok: true };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── REPORT ──
  ipcMain.handle('report:pdf', async (_e, payload) => {
    const { dialog } = require('electron');
    const def = `Diagnostika_${(payload.info && payload.info.imei) || 'telefon'}.pdf`;
    const res = await dialog.showSaveDialog(mainWin, { defaultPath: def, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (res.canceled || !res.filePath) return { ok: false, canceled: true };
    return report.exportPdf(payload, res.filePath);
  });
  ipcMain.handle('report:print', async (_e, payload) => report.printReport(payload));
  ipcMain.handle('report:zakazka', async (_e, { payload, job }) => {
    const st = settings.load();
    const r = await report.saveToZakazka(payload, job, st.uploadScanPath);
    if (r.ok) ctx.notify('Uloženo do zakázky', r.fileName);
    return r;
  });

  // ── NASTAVENÍ ──
  ipcMain.handle('settings:get', async () => settings.load());
  ipcMain.handle('settings:set', async (_e, patch) => {
    const next = settings.save(patch);
    if ('startupWindows' in (patch || {})) {
      try { app.setLoginItemSettings({ openAtLogin: !!next.startupWindows }); } catch (_) {}
    }
    return next;
  });

  // ── TAPETY ──
  const tapetyDirs = () => {
    const dirs = [ctx.dataDir('tapety')];
    if (process.resourcesPath) dirs.push(path.join(process.resourcesPath, 'tapety'));
    return dirs;
  };
  ipcMain.handle('tapety:list', async () => {
    const seen = new Set();
    const out = [];
    for (const dir of tapetyDirs()) {
      try {
        for (const f of fs.readdirSync(dir)) {
          if (/\.(png|jpe?g|webp)$/i.test(f) && !seen.has(f)) { seen.add(f); out.push(f); }
        }
      } catch (_) {}
    }
    return out;
  });
  ipcMain.handle('tapety:url', async (_e, name) => {
    if (!name) return { url: '', light: false };
    let fp = '';
    for (const dir of tapetyDirs()) { const p = path.join(dir, name); if (fs.existsSync(p)) { fp = p; break; } }
    if (!fp) return { url: '', light: false };
    let url;
    try { url = require('url').pathToFileURL(fp).href; }
    catch (_) { url = 'file:///' + fp.replace(/\\/g, '/'); }
    return { url, light: wallpaperIsLight(fp) };
  });

  ipcMain.handle('app:hide', async () => { if (mainWin) mainWin.hide(); return true; });

  // ── restart do režimu (download/Odin, recovery, bootloader, normální) ──
  ipcMain.handle('device:reboot', async (_e, { id, platform, mode }) => {
    if (platform === 'ios') return { ok: false, error: 'Restart do download/recovery je jen pro Android.' };
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    try {
      const ok = await adb.reboot(id, mode || '');
      const názvy = { '': 'normální restart', download: 'download (Odin)', recovery: 'recovery', bootloader: 'bootloader' };
      return ok ? { ok: true, mode: názvy[mode] || mode } : { ok: false, error: 'Příkaz selhal (je USB ladění autorizováno?).' };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── připojení telefonu k Wi-Fi (pošle SSID/heslo do telefonu) ──
  ipcMain.handle('wifi:push', async (_e, { id, ssid, pass }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    if (!ssid) return { ok: false, error: 'Zadej název Wi-Fi (SSID).' };
    try {
      const out = await adb.wifiConnect(id, ssid, pass || '');
      const failed = /not supported|unknown command|error|usage/i.test(out);
      return failed
        ? { ok: false, error: 'Telefon tento příkaz nepodporuje (starší Android). Výstup: ' + out.slice(0, 120) }
        : { ok: true, out };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── testovací APK: spuštění + stažení výsledků ──
  const TEST_PKG = 'cz.britex.unidiatest';
  ipcMain.handle('test:launch', async (_e, { id }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    try { return await adb.launchApp(id, TEST_PKG + '/.MainActivity'); }
    catch (e) { return { ok: false, error: String(e) }; }
  });
  ipcMain.handle('test:pull', async (_e, { id }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    try {
      const json = await adb.pullTestJson(id, TEST_PKG);
      if (!json) return { ok: false, error: 'Výsledky nenalezeny. Spustil technik test a dal „Uložit výsledky"?' };
      let parsed; try { parsed = JSON.parse(json); } catch (_) { return { ok: false, error: 'Výsledky se nepodařilo přečíst.' }; }
      return { ok: true, data: parsed };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── identita přes USB (bez vývojáře) – S/N z USB deskriptoru ──
  ipcMain.handle('usb:ids', async () => {
    try { return await usbid.readUsbIds(); }
    catch (e) { return { ok: false, error: String(e), items: [] }; }
  });
  ipcMain.handle('usb:samsungModes', async () => {
    try { return await usbid.readSamsungModeSerials(); }
    catch (e) { return { ok: false, error: String(e), devices: [] }; }
  });

  // ── dokončit zaseknuté úvodní nastavení (mrtvý aktivační server) ──
  // POJISTKA: pokud je přihlášený účet (Google), odmítne – není to FRP bypass.
  ipcMain.handle('device:finishSetup', async (_e, { id, platform }) => {
    if (platform === 'ios') return { ok: false, error: 'Jen pro Android.' };
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    if (!settings.load().advancedActions) {
      return { ok: false, error: 'Pokročilé servisní akce jsou vypnuté (Nastavení).' };
    }
    try {
      const acc = (await adb.shell(id, 'dumpsys', 'account')) || '';
      if (/type=com\.google/i.test(acc)) {
        return { ok: false, blocked: true, error: 'Telefon má přihlášený Google účet. Tohle NENÍ nástroj na obejití FRP – účet musí odebrat majitel. Akce zrušena.' };
      }
      // ověřit, že ADB vůbec reaguje
      const probe = (await adb.shell(id, 'echo', 'ok')) || '';
      if (!probe.includes('ok')) return { ok: false, error: 'Telefon nereaguje na ADB (je USB ladění zapnuté a autorizované?).' };

      await adb.shell(id, 'settings', 'put', 'global', 'device_provisioned', '1');
      await adb.shell(id, 'settings', 'put', 'secure', 'user_setup_complete', '1');
      // pokus ukončit průvodce a přejít na plochu
      await adb.shell(id, 'am', 'start', '-a', 'android.intent.action.MAIN', '-c', 'android.intent.category.HOME').catch(() => {});

      const check = (await adb.shell(id, 'settings', 'get', 'global', 'device_provisioned') || '').trim();
      return check === '1'
        ? { ok: true }
        : { ok: false, error: 'Nepodařilo se nastavit (telefon to nedovolil).' };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── zapomenout Wi-Fi z telefonu (smaže i heslo) ──
  ipcMain.handle('wifi:forget', async (_e, { id, ssid }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    if (!ssid) return { ok: false, error: 'Zadej SSID, které smazat.' };
    try {
      const r = await adb.wifiForget(id, ssid);
      if (r.found === 0) return { ok: false, error: `Síť „${ssid}" není v telefonu uložená.` };
      return { ok: r.removed > 0, removed: r.removed, error: r.removed ? '' : 'Smazání selhalo (starší Android?).' };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── APK: seznam ze složky apk\ + instalace ──
  const apkDirs = () => {
    const dirs = [ctx.dataDir('apk')];
    if (process.resourcesPath) dirs.push(path.join(process.resourcesPath, 'apk'));
    return dirs;
  };
  ipcMain.handle('apk:list', async () => {
    const seen = new Set();
    const out = [];
    for (const dir of apkDirs()) {
      try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
      try {
        for (const f of fs.readdirSync(dir)) {
          if (f.toLowerCase().endsWith('.apk') && !seen.has(f)) { seen.add(f); out.push(f); }
        }
      } catch (_) {}
    }
    return out;
  });
  ipcMain.handle('apk:install', async (_e, { id, file }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    if (!file) return { ok: false, error: 'APK soubor nenalezen.' };
    let fp = '';
    for (const dir of apkDirs()) { const p = path.join(dir, file); if (fs.existsSync(p)) { fp = p; break; } }
    if (!fp) return { ok: false, error: 'APK soubor nenalezen.' };
    try { return await adb.installApk(id, fp); }
    catch (e) { return { ok: false, error: String(e) }; }
  });
  ipcMain.handle('apk:uninstall', async (_e, { id, pkg }) => {
    if (!id) return { ok: false, error: 'Není vybráno zařízení.' };
    const p = pkg || 'cz.britex.unidiatest';
    try {
      const r = await adb.uninstallApk(id, p);
      return r.ok ? { ok: true } : { ok: false, error: 'Odinstalace selhala (' + (r.out || '') + ')' };
    } catch (e) { return { ok: false, error: String(e) }; }
  });

  // ── auto-aktualizace ──
  ipcMain.handle('app:version', () => updater.currentVersion());

  // ── kontrola připravenosti pro Android (ADB) ──
  ipcMain.handle('android:check', async () => {
    const res = { adbFound: false, adbPath: '', serverOk: false, devices: [], notes: [] };
    try {
      const p = adb.adbPath ? adb.adbPath() : '';
      res.adbPath = p || '';
      try { if (p && (p.indexOf('\\') >= 0 || p.indexOf('/') >= 0)) res.adbFound = fs.existsSync(p); } catch (_) {}
      const ver = await adb.adb(['version']);
      const verTxt = (ver.stdout || '') + (ver.stderr || '');
      if (/Android Debug Bridge/i.test(verTxt)) { res.adbFound = true; res.serverOk = true; }
      const dv = await adb.adb(['devices', '-l']);
      const lines = String(dv.stdout || '').split(/\r?\n/).slice(1).map(s => s.trim()).filter(Boolean);
      for (const ln of lines) {
        const m = /^(\S+)\s+(device|unauthorized|offline|no permissions|recovery|sideload|bootloader|host)\b/.exec(ln);
        if (m) res.devices.push({ serial: m[1], state: m[2] });
      }
    } catch (e) { res.notes.push(String(e)); }
    return res;
  });

  // ── kontrola čtení S/N přes USB (co PC vidí) ──
  ipcMain.handle('usb:check', async () => {
    try { return await usbid.readUsbIds(); }
    catch (e) { return { ok: false, error: String(e), items: [], seen: [] }; }
  });

  // ── doplnění chybějících součástí (ADB / iOS / APK) ze sdíleného disku/GitHubu ──
  ipcMain.handle('tools:fetch', async (_e, { kind }) => {
    try {
      const tools = require('./tools');
      return await tools.fetchTool(kind, ctx.dataDir, '');
    } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
  });

  // ── kontrola nainstalovaných USB ovladačů (Samsung / Apple / Google) ──
  ipcMain.handle('drivers:check', async () => {
    const res = { samsung: false, apple: false, googleAdb: false, list: [], error: '' };
    try {
      const { execFile } = require('child_process');
      const os = require('os'), fs = require('fs'), path = require('path');
      // PowerShell skript: kontroluje (1) soubory ovladačů, (2) službu Apple,
      // (3) úložiště ovladačů přes pnputil, (4) připojená zařízení. Funguje
      // i bez připojeného telefonu (na to byla minulá kontrola krátká).
      const script = [
        "$ErrorActionPreference='SilentlyContinue'",
        "$r=[ordered]@{samsung=$false;apple=$false;googleAdb=$false;list=@()}",
        "$d=Join-Path $env:SystemRoot 'System32\\drivers'",
        "if((Test-Path (Join-Path $d 'ssudbus.sys')) -or (Test-Path (Join-Path $d 'ssudmdm.sys'))){$r.samsung=$true}",
        "if((Test-Path (Join-Path $d 'usbaapl64.sys')) -or (Test-Path (Join-Path $d 'usbaapl.sys')) -or (Test-Path 'C:\\Program Files\\Common Files\\Apple\\Mobile Device Support') -or (Get-Service -Name 'Apple Mobile Device Service')){$r.apple=$true}",
        "$pnp=(& pnputil.exe /enum-drivers 2>$null) -join \"`n\"",
        "if($pnp -match '(?i)samsung|ssudbus|ssudmdm'){$r.samsung=$true}",
        "if($pnp -match '(?i)apple|usbaapl'){$r.apple=$true}",
        "if($pnp -match '(?i)\\bgoogle\\b|winusb|androidwinusb'){$r.googleAdb=$true}",
        "$dev=Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DriverProviderName -match 'Samsung|Apple|Google' -or $_.DeviceName -match 'Samsung|Apple Mobile|Android ADB|WinUSB' } | Select-Object DeviceName,DriverProviderName",
        "foreach($x in $dev){ $r.list+=@{provider=$x.DriverProviderName;name=$x.DeviceName}; $b=\"$($x.DriverProviderName) $($x.DeviceName)\"; if($b -match '(?i)samsung'){$r.samsung=$true}; if($b -match '(?i)apple'){$r.apple=$true}; if($b -match '(?i)google|winusb'){$r.googleAdb=$true} }",
        "$r | ConvertTo-Json -Compress -Depth 4",
      ].join('\n');
      const ps1 = path.join(os.tmpdir(), 'unidia_drvchk_' + Date.now() + '.ps1');
      fs.writeFileSync(ps1, script, 'utf8');
      const out = await new Promise((resolve) => {
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ps1],
          { timeout: 30000, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
          (err, stdout) => resolve(err ? '' : (stdout || '')));
      });
      try { fs.rmSync(ps1, { force: true }); } catch (_) {}
      if (out.trim()) {
        let data; try { data = JSON.parse(out); } catch (_) { data = null; }
        if (data) {
          res.samsung = !!data.samsung;
          res.apple = !!data.apple;
          res.googleAdb = !!data.googleAdb;
          let lst = data.list || [];
          if (!Array.isArray(lst)) lst = [lst];
          res.list = lst.map(d => ({ provider: (d && d.provider) || '?', name: (d && d.name) || '?' }));
        }
      }
    } catch (e) { res.error = String((e && e.message) || e); }
    return res;
  });

  ipcMain.handle('update:check', async () => {
    try { return await updater.checkForUpdates(''); }
    catch (e) { return { error: String((e && e.message) || e) }; }
  });
  ipcMain.handle('update:apply', async () => {
    try { return await updater.downloadAndApply(''); }
    catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
  });

  // ── výběr složky (Průzkumník) + otevření složek ──
  ipcMain.handle('dialog:pickFolder', async () => {
    const { dialog } = require('electron');
    const res = await dialog.showOpenDialog(mainWin, { properties: ['openDirectory', 'createDirectory'] });
    if (res.canceled || !res.filePaths.length) return { ok: false, canceled: true };
    return { ok: true, path: res.filePaths[0] };
  });

  ipcMain.handle('open:folder', async (_e, which) => {
    const { shell } = require('electron');
    let target;
    if (which === 'tapety') {
      target = ctx.dataDir('tapety');
      try { fs.mkdirSync(target, { recursive: true }); } catch (_) {}
    } else if (which === 'upload') {
      target = (settings.load().uploadScanPath || '').trim();
      if (!target) return { ok: false, error: 'Složka zakázek není nastavena.' };
    } else if (which === 'ios') {
      target = ctx.dataDir('ios');
      try { fs.mkdirSync(target, { recursive: true }); } catch (_) {}
    } else if (which === 'apk') {
      target = ctx.dataDir('apk');
      try { fs.mkdirSync(target, { recursive: true }); } catch (_) {}
    } else return { ok: false, error: 'Neznámá složka.' };
    const err = await shell.openPath(target);
    return err ? { ok: false, error: err } : { ok: true };
  });

  // ── otevřít odkaz v prohlížeči (jen https) ──
  ipcMain.handle('open:url', async (_e, url) => {
    const { shell } = require('electron');
    if (typeof url !== 'string' || !/^https:\/\//i.test(url)) return { ok: false, error: 'neplatný odkaz' };
    await shell.openExternal(url);
    return { ok: true };
  });

  // ── automatické vyhledání + nakopírování nástrojů pro iPhone ──
  ipcMain.handle('ios:autosetup', async () => {
    try {
      const targetDir = ctx.dataDir('ios');
      const report = iosSetup.scanAndInstall(targetDir);
      // znovu inicializuj iOS vrstvu, ať se nové binárky načtou hned
      const appRoot = path.join(__dirname, '..', '..');
      const bases = [ctx.dataDir(''), appRoot, process.resourcesPath || appRoot, path.dirname(process.execPath)];
      ios.initIos(bases);
      report.iosAvailableNow = ios.isAvailable();
      return { ok: true, report };
    } catch (e) { return { ok: false, error: String(e) }; }
  });
}

module.exports = { registerIpc, setMainWindow };
