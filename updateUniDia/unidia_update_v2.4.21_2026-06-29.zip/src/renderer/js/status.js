'use strict';
// ── Záložka Stav / Diagnostika ───────────────────────────────────────
(function () {
  const STATUS_LABEL = { OK: 'Pass', WARN: 'Check', FAIL: 'Fail', INFO: 'Info', SKIP: 'Skip' };
  const STATUS_ICON  = { OK: '✓', WARN: '⚠', FAIL: '✗', INFO: 'ℹ', SKIP: '—' };

  // tolerance / vysvětlivky – kolečko ⓘ po najetí ukáže, co je v normě
  const TIPS = [
    [/rsrp/i, 'Síla 4G/LTE signálu (RSRP). ≥ −90 dBm výborné · −90 až −105 použitelné · pod −105 slabé / na hraně.'],
    [/rssi|síla signálu/i, 'Síla Wi-Fi (RSSI). ≥ −55 výborné · −55 až −70 dobré · −70 až −80 slabé · pod −80 velmi slabé.'],
    [/datová síť|generace/i, 'Generace mobilní sítě: 2G < 3G < 4G/LTE < 5G/NR. Vyšší = rychlejší data. Ukazuje, na čem telefon zrovna jede.'],
    [/zdraví bater/i, 'Kapacita baterie vůči nové. ≥ 85 % OK · 75–85 % zhoršené · pod 75 % doporučena výměna.'],
    [/cykl/i, 'Počet nabíjecích cyklů. pod 400 OK · 400–800 zvýšené · nad 800 vysoké opotřebení.'],
    [/teplota/i, 'Teplota baterie. pod 40 °C OK · 40 °C a víc zvýšená – nech vychladnout.'],
    [/nabíjení|nabíjí/i, 'Stav nabíjení. „Vybíjí se" = telefon zrovna nenabíjí. Pro test nabíjení připoj nabíječku (má hlásit nabíjení a kladný proud).'],
    [/stav sim|sim.*stav/i, 'Stav SIM. READY = SIM načtena · ABSENT = není vložena · jiné = chyba / PIN / PUK.'],
    [/úložiště|mmc|\bsd\b/i, 'Volné místo v úložišti. Pod ~10 % volného může zpomalovat systém.'],
    [/\bram\b|operační pam/i, 'Volná operační paměť (RAM). Velmi nízká vede k zásekům a zavírání aplikací.'],
    [/napětí/i, 'Napětí baterie ≈ 3,7–4,4 V podle nabití. Trvale nízké = opotřebená baterie.'],
    [/roaming/i, 'Roaming „Ano" = telefon je v cizí síti, mimo domácího operátora.'],
    [/nabití/i, 'Aktuální nabití baterie v %. Pod 20 % doporučeno dobít před delším testem.'],
    [/frp/i, 'FRP = ochrana po továrním resetu. „Aktivní" = je přihlášen Google účet, takže po resetu telefon vyžádá ten účet. Toto je jen informace, ne obejití.'],
    [/přihlášené účty|root|warranty|bootloader/i, 'Bezpečnostní stav zařízení. Tripnutý Knox / odemčený bootloader / root mohou ovlivnit záruku a přehrání SW.'],
  ];
  function tipFor(item) { for (const [re, txt] of TIPS) if (re.test(item)) return txt; return null; }
  function infoIc(item) {
    const t = tipFor(item);
    if (!t) return '';
    return `<span class="info-ic" data-tip="${t.replace(/"/g, '&quot;')}">i</span>`;
  }

  let AUTO_CATS = [];          // názvy auto-kategorií (dle platformy)
  let STEPS = [];              // dynamicky sestavené ruční testy
  let manualResults = {};
  let skipSet = new Set();

  // ── pevné ruční testy (mimo kamery/senzory, které se detekují) ──
  function fixedSteps(platform) {
    const ios = platform === 'ios';
    return [
      { id:'screen_white', name:'Displej – bílá obrazovka', instr:'Bílá plocha – žádné skvrny, mrtvé pixely, nerovnoměrné podsvícení (burn-in)?', trig:!ios?'screen-bright':null, trigLabel:'Rozsvítit na maximum' },
      { id:'screen_color', name:'Displej – barevnost', instr:'Barvy přirozené, žádné žluté/zelené fleky ani pruhy?' },
      { id:'screen_dark', name:'Displej – tmavá obrazovka', instr:'Žádné světlé skvrny ani prosvítání podsvícení?', trig:!ios?'screen-dim':null, trigLabel:'Ztmavit displej' },
      { id:'touch', name:'Dotyk / multitouch', instr:'Přejeď celou plochu, zkus 2–4 prsty. Reaguje všude bez výpadků?', trig:!ios?'screen-restore':null, trigLabel:'Obnovit jas' },
      { __after:'cameras' },
      { id:'flash', name:'Blesk / svítilna', instr:'Zapni svítilnu. Svítí naplno bez blikání?', trig:!ios?'flashlight':null, trigLabel:'Zapnout svítilnu' },
      { id:'speaker', name:'Reproduktor (hlasitý)', instr:'Přehraj zvuk naplno. Bez chrastění a zkreslení?', trig:!ios?'sound':null, trigLabel:'Nastavit hlasitost' },
      { id:'earpiece', name:'Sluchátko (u ucha)', instr:'Přilož telefon k uchu jako při hovoru. Slyšíš čistě?' },
      { id:'mic', name:'Mikrofon', instr:'Nahraj krátké audio a přehraj zpět. Slyšíš se zřetelně?' },
      { id:'vibration', name:'Vibrace', instr:'Cítíš vibraci?', trig:!ios?'vibrate':null, trigLabel:'Zavibrovat' },
      { id:'buttons', name:'Fyzická tlačítka', instr:'Hlasitost +/− a zapínací tlačítko – vše reaguje?' },
      { __after:'sensors' },
      { id:'proximity', name:'Proximity senzor', instr:'Při hovoru / přiblížení k uchu obrazovka zhasne?' },
      { id:'fingerprint', name:'Čtečka otisků / obličej', instr:'Zaregistruj a ověř otisk nebo Face ID.' },
      { __after:'wireless' },
      { id:'charger', name:'Konektor nabíjení', instr:'Připoj nabíječku – telefon hlásí nabíjení? Konektor sedí pevně?' },
    ];
  }

  // sestavit STEPS z detekce (kamery, senzory, BT, NFC)
  async function buildSteps() {
    const platform = SD.state.platform;
    const ios = platform === 'ios';
    let detect = { cameras: [], sensors: [], bluetooth: false, nfc: false };
    try {
      const r = await window.api.detect(SD.state.serial, platform);
      if (r && r.ok) detect = r.detect;
    } catch (_) {}

    const camSteps = (detect.cameras || []).map(c => ({
      id: 'cam_' + c.id,
      name: '📷 ' + c.label,
      instr: ios
        ? 'Otevři Fotoaparát a přepni na tento objektiv. Ostrý obraz, bez skvrn a šmouh?'
        : 'Vyfoť/zobraz touto kamerou. Ostré, bez skvrn? U zoomu zkontroluj i přiblížení.',
      trig: ios ? null : (c.facing === 'front' ? 'camera-front' : 'camera-back'),
      trigLabel: c.facing === 'front' ? 'Spustit přední kameru' : 'Spustit fotoaparát',
    }));
    if (!camSteps.length) {
      camSteps.push({ id:'cam_0', name:'📷 Kamera', instr:'Vyzkoušej přední i zadní kameru. Ostré, bez skvrn?', trig: ios?null:'camera-back', trigLabel:'Spustit fotoaparát' });
    }

    const sensorList = detect.sensors && detect.sensors.length ? detect.sensors.join(', ') : 'akcelerometr, gyroskop, kompas';
    const sensorSteps = [{
      id: 'sensors', name: '🧭 Senzory polohy/pohybu',
      instr: `Ověř detekované senzory (${sensorList}) – např. v test menu nebo aplikací. Reagují správně?`,
    }];

    const wireless = [];
    if (detect.bluetooth) wireless.push({ id:'bluetooth', name:'🔵 Bluetooth', instr:'Zapni BT, vyhledej okolní zařízení / spáruj. Funguje?', trig: ios?null:'settings-display', trigLabel:null });
    if (detect.nfc) wireless.push({ id:'nfc', name:'📲 NFC', instr:'Přilož NFC kartu/štítek. Telefon ji načte?' });

    // poskládat podle kotev __after
    const out = [];
    for (const s of fixedSteps(platform)) {
      if (s.__after === 'cameras') { out.push(...camSteps); continue; }
      if (s.__after === 'sensors') { out.push(...sensorSteps); continue; }
      if (s.__after === 'wireless') { out.push(...wireless); continue; }
      out.push(s);
    }
    return out;
  }

  // ── Skip panel ──
  async function buildSkipPanel() {
    AUTO_CATS = await window.api.autoNames(SD.state.platform || 'android');
    const panel = SD.$('skipPanel');
    if (!panel) return;
    panel.innerHTML = '<div style="font-size:12px;color:var(--text-dim);margin-bottom:6px">Přeskočit auto-kategorie:</div>';
    skipSet = new Set();
    for (const cat of AUTO_CATS) {
      const wrap = document.createElement('label');
      wrap.style.cssText = 'display:inline-flex;align-items:center;gap:4px;margin:2px 8px 2px 0;font-size:12px;cursor:pointer;color:var(--text-dim)';
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.value = cat;
      cb.addEventListener('change', e => { if (e.target.checked) skipSet.add(cat); else skipSet.delete(cat); });
      wrap.appendChild(cb); wrap.appendChild(document.createTextNode(cat));
      panel.appendChild(wrap);
    }
  }

  function setRunning(on) {
    SD.state.testRunning = on;
    SD.$('btnQuick').disabled = on;
    SD.$('btnComplete').disabled = on;
    SD.$('btnStop').style.display = on ? '' : 'none';
    SD.$('progWrap').style.display = on ? '' : 'none';
    const sp = SD.$('skipPanel'); if (sp) sp.style.display = on ? 'none' : '';
  }

  function clearResults() {
    SD.$('diagResults').innerHTML = '';
    SD.$('summaryChips').innerHTML = '';
    activeFilter = null;
    SD.$('summaryBar').style.display = 'none';
    SD.$('reportCard').style.display = 'none';
    SD.$('manualSummaryCard').style.display = 'none';
  }

  function updateProgress(i, total, name) {
    const pct = total ? Math.round(i / total * 100) : 0;
    SD.$('progBar').style.width = pct + '%';
    SD.$('progText').textContent = `Otestováno ${i} z ${total} · zbývá ${Math.max(0, total - i)}${name ? ' · ' + name : ''}`;
  }

  function renderCategory(name, rows) {
    const wrap = document.createElement('div');
    wrap.className = 'card diag-cat';
    let html = `<h3>${name}</h3>`;
    for (const [item, val, st] of rows) {
      html += `<div class="diag-row"><span class="di">${item}</span><span class="dv">${val}</span>`
        + `<span class="badge b-${st}">${STATUS_LABEL[st] || st}</span>${infoIc(item)}</div>`;
    }
    wrap.innerHTML = html;
    SD.$('diagResults').appendChild(wrap);
  }

  function renderFullSummary(autoCategories) {
    const card = SD.$('manualSummaryCard');
    const manualRows = STEPS.map(s => manualResults[s.id] || { name: s.name, status: 'SKIP', note: '' });
    let tot = 0, cOK = 0, cFAIL = 0, cWARN = 0, cSKIP = 0;
    const bump = st => { tot++; if (st==='OK') cOK++; else if (st==='FAIL') cFAIL++; else if (st==='WARN') cWARN++; else if (st==='SKIP') cSKIP++; };
    for (const r of manualRows) bump(r.status);
    for (const [k, rows] of Object.entries(autoCategories||{})) {
      if (k.startsWith('__')) continue;
      for (const row of rows) bump(row[2]);
    }

    let html = '';

    if (manualRows.length) {
      html += `<div style="font-size:11px;text-transform:uppercase;color:var(--accent);letter-spacing:.06em;margin:8px 0 4px">🖐 Ruční testy</div>
      <table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:12px">
        <thead><tr style="color:var(--text-dim);font-size:10.5px;text-transform:uppercase;border-bottom:1px solid var(--border)">
          <th style="text-align:left;padding:4px 6px;width:38%">Test</th>
          <th style="text-align:left;padding:4px 6px">Poznámka</th>
          <th style="text-align:center;padding:4px 6px;width:80px">Výsledek</th>
          <th style="padding:4px 6px;width:86px"></th></tr></thead><tbody>`;
      for (const step of STEPS) {
        const r = manualResults[step.id] || { name: step.name, status: 'SKIP', note: '' };
        const st = r.status;
        html += `<tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
          <td style="padding:5px 6px">${step.name}</td>
          <td style="padding:5px 6px;color:var(--text-dim);font-size:11.5px">${r.note || ''}</td>
          <td style="padding:5px 6px;text-align:center"><span class="badge b-${st}">${STATUS_ICON[st]} ${STATUS_LABEL[st]||st}</span></td>
          <td style="padding:5px 6px;text-align:right"><button class="btn ghost" style="font-size:11px;padding:3px 8px" onclick="SD._retestStep('${step.id}')">↺ Znovu</button></td>
        </tr>`;
      }
      html += `</tbody></table>`;
    }

    for (const [cat, rows] of Object.entries(autoCategories||{})) {
      if (cat.startsWith('__')) continue;
      html += `<div style="font-size:11px;text-transform:uppercase;color:var(--accent);letter-spacing:.06em;margin:8px 0 4px">${cat}</div>
      <table style="width:100%;border-collapse:collapse;font-size:12.5px;margin-bottom:10px"><tbody>`;
      for (const [item, val, st] of rows) {
        html += `<tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
          <td style="padding:4px 6px;width:38%;color:var(--text)">${item}</td>
          <td style="padding:4px 6px;color:var(--text-dim)">${val}</td>
          <td style="padding:4px 6px;text-align:center;width:80px"><span class="badge b-${st}">${STATUS_ICON[st]} ${STATUS_LABEL[st]||st}</span></td>
          <td style="width:86px;text-align:left;padding:4px 6px">${infoIc(item)}</td></tr>`;
      }
      html += `</tbody></table>`;
    }
    card.innerHTML = html;
    card.style.display = '';
  }

  function renderManualSummary() {
    renderFullSummary(SD.state.lastResult && SD.state.lastResult.categories || {});
    if (SD.state.lastResult) { renderSummary(SD.state.lastResult.summary); SD.$('summaryBar').style.display = ''; }
  }

  SD._retestStep = (stepId) => {
    const step = STEPS.find(s => s.id === stepId);
    if (step) openSingleStep(step);
  };

  function applyTrigger(step) {
    const tb = SD.$('wizTrigger');
    const note = SD.$('wizIosNote');
    if (note) note.style.display = 'none';
    if (step.trig) {
      tb.style.display = ''; tb.textContent = '📲 ' + (step.trigLabel || 'Spustit');
      tb.onclick = async () => {
        const r = await window.api.diagTrigger(SD.state.serial, SD.state.platform, step.trig);
        if (r && r.ios && note) { note.style.display = ''; note.textContent = r.error; }
      };
    } else {
      tb.style.display = 'none';
      if (SD.state.platform === 'ios' && note) {
        note.style.display = ''; note.textContent = 'iOS nelze ovládat přes USB – proveď tento test ručně přímo na iPhonu.';
      }
    }
  }

  function openSingleStep(step) {
    SD.$('wizCount').textContent = 'Přetestování';
    SD.$('wizBar').style.width = '100%';
    SD.$('wizName').textContent = step.name;
    SD.$('wizInstr').textContent = step.instr;
    SD.$('wizNote').value = manualResults[step.id] ? manualResults[step.id].note : '';
    applyTrigger(step);

    const cleanup = () => {
      SD.$('wizOk').onclick = () => recordStep('OK');
      SD.$('wizFail').onclick = () => recordStep('FAIL');
      SD.$('wizSkip').onclick = () => recordStep('SKIP');
      SD.$('wizSkipAll').onclick = skipAllHandler;
    };
    SD.$('wizOk').onclick = () => { manualResults[step.id] = { name: step.name, status:'OK', note: SD.$('wizNote').value.trim() }; closeWizard(); renderManualSummary(); cleanup(); };
    SD.$('wizFail').onclick = () => { manualResults[step.id] = { name: step.name, status:'FAIL', note: SD.$('wizNote').value.trim() }; closeWizard(); renderManualSummary(); cleanup(); };
    SD.$('wizSkip').onclick = () => { manualResults[step.id] = { name: step.name, status:'SKIP', note: SD.$('wizNote').value.trim() }; closeWizard(); renderManualSummary(); cleanup(); };
    SD.$('wizSkipAll').style.display = 'none';
    SD.$('wizard').classList.add('show');
  }

  // ── průběh auto testu ──
  window.api.onProgress(d => updateProgress(d.i, d.total, d.name));
  window.api.onResult(d => renderCategory(d.name, d.rows));

  async function runAuto(interactive) {
    const r = await window.api.diagAuto({
      id: SD.state.serial, platform: SD.state.platform,
      interactive: interactive || [], skip: [...skipSet],
    });
    if (!r || !r.ok) { SD.toast('Chyba', 'Diagnostika selhala'); return null; }
    if (r.categories.__aborted) SD.toast('Test ukončen', 'Ruční ukončení uživatelem');
    renderFullSummary(r.categories);
    renderSummary(r.summary);
    SD.$('diagResults').innerHTML = '';        // živé karty pryč – zůstane jen souhrnná tabulka
    SD.$('summaryBar').style.display = '';      // ukotvený pruh s filtrem
    SD.state.lastResult = {
      info: SD.state.info || {}, phase: '',
      categories: r.categories, interactive: interactive || [], summary: r.summary,
    };
    SD.$('reportCard').style.display = '';
    return r;
  }

  // přepočítá počty z aktuální souhrnné tabulky (ruční + auto)
  function countFromTable() {
    const c = { total: 0, OK: 0, WARN: 0, FAIL: 0, SKIP: 0, INFO: 0 };
    SD.$('manualSummaryCard').querySelectorAll('.badge').forEach(b => {
      for (const k of ['OK', 'WARN', 'FAIL', 'SKIP', 'INFO']) {
        if (b.classList.contains('b-' + k)) { c[k]++; c.total++; break; }
      }
    });
    return c;
  }

  let activeFilter = null;
  function applyFilter(f) {
    activeFilter = f;
    // zvýraznění aktivního čipu
    SD.$('summaryChips').querySelectorAll('.chip').forEach(c =>
      c.classList.toggle('active', (c.dataset.filter || '') === (f || '')));
    // řádky souhrnné tabulky
    SD.$('manualSummaryCard').querySelectorAll('tbody tr').forEach(tr => {
      const b = tr.querySelector('.badge');
      tr.style.display = (!f || (b && b.classList.contains('b-' + f))) ? '' : 'none';
    });
    // skryj prázdné sekce (nadpis kategorie + tabulka bez viditelných řádků)
    SD.$('manualSummaryCard').querySelectorAll('table').forEach(tbl => {
      const any = [...tbl.querySelectorAll('tbody tr')].some(r => r.style.display !== 'none');
      tbl.style.display = any ? '' : 'none';
      const prev = tbl.previousElementSibling; // nadpis sekce
      if (prev && prev.tagName === 'DIV') prev.style.display = any ? '' : 'none';
    });
  }

  function renderSummary(s) {
    const c = countFromTable();
    const filters = [
      ['Celkem', c.total, 'var(--text)', null],
      ['Pass', c.OK, 'var(--ok)', 'OK'],
      ['Check', c.WARN, 'var(--warn)', 'WARN'],
      ['Fail', c.FAIL, 'var(--fail)', 'FAIL'],
      ['Skip', c.SKIP, 'var(--skip)', 'SKIP'],
    ];
    SD.$('summaryChips').innerHTML = filters.map(([l, v, col, f]) =>
      `<span class="chip${(f || '') === (activeFilter || '') ? ' active' : ''}" style="--cc:${col}" data-filter="${f || ''}"><b>${v || 0}</b> ${l}</span>`).join('');
    SD.$('summaryChips').querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const f = chip.dataset.filter || null;
        // klik na již aktivní (mimo Celkem) → zpět na vše
        applyFilter(activeFilter === f && f ? null : f);
      });
    });
    applyFilter(activeFilter); // zachová zvolený filtr (výchozí = vše)
  }

  // ── Quick test (auto) ──
  SD.$('btnQuick').addEventListener('click', async () => {
    if (!SD.state.serial) { SD.toast('Pozor', 'Nepřipojen žádný telefon.'); return; }
    await buildSkipPanel();
    STEPS = [];
    clearResults(); manualResults = {}; setRunning(true);
    updateProgress(0, AUTO_CATS.length, '');
    await runAuto([]);
    setRunning(false);
    SD.$('progText').textContent += '  ✓ hotovo';
  });

  // ── Kompletní test (ruční + auto) ──
  SD.$('btnComplete').addEventListener('click', async () => {
    if (!SD.state.serial) { SD.toast('Pozor', 'Nepřipojen žádný telefon.'); return; }
    await buildSkipPanel();
    clearResults(); manualResults = {}; setRunning(true);
    SD.$('progText') && (SD.$('progText').textContent = 'Detekuji kamery a hardware…');
    STEPS = await buildSteps();
    startWizard();
  });

  SD.$('btnStop').addEventListener('click', async () => {
    await window.api.diagCancel(); wizardAbort = true; closeWizard();
  });

  // ── Wizard ──
  let wizIdx = 0, wizardAbort = false;
  function startWizard() { wizIdx = 0; wizardAbort = false; SD.$('wizSkipAll').style.display = ''; SD.$('wizard').classList.add('show'); showStep(); }
  function closeWizard() { SD.$('wizard').classList.remove('show'); }

  function showStep() {
    if (wizardAbort) { setRunning(false); return; }
    if (wizIdx >= STEPS.length) { finishWizard(); return; }
    const step = STEPS[wizIdx];
    SD.$('wizCount').textContent = `Krok ${wizIdx + 1} / ${STEPS.length}`;
    SD.$('wizBar').style.width = Math.round(wizIdx / STEPS.length * 100) + '%';
    SD.$('wizName').textContent = step.name;
    SD.$('wizInstr').textContent = step.instr;
    SD.$('wizNote').value = '';
    applyTrigger(step);
  }
  function recordStep(status) {
    const step = STEPS[wizIdx];
    manualResults[step.id] = { name: step.name, status, note: SD.$('wizNote').value.trim() };
    wizIdx++; showStep();
  }
  const skipAllHandler = () => {
    for (let i = wizIdx; i < STEPS.length; i++) { const s = STEPS[i]; if (!manualResults[s.id]) manualResults[s.id] = { name: s.name, status:'SKIP', note:'' }; }
    finishWizard();
  };
  SD.$('wizOk').addEventListener('click', () => recordStep('OK'));
  SD.$('wizFail').addEventListener('click', () => recordStep('FAIL'));
  SD.$('wizSkip').addEventListener('click', () => recordStep('SKIP'));
  SD.$('wizSkipAll').addEventListener('click', skipAllHandler);

  async function finishWizard() {
    closeWizard();
    if (wizardAbort) { setRunning(false); return; }
    const interactive = STEPS.map(s => manualResults[s.id] || { name: s.name, status:'SKIP', note:'' });
    updateProgress(0, AUTO_CATS.length, '');
    await runAuto(interactive);
    setRunning(false);
    SD.$('progText').textContent += '  ✓ hotovo';
  }

  // ── Protokol ──
  function getPayload() {
    if (!SD.state.lastResult) { SD.toast('Pozor', 'Nejdřív spusť test.'); return null; }
    return Object.assign({}, SD.state.lastResult, SD.state.apk ? { apk: SD.state.apk } : {});
  }
  SD.$('btnPdf').addEventListener('click', async () => {
    const p = getPayload(); if (!p) return;
    const r = await window.api.reportPdf(p);
    if (r && r.ok) SD.toast('PDF uloženo', r.path);
    else if (r && !r.canceled) SD.toast('Chyba', r.error || 'PDF selhalo');
  });
  SD.$('btnPrint').addEventListener('click', async () => { const p = getPayload(); if (p) await window.api.reportPrint(p); });
  SD.$('btnZakazka').addEventListener('click', async () => {
    const p = getPayload(); if (!p) return;
    const job = SD.$('jobNum').value.trim();
    if (!job) { SD.toast('Pozor', 'Zadej číslo zakázky.'); return; }
    const r = await window.api.reportZakazka(p, job);
    if (r && r.ok) SD.toast('Uloženo do zakázky', r.fileName);
    else SD.toast('Chyba', (r && r.error) || 'Uložení selhalo');
  });

  setTimeout(() => buildSkipPanel(), 80);
})();
