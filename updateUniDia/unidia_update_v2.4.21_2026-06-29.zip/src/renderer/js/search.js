'use strict';
// ── Záložka Vyhledat ─────────────────────────────────────────────────
(function () {
  async function doSearch() {
    const q = SD.$('searchInput').value.trim();
    if (!q) return;
    const r = await window.api.search(q);
    const results = (r && r.results) || [];
    SD.$('searchCount').textContent = results.length ? `Nalezeno: ${results.length}` : 'Nic nenalezeno.';
    const wrap = SD.$('searchResults');
    wrap.innerHTML = '';
    for (const x of results) {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <b style="font-size:15px">${x.model || '—'}</b>
          <span class="chip" style="border-color:var(--accent);color:var(--accent)">${x.faze || '—'}</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;font-size:12.5px">
          <div><span style="color:var(--text-dim)">IMEI</span><br><b>${x.imei || '—'}</b></div>
          <div><span style="color:var(--text-dim)">S/N</span><br><b>${x.sn || '—'}</b></div>
          <div><span style="color:var(--text-dim)">Datum</span><br>${x.datum || '—'} ${x.cas || ''}</div>
          <div><span style="color:var(--text-dim)">Android</span><br>${x.android || '—'}</div>
          <div><span style="color:var(--text-dim)">One UI</span><br>${x.oneui || '—'}</div>
          <div><span style="color:var(--text-dim)">Soubor</span><br>${x.soubor || '—'}</div>
          <div style="grid-column:1/-1"><span style="color:var(--text-dim)">AP SW</span><br>${x.ap || '—'}</div>
        </div>`;
      wrap.appendChild(card);
    }
  }

  SD.$('btnSearch').addEventListener('click', doSearch);
  SD.$('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
  SD.$('btnClearSearch').addEventListener('click', () => {
    SD.$('searchInput').value = '';
    SD.$('searchResults').innerHTML = '';
    SD.$('searchCount').textContent = '';
  });
})();
