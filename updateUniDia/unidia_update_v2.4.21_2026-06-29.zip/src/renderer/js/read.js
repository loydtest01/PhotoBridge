'use strict';
// ── Záložka Načtení SW ───────────────────────────────────────────────
(function () {
  const SW_KEYS = [['bl', 'BL SW'], ['cp', 'CP SW'], ['csc', 'CSC'],
    ['model', 'Model'], ['android', 'Systém'], ['oneui', 'One UI']];

  function makeBarcode(holderId, value) {
    const holder = SD.$(holderId);
    holder.innerHTML = '';
    if (!value || value === 'N/A' || value === '—') { holder.style.display = 'none'; return; }
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    holder.appendChild(svg);
    try {
      JsBarcode(svg, String(value), { format: 'CODE128', displayValue: false, height: 38, width: 1.6, margin: 2 });
      holder.style.display = 'inline-block';
    } catch (_) { holder.style.display = 'none'; }
  }
  SD.makeBarcode = makeBarcode;

  SD.renderInfo = (info) => {
    SD.state.info = info;
    // diagnostika S/N: vypiš všechny zdroje (kvůli starým kusům, kde se liší)
    if (info.snDebug && typeof info.snDebug === 'object') {
      const parts = Object.keys(info.snDebug)
        .filter(k => info.snDebug[k])
        .map(k => k + '=' + info.snDebug[k]);
      if (parts.length) SD.log('🔎 S/N kandidáti: ' + parts.join(' | '));
    }
    SD.$('apTitle').textContent = info.lbl_ap || 'SW verze';
    SD.$('apVal').textContent = info.ap || 'N/A';
    const bb = SD.$('brandBadge');
    if (info.brand) {
      bb.textContent = info.brand + (info.platform === 'ios' ? ' · iOS' : '');
      bb.style.display = '';
    } else bb.style.display = 'none';

    SD.$('imeiVal').textContent = info.imei || (info.platform === 'ios' ? '— (iPad/bez modemu)' : 'N/A');
    SD.$('snVal').textContent = info.sn || info.serial || 'N/A';
    makeBarcode('imeiBc', info.imei);
    makeBarcode('snBc', info.sn || info.serial);

    const grid = SD.$('swGrid');
    grid.innerHTML = '';
    // adaptivní pole podle připojeného modelu (jen co telefon hlásí)
    const fields = (info.fields && info.fields.length) ? info.fields : [];
    if (!fields.length) {
      // záloha: ze základních polí
      for (const [key, deflt] of SW_KEYS) {
        if (info[key] && info[key] !== 'N/A') fields.push({ label: info['lbl_' + key] || deflt, value: info[key] });
      }
    }
    for (const fl of fields) {
      const card = document.createElement('div');
      card.className = 'card mini copyable';
      card.title = 'klikni pro kopírování';
      card.innerHTML = `<span class="lbl">${fl.label}</span><div class="val"></div>`;
      card.querySelector('.val').textContent = fl.value || 'N/A';
      card.addEventListener('click', () => SD.copy(fl.value));
      grid.appendChild(card);
    }

    // historie podle IMEI nebo S/N
    const key = info.imei && info.imei !== 'N/A' ? info.imei : (info.sn || info.serial);
    window.api.search(key).then(r => {
      const el = SD.$('histVal');
      const prev = (r && r.results) || [];
      if (prev.length) {
        const last = prev.slice(-4).map(x => `  [${x.faze}] ${x.datum} ${x.cas}  AP: ${x.ap}  (${x.soubor})`).join('\n');
        el.className = 'hist';
        el.textContent = `⚠ Evidováno ${prev.length}× (poslední):\n${last}`;
        SD.log(`⚠ evidováno ${prev.length}×`);
      } else {
        el.className = 'hist okhist';
        el.textContent = '✓ Zatím v žádném souboru není.';
      }
    });

    enablePhases(true);
    SD.$('phaseConfirm').textContent = '';
    SD.log(`${info.brand} ${info.model} | ${info.lbl_ap}: ${info.ap}`);
  };

  SD.resetRead = () => {
    SD.state.info = null;
    SD.$('apVal').textContent = '—'; SD.$('apTitle').textContent = 'SW verze';
    SD.$('brandBadge').style.display = 'none';
    SD.$('imeiVal').textContent = '—'; SD.$('snVal').textContent = '—';
    SD.$('imeiBc').style.display = 'none'; SD.$('snBc').style.display = 'none';
    SD.$('swGrid').innerHTML = '';
    SD.$('histVal').textContent = '—'; SD.$('histVal').className = 'hist';
    SD.$('phaseConfirm').textContent = '';
    document.querySelectorAll('.phase').forEach(p => p.classList.remove('sel'));
    enablePhases(false);
  };

  function enablePhases(on) {
    document.querySelectorAll('.phase').forEach(p => p.dataset.disabled = on ? '0' : '1');
  }

  // ruční (re)načtení
  SD.readDevice = async (auto) => {
    const id = SD.state.serial;
    if (!id) { if (!auto) SD.toast('Pozor', 'Není vybráno zařízení.'); return; }
    SD.state.reading = true;
    SD.log(`${auto ? '⚡ Auto' : 'Načítám'} ${id}…`);
    const r = await window.api.readDevice(id, SD.state.platform);
    SD.state.reading = false;
    if (r.ok) SD.renderInfo(r.info);
    else if (!auto) SD.toast('Chyba', r.error || 'Načtení selhalo');
  };

  // klik na fázový puntík → uložení do Excelu (vyčtené ZŮSTANE až do odpojení)
  document.querySelectorAll('.phase').forEach(phase => {
    phase.addEventListener('click', async () => {
      if (phase.dataset.disabled === '1' || !SD.state.info) return;
      const ph = phase.dataset.phase;
      document.querySelectorAll('.phase').forEach(p => p.classList.toggle('sel', p === phase));
      const r = await window.api.saveRecord(SD.state.info, ph);
      if (r.ok) {
        SD.$('phaseConfirm').textContent = `✔ uloženo jako ${ph}`;
        SD.log(`✓ [${ph}] uloženo`);
      } else SD.toast('Chyba', r.error || 'Uložení selhalo');
    });
  });

  // ruční tlačítko Načíst
  const btnRead = SD.$('btnRead');
  if (btnRead) btnRead.addEventListener('click', () => SD.readDevice(false));

  // kopírování kliknutím na CELOU buňku (ne jen text)
  const apCard = SD.$('apCard') || SD.$('apVal').closest('.card');
  const imeiCard = SD.$('imeiCard') || SD.$('imeiVal').closest('.card');
  const snCard = SD.$('snCard') || SD.$('snVal').closest('.card');
  if (apCard) apCard.addEventListener('click', () => SD.copy(SD.$('apVal').textContent));
  if (imeiCard) imeiCard.addEventListener('click', () => SD.copy(SD.$('imeiVal').textContent));
  if (snCard) snCard.addEventListener('click', () => SD.copy(SD.$('snVal').textContent));

  // ── S/N přes USB (bez vývojáře) – velké zobrazení + čárový kód ──
  let usbSnValue = '';
  const usbBtn = SD.$('btnUsbSnRead');
  if (usbBtn) usbBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    SD.$('usbSnMsg').textContent = 'čtu USB…';
    const r = await window.api.usbIds();
    if (!r || !r.ok) { SD.$('usbSnMsg').textContent = '✗ ' + ((r && r.error) || 'selhalo'); return; }
    // preferuj reálné S/N telefonu (ne Apple UDID)
    const items = (r.items || []);
    const best = items.find(x => x.value && !x.isApple)
      || items.find(x => x.value) || null;
    if (!best) {
      const seen = (r.seen || []);
      if (seen.length) SD.log('🔌 USB vidělo: ' + seen.map(s => `${s.brand} „${s.name}" S/N=${s.serial}`).join(' | '));
      else SD.log('🔌 USB: žádné zařízení známé značky nenalezeno.');
      // Fallback: telefon je připojený přes ADB → použij jeho S/N (čte se přes
      // ADB protokol, ne z USB deskriptoru). Když ADB není, telefon S/N přes
      // USB nehlásí – chybí ovladač výrobce.
      const info = SD.state.info || {};
      const adbSn = info.sn || info.serial || (SD.state.platform === 'android' ? SD.state.serial : '');
      if (adbSn) {
        usbSnValue = adbSn;
        SD.$('usbSnVal').textContent = adbSn;
        SD.makeBarcode('usbSnBc', adbSn);
        SD.$('usbSnHint').style.display = '';
        SD.$('usbSnMsg').textContent = '✓ S/N z ADB (telefon nehlásí S/N přes USB deskriptor – chybí USB ovladač výrobce)';
      } else {
        SD.$('usbSnVal').textContent = '—';
        SD.makeBarcode('usbSnBc', '');
        SD.$('usbSnMsg').textContent = 'telefon nehlásí S/N přes USB – nainstaluj USB ovladač výrobce (viz Nastavení → Zkontrolovat USB S/N)';
      }
      return;
    }
    usbSnValue = best.value;
    SD.$('usbSnVal').textContent = best.value;
    SD.makeBarcode('usbSnBc', best.value);
    SD.$('usbSnHint').style.display = '';
    const isHexId = /^[0-9a-f]{16,}$/i.test(best.value);
    SD.$('usbSnMsg').textContent = best.isApple
      ? '⚠ iPhone: tohle je UDID, ne tištěné S/N (to dá „Načíst")'
      : (isHexId
          ? '⚠ ' + best.brand + ': tohle je interní USB id, ne štítkové S/N. Štítek telefon hlásí jen v režimu MTP (přenos souborů) – odemkni/povol MTP a načti znovu.'
          : '✓ ' + best.brand + (best.mtp ? ' (přes MTP)' : '') + (r.items.length > 1 ? ' (+ další zařízení v záložce Akce)' : ''));
  });
  const usbCard = SD.$('usbSnCard');
  if (usbCard) usbCard.addEventListener('click', () => { if (usbSnValue) SD.copy(usbSnValue); });

  // ── Načíst z download/recovery módu (pro zamčené telefony) ──
  const modesBtn = SD.$('btnUsbModes');
  if (modesBtn) modesBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    const msg = SD.$('usbModesMsg'), list = SD.$('usbModesList');
    msg.textContent = 'čtu USB módy…';
    const r = await window.api.usbSamsungModes();
    if (!r || !r.ok) { msg.textContent = '✗ ' + ((r && r.error) || 'selhalo'); return; }
    const devs = r.devices || [];
    if (!devs.length) {
      msg.textContent = '✗ žádné Samsung USB zařízení nevidím';
      list.style.display = 'none';
      SD.log('🔽 Download mód: žádné Samsung USB zařízení. Telefon dej do download módu (Vol nahoru + Vol dolů + připoj kabel) a klikni znovu.');
      return;
    }
    // výpis všech módů + sériovek
    list.style.display = '';
    list.innerHTML = devs.map(d =>
      `• <b>${d.mode}</b> ${d.pid ? '(PID ' + d.pid + ')' : ''}: ` +
      (d.serial ? `<span style="color:${d.isLabel ? 'var(--ok,#4ade80)' : 'var(--text)'}">${d.serial}</span>${d.isLabel ? ' ✓ štítek' : ' (interní id)'}` : '— bez S/N') +
      ` <span style="opacity:.7">[${d.name}]</span>`
    ).join('<br>');
    SD.log('🔽 USB módy: ' + devs.map(d => `${d.mode} S/N=${d.serial || '—'}`).join(' | '));
    // vyber štítkové S/N (nejlíp z download módu)
    const dl = devs.find(d => d.isLabel && /download/i.test(d.mode))
            || devs.find(d => d.isLabel)
            || null;
    if (dl) {
      usbSnValue = dl.serial;
      SD.$('usbSnVal').textContent = dl.serial;
      SD.makeBarcode('usbSnBc', dl.serial);
      SD.$('usbSnHint').style.display = '';
      msg.textContent = '✓ štítkové S/N z ' + dl.mode;
    } else {
      msg.textContent = '⚠ štítkové S/N v žádném módu – zkus telefon do download módu, viz seznam níž';
    }
  });
})();
