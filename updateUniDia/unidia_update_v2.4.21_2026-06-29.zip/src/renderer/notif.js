'use strict';
// ── Logika černé notifikace ──────────────────────────────────────────
const $ = id => document.getElementById(id);
let current = null;

function showCopied(msg) {
  const c = $('copied'); c.textContent = msg || '✓ zkopírováno'; c.classList.add('show');
  setTimeout(() => c.classList.remove('show'), 1200);
}

window.notif.onShow((d) => {
  current = d;
  $('brand').textContent = d.brand || 'Telefon';
  $('model').textContent = d.model || '';
  $('plat').textContent = d.platform === 'ios' ? '· iOS' : '· Android';
  $('plat').style.color = d.platform === 'ios' ? '#c0c0c8' : '#36d36e';
  $('apLbl').textContent = d.lbl_ap || 'SW AP';
  $('apVal').textContent = d.ap || 'N/A';
  $('btns').style.display = d.snOnly ? 'none' : '';
  $('snClose').style.display = d.snOnly ? 'block' : 'none';

  // dopočítat výšku podle obsahu a nahlásit do main (ať okno sedí)
  requestAnimationFrame(() => {
    const card = $('card');
    const w = Math.ceil(card.getBoundingClientRect().width) + 14;
    const h = Math.ceil(card.getBoundingClientRect().height) + 14;
    window.notif.resize(Math.max(248, w), h);
  });
});

// ── klik vs dvojklik ──
// jeden klik na SW = kopírovat (s krátkým zpožděním, ať to nepřebije dvojklik)
let clickTimer = null;
$('apWrap').addEventListener('click', (e) => {
  e.stopPropagation();
  if (clickTimer) return; // probíhá rozlišení dvojkliku
  clickTimer = setTimeout(async () => {
    clickTimer = null;
    await window.notif.copyAp();
    showCopied();
  }, 240);
});

// dvojklik kdekoli na kartě (mimo tlačítka) = otevřít program
$('card').addEventListener('dblclick', (e) => {
  if (e.target.closest('#btns')) return;
  if (clickTimer) { clearTimeout(clickTimer); clickTimer = null; }
  window.notif.open();
});

// tlačítka – OLD/NEW SW: ulož, ukaž potvrzení a zavři notifikaci
async function doPhase(ph) {
  const r = await window.notif.phase(ph);
  if (r && r.ok) { showCopied('✓ ' + ph + ' uloženo'); setTimeout(() => window.notif.dismiss(), 850); }
  else { showCopied('✗ chyba ukládání'); }
}
$('bOld').addEventListener('click', (e) => { e.stopPropagation(); doPhase('OLD SW'); });
$('bNew').addEventListener('click', (e) => { e.stopPropagation(); doPhase('NEW SW'); });
$('bX').addEventListener('click',   (e) => { e.stopPropagation(); window.notif.dismiss(); });
$('snClose').addEventListener('click', (e) => { e.stopPropagation(); window.notif.dismiss(); });
