'use strict';
// ── Akce se zařízením: restart do režimu, instalace APK ──────────────
(function () {
  const on = (id, fn) => { const el = SD.$(id); if (el) el.addEventListener('click', fn); };
  const isIos = () => SD.state.platform === 'ios';

  function needDevice() {
    if (!SD.state.serial) { SD.toast('Pozor', 'Nepřipojen žádný telefon.'); return false; }
    return true;
  }

  function gateForPlatform() {
    const ios = isIos();
    const androidOnly = ['btnRebootDownload', 'btnRebootNormal',
      'btnFinishSetup', 'apkSelect', 'btnApkInstall', 'btnApkUninstall', 'btnApkRefresh',
      'btnTestRun', 'btnTestPull'];
    for (const id of androidOnly) { const el = SD.$(id); if (el) el.disabled = ios; }
    const hint = SD.$('actHint');
    if (hint) hint.textContent = ios ? '— iPhone: tyto akce jsou jen pro Android' : '';
    applyRebootButtons();
  }

  // reboot tlačítka se přizpůsobí připojenému telefonu
  function applyRebootButtons() {
    const i = SD.state.info || {};
    const brand = String(i.brand || '').toLowerCase();
    const isSamsung = brand.indexOf('samsung') >= 0;
    const ios = isIos();
    const dl = SD.$('btnRebootDownload'), hint = SD.$('rebootHint');
    if (ios) { if (dl) dl.style.display = ''; if (hint) hint.textContent = ''; return; }
    // Download (Odin) je jen Samsung
    if (dl) dl.style.display = isSamsung ? '' : 'none';
    if (hint) {
      if (!i.brand) hint.textContent = '';
      else if (isSamsung) hint.innerHTML = 'Pro Odin/Fenrir klikni <b>„Download (Odin)"</b> – telefon přejde do download módu i s daty.<br>' +
        'Když telefon nereaguje na ADB (zamčený / nepovolené ladění): <b>vypni ho</b>, podrž <b>Vol nahoru + Vol dolů</b> a teprve pak <b>připoj USB kabel</b> → objeví se modré varování → Vol nahoru potvrdí. ' +
        '(Vol dolů + Power telefon jen resetuje – do download módu nejde.)';
      else hint.textContent = 'Download (Odin) je jen pro Samsung.';
    }
  }

  // riziková sekce (dokončení setupu) je vidět jen když je v Nastavení zapnuto
  function applyAdvanced() {
    const el = SD.$('setupSection');
    if (el) el.style.display = (SD.settings && SD.settings.advancedActions) ? '' : 'none';
  }
  SD.applyAdvanced = applyAdvanced;

  // ── restart do režimu ──
  async function doReboot(mode, label, warn) {
    if (!needDevice()) return;
    if (warn && !window.confirm(`Opravdu restartovat telefon do režimu: ${label}?`)) return;
    SD.log(`↻ Restartuji do: ${label}…`);
    const r = await window.api.reboot(SD.state.serial, SD.state.platform, mode);
    if (r && r.ok) SD.toast('Restart', 'Telefon se restartuje do: ' + (r.mode || label));
    else SD.toast('Chyba', (r && r.error) || 'Restart selhal');
  }
  on('btnRebootDownload', () => doReboot('download', 'Download (Odin)', true));
  on('btnRebootNormal', () => doReboot('', 'normální restart', false));

  // ── APK ──
  async function refreshApks() {
    const sel = SD.$('apkSelect'); if (!sel) return;
    const list = await window.api.apkList();
    sel.innerHTML = list.length
      ? list.map(f => `<option>${f}</option>`).join('')
      : '<option value="">(složka apk je prázdná)</option>';
  }
  on('btnApkRefresh', refreshApks);
  SD.refreshApks = refreshApks;
  on('btnApkFolder', async () => { await window.api.openFolder('apk'); });
  on('btnApkInstall', async () => {
    if (!needDevice()) return;
    const file = SD.$('apkSelect').value;
    if (!file) { SD.toast('Pozor', 'Vlož APK do složky apk a obnov seznam.'); return; }
    SD.$('apkMsg').textContent = 'instaluji ' + file + '…';
    SD.log('⬇ Instaluji APK: ' + file);
    const r = await window.api.apkInstall(SD.state.serial, file);
    if (r && r.ok) { SD.$('apkMsg').textContent = '✓ nainstalováno'; SD.toast('APK', file + ' nainstalováno'); }
    else { SD.$('apkMsg').textContent = '✗ ' + ((r && r.out) || (r && r.error) || 'selhalo'); }
  });

  on('btnApkUninstall', async () => {
    if (!needDevice()) return;
    if (!window.confirm('Odinstalovat testovací aplikaci (UniDia Test) z telefonu?')) return;
    SD.$('apkMsg').textContent = 'odinstalovávám…';
    const r = await window.api.apkUninstall(SD.state.serial, 'cz.britex.unidiatest');
    if (r && r.ok) { SD.$('apkMsg').textContent = '✓ odinstalováno'; SD.toast('APK', 'Testovací aplikace odinstalována'); }
    else { SD.$('apkMsg').textContent = '✗ ' + ((r && r.error) || 'selhalo'); }
  });

  // ── testovací APK: spuštění + načtení výsledků ──
  on('btnTestRun', async () => {
    if (!needDevice()) return;
    SD.$('testMsg').textContent = 'spouštím v telefonu…';
    const r = await window.api.testLaunch(SD.state.serial);
    SD.$('testMsg').textContent = (r && r.ok) ? '✓ aplikace spuštěna – projeď testy a dej „Uložit výsledky"' : '✗ ' + ((r && r.error) || 'nelze spustit (je nainstalovaná?)');
  });

  on('btnTestPull', async () => {
    if (!needDevice()) return;
    SD.$('testMsg').textContent = 'stahuji výsledky…';
    SD.$('testResults').innerHTML = '';
    const r = await window.api.testPull(SD.state.serial);
    if (!r || !r.ok) { SD.$('testMsg').textContent = '✗ ' + ((r && r.error) || 'selhalo'); return; }
    SD.$('testMsg').textContent = '✓ načteno';
    const d = r.data || {};
    SD.state.apk = d;
    const map = { pass: ['#46d17a', 'PASS'], fail: ['#ff6b6b', 'FAIL'], skip: ['#8aa0bd', 'SKIP'], info: ['#22d3ee', 'INFO'] };
    const rows = (d.tests || []).map(t => {
      const m = map[t.status] || ['#8aa0bd', (t.status || '').toUpperCase()];
      return `<div style="display:flex;gap:8px;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.04)">
        <span style="flex:1;color:var(--text)">${t.name || t.id}</span>
        <span style="flex:1.4;color:var(--text-dim)">${t.details || ''}</span>
        <span style="color:${m[0]};font-weight:700;width:48px;text-align:right">${m[1]}</span></div>`;
    }).join('');
    SD.$('testResults').innerHTML =
      `<div style="color:var(--text-dim);margin-bottom:4px">${(d.device && (d.device.manufacturer + ' ' + d.device.model)) || ''} · ${d.timestamp || ''}</div>` + rows;
    SD.log('⬇ Načteny výsledky testu z telefonu (' + (d.tests ? d.tests.length : 0) + ' položek).');
    const row = SD.$('apkReportRow'); if (row) row.style.display = 'flex';
  });

  // ── PDF / tisk výsledků z APK ──
  function apkPayload() {
    if (!SD.state.apk) { SD.toast('Pozor', 'Nejdřív načti výsledky z telefonu.'); return null; }
    const t = SD.state.apk.tests || [];
    const summary = {
      total: t.length,
      ok: t.filter(x => x.status === 'pass').length,
      fail: t.filter(x => x.status === 'fail').length,
      skip: t.filter(x => x.status === 'skip').length,
      warn: 0,
    };
    return { info: SD.state.info || {}, apk: SD.state.apk, summary, categories: {}, interactive: [] };
  }
  on('btnApkPdfAs', async () => {
    const p = apkPayload(); if (!p) return;
    const r = await window.api.reportPdf(p);
    if (r && r.ok) SD.toast('PDF uloženo', r.path);
    else if (r && !r.canceled) SD.toast('Chyba', (r && r.error) || 'PDF selhalo');
  });
  on('btnApkPdf', async () => {
    const p = apkPayload(); if (!p) return;
    const job = (SD.$('apkJob').value || '').trim();
    if (!job) { SD.toast('Pozor', 'Zadej číslo zakázky.'); return; }
    const r = await window.api.reportZakazka(p, job);
    if (r && r.ok) SD.toast('Uloženo do zakázky', r.fileName || ('VT_' + job + 'A.pdf'));
    else SD.toast('Chyba', (r && r.error) || 'Uložení selhalo');
  });
  on('btnApkPrint', async () => { const p = apkPayload(); if (p) await window.api.reportPrint(p); });

  // ── Podklad pro IT (Knox/MDM enrollment) ──
  on('btnItHandoff', async () => {
    const i = SD.state.info || {};
    const v = x => (x && x !== 'N/A') ? x : '(doplň z krabičky / štítku / *#06#)';
    const txt =
`Žádost o uvolnění zařízení z firemního zápisu (Knox)
----------------------------------------------------
Model:   ${v(i.model)}
IMEI:    ${v(i.imei)}
S/N:     ${v(i.sn || i.serial)}

Zařízení se po továrním resetu samo zapisuje do firemního MDM a nelze ho zprovoznit.
Prosím o uvolnění podle toho, kde je zařízení vedené:

1) Knox Mobile Enrollment (KME) – nejčastější příčina:
   portál Samsung Knox -> Knox Mobile Enrollment -> Devices
   -> najít podle IMEI výše -> DELETE (smazat) nebo odebrat přiřazený profil.
   Pozn.: nestačí jen odhlásit z MDM – dokud je v KME, telefon se zapisuje dál.

2) Knox Manage / jiné MDM:
   konzole MDM -> najít zařízení -> Unenroll / Wipe enrollment.

3) Knox Guard (KG) – pokud telefon píše "zařízení uzamčeno správcem / financováním":
   samostatný zámek, uvolní ho jen ten, kdo ho nasadil (KG konzole).

Po smazání z KME stačí na ÚVODNÍ obrazovce připojit Wi-Fi (jde to i bez nastavení) –
telefon se znovu zeptá serveru a pustí dál. Vývojářský režim není potřeba.`;
    try { await navigator.clipboard.writeText(txt); SD.$('itMsg').textContent = '✓ zkopírováno do schránky'; }
    catch (_) { SD.$('itMsg').textContent = '✗ schránka nedostupná'; }
    SD.log('📋 Vygenerován podklad pro IT (Knox).');
  });

  // ── dokončit zaseknuté úvodní nastavení ──
  on('btnFinishSetup', async () => {
    if (!needDevice()) return;
    if (!window.confirm('Dokončit úvodní nastavení telefonu? Použij jen u zařízení zaseknutého na setupu kvůli mrtvému serveru, BEZ účtu zákazníka.')) return;
    SD.$('setupMsg').textContent = 'pracuji…';
    const r = await window.api.finishSetup(SD.state.serial, SD.state.platform);
    if (r && r.ok) { SD.$('setupMsg').textContent = '✓ hotovo – telefon by měl jít na plochu'; SD.log('✓ Úvodní nastavení dokončeno.'); }
    else { SD.$('setupMsg').textContent = '✗ ' + ((r && r.error) || 'selhalo'); if (r && r.blocked) SD.toast('Zablokováno', r.error); }
  });

  // reagovat na změnu připojeného zařízení
  window.api.onDeviceInfo(() => gateForPlatform());
  window.api.onDevicesList(() => gateForPlatform());

  // init (po načtení nastavení)
  function init() { refreshApks(); gateForPlatform(); applyAdvanced(); }
  if (SD.settings) init(); else setTimeout(init, 400);
})();
