// Jednoduchá lokalizace CS/EN. Prvky se tagují atributy:
//   data-i18n="KLIC"        → nastaví innerHTML
//   data-i18n-ph="KLIC"     → nastaví placeholder
//   data-i18n-title="KLIC"  → nastaví title
// Slovník D[KLIC] = { cs, en }. Výchozí jazyk je čeština.
(function () {
  const D = {
    // ── connbar / taby ──
    connText: { cs: 'Čekám na připojení…', en: 'Waiting for a device…' },
    btnRead: { cs: '⤓ Načíst', en: '⤓ Read' },
    btnScan: { cs: '↻ Prohledat', en: '↻ Scan' },
    tab_read: { cs: '📱 Načtení SW', en: '📱 Read SW' },
    tab_sn: { cs: '🔢 S/N (USB)', en: '🔢 S/N (USB)' },
    tab_status: { cs: '🩺 Stav / Diagnostika', en: '🩺 Status / Diagnostics' },
    tab_actions: { cs: '🔧 Akce', en: '🔧 Actions' },
    tab_search: { cs: '🔍 Vyhledat', en: '🔍 Search' },
    tab_settings: { cs: '⚙ Nastavení', en: '⚙ Settings' },

    // ── Načtení SW ──
    hint_copy: { cs: 'klikni pro kopírování', en: 'click to copy' },
    hint_click: { cs: 'klikni', en: 'click' },
    lbl_imei: { cs: 'IMEI', en: 'IMEI' },
    lbl_sn: { cs: 'S/N (sériové číslo)', en: 'S/N (serial number)' },
    lbl_histImei: { cs: 'Historie IMEI (všechny měsíce)', en: 'IMEI history (all months)' },
    lbl_assignPhase: { cs: 'Přiřadit fázi', en: 'Assign phase' },
    phase_old: { cs: '<span class="pdot"></span>OLD SW – vstupní', en: '<span class="pdot"></span>OLD SW – intake' },
    phase_new: { cs: '<span class="pdot"></span>NEW SW – výstupní', en: '<span class="pdot"></span>NEW SW – outgoing' },
    lbl_log: { cs: 'Log', en: 'Log' },

    // ── S/N (USB) ──
    sn_usb_lbl: { cs: 'S/N přes USB <span style="font-weight:400;color:var(--text-dim);text-transform:none">— funguje i bez vývojáře / s rozbitým LCD (klikni na číslo = kopírovat)</span>', en: 'S/N over USB <span style="font-weight:400;color:var(--text-dim);text-transform:none">— works without developer mode / with a broken screen (click the number = copy)</span>' },
    btnUsbSnRead: { cs: '🔌 Načíst S/N přes USB', en: '🔌 Read S/N over USB' },
    sn_usb_help: { cs: 'Přečte sériové číslo, které telefon hlásí už při zapojení do USB – <b>funguje i u zamčeného telefonu, i s rozbitým LCD, bez vývojářského režimu</b>. IMEI takto nelze získat (je v modemu), ale přes S/N ho dohledáš v GSPN. (BlackBerry/některé telefony S/N přes USB nehlásí.)', en: 'Reads the serial number the phone reports as soon as it is plugged into USB – <b>works on a locked phone, with a broken screen, without developer mode</b>. IMEI cannot be obtained this way (it lives in the modem), but you can look it up from the S/N in GSPN. (BlackBerry / some phones do not report S/N over USB.)' },

    // ── Stav / Diagnostika ──
    btnQuick: { cs: '▶ Quick Test (auto)', en: '▶ Quick Test (auto)' },
    btnComplete: { cs: '🧪 Kompletní test (ruční + auto)', en: '🧪 Full test (manual + auto)' },
    btnStop: { cs: '■ Ukončit test', en: '■ Stop test' },
    diag_help: { cs: 'Quick Test: automaticky projede jen <b>funkční</b> kategorie, které opravdu změří funkci (baterie, nabíjení, paměť, úložiště, displej, síť, GPS…). Kompletní: nejdřív průvodce <b>ručními</b> testy (displej, dotyk, <b>každá kamera zvlášť</b> – i 5+, reproduktor, mikrofon, vibrace, senzory…), pak auto. Funguje na <b>Androidu i iPhonu</b> (iOS testy jsou ruční). Vše lze přeskočit.', en: 'Quick Test: automatically runs only <b>functional</b> categories that truly measure a function (battery, charging, memory, storage, display, network, GPS…). Full: first a wizard of <b>manual</b> tests (display, touch, <b>each camera separately</b> – even 5+, speaker, microphone, vibration, sensors…), then auto. Works on <b>Android and iPhone</b> (iOS tests are manual). Everything can be skipped.' },
    lbl_summary: { cs: 'Výsledek testu', en: 'Test result' },
    lbl_protocol: { cs: 'Protokol testu', en: 'Test report' },
    btnPdf: { cs: '📄 Uložit PDF', en: '📄 Save PDF' },
    btnPrint: { cs: '🖨 Tisknout', en: '🖨 Print' },
    btnZakazka: { cs: '💾 Uložit do zakázky (VT_…A)', en: '💾 Save to job (VT_…A)' },
    ph_jobNum: { cs: 'číslo zakázky (např. 4567894)', en: 'job number (e.g. 4567894)' },

    // ── Akce ──
    act_title: { cs: '🔧 Akce se zařízením', en: '🔧 Device actions' },
    act_rebootHdr: { cs: 'Restart do režimu (Android)', en: 'Reboot to mode (Android)' },
    btnRebootDownload: { cs: '⬇ Download (Odin)', en: '⬇ Download (Odin)' },
    btnRebootNormal: { cs: '↻ Restart', en: '↻ Reboot' },
    setup_hdr: { cs: 'Zaseknuté úvodní nastavení (mrtvý server)', en: 'Stuck setup wizard (dead server)' },
    btnFinishSetup: { cs: '✓ Dokončit úvodní nastavení', en: '✓ Finish initial setup' },
    setup_help: { cs: 'Pro Android telefony (i BlackBerry KEY2/KEYone) zaseknuté na úvodním průvodci kvůli vypnutému aktivačnímu serveru. Vyžaduje zapnuté USB ladění. <b>Odmítne fungovat, pokud je na telefonu účet</b> – není to nástroj na obcházení zámků.', en: 'For Android phones (incl. BlackBerry KEY2/KEYone) stuck on the setup wizard due to a shut-down activation server. Requires USB debugging enabled. <b>Refuses to work if an account is present on the phone</b> – this is not a lock-bypass tool.' },
    apk_hdr: { cs: 'Instalovat testovací APK', en: 'Install test APK' },
    btnApkInstall: { cs: '⬇ Nainstalovat', en: '⬇ Install' },
    btnApkUninstall: { cs: '🗑 Odinstalovat test', en: '🗑 Uninstall test' },
    btnApkFolder: { cs: '📁 Složka apk', en: '📁 apk folder' },
    btnTestRun: { cs: '▶ Spustit test v telefonu', en: '▶ Run test on phone' },
    btnTestPull: { cs: '⬇ Načíst výsledky', en: '⬇ Pull results' },
    ph_apkJob: { cs: 'č. zakázky (uloží VT_…A.pdf)', en: 'job no. (saves VT_…A.pdf)' },
    btnApkPdf: { cs: '📄 Uložit PDF (VT_)', en: '📄 Save PDF (VT_)' },
    btnApkPdfAs: { cs: '💾 Uložit PDF jako…', en: '💾 Save PDF as…' },
    btnApkPrint: { cs: '🖨 Tisk', en: '🖨 Print' },
    apk_help: { cs: 'Companion APK „UniDia Test" otestuje přímo v telefonu věci, co z PC nejdou (GPS, multidotyk, repro, vibrace, senzory…) a výsledky pošle sem jako JSON. Zdroj a návod na sestavení je v samostatném balíčku.', en: 'The companion "UniDia Test" APK tests things on the phone itself that a PC cannot (GPS, multitouch, speaker, vibration, sensors…) and sends results here as JSON. Source and build guide are in a separate package.' },
    knox_hdr: { cs: 'Firemní zámek (Knox / MDM)', en: 'Corporate lock (Knox / MDM)' },
    btnItHandoff: { cs: '📋 Podklad pro IT (zkopírovat)', en: '📋 Brief for IT (copy)' },
    knox_help: { cs: 'Vygeneruje text s IMEI/S-N + přesnými kroky, co má správce udělat v Knox Mobile Enrollment. Pošli ho jejich IT.', en: 'Generates text with IMEI/S-N + exact steps the admin must do in Knox Mobile Enrollment. Send it to their IT.' },

    // ── Vyhledat ──
    ph_search: { cs: 'IMEI · S/N · model (i část, např. a56)', en: 'IMEI · S/N · model (partial too, e.g. a56)' },
    btnSearch: { cs: '🔍 Hledat', en: '🔍 Search' },
    btnClearSearch: { cs: '✕ Vymazat', en: '✕ Clear' },

    // ── Nastavení ──
    set_startup_t: { cs: 'Spouštět po startu Windows', en: 'Launch on Windows startup' },
    set_startup_d: { cs: 'Aplikace se otevře automaticky při přihlášení.', en: 'The app opens automatically at sign-in.' },
    set_startmin_t: { cs: 'Po startu rovnou minimalizovat do tray', en: 'Minimize to tray on launch' },
    set_startmin_d: { cs: 'Okno se hned schová do oznamovací oblasti (ikona u hodin). Hodí se k „Spouštět po startu".', en: 'The window hides to the notification area (icon by the clock). Pairs well with "Launch on startup".' },
    set_au_t: { cs: 'Automatická aktualizace', en: 'Automatic update' },
    set_au_d: { cs: 'Po startu zkontroluje novou verzi na GitHubu a nabídne instalaci. Ruční kontrola tlačítkem níže.', en: 'On launch it checks GitHub for a new version and offers to install. Manual check with the button below.' },
    set_aum_t: { cs: 'Aktualizovat o půlnoci (automaticky, bez ptaní)', en: 'Update at midnight (automatic, no prompt)' },
    set_aum_d: { cs: 'Každou půlnoc tiše stáhne a nainstaluje novou verzi a aplikaci sama restartuje. Vyžaduje zapnutou „Automatická aktualizace".', en: 'Every midnight it silently downloads and installs the new version and restarts itself. Requires "Automatic update" enabled.' },
    set_ver_t: { cs: 'Verze aplikace', en: 'App version' },
    btnCheckUpdate: { cs: '⟳ Zkontrolovat aktualizace', en: '⟳ Check for updates' },
    set_autoload_t: { cs: 'Automaticky načíst SW po připojení', en: 'Auto-read SW after connect' },
    set_autoload_d: { cs: 'Po zapojení telefonu rovnou vyčte IMEI, S/N a SW verze.', en: 'Reads IMEI, S/N and SW versions right after the phone is plugged in.' },
    set_disdev_t: { cs: 'Po testu vypnout vývojářský režim', en: 'Disable developer mode after test' },
    set_disdev_d: { cs: 'Výchozí: NE – vývojářský režim zůstane zapnutý.', en: 'Default: NO – developer mode stays on.' },
    set_adv_t: { cs: 'Pokročilé servisní akce', en: 'Advanced service actions' },
    set_adv_d: { cs: 'Zpřístupní „Dokončit úvodní nastavení" (pro telefony zaseknuté na mrtvém serveru). Výchozí: VYPNUTO. Nepovoluj v kopiích pro cizí lidi.', en: 'Enables "Finish initial setup" (for phones stuck on a dead server). Default: OFF. Do not enable in copies for outside people.' },
    set_upload_t: { cs: 'Složka zakázek (UploadScan)', en: 'Jobs folder (UploadScan)' },
    set_upload_d: { cs: 'Sem se ukládá VT_&lt;číslo&gt;A.pdf při uložení do zakázky.', en: 'VT_&lt;number&gt;A.pdf is saved here when saving to a job.' },
    btnBrowseUpload: { cs: '📁 Procházet…', en: '📁 Browse…' },
    set_theme_t: { cs: 'Režim vzhledu', en: 'Appearance mode' },
    set_theme_d: { cs: 'Řídí, která tapeta se použije. <b>Časovač</b> = světlá v zadaném čase, jinak tmavá.', en: 'Controls which wallpaper is used. <b>Timer</b> = light during the set time, dark otherwise.' },
    opt_mode_manual: { cs: 'Ruční (vyber tapetu níže)', en: 'Manual (pick wallpaper below)' },
    opt_mode_light: { cs: 'Světlý', en: 'Light' },
    opt_mode_dark: { cs: 'Tmavý', en: 'Dark' },
    opt_mode_windows: { cs: 'Podle Windows', en: 'Follow Windows' },
    opt_mode_schedule: { cs: 'Časovač', en: 'Timer' },
    lbl_lightWp: { cs: 'Světlá tapeta', en: 'Light wallpaper' },
    lbl_darkWp: { cs: 'Tmavá tapeta', en: 'Dark wallpaper' },
    lbl_lightFrom: { cs: 'Světlá od', en: 'Light from' },
    lbl_lightTo: { cs: 'do', en: 'to' },
    set_wp_t: { cs: 'Tapeta pozadí (ruční)', en: 'Background wallpaper (manual)' },
    set_wp_d: { cs: 'PNG/JPG soubory dej do složky <code>tapety/</code> vedle aplikace. Použije se v režimu „Ruční".', en: 'Put PNG/JPG files in the <code>tapety/</code> folder next to the app. Used in "Manual" mode.' },
    btnOpenTapety: { cs: '📁 Otevřít složku', en: '📁 Open folder' },
    set_ios_t: { cs: 'Nástroje pro iPhone (iOS)', en: 'iPhone tools (iOS)' },
    set_ios_d: { cs: 'Najde na PC binárky libimobiledevice (3uTools / iMazing / iTools / iTunes ovladač) a zkopíruje je do <code>ios/</code>. Vypíše, co ještě chybí.', en: 'Finds libimobiledevice binaries on the PC (3uTools / iMazing / iTools / iTunes driver) and copies them to <code>ios/</code>. Lists what is still missing.' },
    btnIosSetup: { cs: '🔎 Najít a nastavit', en: '🔎 Find and set up' },
    set_android_t: { cs: 'Kontrola Androidu (ADB)', en: 'Android check (ADB)' },
    set_android_d: { cs: 'Ověří, že je v aplikaci ADB a že telefon je vidět (a v jakém stavu: připraven / nepovoleno ladění / chybí ovladač).', en: 'Verifies ADB is present and the phone is visible (and its state: ready / debugging not allowed / driver missing).' },
    btnAndroidCheck: { cs: '🤖 Zkontrolovat Android', en: '🤖 Check Android' },
    set_usb_t: { cs: 'Kontrola čtení S/N přes USB', en: 'USB S/N read check' },
    set_usb_d: { cs: 'Ukáže, co PC vidí na USB a jestli telefon hlásí sériové číslo i bez vývojářského režimu. Když ne, poradí proč.', en: 'Shows what the PC sees on USB and whether the phone reports a serial without developer mode. If not, explains why.' },
    btnUsbCheck: { cs: '🔌 Zkontrolovat USB S/N', en: '🔌 Check USB S/N' },
    set_tools_t: { cs: 'Doplnit chybějící součásti', en: 'Add missing components' },
    set_tools_d: { cs: 'Stáhne z GitHubu (<code>updateUniDia/UniDia-distribuce/</code>) a uloží do datové složky aplikace.', en: 'Downloads from GitHub (<code>updateUniDia/UniDia-distribuce/</code>) and saves to the app data folder.' },
    btnGetSamsung: { cs: '📥 Samsung ovladač', en: '📥 Samsung driver' },
    set_drivers_t: { cs: 'Kontrola ovladačů', en: 'Driver check' },
    set_drivers_d: { cs: 'Ověří, jestli jsou nainstalované USB ovladače potřebné pro čtení S/N (Samsung) a iPhone (Apple).', en: 'Verifies the USB drivers needed for reading S/N (Samsung) and iPhone (Apple) are installed.' },
    btnDriversCheck: { cs: '🧩 Zkontrolovat ovladače', en: '🧩 Check drivers' },
    set_lang_t: { cs: 'Jazyk / Language', en: 'Language / Jazyk' },
    set_lang_d: { cs: 'Přepne jazyk rozhraní. Výchozí čeština.', en: 'Switches the interface language. Czech by default.' },
    about_t: { cs: 'O aplikaci', en: 'About' },

    // ── Wizard ──
    ph_wizNote: { cs: 'poznámka (volitelné)…', en: 'note (optional)…' },
    wizSkipAll: { cs: 'přeskočit vše →', en: 'skip all →' },
    wizOk: { cs: '✓ Pass', en: '✓ Pass' },
    wizFail: { cs: '✗ Fail', en: '✗ Fail' },
    wizSkip: { cs: '— Skip', en: '— Skip' },

    // ── titulky (title=) ──
    't:btnRebootDownload': { cs: 'Pro Odin/Fenrir – telefon přejde do download módu i s daty (Samsung)', en: 'For Odin/Fenrir – phone enters download mode with data intact (Samsung)' },
    't:btnApkUninstall': { cs: 'Odinstaluje testovací aplikaci z telefonu', en: 'Uninstalls the test app from the phone' },
    't:btnApkFolder': { cs: 'Sem dej .apk soubory', en: 'Put .apk files here' },
    't:btnTestRun': { cs: 'Otevře nainstalovanou aplikaci UniDia Test v telefonu', en: 'Opens the installed UniDia Test app on the phone' },
    't:btnTestPull': { cs: 'Stáhne výsledky, které technik uložil v telefonu', en: 'Pulls the results the technician saved on the phone' },
    't:btnBrowseUpload': { cs: 'Vybrat složku', en: 'Choose folder' },
    't:btnOpenUpload': { cs: 'Otevřít v Průzkumníku', en: 'Open in Explorer' },
    't:btnOpenTapety': { cs: 'Otevřít složku tapet', en: 'Open wallpapers folder' },
    't:btnRefreshTapety': { cs: 'Obnovit seznam (po přidání souboru)', en: 'Refresh list (after adding a file)' },
    't:btnOpenIos': { cs: 'Otevřít složku ios', en: 'Open ios folder' },
  };

  window.SD = window.SD || {};
  SD.lang = 'cs';
  SD.t = function (key, fallback) {
    const e = D[key];
    if (!e) return (fallback !== undefined ? fallback : key);
    return e[SD.lang] || e.cs || key;
  };
  SD.applyLang = function (lang) {
    SD.lang = (lang === 'en') ? 'en' : 'cs';
    try {
      document.documentElement.setAttribute('lang', SD.lang);
      document.querySelectorAll('[data-i18n]').forEach(function (el) {
        const e = D[el.getAttribute('data-i18n')];
        if (e) el.innerHTML = e[SD.lang] || e.cs;
      });
      document.querySelectorAll('[data-i18n-ph]').forEach(function (el) {
        const e = D[el.getAttribute('data-i18n-ph')];
        if (e) el.setAttribute('placeholder', e[SD.lang] || e.cs);
      });
      document.querySelectorAll('[data-i18n-title]').forEach(function (el) {
        const e = D[el.getAttribute('data-i18n-title')];
        if (e) el.setAttribute('title', e[SD.lang] || e.cs);
      });
    } catch (_) {}
  };
})();
