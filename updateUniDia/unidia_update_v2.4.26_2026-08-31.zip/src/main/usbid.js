'use strict';
// Čtení identity připojeného telefonu z USB deskriptoru – BEZ vývojářského režimu.
// Funguje na Windows přes Get-PnpDevice. Vrací S/N (sériové číslo z USB),
// které telefon hlásí už při zapojení. IMEI takto NELZE získat (je v modemu).
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

// ── CSV log toho, co které zařízení přes USB opravdu hlásí ───────────
// Smysl: po pár týdnech provozu je z toho tabulka „u kterých modelů a v jakém
// režimu sériovka přijde". Bez toho se dá jen hádat podle internetu, kde je to
// pro každý firmware jinak. Zapisuje se jen na kliknutí technika, ne na pozadí.
let LOG_DIR = null;
function initUsbLog(dir) { LOG_DIR = dir; try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {} }

function csvCell(v) {
  const t = String(v == null ? '' : v);
  return /[";\r\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
}

// jeden soubor na měsíc, ať se to dá otevřít v Excelu a poslat dál
function logRows(rows) {
  if (!LOG_DIR || !rows || !rows.length) return;
  try {
    const d = new Date();
    const fp = path.join(LOG_DIR, `usb_${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}.csv`);
    const hdr = 'datum;cas;vid;pid;rezim;znacka;nazev;serial_instanceid;serial_deskriptor;vyhodnoceno;zdroj\n';
    let out = '';
    if (!fs.existsSync(fp)) out += '\uFEFF' + hdr;   // BOM kvůli českému Excelu
    const den = d.toLocaleDateString('cs-CZ');
    const cas = d.toLocaleTimeString('cs-CZ');
    for (const r of rows) {
      out += [den, cas, r.vid, r.pid, r.mode, r.brand, r.name,
        r.snInstance, r.snDescriptor, r.verdict, r.source].map(csvCell).join(';') + '\n';
    }
    fs.appendFileSync(fp, out, 'utf8');
  } catch (_) { /* log nesmí nikdy shodit čtení S/N */ }
}

// známé VID výrobců telefonů → značka
const VENDORS = {
  '04e8': 'Samsung', '05ac': 'Apple', '18d1': 'Google', '22b8': 'Motorola',
  '2717': 'Xiaomi', '2a70': 'OnePlus/Oppo', '22d9': 'Oppo', '12d1': 'Huawei',
  '1004': 'LG', '0fce': 'Sony', '0bb4': 'HTC', '0b05': 'Asus', '19d2': 'ZTE',
  '17ef': 'Lenovo', '2916': 'Yota', '0e8d': 'MediaTek', '1ebf': 'TCL/Alcatel',
  '2c3f': 'Nothing', '0489': 'Foxconn/Fairphone',
};

function runPowershell(cmd) {
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', cmd],
      { timeout: 20000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
      (err, stdout) => resolve(err ? '' : (stdout || '')));
  });
}

// VIDy známých výrobců telefonů pro filtr v PowerShellu
function vidRegex() { return Object.keys(VENDORS).map(v => v.toUpperCase()).join('|'); }

// rozbor InstanceId: USB\VID_04E8&PID_6860\R58N123ABC  → { vid, serial }
function parseInstance(id) {
  const vidM = /VID_([0-9A-Fa-f]{4})/.exec(id || '');
  const vid = vidM ? vidM[1].toLowerCase() : '';
  const parts = String(id).split('\\');
  let serial = parts.length >= 3 ? parts[2] : '';
  // pokud třetí část obsahuje '&', telefon nehlásí vlastní sériové číslo (je to ID portu)
  const reported = serial && !serial.includes('&');
  return { vid, serial: reported ? serial : '', reported };
}

// ── iPhone v recovery/DFU módu ───────────────────────────────────────
// V recovery módu Apple necpe do iSerialNumber UDID, ale celý informační
// řetězec, ze kterého Windows udělá InstanceId:
//   USB\\VID_05AC&PID_1281\\CPID:8010_..._SRNM:[F17XXXXXXXX]_IMEI:[35XXXXXXXXXXXXX]
// SRNM je štítkové sériové číslo. Funguje i na zamčeném telefonu s mrtvým
// displejem, protože recovery je před bootem systému. IMEI tam u novějších
// modelů bývá N/A – viz komentář v UI.
const APPLE_RECOVERY_PIDS = ['1280', '1281', '1282', '1283'];
const APPLE_DFU_PIDS = ['1222', '1227', '1228', '1338'];

function appleModeFromPid(pid) {
  const p = String(pid || '').toLowerCase();
  if (APPLE_RECOVERY_PIDS.includes(p)) return 'recovery';
  if (APPLE_DFU_PIDS.includes(p)) return 'DFU';
  return '';
}

// vytáhne SRNM / IMEI / ECID z recovery řetězce (Windows nahrazuje mezery '_')
function parseAppleRecovery(id) {
  const blob = String(id || '').replace(/_/g, ' ');
  const pick = (key) => {
    const m = new RegExp(key + ':\\[([^\\]]+)\\]').exec(blob) || new RegExp(key + ':([^\\s]+)').exec(blob);
    const v = m ? m[1].trim() : '';
    return (!v || /^n\/a$/i.test(v)) ? '' : v;
  };
  return { srnm: pick('SRNM'), imei: pick('IMEI'), ecid: pick('ECID') };
}

// příslušenství (dongle, myš, audio, disk, monitor…) – NE telefon
const ACCESSORY = /bluetooth|bt-?\d|bt400|dongle|adapt|receiver|mouse|keyboard|webcam|head\s?set|speaker|\baudio\b|\bhub\b|dock|printer|scanner|card\s?reader|\breader\b|wi-?fi|wireless|gamepad|controller|fingerprint|\bups\b|serial|com\s?port|\bdisk\b|storage|volume|\bssd\b|mass\s?storage|monitor|\bdisplay\b/i;
// pozitivní signál, že jde o telefon
const PHONE_HINT = /mobile|\bmtp\b|android|\badb\b|iphone|ipad|composite device|\bphone\b|galaxy|pixel|redmi|poco|oneplus/i;

// Druhá cesta: serial přes MTP/WPD (Shell „System.Devices.SerialNumber").
// Telefon v režimu MTP hlásí S/N i bez vývojářského režimu, i když ho USB
// deskriptor neobsahuje.
async function readMtpSerials() {
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$o=@();$sh=New-Object -ComObject Shell.Application;$pc=$sh.NameSpace(17);" +
    "if($pc){foreach($it in $pc.Items()){try{" +
    "$sn=$it.ExtendedProperty('System.Devices.SerialNumber');" +
    "$o+=[PSCustomObject]@{Name=$it.Name;Type=$it.Type;Serial=[string]$sn}" +
    "}catch{}}}" +
    "$o | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return [];
  let data;
  try { data = JSON.parse(out); } catch (_) { return []; }
  if (!Array.isArray(data)) data = [data];
  return data;
}

// Třetí cesta: serial z registru „Windows Portable Devices\Devices". Když byl
// telefon v MTP režimu, Windows si tu uloží jeho MTP identitu – a u Samsungů
// tam bývá skutečné štítkové S/N (R39K60C0DN), ne USB descriptor hex.
async function readWpdRegistrySerials() {
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$base='HKLM:\\SOFTWARE\\Microsoft\\Windows Portable Devices\\Devices';" +
    "$o=@();" +
    "Get-ChildItem $base | ForEach-Object { $p=Get-ItemProperty $_.PSPath; " +
    "$o+=[PSCustomObject]@{Key=$_.PSChildName;FriendlyName=[string]$p.FriendlyName} };" +
    "$o | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return [];
  let data; try { data = JSON.parse(out); } catch (_) { return []; }
  if (!Array.isArray(data)) data = [data];
  return data;
}

function brandFromName(name) {
  const n = String(name || '').toLowerCase();
  if (/samsung|galaxy/.test(n)) return 'Samsung';
  if (/pixel|google/.test(n)) return 'Google';
  if (/xiaomi|redmi|poco/.test(n)) return 'Xiaomi';
  if (/oneplus/.test(n)) return 'OnePlus';
  if (/oppo/.test(n)) return 'Oppo';
  if (/huawei|honor/.test(n)) return 'Huawei';
  if (/motorola|moto/.test(n)) return 'Motorola';
  if (/sony|xperia/.test(n)) return 'Sony';
  if (/nokia|hmd/.test(n)) return 'Nokia';
  if (/iphone|ipad|apple/.test(n)) return 'Apple';
  return 'Telefon';
}
// vypadá záznam jako disk/jednotka (ne telefon)?
const DRIVE_LIKE = /disk|drive|jednotka|svazek|volume|usb drive|\bssd\b|flash|\bcard\b|paměť/i;

async function readUsbIds() {
  if (process.platform !== 'win32') return { ok: false, error: 'Čtení přes USB je jen na Windows.', items: [], seen: [] };
  // Vytáhneme i DEVPKEY_Device_SerialNumber (USB deskriptor iSerialNumber),
  // protože některé telefony nehlásí S/N v InstanceId, ale v deskriptoru ano.
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$vids='" + vidRegex() + "';" +
    "$d=Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\\*' -and $_.InstanceId -match ('VID_('+$vids+')') };" +
    "($d | ForEach-Object { $sn=(Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_SerialNumber').Data;" +
    "[PSCustomObject]@{ FriendlyName=$_.FriendlyName; InstanceId=$_.InstanceId; Serial=$sn } }) | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return { ok: true, items: [], seen: [] };

  let data;
  try { data = JSON.parse(out); } catch (_) { return { ok: false, error: 'Neočekávaný výstup systému.', items: [], seen: [] }; }
  if (!Array.isArray(data)) data = [data];

  const raw = [];
  const seen = [];
  for (const d of data) {
    const id = d.InstanceId || '';
    const name = d.FriendlyName || '';
    const parsed = parseInstance(id);
    const vid = parsed.vid;
    if (!VENDORS[vid]) continue;
    // serial: nejdřív z InstanceId (čisté), jinak z USB deskriptoru
    let serial = parsed.serial;
    const devSn = (d.Serial == null ? '' : String(d.Serial)).trim();
    if (!serial && devSn && !devSn.includes('&') && devSn.length >= 4) serial = devSn;
    const reported = !!serial;
    seen.push({ brand: VENDORS[vid], name: name || '(bez názvu)', serial: serial || '(žádné S/N)' });
    if (ACCESSORY.test(name)) continue;
    if (!PHONE_HINT.test(name) && !reported) continue;
    const isApple = vid === '05ac';
    // iPhone v recovery/DFU: sériovka a někdy i IMEI jsou přímo v InstanceId
    const pidM = /PID_([0-9A-Fa-f]{4})/.exec(id);
    const pid = pidM ? pidM[1].toLowerCase() : '';
    const appleMode = isApple ? appleModeFromPid(pid) : '';
    if (appleMode) {
      const a = parseAppleRecovery(id);
      if (a.srnm) {
        raw.push({ brand: 'Apple', name: name || ('iPhone – ' + appleMode), isApple: true,
          serial: a.srnm, reported: true, appleMode, imei: a.imei, ecid: a.ecid });
        continue;
      }
    }
    raw.push({ brand: VENDORS[vid], name, isApple, serial: reported ? serial : '', reported, pid });
  }

  // sloučit duplicitní záznamy téhož telefonu: upřednostnit štítkové S/N,
  // pak jakékoli S/N, teprve nakonec záznam bez identity
  const isLabelSn = v => /^[A-Z0-9]{8,14}$/.test(String(v || '')) && /[G-Z]/.test(String(v || ''));
  raw.sort((a, b) => (isLabelSn(b.serial) ? 1 : 0) - (isLabelSn(a.serial) ? 1 : 0));
  const byBrand = {};
  for (const it of raw) (byBrand[it.brand] = byBrand[it.brand] || []).push(it);
  const items = [];
  const seenSerial = new Set();
  for (const brand of Object.keys(byBrand)) {
    const list = byBrand[brand];
    const withSn = list.filter(x => x.serial);
    const pick = withSn.length ? withSn : list.slice(0, 1);
    for (const it of pick) {
      const k = it.brand + '|' + (it.serial || it.name);
      if (seenSerial.has(k)) continue; seenSerial.add(k);
      items.push({
        brand: it.brand,
        name: it.name,
        value: it.serial,
        // v recovery módu je to skutečné S/N, ne UDID
        label: (it.isApple && !it.appleMode) ? 'UDID' : 'S/N',
        isApple: it.isApple,
        appleMode: it.appleMode || '',
        imei: it.imei || '',
        ecid: it.ecid || '',
        note: it.serial ? '' : 'telefon nehlásí identitu přes USB',
      });
    }
  }
  items.sort((a, b) => (b.value ? 1 : 0) - (a.value ? 1 : 0));

  // Když přes USB deskriptor NEMÁME žádné S/N telefonu, zkus MTP/WPD jako
  // fallback (telefon v MTP režimu hlásí S/N i bez vývojáře). Bereme jen
  // zařízení, které vypadá jako telefon – ne náhodná čísla z hubů/donglů.
  const haveSn = items.some(x => x.value);
  if (!haveSn) {
    try {
      const mtp = await readMtpSerials();
      for (const m of mtp) {
        const sn = (m.Serial == null ? '' : String(m.Serial)).trim();
        const nm = m.Name || '';
        const ty = m.Type || '';
        const blob = nm + ' ' + ty;
        if (DRIVE_LIKE.test(blob)) continue;
        if (/zástupce|shortcut|síť|network|složk|folder/i.test(ty)) continue;
        const looksPhone = brandFromName(nm) !== 'Telefon' || /telefon|phone|portable|mobil/i.test(blob);
        if (!looksPhone) continue;
        seen.push({ brand: brandFromName(nm), name: nm + (ty ? ' [' + ty + ']' : ''), serial: sn || '(žádné S/N)', mtp: true });
        if (!sn || sn.length < 4 || sn.includes('&')) continue;
        const k = 'mtp|' + sn;
        if (seenSerial.has(k)) continue; seenSerial.add(k);
        items.push({ brand: brandFromName(nm), name: nm, value: sn, label: 'S/N', isApple: false, note: '', mtp: true });
      }
      items.sort((a, b) => (b.value ? 1 : 0) - (a.value ? 1 : 0));
    } catch (_) {}
  }

  logRows(raw.map(r => ({
    vid: '', pid: r.pid || '', mode: r.appleMode || 'normální', brand: r.brand, name: r.name,
    snInstance: r.serial, snDescriptor: '', verdict: r.serial ? (r.appleMode ? 'S/N (recovery)' : 'S/N') : 'nic',
    source: 'usb-tlacitko',
  })));

  return { ok: true, items, seen };
}

module.exports = { readUsbIds, readSamsungModeSerials, initUsbLog };

// ── Čtení Samsung zařízení podle USB módu (vč. download/recovery) ──────────
// Telefon v download (Odin) módu se přehlásí na jiný PID a jeho USB descriptor
// někdy nese skutečné štítkové S/N. Tady čteme VŠECHNA přítomná Samsung USB
// zařízení (bez filtru příslušenství) a vracíme jejich sériovky + mód podle PID,
// ať je vidět, co který režim hlásí. Bez nativních modulů – jen PnP descriptor.
function modeFromPid(pid) {
  const p = String(pid || '').toLowerCase();
  const DL = ['685d', '6601', '685e', '68c3'];           // download / Odin / CDC
  const ADB = ['6860', '6863', '6864', '4ee7', '6862', '6866', '6865']; // MTP / ADB / normální
  if (DL.includes(p)) return 'download (Odin)';
  if (ADB.includes(p)) return 'MTP/ADB (normální)';
  return 'PID ' + p;
}

async function readSamsungModeSerials() {
  if (process.platform !== 'win32') return { ok: false, error: 'Jen na Windows.', devices: [] };
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$d=Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\\VID_04E8*' };" +
    "($d | ForEach-Object { $sn=(Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_SerialNumber').Data;" +
    "[PSCustomObject]@{ InstanceId=$_.InstanceId; FriendlyName=$_.FriendlyName; Status=[string]$_.Status; Serial=[string]$sn } }) | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return { ok: true, devices: [] };
  let data; try { data = JSON.parse(out); } catch (_) { return { ok: false, error: 'Neočekávaný výstup.', devices: [] }; }
  if (!Array.isArray(data)) data = [data];

  // Rozpoznání štítkového S/N (R58M12ABCDE) od interního USB id (a1b2c3d4e5f6).
  // Původní verze zahazovala jen hexy delší než 16 znaků, takže 12místné hex id
  // prošlo jako „štítek" a technik ho v dobré víře opsal do zakázky.
  // Rozhoduje: velká písmena + musí obsahovat znak mimo hex abecedu (G–Z).
  const looksLabel = s => {
    const v = String(s || '');
    if (!/^[A-Z0-9]{8,14}$/.test(v)) return false;   // štítek je vždy VELKÝMI, bez oddělovačů
    if (!/[G-Z]/.test(v)) return false;              // samé 0-9A-F → interní id, ne štítek
    return true;
  };
  const devices = [];
  const seenK = new Set();
  for (const d of data) {
    const id = d.InstanceId || '';
    const pidM = /PID_([0-9A-Fa-f]{4})/.exec(id);
    const pid = pidM ? pidM[1].toLowerCase() : '';
    const parsed = parseInstance(id);
    let serial = parsed.serial;                                  // z InstanceId (čisté)
    const devSn = (d.Serial == null ? '' : String(d.Serial)).trim();
    if (!serial && devSn && !devSn.includes('&') && devSn.length >= 4) serial = devSn;
    const k = pid + '|' + serial + '|' + (d.FriendlyName || '');
    if (seenK.has(k)) continue; seenK.add(k);
    devices.push({
      mode: modeFromPid(pid),
      pid,
      name: d.FriendlyName || '(bez názvu)',
      serial: serial || '',
      isLabel: looksLabel(serial),
    });
  }
  logRows(devices.map(d => ({
    vid: '04e8', pid: d.pid, mode: d.mode, brand: 'Samsung', name: d.name,
    snInstance: d.serial, snDescriptor: '',
    verdict: d.serial ? (d.isLabel ? 'štítkové S/N' : 'interní id') : 'nic',
    source: 'samsung-mody',
  })));

  // štítkové S/N nahoru
  devices.sort((a, b) => (b.isLabel ? 1 : 0) - (a.isLabel ? 1 : 0));
  return { ok: true, devices };
}
