'use strict';
// ── iOS wrapper přes libimobiledevice (pouze USB) ─────────────────────
// Vyžaduje binárky idevice_id(.exe), ideviceinfo(.exe), idevicediagnostics(.exe)
// + závislé DLL/dylib. Hledá je v PATH/, ios/ nebo vedle .exe.
// Na Windows je navíc nutné mít nainstalované Apple Mobile Device ovladače (iTunes).
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

let TOOLS = {}; // { idevice_id, ideviceinfo, idevicediagnostics }
let BASE_DIRS = [];
let AVAILABLE = false;

function findUnder(dir, exe, depth) {
  // omezené rekurzivní hledání souboru exe pod složkou dir
  if (depth < 0) return null;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return null; }
  // nejdřív soubory v této úrovni
  for (const e of entries) {
    if (!e.isDirectory() && e.name.toLowerCase() === exe.toLowerCase()) return path.join(dir, e.name);
  }
  // pak podsložky
  for (const e of entries) {
    if (e.isDirectory()) {
      const hit = findUnder(path.join(dir, e.name), exe, depth - 1);
      if (hit) return hit;
    }
  }
  return null;
}

function resolveTool(name) {
  const exe = process.platform === 'win32' ? name + '.exe' : name;
  for (const base of BASE_DIRS) {
    // přímé umístění
    for (const cand of [
      path.join(base, 'PATH', exe),
      path.join(base, 'ios', exe),
      path.join(base, exe),
    ]) {
      try { if (fs.existsSync(cand)) return cand; } catch (_) {}
    }
    // i v podsložkách ios\ a PATH\ (kdyby uživatel rozbalil zip do podsložky)
    for (const sub of ['ios', 'PATH']) {
      const hit = findUnder(path.join(base, sub), exe, 3);
      if (hit) return hit;
    }
  }
  return null;
}

function initIos(baseDirs) {
  BASE_DIRS = baseDirs || [];
  TOOLS = {
    idevice_id: resolveTool('idevice_id'),
    ideviceinfo: resolveTool('ideviceinfo'),
    idevicediagnostics: resolveTool('idevicediagnostics'),
    idevicepair: resolveTool('idevicepair'),
  };
  AVAILABLE = !!(TOOLS.idevice_id && TOOLS.ideviceinfo);
  return AVAILABLE;
}

function isAvailable() { return AVAILABLE; }

function run(toolPath, args, timeoutMs = 12000) {
  return new Promise((resolve) => {
    if (!toolPath) return resolve({ code: -1, stdout: '', stderr: 'tool-missing' });
    let out = '', err = '', done = false, child;
    try { child = spawn(toolPath, args, { windowsHide: true }); }
    catch (e) { return resolve({ code: -1, stdout: '', stderr: String(e) }); }
    const timer = setTimeout(() => { if (!done) { try { child.kill('SIGKILL'); } catch (_) {} } }, timeoutMs);
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', e => { if (done) return; done = true; clearTimeout(timer); resolve({ code: -1, stdout: out, stderr: String(e) }); });
    child.on('close', code => { if (done) return; done = true; clearTimeout(timer); resolve({ code, stdout: out.trim(), stderr: err.trim() }); });
  });
}

// Ověření spárování. Původní verze používala `ideviceinfo -k DeviceName` –
// jenže DeviceName lockdownd vrací i NESPÁROVANÉMU počítači. iPhone tak prošel
// jako důvěřovaný, ale SerialNumber a IMEI (chráněné klíče) se pak vrátily
// prázdné a aplikace místo nich zobrazila UDID/ECID. Proto se ptáme přímo
// idevicepair, a když není k dispozici, testujeme na chráněném klíči.
async function isPaired(udid) {
  if (TOOLS.idevicepair) {
    const r = await run(TOOLS.idevicepair, ['-u', udid, 'validate'], 8000);
    const txt = (r.stdout || '') + ' ' + (r.stderr || '');
    if (/success/i.test(txt)) return true;
    if (/no trusted pairing|not paired|invalid.*pairing|please accept the trust/i.test(txt)) return false;
    // jiná chyba (např. zamčený telefon) → rozhodne fallback níž
  }
  const t = await run(TOOLS.ideviceinfo, ['-u', udid, '-k', 'SerialNumber'], 8000);
  return !!(t.code === 0 && (t.stdout || '').trim());
}

// seznam připojených iPhonů → [{ udid, state }]
// state: 'device' (spárováno) | 'unauthorized' (připojen, ale netrustnuto/zamčen)
async function devices() {
  if (!AVAILABLE) return [];
  const r = await run(TOOLS.idevice_id, ['-l']);
  const udids = (r.stdout || '').split('\n').map(s => s.trim()).filter(Boolean);
  const out = [];
  for (const udid of udids) {
    out.push({ udid, state: (await isPaired(udid)) ? 'device' : 'unauthorized' });
  }
  return out;
}

// načte konkrétní klíč
async function info(udid, key, domain) {
  const args = ['-u', udid];
  if (domain) args.push('-q', domain);
  if (key) args.push('-k', key);
  const r = await run(TOOLS.ideviceinfo, args);
  return r.code === 0 ? (r.stdout || '').trim() : '';
}

// načte všechny klíče domény jako objekt (-x XML nebo plain key: value)
async function infoAll(udid, domain) {
  const args = ['-u', udid];
  if (domain) args.push('-q', domain);
  const r = await run(TOOLS.ideviceinfo, args);
  const d = {};
  for (const line of (r.stdout || '').split('\n')) {
    const i = line.indexOf(':');
    if (i > -1) d[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return d;
}

// diagnostika (baterie apod.) – nemusí fungovat na novějších iOS
async function diagnostics(udid, type) {
  if (!TOOLS.idevicediagnostics) return '';
  const r = await run(TOOLS.idevicediagnostics, ['-u', udid, 'ioregentry', type], 12000);
  return r.code === 0 ? r.stdout : '';
}

module.exports = { initIos, isAvailable, devices, isPaired, info, infoAll, diagnostics };
