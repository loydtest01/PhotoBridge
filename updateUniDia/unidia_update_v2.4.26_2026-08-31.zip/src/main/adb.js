'use strict';
// ── ADB wrapper (pouze USB) ───────────────────────────────────────────
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

let ADB_PATH = null;

function resolveAdb(baseDirs) {
  const exe = process.platform === 'win32' ? 'adb.exe' : 'adb';
  for (const base of baseDirs) {
    for (const cand of [path.join(base, 'PATH', exe), path.join(base, exe)]) {
      try { if (fs.existsSync(cand)) return cand; } catch (_) {}
    }
  }
  return exe;
}

function initAdb(baseDirs) {
  ADB_PATH = resolveAdb(baseDirs);
  return ADB_PATH;
}

function adb(args, timeoutMs = 12000) {
  return new Promise((resolve) => {
    let out = '', err = '', done = false;
    let child;
    try { child = spawn(ADB_PATH, args, { windowsHide: true }); }
    catch (e) { return resolve({ code: -1, stdout: '', stderr: String(e) }); }
    const timer = setTimeout(() => { if (!done) { try { child.kill('SIGKILL'); } catch (_) {} } }, timeoutMs);
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', e => { if (done) return; done = true; clearTimeout(timer); resolve({ code: -1, stdout: out, stderr: String(e) }); });
    child.on('close', code => { if (done) return; done = true; clearTimeout(timer); resolve({ code, stdout: out.trim(), stderr: err.trim() }); });
  });
}

// ── ADB server: startovat JEDNOU, ne při každém dotazu ───────────────
// Původně se `adb start-server` spouštěl při každém `devices()`, tj. každé
// 3 s z watcheru → ~29 000 procesů denně. To je hlavní podezřelý u toho,
// že po dni běhu přestane detekce fungovat (vyčerpané handly/procesy).
let serverPromise = null;
let ADB_HEALTHY = true;      // false = spawn adb.exe selhal (ne „žádný telefon")

async function startServer() {
  if (!serverPromise) serverPromise = adb(['start-server'], 20000);
  const r = await serverPromise;
  if (r.code === -1) { serverPromise = null; ADB_HEALTHY = false; }
  return r;
}

// tvrdý restart adb serveru – po probuzení PC, po chybě, ručně
async function resetServer() {
  serverPromise = null;
  await adb(['kill-server'], 10000);
  ADB_HEALTHY = true;
  return startServer();
}

function healthy() { return ADB_HEALTHY; }

async function shell(serial, ...cmd) {
  const r = await adb(['-s', serial, 'shell', ...cmd]);
  return r.code === 0 || r.stdout ? r.stdout : '';
}

async function getprop(serial, key) {
  return ((await shell(serial, 'getprop', key)) || '').trim();
}

async function devices() {
  await startServer();
  const r = await adb(['devices']);
  const res = [];
  // Rozliš „adb běží, ale nic není připojeno" od „adb.exe vůbec nejde spustit".
  // Bez toho se rozbité adb tváří stejně jako prázdný stůl a nikdy se neopraví.
  if (r.code === -1) { ADB_HEALTHY = false; serverPromise = null; throw new Error('adb-spawn-failed: ' + r.stderr); }
  ADB_HEALTHY = true;
  if (!r.stdout) return res;
  for (const l of r.stdout.split('\n').slice(1)) {
    const parts = l.trim().split('\t');
    if (parts.length === 2) res.push({ serial: parts[0].trim(), state: parts[1].trim() });
  }
  return res;
}

async function deviceSerials() {
  return (await devices()).filter(d => d.state === 'device').map(d => d.serial);
}

// restart do režimu: '' (normální) | 'download' (Odin)
// Recovery a bootloader vyhozeny – na servisních kusech stejně nefungovaly
// a byla to jen možnost, jak se ukliknout.
const REBOOT_MODES = ['', 'download'];
async function reboot(serial, mode) {
  const m = REBOOT_MODES.includes(mode || '') ? (mode || '') : '';
  const args = ['-s', serial, 'reboot'];
  if (m) args.push(m);
  const r = await adb(args, 15000);
  return r.code === 0;
}

// instalace APK do telefonu
async function installApk(serial, apkPath) {
  const r = await adb(['-s', serial, 'install', '-r', '-g', apkPath], 120000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: /success/i.test(txt), out: txt.trim() };
}

// odinstalace balíčku z telefonu
async function uninstallApk(serial, pkg) {
  const r = await adb(['-s', serial, 'uninstall', pkg], 30000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: /success/i.test(txt), out: txt.trim() };
}

// spustit nainstalovanou aplikaci (component = "pkg/.Activity")
async function launchApp(serial, component) {
  const r = await adb(['-s', serial, 'shell', 'am', 'start', '-n', component], 15000);
  const txt = (r.stdout || '') + (r.stderr || '');
  return { ok: !/error|does not exist|unable/i.test(txt), out: txt.trim() };
}

// stáhnout result.json z testovací APK (zkusí run-as i app-specific úložiště)
async function pullTestJson(serial, pkg) {
  // 1) interní přes run-as (debug APK)
  let out = (await shell(serial, 'run-as', pkg, 'cat', 'files/result.json')) || '';
  if (out.includes('"app"')) return out;
  // 2) app-specific externí úložiště
  out = (await shell(serial, 'cat', `/sdcard/Android/data/${pkg}/files/result.json`)) || '';
  if (out.includes('"app"')) return out;
  return '';
}

function adbPath() { return ADB_PATH; }
module.exports = { initAdb, adbPath, adb, shell, getprop, devices, deviceSerials, startServer, resetServer, healthy, reboot, installApk, uninstallApk, launchApp, pullTestJson };
