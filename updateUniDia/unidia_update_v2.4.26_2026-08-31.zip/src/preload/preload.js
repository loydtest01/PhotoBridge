'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // zařízení (sjednocené Android + iOS)
  devicesList: () => ipcRenderer.invoke('devices:list'),
  readDevice: (id, platform) => ipcRenderer.invoke('device:read', { id, platform }),
  saveRecord: (info, phase) => ipcRenderer.invoke('record:save', { info, phase }),
  search: q => ipcRenderer.invoke('search', q),

  // diagnostika
  autoNames: platform => ipcRenderer.invoke('diag:autoNames', platform),
  detect: (id, platform) => ipcRenderer.invoke('diag:detect', { id, platform }),
  diagAuto: opts => ipcRenderer.invoke('diag:auto', opts),
  diagCancel: () => ipcRenderer.invoke('diag:cancel'),
  diagTrigger: (id, platform, action) => ipcRenderer.invoke('diag:trigger', { id, platform, action }),

  // report
  reportPdf: payload => ipcRenderer.invoke('report:pdf', payload),
  reportPrint: payload => ipcRenderer.invoke('report:print', payload),
  reportZakazka: (payload, job) => ipcRenderer.invoke('report:zakazka', { payload, job }),

  // nastavení + tapety
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: patch => ipcRenderer.invoke('settings:set', patch),
  tapetyList: () => ipcRenderer.invoke('tapety:list'),
  tapetaUrl: name => ipcRenderer.invoke('tapety:url', name),
  pickFolder: () => ipcRenderer.invoke('dialog:pickFolder'),
  openFolder: which => ipcRenderer.invoke('open:folder', which),
  iosAutoSetup: () => ipcRenderer.invoke('ios:autosetup'),
  openUrl: url => ipcRenderer.invoke('open:url', url),
  reboot: (id, platform, mode) => ipcRenderer.invoke('device:reboot', { id, platform, mode }),
  finishSetup: (id, platform) => ipcRenderer.invoke('device:finishSetup', { id, platform }),
  usbIds: () => ipcRenderer.invoke('usb:ids'),
  usbSamsungModes: () => ipcRenderer.invoke('usb:samsungModes'),
  apkList: () => ipcRenderer.invoke('apk:list'),
  apkInstall: (id, file) => ipcRenderer.invoke('apk:install', { id, file }),
  apkUninstall: (id, pkg) => ipcRenderer.invoke('apk:uninstall', { id, pkg }),
  appVersion: () => ipcRenderer.invoke('app:version'),
  androidCheck: () => ipcRenderer.invoke('android:check'),
  usbCheck: () => ipcRenderer.invoke('usb:check'),
  toolsFetch: (kind) => ipcRenderer.invoke('tools:fetch', { kind }),
  driversCheck: () => ipcRenderer.invoke('drivers:check'),
  osDark: () => ipcRenderer.invoke('theme:osDark'),
  onOsThemeChanged: (cb) => ipcRenderer.on('theme:osChanged', (_e, dark) => cb(dark)),
  updateCheck: () => ipcRenderer.invoke('update:check'),
  updateApply: () => ipcRenderer.invoke('update:apply'),
  onUpdateProgress: (cb) => ipcRenderer.on('update:progress', (_e, d) => cb(d)),
  onUpdateAvailable: (cb) => ipcRenderer.on('update:available', (_e, d) => cb(d)),
  testLaunch: id => ipcRenderer.invoke('test:launch', { id }),
  testPull: id => ipcRenderer.invoke('test:pull', { id }),
  hide: () => ipcRenderer.invoke('app:hide'),

  // události z main procesu
  onProgress: cb => ipcRenderer.on('diag:progress', (_e, d) => cb(d)),
  onResult: cb => ipcRenderer.on('diag:result', (_e, d) => cb(d)),
  onNotify: cb => ipcRenderer.on('notify', (_e, d) => cb(d)),
  onDevicesList: cb => ipcRenderer.on('devices:list', (_e, d) => cb(d)),
  onDeviceInfo: cb => ipcRenderer.on('device:info', (_e, d) => cb(d)),
  onDeviceGone: cb => ipcRenderer.on('device:gone', (_e, d) => cb(d)),
  onRecordSaved: cb => ipcRenderer.on('record:saved', (_e, d) => cb(d)),
});
