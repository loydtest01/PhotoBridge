=== Podpora iPhone / iOS – nástroje libimobiledevice ===

NEJSNAZŠÍ CESTA:
V aplikaci jdi do Nastavení → "Nástroje pro iPhone (iOS)" → tlačítko
"🔎 Najít a nastavit". UniDia prohledá PC (3uTools, iMazing, iTools,
Apple ovladač) a zkopíruje nalezené binárky sem do složky ios\.
Pak vypíše, co případně ještě chybí.

CO JE POTŘEBA NA WINDOWS:
1) Apple Mobile Device Support (ovladač + usbmux)
   - nainstaluj iTunes z apple.com (ne z Microsoft Store).
   - bez něj Windows iPhone přes USB "nevidí". iTunes ale neobsahuje
     samotné CLI nástroje (ideviceinfo.exe …), jen ovladač.

2) Binárky libimobiledevice (.exe + .dll)
   - bývají součástí 3uTools / iMazing / iTools – pokud je máš nainstalované,
     tlačítko v aplikaci je najde a zkopíruje samo.
   - nebo je stáhni ručně (GitHub release "libimobiledevice-win32") a dej sem:
       idevice_id.exe, ideviceinfo.exe, idevicediagnostics.exe
       + všechny doprovodné .dll (libimobiledevice, libusbmuxd, libplist,
         openssl/libcrypto, libxml2, iconv, zlib, winpthread…)

3) Na telefonu po připojení USB potvrď "Důvěřovat tomuto počítači" a odemkni iPhone.

CO UNIDIA Z iPHONU PŘEČTE AUTOMATICKY:
   model, iOS verze + build, sériové číslo, IMEI/IMEI2, UDID, kapacita úložiště,
   stav aktivace / Find My (aktivační zámek), Wi-Fi/BT MAC,
   baterie (jen na starších iOS).

CO U iPHONU NEJDE (a je proto RUČNÍ):
   spuštění kamery, repro, vibrací apod. – iOS nedovolí vzdálené ovládání přes USB.
