'use strict';
// ── UniDia auto-update z GitHubu ───────────────────────────────────────
// Sleduje složku updateUniDia v repu loydtaest01/PhotoBridge (stejné jako
// PhotoBridge, jen jiná složka). Hledá ZIPy pojmenované:
//     unidia_update_vX.Y.Z_YYYY-MM-DD.zip   (verze povinná)
// Nejnovější verzi (vyšší než aktuální) stáhne, rozbalí a přepíše soubory
// aplikace, pak restartuje přes .bat (čeká na konec procesu).
const { app } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const { spawn } = require('child_process');

// ── konfigurace (uprav, pokud bude repo jiné) ──
const GH_OWNER  = 'loydtest01';
const GH_REPO   = 'PhotoBridge';
const GH_BRANCH = 'main';
const GH_FOLDER = 'updateUniDia';
const SLUG      = 'unidia';

let winRef = null;
function setWin(w) { winRef = w; }
function progress(pct, msg) { try { if (winRef && !winRef.isDestroyed()) winRef.webContents.send('update:progress', { pct, msg }); } catch (_) {} }

// ── HTTPS GET (JSON nebo buffer), 1 redirect ──
function httpsGet(url, headers, asBuffer) {
  return new Promise((resolve, reject) => {
    const opts = { headers: Object.assign({ 'User-Agent': 'UniDia-Updater' }, headers || {}) };
    https.get(url, opts, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307) && res.headers.location) {
        res.resume();
        return httpsGet(res.headers.location, headers, asBuffer).then(resolve, reject);
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = [];
      res.on('data', d => chunks.push(d));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        resolve(asBuffer ? buf : buf.toString('utf8'));
      });
    }).on('error', reject);
  });
}

// ── verze ──
function currentVersion() { try { return app.getVersion(); } catch (_) { return '0.0.0'; } }
function parseName(name) {
  const m = /^unidia_update_v(\d+(?:\.\d+)*)(?:_(\d{4}-\d{2}-\d{2}))?\.zip$/i.exec(name);
  if (!m) return null;
  return { name, ver: m[1], date: m[2] || '' };
}
function cmpVer(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x - y;
  }
  return 0;
}

// ── seznam ZIPů na GitHubu ──
async function listGithub(pat) {
  const url = `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${GH_FOLDER}?ref=${GH_BRANCH}`;
  const headers = { 'Accept': 'application/vnd.github+json' };
  if (pat) headers['Authorization'] = 'token ' + pat;
  let json;
  try { json = JSON.parse(await httpsGet(url, headers, false)); }
  catch (e) { throw new Error('GitHub nedostupný: ' + e.message); }
  if (!Array.isArray(json)) return [];
  const out = [];
  for (const it of json) {
    if (it.type !== 'file' || !/\.zip$/i.test(it.name)) continue;
    const p = parseName(it.name);
    if (p) out.push(Object.assign(p, { url: it.download_url }));
  }
  out.sort((a, b) => cmpVer(b.ver, a.ver) || (b.date || '').localeCompare(a.date || ''));
  return out;
}

// ── kontrola (bez stažení) ──
async function checkForUpdates(pat) {
  const cur = currentVersion();
  const list = await listGithub(pat || '');
  const newest = list[0] || null;
  const hasUpdate = !!(newest && cmpVer(newest.ver, cur) > 0);
  return { current: cur, latest: newest ? newest.ver : null, name: newest ? newest.name : null, url: newest ? newest.url : null, hasUpdate };
}

// ── rozbalení přes PowerShell Expand-Archive (bez extra závislostí) ──
function expandZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    try { fs.rmSync(destDir, { recursive: true, force: true }); } catch (_) {}
    try { fs.mkdirSync(destDir, { recursive: true }); } catch (_) {}
    const ps = `Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${destDir}' -Force`;
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true });
    let err = '';
    p.stderr.on('data', d => err += d);
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error('Expand-Archive selhal: ' + err)));
  });
}

// ── stažení + aplikace + restart ──
async function downloadAndApply(pat) {
  const info = await checkForUpdates(pat);
  if (!info.hasUpdate) return { ok: false, error: 'Žádná novější verze.' };
  progress(5, 'Stahuji ' + info.name + '…');
  const buf = await httpsGet(info.url, pat ? { 'Authorization': 'token ' + pat } : {}, true);
  const tmpZip = path.join(os.tmpdir(), info.name);
  fs.writeFileSync(tmpZip, buf);
  progress(40, 'Rozbaluji…');
  const tmpExtract = path.join(os.tmpdir(), SLUG + '_pending');
  await expandZip(tmpZip, tmpExtract);

  progress(70, 'Připravuji instalaci…');
  const targetDir = app.isPackaged
    ? path.join(path.dirname(app.getPath('exe')), 'resources', 'app')
    : path.resolve(__dirname, '..', '..');

  // umíme do cíle zapsat? (Program Files bez správce = ne)
  let writable = true;
  try {
    const t = path.join(targetDir, '.wtest_' + Date.now());
    fs.writeFileSync(t, 'x'); fs.rmSync(t, { force: true });
  } catch (_) { writable = false; }

  progress(90, 'Restartuji…');
  // Kopírování i restart provede helper až PO ukončení appky (soubory pak
  // nejsou zamčené). Když cíl není zapisovatelný (Program Files), spustí se
  // helper přes UAC (správce). Celé skrytě, žádná černá okna.
  const stamp = Date.now();
  const batPath = path.join(os.tmpdir(), SLUG + '_apply_' + stamp + '.bat');
  const vbsPath = path.join(os.tmpdir(), SLUG + '_apply_' + stamp + '.vbs');
  const lines = ['@echo off', 'timeout /t 2 /nobreak >nul'];
  let launch;
  if (app.isPackaged) {
    const exe = app.getPath('exe');
    lines.push(`taskkill /F /IM "${path.basename(exe)}" /T >nul 2>&1`);
    lines.push('timeout /t 1 /nobreak >nul');
    launch = `"${exe}"`;
  } else {
    launch = `"${process.execPath}" "${targetDir}"`;
  }
  lines.push(`robocopy "${tmpExtract}" "${targetDir}" /E /NFL /NDL /NJH /NJS /NP /R:2 /W:1 >nul`);
  lines.push(`rmdir /S /Q "${tmpExtract}" >nul 2>&1`);
  lines.push(`del "${tmpZip}" >nul 2>&1`);
  lines.push(`start "" ${launch}`);
  lines.push(`del "${vbsPath}" >nul 2>&1`);
  lines.push('del "%~f0" >nul 2>&1');
  let started = false;
  try {
    fs.writeFileSync(batPath, lines.join('\r\n'), 'utf8');
    if (writable) {
      const vbs = 'CreateObject("WScript.Shell").Run "cmd /c ""' + batPath + '""", 0, False';
      fs.writeFileSync(vbsPath, vbs, 'utf8');
      spawn('wscript.exe', [vbsPath], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      started = true;
    } else {
      // potřeba správce → UAC; elevujeme cmd.exe s batem (elevace samotného .bat
      // Windows někdy tiše neprovedou → UAC by nevyskočilo)
      const ps = `Start-Process -FilePath 'cmd.exe' -ArgumentList '/c "${batPath}"' -Verb RunAs -WindowStyle Hidden`;
      spawn('powershell.exe', ['-NoProfile', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      started = true;
    }
  } catch (e) {
    try { app.relaunch(); app.exit(0); } catch (_) {}
    return { ok: false, error: String(e.message || e) };
  }
  progress(100, 'Hotovo – restartuji.');
  // U zapisovatelného cíle appku ukončíme rovnou; u UAC variantu necháme
  // ukončení na helperu (až uživatel potvrdí správce – při „Ne" appka zůstane).
  if (writable && started) setTimeout(() => { try { app.exit(0); } catch (_) {} }, 700);
  return { ok: true, version: info.latest, elevated: !writable };
}

module.exports = { setWin, checkForUpdates, downloadAndApply, currentVersion, GH_OWNER, GH_REPO, GH_FOLDER };
