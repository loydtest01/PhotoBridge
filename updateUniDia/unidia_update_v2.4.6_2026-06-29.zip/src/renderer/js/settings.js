'use strict';
// ── Záložka Nastavení ────────────────────────────────────────────────
(function () {
  const TOGGLES = [
    ['swStartup',    'startupWindows'],
    ['swStartMin',   'startMinimized'],
    ['swAutoUpdate', 'autoUpdate'],
    ['swAutoUpdateMidnight', 'autoUpdateMidnight'],
    ['swAutoload',   'autoLoadOnConnect'],
    ['swDisableDev', 'disableDevModeAfterTest'],
    ['swAdvanced',   'advancedActions'],
  ];

  SD.applySettings = () => {
    const s = SD.settings || {};
    for (const [el, key] of TOGGLES) {
      SD.$(el).classList.toggle('on', !!s[key]);
    }
    SD.$('inUpload').value = s.uploadScanPath || '';
    if (SD.$('selLang')) SD.$('selLang').value = s.lang || 'cs';
    populateWallpapers(s.wallpaper);
    // režim vzhledu
    if (SD.$('selThemeMode')) {
      SD.$('selThemeMode').value = s.themeMode || 'manual';
      populateWpSelect('selLightWp', s.lightWallpaper);
      populateWpSelect('selDarkWp', s.darkWallpaper);
      if (SD.$('inLightFrom')) SD.$('inLightFrom').value = s.lightFrom || '06:00';
      if (SD.$('inLightTo')) SD.$('inLightTo').value = s.lightTo || '18:00';
      updateThemeRows(s.themeMode || 'manual');
    }
  };

  function updateThemeRows(mode) {
    const ld = SD.$('rowThemeLD'), tm = SD.$('rowThemeTime');
    if (ld) ld.style.display = (mode === 'light' || mode === 'dark' || mode === 'windows' || mode === 'schedule') ? 'flex' : 'none';
    if (tm) tm.style.display = (mode === 'schedule') ? 'flex' : 'none';
  }

  async function populateWpSelect(id, current) {
    const sel = SD.$(id);
    if (!sel) return;
    let list = [];
    try { list = await window.api.tapetyList(); } catch (_) {}
    const cur = (current !== undefined) ? current : sel.value;
    sel.innerHTML = `<option value="">(žádná)</option>` +
      list.map(f => `<option${f === cur ? ' selected' : ''}>${f}</option>`).join('');
  }

  async function populateWallpapers(current) {
    const sel = SD.$('selWallpaper');
    if (!sel) return;
    let list = [];
    try { list = await window.api.tapetyList(); } catch (_) {}
    const cur = (current !== undefined) ? current : sel.value;
    sel.innerHTML = `<option value="">(žádná)</option>` +
      list.map(f => `<option${f === cur ? ' selected' : ''}>${f}</option>`).join('');
  }
  SD.populateWallpapers = () => populateWallpapers(SD.settings ? SD.settings.wallpaper : '');

  for (const [el, key] of TOGGLES) {
    const node = SD.$(el);
    if (!node) continue;
    node.addEventListener('click', async () => {
      const on = !node.classList.contains('on');
      node.classList.toggle('on', on);
      SD.settings = await window.api.setSettings({ [key]: on });
      if (key === 'advancedActions' && SD.applyAdvanced) SD.applyAdvanced();
      SD.toast('Nastavení uloženo', '');
    });
  }

  // bezpečné navázání – chybějící prvek neshodí zbytek souboru
  const onClick = (id, fn) => { const el = SD.$(id); if (el) el.addEventListener('click', fn); };

  // ── aktualizace ──
  async function showVersion() {
    const m = SD.$('updMsg'); if (!m) return;
    try { const v = await window.api.appVersion(); m.textContent = 'Nainstalováno: v' + v; } catch (_) {}
  }
  showVersion();

  if (window.api.onUpdateProgress) window.api.onUpdateProgress((d) => {
    const m = SD.$('updMsg'); if (m && d) m.textContent = (d.msg || '') + (d.pct != null ? ' (' + d.pct + '%)' : '');
  });
  async function applyUpdateFlow() {
    const m = SD.$('updMsg');
    if (m) m.textContent = (SD.lang === 'en' ? 'Downloading…' : 'Stahuji…');
    const a = await window.api.updateApply();
    if (a && a.ok) {
      if (m) m.textContent = a.dev
        ? (SD.lang === 'en' ? '✓ Installed (DEV – restart manually).' : '✓ Nainstalováno (DEV – restartuj ručně).')
        : (SD.lang === 'en' ? '✓ Installed – restarting…' : '✓ Nainstalováno – restartuji…');
    } else {
      if (m) m.textContent = '✗ ' + ((a && a.error) || (SD.lang === 'en' ? 'install failed' : 'instalace selhala'));
    }
  }

  if (window.api.onUpdateAvailable) window.api.onUpdateAvailable((r) => {
    if (r && r.hasUpdate) {
      const m = SD.$('updMsg'); if (m) m.textContent = '🔔 v' + r.latest;
      const msg = (SD.lang === 'en')
        ? 'Version v' + r.latest + ' is available (you have v' + (r.current || '?') + ').\n\nUpdate now? The app will restart after install.'
        : 'Je k dispozici verze v' + r.latest + ' (máš v' + (r.current || '?') + ').\n\nAktualizovat teď? Aplikace se po instalaci restartuje.';
      if (window.confirm(msg)) applyUpdateFlow();
      else if (m) m.textContent = (SD.lang === 'en' ? 'v' + r.latest + ' available (not installed).' : 'K dispozici v' + r.latest + ' (neinstalováno).');
    }
  });

  onClick('btnCheckUpdate', async () => {
    const m = SD.$('updMsg'); if (m) m.textContent = SD.lang === 'en' ? 'Checking…' : 'Kontroluji…';
    const r = await window.api.updateCheck();
    if (!r || r.error) { if (m) m.textContent = '✗ ' + ((r && r.error) || (SD.lang === 'en' ? 'check failed' : 'kontrola selhala')); return; }
    if (!r.hasUpdate) { if (m) m.textContent = (SD.lang === 'en' ? '✓ You have the latest version (v' : '✓ Máš nejnovější verzi (v') + r.current + ').'; return; }
    const msg = (SD.lang === 'en')
      ? 'Version v' + r.latest + ' is available (you have v' + r.current + ').\n\nDownload and install? The app will restart after install.'
      : 'Je k dispozici verze v' + r.latest + ' (máš v' + r.current + ').\n\nStáhnout a nainstalovat? Aplikace se po instalaci restartuje.';
    if (!window.confirm(msg)) { if (m) m.textContent = (SD.lang === 'en' ? 'v' + r.latest + ' available (not installed).' : 'K dispozici v' + r.latest + ' (neinstalováno).'); return; }
    await applyUpdateFlow();
  });


  let upT;
  if (SD.$('inUpload')) SD.$('inUpload').addEventListener('input', () => {
    clearTimeout(upT);
    upT = setTimeout(async () => {
      SD.settings = await window.api.setSettings({ uploadScanPath: SD.$('inUpload').value.trim() });
    }, 600);
  });

  // Procházet… → výběr složky zakázek přes Průzkumník
  onClick('btnBrowseUpload', async () => {
    const r = await window.api.pickFolder();
    if (r && r.ok) {
      SD.$('inUpload').value = r.path;
      SD.settings = await window.api.setSettings({ uploadScanPath: r.path });
      SD.toast('Složka zakázek nastavena', r.path);
    }
  });
  // Otevřít složku zakázek
  onClick('btnOpenUpload', async () => {
    const r = await window.api.openFolder('upload');
    if (r && !r.ok) SD.toast('Nelze otevřít', r.error || 'Složka nenalezena');
  });
  // Otevřít složku tapet
  onClick('btnOpenTapety', async () => {
    const r = await window.api.openFolder('tapety');
    if (r && !r.ok) SD.toast('Nelze otevřít', r.error || '');
  });
  // Obnovit seznam tapet (po přidání souboru do složky)
  onClick('btnRefreshTapety', async () => {
    await populateWallpapers(SD.settings ? SD.settings.wallpaper : '');
    await populateWpSelect('selLightWp', SD.settings ? SD.settings.lightWallpaper : '');
    await populateWpSelect('selDarkWp', SD.settings ? SD.settings.darkWallpaper : '');
    SD.toast('Seznam tapet obnoven', '');
  });

  // ── iPhone nástroje: najít a nastavit ──
  const iosBtn = SD.$('btnIosSetup');
  const iosRep = SD.$('iosSetupReport');
  if (SD.$('btnOpenIos')) SD.$('btnOpenIos').addEventListener('click', async () => {
    const r = await window.api.openFolder('ios');
    if (r && !r.ok) SD.toast('Nelze otevřít', r.error || '');
  });
  if (iosBtn) iosBtn.addEventListener('click', async () => {
    iosBtn.disabled = true;
    const orig = iosBtn.textContent; iosBtn.textContent = '⏳ Hledám na disku…';
    iosRep.style.display = '';
    iosRep.innerHTML = 'Prohledávám PC (3uTools, iMazing, iTools, Apple ovladač)…';
    try {
      const res = await window.api.iosAutoSetup();
      if (!res || !res.ok) { iosRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + ((res && res.error) || 'neznámá') + '</span>'; }
      else renderIosReport(res.report);
    } catch (e) {
      iosRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + e + '</span>';
    }
    iosBtn.disabled = false; iosBtn.textContent = orig;
  });

  function renderIosReport(r) {
    const yes = '<span style="color:var(--ok)">✓</span>';
    const no = '<span style="color:var(--fail)">✗</span>';
    const line = (ok, txt) => `<div>${ok ? yes : no} ${txt}</div>`;
    let h = '';
    if (r.ready) {
      h += `<div style="color:var(--ok);font-weight:700;margin-bottom:6px">✓ Hotovo – iPhony lze číst.</div>`;
    } else {
      h += `<div style="color:var(--warn);font-weight:700;margin-bottom:6px">⚠ Ještě něco chybí (viz níže).</div>`;
    }
    h += line(r.appleDriver && r.appleDriver.ok, 'Apple Mobile Device Support (ovladač + usbmux)');
    h += line(r.haveExe && r.haveExe['idevice_id.exe'], 'idevice_id.exe');
    h += line(r.haveExe && r.haveExe['ideviceinfo.exe'], 'ideviceinfo.exe');
    h += line(r.haveExe && r.haveExe['idevicediagnostics.exe'], 'idevicediagnostics.exe');
    if (r.dllCount) h += `<div style="color:var(--text-dim)">Zkopírováno ${r.dllCount} závislých DLL${r.copied && r.copied.length ? ' (' + r.copied.length + ' souborů celkem)' : ''}.</div>`;
    if (r.runtime && !r.runtime.ok) h += line(false, 'Spuštění nástroje: ' + (r.runtime.reason || 'selhalo'));

    if (r.missing && r.missing.length) {
      h += `<div style="margin-top:8px;color:var(--warn);font-weight:700">Chybí:</div><ul style="margin:2px 0 0 18px">`;
      for (const m of r.missing) h += `<li>${m}</li>`;
      h += `</ul>`;
    }
    if (r.notes && r.notes.length) {
      h += `<div style="margin-top:8px;color:var(--text-dim);font-size:11.5px">`;
      for (const n of r.notes) h += `<div>• ${n}</div>`;
      h += `</div>`;
    }
    if (r.foundExe && r.foundExe.length) {
      h += `<div style="margin-top:8px;font-size:11px;color:var(--text-dim)">Nalezené nástroje na disku:</div>
        <div style="font-size:10.5px;color:var(--text-dim);max-height:90px;overflow:auto;white-space:pre-wrap;word-break:break-all">${r.foundExe.join('\n')}</div>`;
    }
    // akční tlačítka
    h += `<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">`;
    if (!r.ready) h += `<button class="btn" id="iosDl">📥 Stáhnout nástroje (GitHub)</button>`;
    h += `<button class="btn ghost" id="iosOpenFolder">📁 Otevřít složku ios</button></div>`;
    if (!r.ready) h += `<div style="margin-top:6px;font-size:11px;color:var(--text-dim)">V sekci <b>Assets</b> stáhni soubor končící na <code>-win-x64.zip</code> (ne .nupkg ani Source code), rozbal jeho obsah do složky <code>ios\\</code> (klidně i do podsložky) a klikni znovu na „Najít a nastavit".</div>`;

    iosRep.innerHTML = h;
    const dl = SD.$('iosDl');
    if (dl) dl.onclick = () => window.api.openUrl('https://github.com/libimobiledevice-win32/imobiledevice-net/releases/latest');
    const of = SD.$('iosOpenFolder');
    if (of) of.onclick = () => window.api.openFolder('ios');
  }

  // ── Kontrola Androidu (ADB) ──
  const yesI = '<span style="color:var(--ok)">✓</span>';
  const noI = '<span style="color:var(--fail)">✗</span>';
  const stateLabel = {
    'device': '✓ připraven (čte se)', 'unauthorized': '⚠ nepovolené USB ladění – odemkni telefon a potvrď „Povolit USB ladění"',
    'offline': '⚠ offline – odpoj a znovu připoj kabel', 'no permissions': '⚠ chybí ovladač / práva – nainstaluj USB ovladač',
    'recovery': 'recovery', 'sideload': 'sideload', 'bootloader': 'bootloader', 'host': 'host',
  };
  const aBtn = SD.$('btnAndroidCheck'), aRep = SD.$('androidReport');
  if (aBtn) aBtn.addEventListener('click', async () => {
    aBtn.disabled = true; const o = aBtn.textContent; aBtn.textContent = '⏳ Kontroluji…';
    aRep.style.display = ''; aRep.innerHTML = 'Spouštím ADB…';
    try {
      const r = await window.api.androidCheck();
      let h = '';
      h += `<div>${r.adbFound ? yesI : noI} ADB nalezeno v aplikaci${r.adbPath ? ' <span style="color:var(--text-dim);font-size:11px">(' + r.adbPath + ')</span>' : ''}</div>`;
      h += `<div>${r.serverOk ? yesI : noI} ADB se spustí</div>`;
      if (!r.devices.length) {
        h += `<div style="margin-top:6px;color:var(--warn)">⚠ Žádný telefon přes ADB. Zapni v telefonu <b>Vývojářské možnosti → USB ladění</b> a po připojení potvrď dotaz „Povolit USB ladění". Bez toho čteš jen S/N přes USB (vedlejší kontrola).</div>`;
      } else {
        h += `<div style="margin-top:6px;font-weight:700">Připojené telefony:</div>`;
        for (const d of r.devices) h += `<div>• <b>${d.serial}</b> – ${stateLabel[d.state] || d.state}</div>`;
      }
      if (!r.adbFound) h += `<div style="margin-top:6px;color:var(--fail)">ADB chybí – ve složce aplikace musí být <code>PATH\\adb.exe</code> (u buildu je uvnitř). Když běžíš ze zdrojáků, zkontroluj složku <code>PATH\\</code>.</div>`;
      aRep.innerHTML = h;
    } catch (e) { aRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + e + '</span>'; }
    aBtn.disabled = false; aBtn.textContent = o;
  });

  // ── Kontrola čtení S/N přes USB ──
  const uBtn = SD.$('btnUsbCheck'), uRep = SD.$('usbReport');
  if (uBtn) uBtn.addEventListener('click', async () => {
    uBtn.disabled = true; const o = uBtn.textContent; uBtn.textContent = '⏳ Kontroluji…';
    uRep.style.display = ''; uRep.innerHTML = 'Čtu USB…';
    try {
      const r = await window.api.usbCheck();
      if (!r || !r.ok) { uRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + ((r && r.error) || 'selhalo') + '</span>'; }
      else {
        const withSn = (r.items || []).filter(x => x.value && !x.isApple);
        let h = '';
        if (withSn.length) {
          h += `<div style="color:var(--ok);font-weight:700">✓ Čtení S/N přes USB funguje.</div>`;
          for (const it of withSn) h += `<div>• ${it.brand}: <b>${it.value}</b></div>`;
        } else if ((r.seen || []).length) {
          h += `<div style="color:var(--warn);font-weight:700">⚠ Telefon je na USB vidět, ale nehlásí sériové číslo.</div>`;
          h += `<div style="margin-top:4px;font-size:11.5px;color:var(--text-dim)">Co PC vidí:</div>`;
          for (const s of r.seen) h += `<div style="font-size:11.5px">• ${s.brand} „${s.name}" – S/N: ${s.serial}</div>`;
          h += `<div style="margin-top:8px;color:var(--accent);font-weight:700;font-size:11.5px">Nejčastější příčina: chybí USB ovladač výrobce na tomto PC.</div>
            <div style="font-size:11.5px;color:var(--text-dim)">Když na jiném PC stejný telefon S/N přes USB hlásí a tady ne, je to skoro jistě tím. Windows přečte S/N z USB jen se správným ovladačem.</div>
            <ul style="margin:4px 0 0 18px;font-size:11.5px">
              <li><b>Samsung:</b> nainstaluj <b>Samsung USB Driver for Mobile Phones</b> (nebo Smart Switch / 3uTools).</li>
              <li><b>Ostatní Android:</b> <b>Google USB Driver</b> nebo ovladač výrobce.</li>
              <li>Pak zopakuj čtení – S/N přes USB pak půjde i bez vývojáře (jako na druhém PC).</li>
              <li>Dočasně: když je zapnuté <b>USB ladění</b>, S/N se vezme z ADB (čte se i tak).</li>
            </ul>`;
        } else {
          h += `<div style="color:var(--fail);font-weight:700">✗ Na USB není vidět žádný telefon známé značky.</div>
            <div style="margin-top:4px;font-size:11.5px;color:var(--text-dim)">Zkontroluj kabel (datový, ne jen nabíjecí), USB port a USB ovladač telefonu.</div>`;
        }
        uRep.innerHTML = h;
      }
    } catch (e) { uRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + e + '</span>'; }
    uBtn.disabled = false; uBtn.textContent = o;
  });

  // ── doplnění chybějících součástí (ADB/iOS/APK/ovladač) ──
  const tRep = SD.$('toolsReport');
  async function getTool(kind, btn) {
    if (!btn) return;
    const o = btn.textContent; btn.disabled = true; btn.textContent = '⏳';
    if (tRep) { tRep.style.display = ''; tRep.innerHTML = 'Stahuji…'; }
    try {
      const r = await window.api.toolsFetch(kind);
      if (r && r.ok) {
        if (kind === 'samsungdrv') { if (tRep) tRep.innerHTML = `<span style="color:var(--ok)">✓ Samsung ovladač stažen – spusť instalaci (otevřela se).</span>`; }
        else { if (tRep) tRep.innerHTML = `<span style="color:var(--ok)">✓ ${r.label} staženo → ${r.dir}</span>`; }
        if (kind === 'apk' && SD.refreshApks) SD.refreshApks();
      } else {
        const fn = { adb: 'adb.zip', ios: 'ios.zip', apk: 'unidia-test.apk', samsungdrv: 'samsung-usb-driver.exe' }[kind] || kind;
        if (tRep) tRep.innerHTML = `<span style="color:var(--fail)">✗ ${(r && r.label) || ''}: ${(r && r.error) || 'selhalo'}</span>` +
          `<div style="font-size:11px;color:var(--text-dim);margin-top:4px">Zkontroluj, že na GitHubu existuje <code>updateUniDia/UniDia-distribuce/${fn}</code>.</div>`;
      }
    } catch (e) { if (tRep) tRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + e + '</span>'; }
    btn.disabled = false; btn.textContent = o;
  }
  if (SD.$('btnGetAdb')) SD.$('btnGetAdb').addEventListener('click', () => getTool('adb', SD.$('btnGetAdb')));
  if (SD.$('btnGetIos')) SD.$('btnGetIos').addEventListener('click', () => getTool('ios', SD.$('btnGetIos')));
  if (SD.$('btnGetApk')) SD.$('btnGetApk').addEventListener('click', () => getTool('apk', SD.$('btnGetApk')));
  if (SD.$('btnGetSamsung')) SD.$('btnGetSamsung').addEventListener('click', () => getTool('samsungdrv', SD.$('btnGetSamsung')));

  // ── kontrola ovladačů ──
  const dRep = SD.$('driversReport');
  if (SD.$('btnDriversCheck')) SD.$('btnDriversCheck').addEventListener('click', async () => {
    const b = SD.$('btnDriversCheck'); const o = b.textContent; b.disabled = true; b.textContent = '⏳ Kontroluji…';
    dRep.style.display = ''; dRep.innerHTML = 'Čtu nainstalované ovladače…';
    try {
      const r = await window.api.driversCheck();
      if (!r || r.error) { dRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + ((r && r.error) || 'selhalo') + '</span>'; }
      else {
        const ok = '<span style="color:var(--ok)">✓</span>', no = '<span style="color:var(--fail)">✗</span>';
        let h = '';
        h += `<div>${r.samsung ? ok : no} Samsung USB ovladač ${r.samsung ? '' : '– <b>chybí</b> (kvůli tomu nejde S/N přes USB; stáhni „📥 Samsung ovladač" výše)'}</div>`;
        h += `<div>${r.apple ? ok : no} Apple Mobile Device ovladač ${r.apple ? '' : '– chybí (pro iPhone; nainstaluj iTunes/AMDS)'}</div>`;
        h += `<div>${r.googleAdb ? ok : no} Google/WinUSB ADB ovladač ${r.googleAdb ? '' : '– volitelný (pro ne-Samsung Androidy)'}</div>`;
        if ((r.list || []).length) {
          h += `<div style="margin-top:6px;font-size:11px;color:var(--text-dim)">Nalezené relevantní ovladače:</div>`;
          for (const d of r.list) h += `<div style="font-size:11px">• ${d.provider}: ${d.name}</div>`;
        }
        dRep.innerHTML = h;
      }
    } catch (e) { dRep.innerHTML = '<span style="color:var(--fail)">Chyba: ' + e + '</span>'; }
    b.disabled = false; b.textContent = o;
  });

  SD.$('selWallpaper').addEventListener('change', async () => {
    const name = SD.$('selWallpaper').value;
    SD.settings = await window.api.setSettings({ wallpaper: name });
    if ((SD.settings.themeMode || 'manual') === 'manual') await SD.resolveWallpaper();
    SD.toast('Tapeta změněna', name || '(žádná)');
  });

  // ── jazyk CS/EN ──
  if (SD.$('selLang')) {
    SD.$('selLang').addEventListener('change', async () => {
      const lang = SD.$('selLang').value === 'en' ? 'en' : 'cs';
      SD.settings = await window.api.setSettings({ lang });
      if (SD.applyLang) SD.applyLang(lang);
    });
  }

  // ── režim vzhledu ──
  if (SD.$('selThemeMode')) {
    SD.$('selThemeMode').addEventListener('change', async () => {
      const mode = SD.$('selThemeMode').value;
      SD.settings = await window.api.setSettings({ themeMode: mode });
      updateThemeRows(mode);
      await SD.resolveWallpaper();
    });
  }
  if (SD.$('selLightWp')) {
    SD.$('selLightWp').addEventListener('change', async () => {
      SD.settings = await window.api.setSettings({ lightWallpaper: SD.$('selLightWp').value });
      await SD.resolveWallpaper();
    });
  }
  if (SD.$('selDarkWp')) {
    SD.$('selDarkWp').addEventListener('change', async () => {
      SD.settings = await window.api.setSettings({ darkWallpaper: SD.$('selDarkWp').value });
      await SD.resolveWallpaper();
    });
  }
  if (SD.$('inLightFrom')) {
    SD.$('inLightFrom').addEventListener('change', async () => {
      SD.settings = await window.api.setSettings({ lightFrom: SD.$('inLightFrom').value || '06:00' });
      await SD.resolveWallpaper();
    });
  }
  if (SD.$('inLightTo')) {
    SD.$('inLightTo').addEventListener('change', async () => {
      SD.settings = await window.api.setSettings({ lightTo: SD.$('inLightTo').value || '18:00' });
      await SD.resolveWallpaper();
    });
  }
})();
