'use strict';
// Čtení identity připojeného telefonu z USB deskriptoru – BEZ vývojářského režimu.
// Funguje na Windows přes Get-PnpDevice. Vrací S/N (sériové číslo z USB),
// které telefon hlásí už při zapojení. IMEI takto NELZE získat (je v modemu).
const { execFile } = require('child_process');

// známé VID výrobců telefonů → značka
const VENDORS = {
  '04e8': 'Samsung', '05ac': 'Apple', '18d1': 'Google', '22b8': 'Motorola',
  '2717': 'Xiaomi', '2a70': 'OnePlus/Oppo', '22d9': 'Oppo', '12d1': 'Huawei',
  '1004': 'LG', '0fce': 'Sony', '0bb4': 'HTC', '0b05': 'Asus', '19d2': 'ZTE',
  '17ef': 'Lenovo', '2916': 'Yota', '0e8d': 'MediaTek', '1ebf': 'TCL/Alcatel',
  '2c3f': 'Nothing', '0489': 'Foxconn/Fairphone',
};

function runPowershell(cmd) {
  return new Promise(resolve => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', cmd],
      { timeout: 20000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
      (err, stdout) => resolve(err ? '' : (stdout || '')));
  });
}

// VIDy známých výrobců telefonů pro filtr v PowerShellu
function vidRegex() { return Object.keys(VENDORS).map(v => v.toUpperCase()).join('|'); }

// rozbor InstanceId: USB\VID_04E8&PID_6860\R58N123ABC  → { vid, serial }
function parseInstance(id) {
  const vidM = /VID_([0-9A-Fa-f]{4})/.exec(id || '');
  const vid = vidM ? vidM[1].toLowerCase() : '';
  const parts = String(id).split('\\');
  let serial = parts.length >= 3 ? parts[2] : '';
  // pokud třetí část obsahuje '&', telefon nehlásí vlastní sériové číslo (je to ID portu)
  const reported = serial && !serial.includes('&');
  return { vid, serial: reported ? serial : '', reported };
}

// příslušenství (dongle, myš, audio, disk, monitor…) – NE telefon
const ACCESSORY = /bluetooth|bt-?\d|bt400|dongle|adapt|receiver|mouse|keyboard|webcam|head\s?set|speaker|\baudio\b|\bhub\b|dock|printer|scanner|card\s?reader|\breader\b|wi-?fi|wireless|gamepad|controller|fingerprint|\bups\b|serial|com\s?port|\bdisk\b|storage|volume|\bssd\b|mass\s?storage|monitor|\bdisplay\b/i;
// pozitivní signál, že jde o telefon
const PHONE_HINT = /mobile|\bmtp\b|android|\badb\b|iphone|ipad|composite device|\bphone\b|galaxy|pixel|redmi|poco|oneplus/i;

// Druhá cesta: serial přes MTP/WPD (Shell „System.Devices.SerialNumber").
// Telefon v režimu MTP hlásí S/N i bez vývojářského režimu, i když ho USB
// deskriptor neobsahuje.
async function readMtpSerials() {
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$o=@();$sh=New-Object -ComObject Shell.Application;$pc=$sh.NameSpace(17);" +
    "if($pc){foreach($it in $pc.Items()){try{" +
    "$sn=$it.ExtendedProperty('System.Devices.SerialNumber');" +
    "$o+=[PSCustomObject]@{Name=$it.Name;Type=$it.Type;Serial=[string]$sn}" +
    "}catch{}}}" +
    "$o | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return [];
  let data;
  try { data = JSON.parse(out); } catch (_) { return []; }
  if (!Array.isArray(data)) data = [data];
  return data;
}

function brandFromName(name) {
  const n = String(name || '').toLowerCase();
  if (/samsung|galaxy/.test(n)) return 'Samsung';
  if (/pixel|google/.test(n)) return 'Google';
  if (/xiaomi|redmi|poco/.test(n)) return 'Xiaomi';
  if (/oneplus/.test(n)) return 'OnePlus';
  if (/oppo/.test(n)) return 'Oppo';
  if (/huawei|honor/.test(n)) return 'Huawei';
  if (/motorola|moto/.test(n)) return 'Motorola';
  if (/sony|xperia/.test(n)) return 'Sony';
  if (/nokia|hmd/.test(n)) return 'Nokia';
  if (/iphone|ipad|apple/.test(n)) return 'Apple';
  return 'Telefon';
}
// vypadá záznam jako disk/jednotka (ne telefon)?
const DRIVE_LIKE = /disk|drive|jednotka|svazek|volume|usb drive|\bssd\b|flash|\bcard\b|paměť/i;

async function readUsbIds() {
  if (process.platform !== 'win32') return { ok: false, error: 'Čtení přes USB je jen na Windows.', items: [], seen: [] };
  // Vytáhneme i DEVPKEY_Device_SerialNumber (USB deskriptor iSerialNumber),
  // protože některé telefony nehlásí S/N v InstanceId, ale v deskriptoru ano.
  const cmd =
    "$ErrorActionPreference='SilentlyContinue';" +
    "$vids='" + vidRegex() + "';" +
    "$d=Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB\\*' -and $_.InstanceId -match ('VID_('+$vids+')') };" +
    "($d | ForEach-Object { $sn=(Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_SerialNumber').Data;" +
    "[PSCustomObject]@{ FriendlyName=$_.FriendlyName; InstanceId=$_.InstanceId; Serial=$sn } }) | ConvertTo-Json -Compress";
  const out = await runPowershell(cmd);
  if (!out.trim()) return { ok: true, items: [], seen: [] };

  let data;
  try { data = JSON.parse(out); } catch (_) { return { ok: false, error: 'Neočekávaný výstup systému.', items: [], seen: [] }; }
  if (!Array.isArray(data)) data = [data];

  const raw = [];
  const seen = [];
  for (const d of data) {
    const id = d.InstanceId || '';
    const name = d.FriendlyName || '';
    const parsed = parseInstance(id);
    const vid = parsed.vid;
    if (!VENDORS[vid]) continue;
    // serial: nejdřív z InstanceId (čisté), jinak z USB deskriptoru
    let serial = parsed.serial;
    const devSn = (d.Serial == null ? '' : String(d.Serial)).trim();
    if (!serial && devSn && !devSn.includes('&') && devSn.length >= 4) serial = devSn;
    const reported = !!serial;
    seen.push({ brand: VENDORS[vid], name: name || '(bez názvu)', serial: serial || '(žádné S/N)' });
    if (ACCESSORY.test(name)) continue;
    if (!PHONE_HINT.test(name) && !reported) continue;
    const isApple = vid === '05ac';
    raw.push({ brand: VENDORS[vid], name, isApple, serial: reported ? serial : '', reported });
  }

  // sloučit duplicitní záznamy téhož telefonu: podle značky upřednostnit ten se sériovým číslem
  const byBrand = {};
  for (const it of raw) (byBrand[it.brand] = byBrand[it.brand] || []).push(it);
  const items = [];
  const seenSerial = new Set();
  for (const brand of Object.keys(byBrand)) {
    const list = byBrand[brand];
    const withSn = list.filter(x => x.serial);
    const pick = withSn.length ? withSn : list.slice(0, 1);
    for (const it of pick) {
      const k = it.brand + '|' + (it.serial || it.name);
      if (seenSerial.has(k)) continue; seenSerial.add(k);
      items.push({
        brand: it.brand,
        name: it.name,
        value: it.serial,
        label: it.isApple ? 'UDID' : 'S/N',
        isApple: it.isApple,
        note: it.serial ? '' : 'telefon nehlásí identitu přes USB',
      });
    }
  }
  // Vypadá hodnota jako štítkové S/N (R39K60C0DN, R5CWB1QP4HH)? Tj. začíná
  // písmenem a NENÍ to 16místné hex (interní/USB id čipu jako 23a29ca405017ece).
  const looksLabel = s => /^[A-Z][0-9A-Z]{6,13}$/i.test(String(s || '')) && !/^[0-9a-f]{16,}$/i.test(String(s || ''));
  const score = it => (it.value ? (looksLabel(it.value) ? 2 : 1) : 0);
  items.sort((a, b) => score(b) - score(a));

  // MTP/WPD čteme VŽDY (ne jen když chybí USB serial) – telefon v MTP režimu
  // hlásí často skutečné štítkové S/N, i když USB deskriptor vrací interní hex.
  {
    try {
      const mtp = await readMtpSerials();
      for (const m of mtp) {
        const sn = (m.Serial == null ? '' : String(m.Serial)).trim();
        const nm = m.Name || '';
        const ty = m.Type || '';
        const blob = nm + ' ' + ty;
        if (DRIVE_LIKE.test(blob)) continue;                       // disky/jednotky pryč
        if (/zástupce|shortcut|síť|network|složk|folder/i.test(ty)) continue;  // síťové složky/zástupce pryč
        const looksPhone = brandFromName(nm) !== 'Telefon' || /telefon|phone|portable|mobil/i.test(blob);
        if (!looksPhone) continue;
        seen.push({ brand: brandFromName(nm), name: nm + (ty ? ' [' + ty + ']' : ''), serial: sn || '(žádné S/N)', mtp: true });
        if (!sn || sn.length < 4 || sn.includes('&')) continue;
        const k = 'mtp|' + sn;
        if (seenSerial.has(k)) continue; seenSerial.add(k);
        items.push({ brand: brandFromName(nm), name: nm, value: sn, label: 'S/N', isApple: false, note: '', mtp: true });
      }
    } catch (_) {}
    // znovu seřaď – štítkové S/N (z MTP) nahoru před hex id z deskriptoru
    items.sort((a, b) => score(b) - score(a));
  }

  return { ok: true, items, seen };
}

module.exports = { readUsbIds };
