'use strict';
const { app, BrowserWindow, Tray, Menu, nativeImage, screen, clipboard, nativeTheme } = require('electron');
const path = require('path');
const fs = require('fs');

// ── zachytit pády a zapsat do crash.log ──────────────────────────────
const crashLog = path.join(__dirname, '..', '..', 'crash.log');
function writeLog(type, err) {
  const line = `[${new Date().toISOString()}] ${type}: ${err && (err.stack || err)}\n`;
  try { fs.appendFileSync(crashLog, line); } catch (_) {}
  console.error(line);
}
process.on('uncaughtException',  err => { writeLog('uncaughtException', err);  });
process.on('unhandledRejection', err => { writeLog('unhandledRejection', err); });

const adb = require('./adb');
const ios = require('./ios');
const devices = require('./devices');
const deviceInfo = require('./deviceInfo');
const excel = require('./excel');
const settings = require('./settings');
const usbid = require('./usbid');
const updater = require('./updater');
const { registerIpc, setMainWindow } = require('./ipc');

let win = null;
let notifWin = null;
let tray = null;
let quitting = false;

// ── stav watcheru ──
const known = new Map();   // id -> { platform, state, infoRead:bool }
let notifDevice = null;    // { id, platform, info }

// zapisovatelný kořen pro data (záznamy, tapety):
//  - vývoj: složka projektu
//  - portable .exe: složka, kde leží portable .exe (PORTABLE_EXECUTABLE_DIR)
//  - instalace (NSIS): %APPDATA%\UniDia (Program Files není zapisovatelný)
function dataRoot() {
  if (!app.isPackaged) return path.join(__dirname, '..', '..');
  if (process.env.PORTABLE_EXECUTABLE_DIR) return process.env.PORTABLE_EXECUTABLE_DIR;
  return app.getPath('userData');
}
function dataDir(sub) { return path.join(dataRoot(), sub); }

function appIcon() {
  const p = path.join(__dirname, '..', '..', 'assets', 'icon.png');
  try { if (fs.existsSync(p)) return nativeImage.createFromPath(p); } catch (_) {}
  return undefined;
}

function initDirs() {
  const appRoot = path.join(__dirname, '..', '..');
  // hledat nástroje (adb v PATH\, idevice* v ios\) v zabalených resources i u dat
  const bases = [dataRoot(), appRoot, process.resourcesPath || appRoot, path.dirname(process.execPath)];
  adb.initAdb(bases);
  ios.initIos(bases);
  try { fs.mkdirSync(dataDir('zaznamy'), { recursive: true }); } catch (_) {}
  excel.initExcel(dataDir('zaznamy'));
  settings.initSettings(app.getPath('userData'));
  const tapety = dataDir('tapety');
  try { fs.mkdirSync(tapety, { recursive: true }); } catch (_) {}
  try { fs.mkdirSync(dataDir('ios'), { recursive: true }); } catch (_) {}
}

let midnightScheduled = false;
// Každou půlnoc: tichá aktualizace (stáhne, nainstaluje a sám restartuje) bez ptaní.
function scheduleMidnightUpdate() {
  if (midnightScheduled) return;
  midnightScheduled = true;
  const run = async () => {
    try {
      const s = settings.load();
      if (s && s.autoUpdate && s.autoUpdateMidnight) {
        const r = await updater.checkForUpdates('');
        if (r && r.hasUpdate) { await updater.downloadAndApply(''); return; } // sám restartuje
      }
    } catch (_) {}
    schedule(); // další půlnoc
  };
  const schedule = () => {
    const now = new Date();
    const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0);
    let ms = next - now;
    if (ms < 60000) ms = 60000;
    setTimeout(run, ms);
  };
  schedule();
}

function createWindow() {
  win = new BrowserWindow({
    width: 960, height: 900, minWidth: 780, minHeight: 600,
    backgroundColor: '#0d1410',
    title: 'UniDia', icon: appIcon(),
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload', 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  setMainWindow(win);
  updater.setWin(win);

  // auto-kontrola aktualizací po startu (jen upozorní, neinstaluje sám)
  win.webContents.once('did-finish-load', () => {
    setTimeout(async () => {
      try {
        const s = settings.load();
        if (!s || !s.autoUpdate) return;
        const r = await updater.checkForUpdates('');
        if (r && r.hasUpdate && win && !win.isDestroyed()) {
          win.webContents.send('update:available', r);
        }
      } catch (_) {}
    }, 4000);
    scheduleMidnightUpdate();
  });

  // po startu rovnou do tray (volitelně)
  try {
    const s = settings.load();
    if (s && s.startMinimized) {
      win.once('ready-to-show', () => { try { win.hide(); } catch (_) {} });
      // pojistka, kdyby ready-to-show nepřišel
      win.webContents.once('did-finish-load', () => { setTimeout(() => { try { if (s.startMinimized) win.hide(); } catch (_) {} }, 400); });
    }
  } catch (_) {}

  win.on('close', (e) => {
    if (!quitting) { e.preventDefault(); win.hide(); }
  });
  // tlačítko minimalizovat → skrýt do tray
  win.on('minimize', (e) => {
    e.preventDefault(); win.hide();
  });
}

// ── černá notifikace (samostatné okno) ──
function createNotifWindow() {
  notifWin = new BrowserWindow({
    width: 268, height: 132,
    show: false, frame: false, transparent: true, resizable: false,
    skipTaskbar: true, alwaysOnTop: true, focusable: true,
    hasShadow: false, backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload', 'notifPreload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
    },
  });
  notifWin.setAlwaysOnTop(true, 'screen-saver');
  notifWin.loadFile(path.join(__dirname, '..', 'renderer', 'notif.html'));
  notifWin.on('close', e => { if (!quitting) { e.preventDefault(); notifWin.hide(); } });
}

function positionNotif(w, h) {
  if (!notifWin) return;
  const wa = screen.getPrimaryDisplay().workArea;
  const x = wa.x + wa.width - w - 16;
  const y = wa.y + wa.height - h - 16;
  notifWin.setBounds({ x, y, width: w, height: h });
}

function showNotif(info) {
  if (!notifWin) return;
  notifDevice = { id: info.serial || info.udid, platform: info.platform, info };
  notifWin.webContents.send('notif:show', info);
  positionNotif(notifWin.getBounds().width, notifWin.getBounds().height);
  notifWin.showInactive();
}
function hideNotif() { if (notifWin) notifWin.hide(); }

// notifikace jen se sériovým číslem (z tray „Vyčíst S/N") – klik = kopírovat
function showSnNotif(serial) {
  if (!notifWin) return;
  const info = { brand: 'S/N přes USB', model: '', platform: 'android', lbl_ap: 'S/N', ap: serial, snOnly: true };
  notifDevice = { id: 'usb-sn', platform: 'android', info };
  notifWin.webContents.send('notif:show', info);
  positionNotif(notifWin.getBounds().width, notifWin.getBounds().height);
  notifWin.showInactive();
}

async function trayReadSn() {
  try {
    const r = await usbid.readUsbIds();
    const best = (r.items || []).find(x => x.value && !x.isApple) || (r.items || []).find(x => x.value);
    if (best) { clipboard.writeText(best.value); showSnNotif(best.value); }
    else { showSnNotif('—  (žádný telefon na USB)'); }
  } catch (e) { showSnNotif('— chyba čtení'); }
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

// ── WATCHER: detekuje připojení/odpojení Android i iOS, čte info, ukáže notifikaci ──
let watchTimer = null;
async function watchTick() {
  let list = [];
  try { list = await devices.list(); } catch (_) {}

  const seen = new Set();
  for (const d of list) {
    seen.add(d.id);
    const prev = known.get(d.id);
    if (!prev) known.set(d.id, { platform: d.platform, state: d.state, infoRead: false });
    const rec = known.get(d.id);
    rec.state = d.state; rec.platform = d.platform;

    // autorizované a ještě nenačtené → načíst + notifikace
    if (d.state === 'device' && !rec.infoRead) {
      rec.infoRead = true;
      try {
        const info = await deviceInfo.readDevice(d.id, d.platform);
        rec.info = info;
        send('device:info', info);          // hlavní okno ukáže vyčtené údaje
        showNotif(info);                    // černá notifikace
      } catch (e) { rec.infoRead = false; writeLog('read', e); }
    }
  }

  // odpojená zařízení
  for (const id of [...known.keys()]) {
    if (!seen.has(id)) {
      known.delete(id);
      send('device:gone', { id });
      if (notifDevice && notifDevice.id === id) { hideNotif(); notifDevice = null; }
    }
  }

  // stav lišty (autorizace/offline)
  send('devices:list', list);
}
function startWatcher() { stopWatcher(); watchTick(); watchTimer = setInterval(watchTick, 3000); }
function stopWatcher() { if (watchTimer) clearInterval(watchTimer); watchTimer = null; }

// ── notifikace → akce (registrováno zde, kde žije stav) ──
function registerNotifIpc() {
  const { ipcMain } = require('electron');

  // stav světlého/tmavého motivu Windows + sledování změny
  ipcMain.handle('theme:osDark', async () => { try { return !!nativeTheme.shouldUseDarkColors; } catch (_) { return true; } });
  try {
    nativeTheme.on('updated', () => {
      try { send('theme:osChanged', !!nativeTheme.shouldUseDarkColors); } catch (_) {}
    });
  } catch (_) {}

  ipcMain.handle('notif:copy', async () => {
    if (notifDevice && notifDevice.info) clipboard.writeText(notifDevice.info.ap || '');
    return true;
  });

  ipcMain.handle('notif:phase', async (_e, phase) => {
    // OLD SW / NEW SW → uložit do Excelu
    if (!notifDevice || !notifDevice.info) return { ok: false };
    try {
      const fp = await excel.saveRecord(notifDevice.info, phase);
      notify('Záznam uložen', `${phase} · ${notifDevice.info.model || ''} · ${notifDevice.info.imei || ''}`);
      send('record:saved', { id: notifDevice.id, phase });
      return { ok: true, path: fp };
    } catch (e) { writeLog('notif:phase', e); return { ok: false, error: String(e) }; }
  });

  ipcMain.handle('notif:dismiss', async () => { hideNotif(); return true; }); // ✕ = neukládat

  ipcMain.handle('notif:open', async () => {
    if (win) { win.show(); win.focus(); }
    if (notifDevice && notifDevice.info) send('device:info', notifDevice.info);
    return true;
  });

  ipcMain.handle('notif:resize', async (_e, { w, h }) => {
    if (notifWin) positionNotif(w, h);
    return true;
  });
}

function buildTray() {
  let img = appIcon();
  if (img) { img = img.resize({ width: 16, height: 16 }); }
  else {
    img = nativeImage.createFromDataURL('data:image/svg+xml;base64,' + Buffer.from(
      `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><circle cx="16" cy="16" r="14" fill="#1f6feb"/><text x="16" y="22" font-size="16" text-anchor="middle" fill="#fff" font-family="Arial" font-weight="bold">U</text></svg>`
    ).toString('base64'));
  }
  tray = new Tray(img);
  tray.setToolTip('UniDia');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Obnovit', click: () => { win.show(); win.focus(); } },
    { label: '🔌 Vyčíst S/N (USB, bez vývojáře)', click: () => trayReadSn() },
    { type: 'separator' },
    { label: 'Ukončit', click: () => { quitting = true; app.quit(); } },
  ]));
  tray.on('double-click', () => { win.show(); win.focus(); });
}

function notify(title, body) {
  if (win && !win.isDestroyed()) win.webContents.send('notify', { title, body });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { win.show(); win.focus(); } });
  app.whenReady().then(() => {
    const step = (name, fn) => { try { fn(); } catch (e) { writeLog('init:' + name, e); } };
    initDirs();
    step('window', createWindow);
    step('notif', createNotifWindow);
    step('tray', buildTray);
    step('ipc', () => registerIpc({ notify, dataDir }));
    step('notifIpc', registerNotifIpc);
    step('watcher', startWatcher);
    try { app.setLoginItemSettings({ openAtLogin: settings.load().startupWindows }); } catch (_) {}
  }).catch(err => writeLog('whenReady', err));
}

app.on('window-all-closed', () => { /* žije v tray */ });
app.on('before-quit', () => { quitting = true; });
