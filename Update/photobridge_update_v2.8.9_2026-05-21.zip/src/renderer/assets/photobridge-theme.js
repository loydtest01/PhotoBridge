/**
 * PHOTOBRIDGE — THEME MANAGER  v2.0
 * ─────────────────────────────────────────────────────────────────────────────
 * Správce světlého / tmavého tématu pro Electron aplikace.
 * Funguje ve všech oknech: hlavní okno, Settings, DevTools, Crash dialog.
 * Lze použít v jakékoliv jiné Electron aplikaci bez úprav.
 *
 * POUŽITÍ:
 *   <script src="assets/photobridge-theme.js"></script>
 *
 * API:
 *   PBTheme.set('light' | 'dark')   → nastav téma
 *   PBTheme.get()                    → vrátí aktuální téma
 *   PBTheme.toggle()                 → přepni
 *   PBTheme.bindToggle(el)           → navěš přepínač na element
 *   PBTheme.watch(cb)                → registruj callback při změně
 *   PBTheme.unwatch(cb)              → odregistruj callback
 *
 * ELECTRON IPC PROPOJENÍ (přes preload.js):
 *   Renderer přijímá téma:  window.electronAPI.onThemeChange(cb)
 *   Renderer odesílá téma:  window.electronAPI.setTheme(theme)
 *
 * PŘÍKLAD preload.js:
 *   contextBridge.exposeInMainWorld('electronAPI', {
 *     setTheme:      (t) => ipcRenderer.send('theme:set', t),
 *     onThemeChange: (cb) => ipcRenderer.on('theme:changed', (_, t) => cb(t)),
 *   });
 *
 * PŘÍKLAD main.js (detekce Windows nastavení):
 *   nativeTheme.on('updated', () => {
 *     const t = nativeTheme.shouldUseDarkColors ? 'dark' : 'light';
 *     BrowserWindow.getAllWindows().forEach(w =>
 *       w.webContents.send('theme:changed', t)
 *     );
 *   });
 *   ipcMain.on('theme:set', (_, t) => { /* ulož do config *\/ });
 */

;(function (global) {
  'use strict';

  /* ── Konstanty ─────────────────────────────────────── */
  const STORAGE_KEY  = 'pb-theme';           // localStorage klíč
  const HTML_ATTR    = 'data-theme';         // atribut na <html>
  const VALID_THEMES = ['light', 'dark'];

  /* ── Stav ──────────────────────────────────────────── */
  let _watchers = [];     // registrované callbacky
  let _initialized = false;
  let _periodicTimer = null;   // setInterval pro auto_timer / auto_windows
  let _lastConfig = null;      // poslední config, podle kterého počítáme

  /* ── Interní pomocníci ─────────────────────────────── */
  const _html = () => document.documentElement;

  function _isValid(t) { return VALID_THEMES.includes(t); }

  /** Tichý zápis do localStorage (Electron může mít storage zakázaný) */
  function _save(t) {
    try { localStorage.setItem(STORAGE_KEY, t); } catch {}
  }

  /** Tiché čtení z localStorage */
  function _load() {
    try { return localStorage.getItem(STORAGE_KEY); } catch { return null; }
  }

  /** Systémová preference OS */
  function _sysPref() {
    return global.matchMedia?.('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  }

  /** Aplikuje téma na DOM + notifikuje watcher callbacky */
  function _apply(theme, source) {
    const el = _html();
    const prev = el.getAttribute(HTML_ATTR);
    el.setAttribute(HTML_ATTR, theme);

    /* Notify: Electron main process */
    if (global.electronAPI?.setTheme) {
      global.electronAPI.setTheme(theme);
    }

    /* Notify: registrované callbacky (pouze pokud se téma změnilo) */
    if (theme !== prev) {
      for (const fn of _watchers) {
        try { fn(theme, prev, source); } catch (e) { console.warn('[PBTheme] watcher error', e); }
      }
    }
  }

  /** Vypočítá cílové téma pro auto_timer z aktuálního času */
  function _evalAutoTimer(cfg) {
    if (!cfg) return null;
    const mode = (cfg.THEME_MODE || '').toLowerCase().trim();
    if (mode !== 'auto_timer') return null;
    const now   = new Date();
    const hhmm  = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
    const start = cfg.DAY_START || '08:00';
    const end   = cfg.DAY_END   || '18:00';
    const isDay = start <= end
      ? (hhmm >= start && hhmm <= end)
      : (hhmm >= start || hhmm <= end);
    return isDay ? 'light' : 'dark';
  }

  /** Restartuje periodický timer (pouze pro auto_timer režim).
   *  Bez tohoto se téma nikdy nepřepne, když uplyne hranice DAY_START / DAY_END. */
  function _restartPeriodicTimer() {
    if (_periodicTimer) {
      clearInterval(_periodicTimer);
      _periodicTimer = null;
    }
    if (!_lastConfig) return;
    const mode = (_lastConfig.THEME_MODE || '').toLowerCase().trim();
    if (mode !== 'auto_timer') return;
    _periodicTimer = setInterval(() => {
      const target = _evalAutoTimer(_lastConfig);
      if (!target) return;
      const cur = _html().getAttribute(HTML_ATTR);
      if (cur !== target) {
        _apply(target, 'auto_timer');
      }
    }, 30 * 1000); // každých 30 sekund
  }

  /* ═════════════════════════════════════════════════════
     Veřejné API  →  window.PBTheme
  ═════════════════════════════════════════════════════ */
  const PBTheme = {

    /**
     * Nastav téma.
     * @param {'light'|'dark'} theme
     * @param {'user'|'config'|'ipc'|'system'} [source='user']
     */
    set(theme, source = 'user') {
      if (!_isValid(theme)) {
        console.warn('[PBTheme] Neznámé téma:', theme, '— použij "light" nebo "dark"');
        return;
      }
      _apply(theme, source);
      /* Ulož preferenci pouze pokud to nastavil uživatel nebo config */
      if (source === 'user' || source === 'config') _save(theme);
    },

    /** Vrátí aktuální téma ('light' nebo 'dark') */
    get() {
      const cur = _html().getAttribute(HTML_ATTR);
      return _isValid(cur) ? cur : 'light';
    },

    /** Přepni mezi světlým a tmavým */
    toggle() {
      this.set(this.get() === 'light' ? 'dark' : 'light', 'user');
    },

    /**
     * Inicializace — volá se automaticky po načtení DOM.
     * Lze volat ručně s options pro přepsání výchozí detekce.
     *
     * @param {object}  [opts]
     * @param {string}  [opts.theme]        - přímo nastav téma ('light'|'dark')
     * @param {string}  [opts.fromConfig]   - téma z config.json ('light'|'dark'|'auto_windows'|'auto_timer')
     * @param {boolean} [opts.followSystem] - přepsání: vždy sleduj OS (ignoruj uloženou preferenci)
     */
    init(opts = {}) {
      if (_initialized) return;
      _initialized = true;

      let theme;

      if (opts.theme && _isValid(opts.theme)) {
        /* Explicitní override */
        theme = opts.theme;
        this.set(theme, 'config');
      } else if (opts.fromConfig && _isValid(opts.fromConfig)) {
        /* Config řekl konkrétní téma */
        theme = opts.fromConfig;
        this.set(theme, 'config');
      } else if (opts.followSystem) {
        /* Vždy systémové — bez ukládání */
        theme = _sysPref();
        _apply(theme, 'system');
      } else {
        /* Výchozí pořadí: uložená preference → systém */
        const saved = _load();
        theme = (_isValid(saved) ? saved : _sysPref());
        _apply(theme, saved ? 'storage' : 'system');
      }

      /* Sleduj systémovou preferenci — použij ji pouze pokud uživatel nemá uloženou volbu */
      global.matchMedia?.('(prefers-color-scheme: dark)')
        .addEventListener('change', e => {
          if (!_load()) {
            this.set(e.matches ? 'dark' : 'light', 'system');
          }
        });

      /* Electron IPC: přijímej změny tématu z main procesu (Settings okno) */
      if (global.electronAPI?.onThemeChange) {
        global.electronAPI.onThemeChange((t) => {
          if (_isValid(t)) {
            _apply(t, 'ipc');
            _save(t);           /* synchronizuj localStorage */
          }
        });
      }
    },

    /**
     * Navěš přepínač tématu na HTML element.
     * @param {HTMLElement|string} el — element nebo CSS selektor
     */
    bindToggle(el) {
      const btn = typeof el === 'string' ? document.querySelector(el) : el;
      if (!btn) { console.warn('[PBTheme] bindToggle: element nenalezen', el); return; }
      btn.addEventListener('click', () => this.toggle());
    },

    /**
     * Registruj callback při změně tématu.
     * @param {(newTheme: string, prevTheme: string, source: string) => void} fn
     */
    watch(fn) {
      if (typeof fn === 'function' && !_watchers.includes(fn)) {
        _watchers.push(fn);
      }
    },

    /** Odregistruj callback */
    unwatch(fn) {
      _watchers = _watchers.filter(w => w !== fn);
    },

    /**
     * Aplikuj téma na základě PhotoBridge konfigurace.
     * Volá se z renderer procesu po načtení config.json.
     *
     * @param {object} config - PhotoBridge config objekt
     * @param {string} config.THEME_MODE  - 'light'|'dark'|'auto_windows'|'auto_timer'
     * @param {string} [config.DAY_START] - 'HH:MM' pro auto_timer
     * @param {string} [config.DAY_END]   - 'HH:MM' pro auto_timer
     */
    applyFromConfig(config = {}) {
      _lastConfig = config || {};
      const mode = (config.THEME_MODE || 'auto_windows').toLowerCase().trim();

      if (mode === 'light') {
        this.set('light', 'config');
      } else if (mode === 'dark') {
        this.set('dark', 'config');
      } else if (mode === 'auto_timer') {
        const target = _evalAutoTimer(config) || 'light';
        this.set(target, 'config');
      } else {
        /* auto_windows nebo neznámý → systémová preference */
        const saved = _load();
        this.set(_isValid(saved) ? saved : _sysPref(), 'system');
      }

      /* Restartuj periodický timer — bez něj se auto_timer nikdy
         nepřepne když mezitím uplyne DAY_START nebo DAY_END. */
      _restartPeriodicTimer();
    },

  };

  /* ── Automatická inicializace ──────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => PBTheme.init(), { once: true });
  } else {
    PBTheme.init();
  }

  /* ── Export ─────────────────────────────────────────── */
  global.PBTheme = PBTheme;

})(typeof globalThis !== 'undefined' ? globalThis : window);
