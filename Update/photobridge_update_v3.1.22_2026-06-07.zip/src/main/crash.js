// ============================================================
// src/main/crash.js
// Crash detection + crash dialog IPC handlery
// Ekvivalent Python: _check_crash_on_startup, _show_crash_dialog,
//                    _launch_crash_diagnostics (řádky 9553–10005)
// ============================================================

'use strict';

const {
  ipcMain,
  BrowserWindow,
  dialog,
  shell,
  app,
} = require('electron');

const path = require('path');
const fs   = require('fs');
const { execFile, spawn } = require('child_process');

// ── Cesty ────────────────────────────────────────────────────────────────────
const CRASH_FLAG_FILE = path.join(app.getPath('userData'), 'crash_flag.txt');

// Reference na crash dialog okno
let _crashWin = null;

// Obsah crash flagu načtený při startu (pro report)
let _crashFlagContent = '';

// Poslední crash zpráva (z uncaughtException)
let _lastCrashMsg = '';

// ── Pomocné: cesta k backups/ ─────────────────────────────────────────────────
function _backupsDir() {
  // Ve frozeném buildu: exe_dir/backups
  // V dev módu: project root/backups
  const base = app.isPackaged
    ? path.dirname(process.execPath)
    : path.join(__dirname, '../../..');
  return path.join(base, 'backups');
}

function _batPath() {
  return path.join(_backupsDir(), 'PB_restore.bat');
}

// ── Zápis crash flagu ─────────────────────────────────────────────────────────
// Zapisuje se při startu app, maže se při čistém ukončení (_clearCrashFlag).
function writeCrashFlag() {
  try {
    const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
    fs.writeFileSync(CRASH_FLAG_FILE, ts, 'utf8');
  } catch (_e) { /* tichý fail */ }
}

// ── Smazání crash flagu (volá se při čistém ukončení) ────────────────────────
function clearCrashFlag() {
  try {
    if (fs.existsSync(CRASH_FLAG_FILE)) {
      fs.unlinkSync(CRASH_FLAG_FILE);
    }
  } catch (_e) { /* tichý fail */ }
}

// ── Detekce předchozího pádu ─────────────────────────────────────────────────
// Vrací true pokud crash_flag.txt existuje.
function hasCrashFlag() {
  return fs.existsSync(CRASH_FLAG_FILE);
}

// ── Načtení obsahu crash flagu ────────────────────────────────────────────────
function readCrashFlag() {
  try {
    return fs.readFileSync(CRASH_FLAG_FILE, 'utf8');
  } catch (_e) {
    return '(obsah nedostupný)';
  }
}

// ── Spuštění diagnostiky (ekvivalent _launch_crash_diagnostics) ───────────────
function launchCrashDiagnostics(thenRestore = false) {
  try {
    // Najdi PB_diagnostics.py
    const base = app.isPackaged
      ? path.dirname(process.execPath)
      : path.join(__dirname, '../../..');
    const diagScript = path.join(base, 'engine', 'PB_diagnostics.py');

    if (!fs.existsSync(diagScript)) {
      console.warn('[CRASH] PB_diagnostics.py nenalezen:', diagScript);
      return;
    }

    // Najdi Python interpreter
    const pythonCandidates = process.platform === 'win32'
      ? ['python', 'python3', 'py']
      : ['python3', 'python'];

    const { execSync } = require('child_process');
    let pythonExe = 'python';
    for (const candidate of pythonCandidates) {
      try {
        execSync(`${candidate} --version`, { stdio: 'pipe' });
        pythonExe = candidate;
        break;
      } catch (_e) { /* zkus další */ }
    }

    const args = [diagScript, '--auto'];
    if (thenRestore) args.push('--then-restore');

    // Ekvivalent Python CREATE_NO_WINDOW + SW_MINIMIZE
    const opts = {
      cwd: base,
      detached: true,
      stdio: 'ignore',
    };

    // Přidej _internal/ do PYTHONPATH (stejně jako Python originál)
    const internalDir = path.join(base, '_internal');
    if (fs.existsSync(internalDir)) {
      opts.env = {
        ...process.env,
        PYTHONPATH: process.env.PYTHONPATH
          ? `${internalDir}${path.delimiter}${process.env.PYTHONPATH}`
          : internalDir,
      };
    }

    const child = spawn(pythonExe, args, opts);
    child.unref(); // Odpoj od parent procesu

    console.info('[CRASH] Diagnostika spuštěna' + (thenRestore ? ' + then-restore' : ''));
  } catch (e) {
    console.warn('[CRASH] Spuštění diagnostiky selhalo:', e.message);
  }
}

// ── Odeslání error reportu na server ──────────────────────────────────────────
// Volá config/server URL z konfigurace.
async function sendCrashReport(crashMsg) {
  try {
    const { readConfig } = require('./config');
    const cfg = readConfig();
    const sb  = require('./supabase');
    const res = await sb.sbInsertFeedback(cfg, {
      kind:       'crash',
      message:    crashMsg,
      appVersion: app.getVersion(),
    });
    // ok = odesláno teď; queued = uloženo do fronty (odešle se po přihlášení)
    return res.ok === true || res.queued === true;
  } catch (e) {
    console.warn('[CRASH] sendCrashReport selhal:', e.message);
    return false;
  }
}

// ── Dialog při detekci předchozího pádu (startup check) ──────────────────────
// Ekvivalent Python _check_crash_on_startup
// Zobrazí se PŘED spuštěním hlavního okna.
async function checkCrashOnStartup() {
  if (!hasCrashFlag()) return;

  _crashFlagContent = readCrashFlag();

  // Zobraz dialog s možnostmi (native dialog místo Tkinter)
  const { response } = await dialog.showMessageBox({
    type:    'warning',
    title:   'PhotoBridge – byl zjištěn pád',
    message: '⚠  PhotoBridge nebyl naposledy správně ukončen.',
    detail:
      'Co chcete udělat?\n\n' +
      '• Diagnostika  –  uloží diagnostický ZIP do složky logs/ na tomto PC\n' +
      '• Diagnostika s obnovou  –  totéž + obnoví zálohu předchozí verze\n' +
      '• Odeslat report správci  –  odešle log na server (jen pokud souhlasíte)\n' +
      '• Přeskočit  –  spustit aplikaci normálně bez jakékoli akce\n\n' +
      'ℹ  Bez vašeho souhlasu se neodešle nic.',
    buttons: [
      'Diagnostika',
      'Diagnostika s obnovou',
      '📤 Odeslat report správci',
      'Přeskočit',
    ],
    defaultId: 3, // Přeskočit
    cancelId:  3,
  });

  // Smaž crash flag bez ohledu na volbu
  clearCrashFlag();

  // Zpracuj volbu uživatele
  switch (response) {
    case 0: // Diagnostika
      launchCrashDiagnostics(false);
      break;

    case 1: // Diagnostika s obnovou
      launchCrashDiagnostics(true);
      break;

    case 2: { // Odeslat report
      const sent = await sendCrashReport(
        `CRASH REPORT (uživatel odeslal)\n${_crashFlagContent}`
      );
      await dialog.showMessageBox({
        type:    sent ? 'info' : 'warning',
        title:   sent ? 'Report odeslán' : 'Report neodeslán',
        message: sent
          ? 'Report byl úspěšně odeslán správci.'
          : 'Server není dostupný.\nUložte chybový detail ručně.',
        buttons: ['OK'],
      });
      break;
    }

    case 3: // Přeskočit
    default:
      break;
  }
}

// ── Crash dialog okno po pádu hlavní aplikace ─────────────────────────────────
// Ekvivalent Python _show_crash_dialog
// Otevře se po uncaughtException v main procesu.
function showCrashDialog(crashMsg) {
  _lastCrashMsg = crashMsg;

  // Pokud okno již existuje, jen ho vyforejgrunduj
  if (_crashWin && !_crashWin.isDestroyed()) {
    _crashWin.focus();
    return;
  }

  _crashWin = new BrowserWindow({
    width:     560,
    height:    460,
    minWidth:  440,
    minHeight: 360,
    title:     'PhotoBridge – chyba při spuštění',
    resizable: true,
    frame:     true,
    // Vždy navrchu ostatních oken
    alwaysOnTop: true,
    webPreferences: {
      preload:          path.join(__dirname, '../../preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
    },
    backgroundColor: '#1a1a2e',
    show:  false,
    // Zobrazit v taskbaru aby uživatel věděl, že aplikace stále "běží"
    skipTaskbar: false,
  });

  _crashWin.loadFile(path.join(__dirname, '../renderer/crash.html'));

  _crashWin.once('ready-to-show', () => {
    _crashWin.show();
    _crashWin.focus();
    // Vycentruj na obrazovce
    _crashWin.center();
  });

  _crashWin.on('closed', () => {
    _crashWin = null;
  });

  // Zakáž menu bar v crash dialogu
  _crashWin.setMenuBarVisibility(false);
}

// ── Fallback: Windows MessageBox pokud ani Electron dialog nefunguje ──────────
// Ekvivalent Python ctypes.windll.user32.MessageBoxW fallback
function showFallbackErrorBox(crashMsg) {
  try {
    // Electron nabízí dialog.showErrorBox jako synchronní fallback
    dialog.showErrorBox(
      'PhotoBridge – chyba',
      `PhotoBridge se nepodařilo spustit.\n\n` +
      `Otevři složku backups\\ a spusť PB_restore.bat\n\n` +
      `Technický detail:\n${crashMsg.slice(0, 500)}`,
    );
  } catch (_e) {
    // Absolutní fallback – nic dalšího nelze dělat
    process.exit(1);
  }
}

// ── Registrace IPC handlerů ────────────────────────────────────────────────────
function registerIpcHandlers() {

  // Renderer žádá o crash info (crashMsg, batExists, batPath, backupsDir)
  ipcMain.handle('crash:get-info', () => {
    const batExists = fs.existsSync(_batPath());
    let selfHeal = true, pollMin = 10, version = '';
    try {
      const cfg = require('./config').readConfig();
      selfHeal = String(cfg.AUTO_SILENT_UPDATE) !== 'false';
      const m = parseInt(cfg.UPDATE_POLL_MIN, 10);
      pollMin = (Number.isFinite(m) && m >= 2) ? m : 10;
    } catch (_) {}
    try { version = app.getVersion(); } catch (_) {}
    return {
      crashMsg:   _lastCrashMsg,
      batExists,
      batPath:    batExists ? _batPath()    : '',
      backupsDir: batExists ? _backupsDir() : '',
      selfHeal,
      pollMin,
      version,
    };
  });

  // Renderer: "Vyhledat opravu hned" → okamžitý tichý pokus o aktualizaci z GitHubu
  ipcMain.handle('crash:find-fix', async () => {
    try { await require('./updater').checkForUpdates(false, true); return { ok: true }; }
    catch (e) { return { ok: false, error: e.message }; }
  });

  // Renderer: "Skrýt do lišty" → zavři crash okno, aplikace běží dál (self-heal poll ji opraví)
  ipcMain.on('crash:hide-to-tray', () => {
    if (_crashWin && !_crashWin.isDestroyed()) _crashWin.close();
  });

  // Renderer: zavřít crash dialog
  ipcMain.on('crash:close', () => {
    if (_crashWin && !_crashWin.isDestroyed()) {
      _crashWin.close();
    }
  });

  // Renderer: odeslat crash report (s explicitním souhlasem uživatele)
  ipcMain.handle('crash:send-report', async (_event, crashMsg) => {
    return await sendCrashReport(crashMsg);
  });

  // Renderer: spustit PB_restore.bat
  ipcMain.on('crash:run-restore-bat', (_event, batFilePath) => {
    try {
      if (process.platform === 'win32') {
        // Spusť bat soubor přes shell
        execFile('cmd.exe', ['/c', 'start', '', batFilePath || _batPath()], {
          detached: true,
          stdio: 'ignore',
        }).unref();
      } else {
        shell.openPath(batFilePath || _batPath());
      }
      // Po 800ms zavři crash dialog (stejně jako Python originál)
      setTimeout(() => {
        if (_crashWin && !_crashWin.isDestroyed()) {
          _crashWin.close();
        }
      }, 800);
    } catch (e) {
      console.warn('[CRASH] Spuštění restore.bat selhalo:', e.message);
    }
  });

  // Renderer: otevřít složku backups
  ipcMain.on('crash:open-backups-folder', (_event, backupsDirPath) => {
    shell.openPath(backupsDirPath || _backupsDir());
  });
}

// ── Registrace globálního uncaughtException handleru ─────────────────────────
// Ekvivalent Python: except Exception as _crash → _show_crash_dialog
// Volat z main.js co nejdřív po inicializaci app.
function registerCrashHandler() {
  process.on('uncaughtException', (err) => {
    const crashMsg = err.stack || err.message || String(err);
    console.error('[CRASH] uncaughtException:', crashMsg);

    try {
      // Zaloguj crash
      const { addLog } = require('./devtools');
      addLog('ERROR', 'APP CRASH', crashMsg.replace(/\n/g, ' | '));
    } catch (_e) { /* tichý fail */ }

    // Zobraz crash dialog
    try {
      showCrashDialog(crashMsg);
    } catch (dialogErr) {
      // Fallback pokud ani BrowserWindow nefunguje
      showFallbackErrorBox(crashMsg);
    }

    // Aktivuj self-heal: zapiš stav pádu a začni hledat opravu na GitHubu (á X min)
    try { require('./updater').armSelfHeal('uncaught'); } catch (_e) { /* tichý fail */ }
  });

  process.on('unhandledRejection', (reason) => {
    const crashMsg = reason instanceof Error
      ? (reason.stack || reason.message)
      : String(reason);
    console.error('[CRASH] unhandledRejection:', crashMsg);

    try {
      const { addLog } = require('./devtools');
      addLog('ERROR', 'UNHANDLED REJECTION', crashMsg.replace(/\n/g, ' | '));
    } catch (_e) { /* tichý fail */ }
  });
}

module.exports = {
  // Startup
  hasCrashFlag,
  writeCrashFlag,
  clearCrashFlag,
  checkCrashOnStartup,
  // Runtime
  showCrashDialog,
  registerCrashHandler,
  // Utility
  sendCrashReport,
  launchCrashDiagnostics,
  // IPC
  registerIpcHandlers,
};
