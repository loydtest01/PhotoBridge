'use strict';
// ============================================================================
//  PhotoBridge – src/main/denni-zaloha.js
//
//  DENNÍ ZÁLOHA ZDROJOVÝCH SOUBORŮ APLIKACE
//
//  K ČEMU TO JE
//  Balíčky aktualizací jsou ROZDÍLOVÉ – obsahují jen změněné soubory. Když
//  se ve vydané verzi objeví chyba, nedá se vrátit prostě znovu vydáním
//  starého balíčku: ten by přepsal jen to, co v něm je, a zbytek by zůstal.
//
//  Tahle záloha je proto KOMPLETNÍ stav aplikace k danému dni. Když se něco
//  pokazí, správce vezme zálohu té verze, která fungovala, zabalí ji jako
//  balíček s vyšším číslem a vydá. Všechny počítače se tím srovnají na
//  známý stav – jednou operací a s jistým výsledkem.
//
//  JEDNA ZÁLOHA ZA DEN
//  Za den může vyjít i deset aktualizací. Deset záloh by nic nepřineslo –
//  zajímavý je stav PŘED prvním zásahem toho dne. Když už dnešní záloha
//  existuje, další se nedělá.
//
//  CO SE ZÁLOHUJE
//  Jen to, co aktualizace mění: main.js, preload.js, src/, templates/
//  a package.json. NE node_modules – ty se nikdy neaktualizují a měly by
//  stovky megabajtů.
//
//  DRŽÍ SE TÝDEN
//  Starší se mažou. Týden je dost na to, aby se chyba stihla projevit,
//  a málo na to, aby to zabralo místo.
// ============================================================================

const fs   = require('fs');
const path = require('path');

const DNU_ZPET = 7;

// Co se zálohuje – přesně to, co může přijít v balíčku aktualizace.
const SLOZKY  = ['src', 'templates'];
const SOUBORY = ['main.js', 'preload.js', 'package.json'];

function _log(uroven, zprava) {
    try { require('./utils').log(uroven, 'ZALOHA', zprava); }
    catch (_) { console.log(`[${uroven}] [ZALOHA] ${zprava}`); }
}

/** Kořen aplikace – tam, kde leží main.js. */
function _appDir() {
    return path.resolve(__dirname, '..', '..');
}

function _zalohyDir() {
    const { app } = require('electron');
    return path.join(app.getPath('userData'), 'zalohy');
}

function _dnesniZnacka() {
    const d = new Date();
    const dvojciferne = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${dvojciferne(d.getMonth() + 1)}-${dvojciferne(d.getDate())}`;
}

/** Rekurzivní kopie bez node_modules. */
function _kopiruj(zdroj, cil) {
    const stat = fs.statSync(zdroj);

    if (stat.isDirectory()) {
        const jmeno = path.basename(zdroj);
        if (jmeno === 'node_modules' || jmeno === '.git') return 0;

        fs.mkdirSync(cil, { recursive: true });
        let pocet = 0;
        for (const polozka of fs.readdirSync(zdroj)) {
            pocet += _kopiruj(path.join(zdroj, polozka), path.join(cil, polozka));
        }
        return pocet;
    }

    fs.mkdirSync(path.dirname(cil), { recursive: true });
    fs.copyFileSync(zdroj, cil);
    return 1;
}

/** Existuje už dnešní záloha? */
function maDnesniZalohu() {
    try {
        const dir = _zalohyDir();
        if (!fs.existsSync(dir)) return false;
        const dnes = _dnesniZnacka();
        return fs.readdirSync(dir).some(x => x.startsWith(dnes));
    } catch (_) { return false; }
}

/** Smaže zálohy starší než DNU_ZPET dní. */
function uklid() {
    try {
        const dir = _zalohyDir();
        if (!fs.existsSync(dir)) return 0;

        const hranice = Date.now() - DNU_ZPET * 86400000;
        let smazano = 0;

        for (const jmeno of fs.readdirSync(dir)) {
            // Jméno začíná datem: 2026-08-30_v3.3.24
            const m = jmeno.match(/^(\d{4})-(\d{2})-(\d{2})/);
            if (!m) continue;

            const kdy = new Date(+m[1], +m[2] - 1, +m[3]).getTime();
            if (kdy < hranice) {
                fs.rmSync(path.join(dir, jmeno), { recursive: true, force: true });
                smazano++;
            }
        }
        if (smazano) _log('INFO', `Smazáno starých záloh: ${smazano}`);
        return smazano;
    } catch (e) {
        _log('WARN', `Úklid záloh selhal: ${e.message}`);
        return 0;
    }
}

/**
 * Vytvoří dnešní zálohu, pokud ještě není.
 *
 * Vrací { ok, duvod } – duvod říká, proč se nic nedělo, ať se to dá
 * poznat z logu i bez hádání.
 */
function zalohujPokudTreba() {
    try {
        // Zálohuje se JEN NA POČÍTAČÍCH SPRÁVCŮ.
        //
        // Kdo vydává aktualizace, ten z té zálohy sestaví opravu. Na dílenském
        // počítači by jen zabírala místo – tam stačí ta stávající záloha
        // z updateru, která zachraňuje spadlou instalaci.
        //
        // Správcovství se čte ze serveru, ale výsledek se pamatuje v
        // config.JE_SPRAVCE. Bez toho by se při startu bez sítě nezálohovalo –
        // a záloha se dělá právě při startu, ještě před aktualizací.
        const cfg = require('./config').readConfig();
        if (String(cfg.JE_SPRAVCE) !== 'true') {
            return { ok: false, duvod: 'není správce' };
        }

        if (maDnesniZalohu()) {
            return { ok: false, duvod: 'dnešní záloha už existuje' };
        }

        const { app } = require('electron');
        const verze = app.getVersion();
        const cil   = path.join(_zalohyDir(), `${_dnesniZnacka()}_v${verze}`);
        const zdroj = _appDir();

        fs.mkdirSync(cil, { recursive: true });
        let pocet = 0;

        for (const s of SLOZKY) {
            const od = path.join(zdroj, s);
            if (fs.existsSync(od)) pocet += _kopiruj(od, path.join(cil, s));
        }
        for (const f of SOUBORY) {
            const od = path.join(zdroj, f);
            if (fs.existsSync(od)) pocet += _kopiruj(od, path.join(cil, f));
        }

        _log('INFO', `Záloha v${verze} hotova – ${pocet} souborů → ${cil}`);
        uklid();
        return { ok: true, cesta: cil, verze, pocet };

    } catch (e) {
        // Záloha NIKDY nesmí zabránit aktualizaci ani startu aplikace.
        _log('ERROR', `Záloha selhala: ${e.message}`);
        return { ok: false, duvod: e.message };
    }
}

/** Seznam záloh pro Admin centrum. */
function seznam() {
    try {
        const dir = _zalohyDir();
        if (!fs.existsSync(dir)) return [];

        return fs.readdirSync(dir)
            .filter(x => /^\d{4}-\d{2}-\d{2}_v/.test(x))
            .sort().reverse()
            .map(jmeno => {
                const m = jmeno.match(/^(\d{4}-\d{2}-\d{2})_v(.+)$/);
                let velikost = 0;
                try {
                    const spocitej = (p) => {
                        for (const x of fs.readdirSync(p, { withFileTypes: true })) {
                            const cesta = path.join(p, x.name);
                            if (x.isDirectory()) spocitej(cesta);
                            else velikost += fs.statSync(cesta).size;
                        }
                    };
                    spocitej(path.join(dir, jmeno));
                } catch (_) {}
                return { jmeno, datum: m ? m[1] : '', verze: m ? m[2] : '', velikost };
            });
    } catch (_) { return []; }
}

/** Otevře složku se zálohami v průzkumníku. */
function otevriSlozku() {
    try {
        const dir = _zalohyDir();
        fs.mkdirSync(dir, { recursive: true });
        require('electron').shell.openPath(dir);
        return { ok: true, cesta: dir };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
}

module.exports = { zalohujPokudTreba, maDnesniZalohu, uklid, seznam, otevriSlozku };
