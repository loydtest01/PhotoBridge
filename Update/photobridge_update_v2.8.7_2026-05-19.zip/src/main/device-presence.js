'use strict';
// ============================================================
// PhotoBridge – src/main/device-presence.js
//
// Detekce, že je stejný účet přihlášený na VÍCE PC současně –
// postavené na Supabase Realtime Presence + Broadcast (stejný
// websocket princip jako _startRealtime pro fotky).
//
// Princip:
//   • PC se po startu příjmu připojí na Realtime kanál
//     "realtime:presence:<user_id>" a přihlásí svou přítomnost.
//     Dokud běží websocket, je "tady". Když se PC odhlásí /
//     zavře / TVRDĚ VYPNE → websocket spadne a Supabase do pár
//     vteřin přítomnost sám odebere (žádná expirace na minuty).
//
//   • Po připojení Supabase pošle "presence_state" = kdo je online.
//     Když PC 2 uvidí, že tam je i JINÉ zařízení (PC 1), pošle do
//     rendereru 'presence:conflict' → renderer ukáže dialog:
//       – Odhlásit to druhé PC  → broadcast 'force_logout'
//       – Odhlásit se tady      → PC 2 se odhlásí
//
//   • Každé PC poslouchá broadcast 'force_logout'. Když dorazí pro
//     něj (target = jeho deviceId), provede plné odhlášení.
//
// Bezpečnost: jakákoli chyba jen zaloguje. Presence NIKDY nesmí
// shodit poller ani přihlášení. Bez Realtime se modul tiše vypne.
// ============================================================

const crypto = require('crypto');

let _utils = null;
function U() { return _utils || (_utils = require('./utils')); }
function log(...a) { try { U().log(...a); } catch (_) {} }

const REJOIN_DELAY_MS = 8000;   // reconnect po pádu websocketu
const HEARTBEAT_MS    = 25000;  // Phoenix heartbeat (Supabase timeout 30 s)

let _socket   = null;
let _hbTimer  = null;
let _rejoin   = null;
let _ref      = 0;
let _joinRef  = null;
let _deviceId = null;
let _label    = null;
let _cfg      = null;
let _active   = false;
let _topic    = null;
let _conflictReported = false;

// ── Stabilní ID a název tohoto PC ─────────────────────────────
function _getDeviceId() {
  if (_deviceId) return _deviceId;
  try {
    const st = U().loadState();
    if (st && typeof st.device_id === 'string' && st.device_id.length >= 8) {
      _deviceId = st.device_id;
    } else {
      _deviceId = crypto.randomBytes(8).toString('hex');
      const st2 = U().loadState();
      st2.device_id = _deviceId;
      U().saveState(st2);
    }
  } catch (_) {
    _deviceId = _deviceId || crypto.randomBytes(8).toString('hex');
  }
  return _deviceId;
}

function _deviceLabel() {
  if (_label) return _label;
  try { _label = require('os').hostname() || 'PC'; }
  catch (_) { _label = 'PC'; }
  return _label;
}

function _sbBits(cfg) {
  try {
    const url  = (cfg.SB_URL || '').trim().replace(/\/$/, '');
    const anon = (cfg.SB_ANON || '').trim();
    return (url && anon) ? { url, anon } : null;
  } catch (_) { return null; }
}

function _send(obj) {
  try {
    if (_socket && _socket.readyState === 1) {
      _socket.send(JSON.stringify(obj));
      return true;
    }
  } catch (_) {}
  return false;
}

// ── Připojení na presence kanál ───────────────────────────────
function _connect(cfg) {
  _disconnect();

  const bits = _sbBits(cfg);
  if (!bits) return;

  const userId = (U().STATE && U().STATE.sbUserId) || '';
  if (!userId) return;            // nepřihlášen – nemá smysl
  _cfg = cfg;

  const WS = (typeof globalThis.WebSocket === 'function') ? globalThis.WebSocket : null;
  if (!WS) {
    log('INFO', 'PRESENCE', 'WebSocket není dostupný – detekce více PC vypnuta');
    return;
  }

  const wsUrl = bits.url.replace(/^http/, 'ws')
    + `/realtime/v1/websocket?apikey=${encodeURIComponent(bits.anon)}&vsn=1.0.0`;

  let socket;
  try { socket = new WS(wsUrl); }
  catch (err) {
    log('WARN', 'PRESENCE connect', String(err));
    _scheduleRejoin();
    return;
  }
  _socket = socket;
  _topic  = `realtime:presence:${userId}`;
  _conflictReported = false;

  socket.onopen = async () => {
    let tok = null;
    try { tok = await require('./supabase').sbEnsureToken(cfg); } catch (_) {}

    _joinRef = String(++_ref);
    // Privátní kanál → Supabase ověří přes RLS policy na realtime.messages,
    // že se smí připojit jen přihlášený uživatel (viz pb_realtime_rls.sql).
    _send({
      topic:   _topic,
      event:   'phx_join',
      payload: {
        config: {
          private:   true,
          presence:  { key: _getDeviceId() },
          broadcast: { self: false },
        },
        access_token: tok || bits.anon,
      },
      ref: _joinRef,
    });

    if (_hbTimer) clearInterval(_hbTimer);
    let _sinceTok = 0;
    _hbTimer = setInterval(async () => {
      if (!_socket || _socket.readyState !== 1) return;
      _send({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++_ref) });

      // Každých ~10 min pošli čerstvý JWT – privátní kanál jinak po
      // expiraci tokenu klienta odpojí (viz Realtime Authorization docs).
      _sinceTok += HEARTBEAT_MS;
      if (_sinceTok >= 600000) {
        _sinceTok = 0;
        try {
          const fresh = await require('./supabase').sbEnsureToken(_cfg).catch(() => null);
          if (fresh) {
            _send({
              topic:   _topic,
              event:   'access_token',
              payload: { access_token: fresh },
              ref:     String(++_ref),
            });
          }
        } catch (_) {}
      }
    }, HEARTBEAT_MS);
  };

  socket.onmessage = (evt) => {
    let msg;
    try { msg = JSON.parse(evt.data); } catch { return; }
    if (!msg || msg.topic !== _topic) return;

    // Join potvrzen → pošli track (jsem tady)
    if (msg.event === 'phx_reply' && msg.ref === _joinRef
        && msg.payload && msg.payload.status === 'ok') {
      log('INFO', 'PRESENCE', 'připojeno – hlásím přítomnost');
      _send({
        topic:   _topic,
        event:   'presence',
        payload: {
          type:  'presence',
          event: 'track',
          payload: {
            device_id: _getDeviceId(),
            label:     _deviceLabel(),
            online_at: new Date().toISOString(),
          },
        },
        ref: String(++_ref),
      });
      return;
    }

    if (msg.event === 'presence_state') {
      _evaluatePresence(msg.payload || {});
      return;
    }
    if (msg.event === 'presence_diff') {
      _evaluatePresenceDiff(msg.payload || {});
      return;
    }

    if (msg.event === 'broadcast' && msg.payload && msg.payload.event === 'force_logout') {
      const p = msg.payload.payload || {};
      if (p.target === _getDeviceId()) {
        log('INFO', 'PRESENCE', 'přišel pokyn k odhlášení z jiného PC');
        _doForcedLogout(p.by_label || 'jiné PC');
      }
      return;
    }
  };

  socket.onerror = (e) => {
    log('DEBUG', 'PRESENCE error', String(e && e.message || e));
  };

  socket.onclose = () => {
    if (_hbTimer) { clearInterval(_hbTimer); _hbTimer = null; }
    if (_active) _scheduleRejoin();
  };
}

// Spočítej JINÁ zařízení v presence stavu
function _countOthers(stateObj) {
  const others = [];
  try {
    const myId = _getDeviceId();
    for (const key of Object.keys(stateObj || {})) {
      if (key === myId) continue;
      const metas = (stateObj[key] && stateObj[key].metas) || [];
      const m = metas[0] || {};
      others.push({ device_id: key, label: m.label || 'PC' });
    }
  } catch (_) {}
  return others;
}

function _evaluatePresence(stateObj) {
  const others = _countOthers(stateObj);
  if (others.length > 0 && !_conflictReported) {
    _conflictReported = true;
    log('INFO', 'PRESENCE', `stejný účet aktivní i na: ${others.map(o => o.label).join(', ')}`);
    _broadcastConflict(others);
  } else if (others.length === 0 && _conflictReported) {
    _conflictReported = false;
    _broadcastClear();
  }
}

function _evaluatePresenceDiff(diff) {
  try {
    const myId   = _getDeviceId();
    const joins  = diff.joins  || {};
    const leaves = diff.leaves || {};
    const otherJoin  = Object.keys(joins).some(k => k !== myId);
    const otherLeave = Object.keys(leaves).some(k => k !== myId);

    if (otherJoin && !_conflictReported) {
      const others = Object.keys(joins)
        .filter(k => k !== myId)
        .map(k => ({ device_id: k, label: (joins[k] && joins[k].metas && joins[k].metas[0] && joins[k].metas[0].label) || 'PC' }));
      if (others.length) {
        _conflictReported = true;
        log('INFO', 'PRESENCE', `připojilo se další PC: ${others.map(o => o.label).join(', ')}`);
        _broadcastConflict(others);
      }
    }
    if (otherLeave && _conflictReported) {
      _conflictReported = false;
      _broadcastClear();
    }
  } catch (_) {}
}

// ── Posílání do rendereru ─────────────────────────────────────
function _wins() {
  try { return require('electron').BrowserWindow.getAllWindows(); }
  catch (_) { return []; }
}

function _broadcastConflict(others) {
  const payload = {
    others: (others || []).map(o => ({ label: o.label || 'PC', device_id: o.device_id })),
    self:   { device_id: _getDeviceId(), label: _deviceLabel() },
  };
  for (const w of _wins()) {
    if (!w.isDestroyed()) {
      try { w.webContents.send('presence:conflict', payload); } catch (_) {}
    }
  }
}

function _broadcastClear() {
  for (const w of _wins()) {
    if (!w.isDestroyed()) {
      try { w.webContents.send('presence:clear', {}); } catch (_) {}
    }
  }
}

// ── Vzdálené odhlášení ────────────────────────────────────────
// PC 2 volá přes IPC když uživatel zvolil "Odhlásit to druhé PC".
function requestRemoteLogout(targetDeviceId) {
  if (!_socket || _socket.readyState !== 1 || !_topic) return false;
  return _send({
    topic:   _topic,
    event:   'broadcast',
    payload: {
      type:  'broadcast',
      event: 'force_logout',
      payload: {
        target:   targetDeviceId,
        by_label: _deviceLabel(),
      },
    },
    ref: String(++_ref),
  });
}

// Toto PC dostalo pokyn se odhlásit.
function _doForcedLogout(byLabel) {
  try {
    const sb = require('./supabase');
    if (sb && typeof sb.forceLogout === 'function') {
      sb.forceLogout();
    } else {
      try { require('electron').ipcMain.emit('supabase:logout'); } catch (_) {}
    }
  } catch (e) {
    log('WARN', 'PRESENCE forced-logout', e.message);
  }
  for (const w of _wins()) {
    if (!w.isDestroyed()) {
      try { w.webContents.send('presence:forced-logout', { by: byLabel || 'jiné PC' }); } catch (_) {}
    }
  }
}

// ── Lifecycle ─────────────────────────────────────────────────
function _scheduleRejoin() {
  if (_rejoin || !_active) return;
  _rejoin = setTimeout(() => {
    _rejoin = null;
    if (_active && _cfg) _connect(_cfg);
  }, REJOIN_DELAY_MS + Math.floor(Math.random() * 3000));
}

function _disconnect() {
  if (_hbTimer) { clearInterval(_hbTimer); _hbTimer = null; }
  if (_rejoin)  { clearTimeout(_rejoin);  _rejoin = null; }
  if (_socket) {
    try { _socket.close(); } catch (_) {}
    _socket = null;
  }
}

function startPresence(cfg) {
  _active = true;
  _cfg    = cfg || _cfg;
  try {
    setTimeout(() => { if (_active) _connect(_cfg); }, 2500);
    log('INFO', 'PRESENCE', 'spuštěno (Realtime detekce více PC)');
  } catch (e) {
    log('WARN', 'PRESENCE start', e.message);
  }
}

function stopPresence() {
  _active = false;
  _conflictReported = false;
  _disconnect();
}

module.exports = { startPresence, stopPresence, requestRemoteLogout };
