'use strict';
// ============================================================
// PhotoBridge – src/main/mobile-preview-window.js
// Náhledové okno mobilní webapp (templates/index.html) v rámu
// připomínajícím telefon. Otevírá se z prohlídky, aby uživatel
// viděl jak mobilní strana vypadá – bez nutnosti brát telefon do ruky.
//
// Mobilní webapp není modifikována – jen ji načteme do iframe v rámu.
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

let _win = null;
let _registered = false;

function openMobilePreview(mainWindow) {
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return;
  }

  // Spočítej polohu – pokud možno vlevo dole, aby se nepřekrývalo s Tour oknem (vpravo)
  const W = 360;
  const H = 720;
  let x, y;
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      const mb = mainWindow.getBounds();
      const { screen } = require('electron');
      const display = screen.getDisplayMatching(mb);
      const wa = display.workArea;
      // Vlevo od hlavního okna, jinak vpravo, jinak dolů
      x = mb.x - W - 12;
      y = mb.y;
      if (x < wa.x) {
        x = mb.x + mb.width + 12;
        if (x + W > wa.x + wa.width) {
          x = wa.x + Math.max(0, (wa.width - W) / 2);
          y = mb.y + mb.height + 12;
          if (y + H > wa.y + wa.height) {
            y = wa.y + Math.max(0, (wa.height - H) / 2);
          }
        }
      }
      x = Math.max(wa.x + 4, Math.min(wa.x + wa.width - W - 4, x));
      y = Math.max(wa.y + 4, Math.min(wa.y + wa.height - H - 4, y));
    }
  } catch (_) {}

  _win = new BrowserWindow({
    width:           W,
    height:          H,
    minWidth:        320,
    minHeight:       560,
    x, y,
    title:           'PhotoBridge – Mobilní webapp (náhled)',
    icon:            path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico'),
    parent:          undefined,    // nezávislé okno
    modal:           false,
    resizable:       true,
    autoHideMenuBar: true,
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      // iframe potřebuje webSecurity vypnutou pro file:// → file:// loading
      webSecurity:      false,
      devTools:         false,
    },
    show: false,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'mobile-preview.html'));

  _win.once('ready-to-show', () => _win.show());
  _win.on('closed', () => { _win = null; });
}

// Řekni náhledu, kterou obrazovku webapp ukázat (login/upload/settings/app).
// Volá to tour-window podle kroku prohlídky. Malá prodleva dá iframu čas
// se načíst, pokud se voláním trefí těsně po otevření okna.
function setPreviewScreen(screen) {
  if (!_win || _win.isDestroyed()) return;
  const send = () => {
    try { _win.webContents.send('mobile-preview:screen', screen); } catch (_) {}
  };
  // Pošli hned + ještě jednou s odstupem (kdyby iframe nebyl ready)
  send();
  setTimeout(send, 600);
}

function closeMobilePreview() {
  if (_win && !_win.isDestroyed()) {
    try { _win.close(); } catch (_) {}
  }
}

function registerIpcHandlers(getMainWindow) {
  if (_registered) return;
  _registered = true;
  ipcMain.handle('mobile-preview:open', () => {
    const mw = getMainWindow ? getMainWindow() : null;
    openMobilePreview(mw);
    return { ok: true };
  });
  ipcMain.handle('mobile-preview:close', () => {
    if (_win && !_win.isDestroyed()) _win.close();
    return { ok: true };
  });
}

module.exports = { openMobilePreview, setPreviewScreen, closeMobilePreview, registerIpcHandlers };
