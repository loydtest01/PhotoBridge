'use strict';
// ============================================================
// PhotoBridge – preload.js
// Bezpečný most (contextBridge) mezi main a renderer procesem.
// Renderer NESMÍ mít přímý přístup k Node.js nebo Electron API –
// vše prochází přes toto API vystavené přes contextBridge.
//
// VERZE: zahrnuje Fáze 1 + Fáze 9 (tray, soubory) + Fáze 11 (crash, devtools)
// API název: 'electronAPI' (konzistentní s app.js, crash.html, devtools.html)
// ============================================================

const { contextBridge, ipcRenderer } = require('electron');

// ── Pomocná funkce – odeslání IPC a čekání na odpověď ────────────────────────
const invoke = (channel, ...args) => ipcRenderer.invoke(channel, ...args);

// ── Pomocná funkce – přijímání zpráv z main procesu ─────────────────────────
const on = (channel, callback) => {
  const handler = (_event, ...args) => callback(...args);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

// ── Send bez odpovědi (fire & forget) ────────────────────────────────────────
const send = (channel, ...args) => ipcRenderer.send(channel, ...args);

contextBridge.exposeInMainWorld('electronAPI', {

  // ── Informace o aplikaci ──────────────────────────────────────────────────
  getAppInfo: () => invoke('ipc:app-info'),

  // ── Správa okna ──────────────────────────────────────────────────────────
  window: {
    minimize: () => invoke('ipc:window:minimize'),
    close:    () => invoke('ipc:window:close'),
    quit:     () => invoke('ipc:window:quit'),
    show:     () => invoke('ipc:window:show'),
  },

  // ── Konfigurace ───────────────────────────────────────────────────────────
  // ── RTS API (Britex) ───────────────────────────────────────
  rts: {
    test:   (partialCfg) => invoke('ipc:rts:test', partialCfg),
    login:  ()           => invoke('ipc:rts:login'),
    logout: ()           => invoke('ipc:rts:logout'),
    status: ()           => invoke('ipc:rts:status'),
    queue:  ()           => invoke('ipc:rts:queue'),
    openQueueFolder: ()  => invoke('ipc:rts:open-queue-folder'),
  },

  config: {
    get: ()          => invoke('ipc:config:get'),
    set: (partial)   => invoke('ipc:config:set', partial),
  },

  // ── HTTP Server ───────────────────────────────────────────────────────────
  server: {
    start:    ()     => invoke('ipc:server:start'),
    stop:     ()     => invoke('ipc:server:stop'),
    status:   ()     => invoke('ipc:server:status'),
    onStatus: (cb)   => on('ipc:server:status', cb),
  },

  // ── Supabase (Auth + Storage) ─────────────────────────────────────────────
  supabase: {
    login:          (email, pass) => invoke('ipc:sb:login', { email, password: pass }),
    logout:         ()            => invoke('ipc:sb:logout'),
    startPoller:    (job)         => invoke('ipc:sb:poller:start', { job }),
    stopPoller:     ()            => invoke('ipc:sb:poller:stop'),
    onFileReceived: (cb)          => on('ipc:sb:file-received', cb),
    onPollerStatus: (cb)          => on('ipc:sb:poller-status', cb),
  },

  // ── Paint monitoring ──────────────────────────────────────────────────────
  paint: {
    start:       () => invoke('ipc:paint:start'),
    stop:        () => invoke('ipc:paint:stop'),
    onFileMoved: (cb) => on('ipc:paint:file-moved', cb),
  },

  // ── Auto-updater ──────────────────────────────────────────────────────────
  updater: {
    checkForUpdates:   ()   => invoke('ipc:update:check'),
    onUpdateAvailable: (cb) => on('ipc:update:available', cb),
    onUpdateProgress:  (cb) => on('ipc:update:progress', cb),
    onUpdateReady:     (cb) => on('ipc:update:ready', cb),
  },

  // ── Logování (renderer → main → soubor) ──────────────────────────────────
  log: (level, context, message) => invoke('ipc:log', { level, context, message }),

  // ── Shell operace ─────────────────────────────────────────────────────────
  shell: {
    openFolder: (folderPath) => invoke('ipc:shell:open-folder', folderPath),
    openUrl:    (url)        => invoke('ipc:shell:open-url', url),
  },

  // ── Dialogy ───────────────────────────────────────────────────────────────
  dialog: {
    selectFolder: () => invoke('ipc:dialog:select-folder'),
    selectFiles:  () => invoke('ipc:dialog:select-files'),
  },

  // ── Tray ──────────────────────────────────────────────────────────────────
  tray: {
    update: (extraItems) => invoke('ipc:tray:update', extraItems),
  },

  // ── Notifikace ────────────────────────────────────────────────────────────
  notify: (title, body) => invoke('ipc:notify', { title, body }),

  // ── Statistiky ────────────────────────────────────────────────────────────
  onStats: (cb) => on('ipc:stats-update', cb),

  // ── Soubory (Fáze 9 – drag & drop, ruční výběr, uložení) ─────────────────
  files: {
    save:           (files, job)      => invoke('files:save', { files, job }),
    drop:           (paths, job)      => invoke('files:drop', { paths, job }),
    manualSelect:   (job)             => invoke('files:manual-select', { job }),
    clipboardPaste: (job)             => invoke('files:clipboard-paste', { job }),
    onNativeDrop: (cb)              => on('files:nativeDrop', cb),
    onSaved:      (cb)              => on('files:saved', cb),
  },

  // ── Upload okno (samostatné BrowserWindow) ────────────────────────────────
  upload: {
    open:  (files, job) => invoke('upload:open',  { files, job }),
    close: ()           => invoke('upload:close', {}),
    onAddFiles: (cb)    => on('upload:add-files', cb),
    onTourDemo: (cb)    => on('upload:tour-demo', cb),
  },

  // ── Nestažené zakázky ─────────────────────────────────────────────────────
  pending: {
    open:    ()    => invoke('pending:open'),
    close:   ()    => invoke('pending:close'),
    useJob:  (job) => invoke('pending:use-job', job),
    onFillJob: (cb) => on('pending:fill-job', cb),
  },

  // ── Přímý send (fire & forget) pro jednoduché eventy ─────────────────────
  send,

  // ── Obecný on() pro ostatní kanály ────────────────────────────────────────
  on,
  invoke,

  // ══════════════════════════════════════════════════════════════════════════
  // FÁZE 11 – DevTools konzole
  // ══════════════════════════════════════════════════════════════════════════

  /** Vrátí celý log buffer (pole raw string) */
  getAllLogs: () => invoke('devtools:get-all-logs'),

  /** Oznámí main procesu vymazání logů */
  clearDevLogs: () => send('devtools:clear-logs'),

  /** Exportuje text logů do souboru; vrátí cestu nebo null */
  exportLogs: (text) => invoke('devtools:export-logs', text),

  /** Callback volaný při každém novém logu (push místo pollingu) */
  onLogAdded: (callback) => {
    ipcRenderer.removeAllListeners('devtools:log-added');
    ipcRenderer.on('devtools:log-added', (_event, raw) => callback(raw));
  },

  /** Požádá main o otevření DevTools konzole */
  openDevTools: () => send('devtools:open'),

  // ══════════════════════════════════════════════════════════════════════════
  // FÁZE 11 – Crash dialog
  // ══════════════════════════════════════════════════════════════════════════

  /**
   * Vrátí crash info: { crashMsg, batExists, batPath, backupsDir }
   */
  getCrashInfo: () => invoke('crash:get-info'),

  /** Zavře crash dialog okno */
  closeCrashDialog: () => send('crash:close'),

  /** Odešle crash report (jen po souhlasu uživatele) */
  sendCrashReport: (crashMsg) => invoke('crash:send-report', crashMsg),

  /** Spustí PB_restore.bat */
  runRestoreBat: (batPath) => send('crash:run-restore-bat', batPath),

  /** Otevře složku backups v Průzkumníku */
  openBackupsFolder: (backupsDir) => send('crash:open-backups-folder', backupsDir),

  // Self-heal: vyhledat opravu hned / skrýt do lišty
  crashFindFix:    () => invoke('crash:find-fix'),
  crashHideToTray: () => send('crash:hide-to-tray'),

});
