# Přechod z UploadScanu na RTS

Stav k 12. 8. 2026, PhotoBridge v3.3.12.

> # ⛔ NEŽ NĚCO PŘEPNEŠ, PŘEČTI SI TOHLE
>
> **Špatně přepnutý režim posílá fotky do zakázek DVAKRÁT.**
> Nejde o kosmetickou chybu – fotky se pak musí ze zakázek mazat ručně,
> jedna po druhé, a nikdo o tom neví, dokud se zakázka neotevře.
>
> Dvě situace, ve kterých se to stane:
>
> 1. **Režim `both` s cílem na `M:`** – fotka se uloží na `M:`, odkud ji
>    UploadScan vloží do zakázky, a zároveň se pošle do RTS, které ji tam
>    vloží podruhé. Na zkoušku se **musí** přesměrovat cílová složka
>    na lokální disk.
>
> 2. **Zapnuté přímé odesílání na telefonu, zatímco počítač je v režimu
>    `disk`** – fotka jde do zakázky z RTS i přes `M:` z UploadScanu.
>    Dokud běží UploadScan, ať si to technici na telefonu nezapínají.
>
> **Osobní fotky se do zakázek neposílají nikdy** – viz kapitola níž.
> To platí ve všech režimech a je to hlídané dvakrát nezávisle.

**Nic z toho zatím není zapnuté.** Aplikace je připravená, ale běží jako dosud
— přes `M:\UploadScan`. Tenhle návod popisuje, co udělat v den, kdy UploadScan
skončí.

---

## Proč to existuje

`M:\UploadScan` je sdílená složka, kterou jiná služba každou minutu prohledává
a nalezené fotky vkládá do zakázky. PhotoBridge do ní ukládá a dál se o nic
nestará.

RTS umí totéž, ale bez té složky — fotka se do zakázky odešle přímo přes
`SavePhotoFile`. Až se UploadScan vypne, `M:` zmizí a bez přípravy by aplikace
neměla kam ukládat.

---

## Tři režimy

Nastavení → **Odesílání do servisu (RTS / API)**. Uloženo lokálně v každém
počítači jako `API_MODE` v `config.json`.

| Režim | Ukládá na `M:` | Posílá do RTS | Kdy použít |
|---|---|---|---|
| `disk` | ano | ne | **dnes** — dokud UploadScan běží |
| `both` | ano | ano | jen pro zkoušku, viz varování níž |
| `api` | ne | ano | až UploadScan skončí |

### ⚠️ Režim `both` s cílem na `M:` dělá duplicity

Fotka se uloží na `M:`, odkud ji UploadScan vloží do zakázky — a zároveň se
pošle do RTS, které ji tam vloží podruhé. **V zakázce bude dvakrát.**

Když chceš RTS vyzkoušet dřív, než UploadScan skončí, přepni cílovou složku
na lokální disk (třeba `C:\PhotoBridge\Test`) a teprve pak zapni `both`.
UploadScan tam nekouká, takže do zakázky se dostane jen to z RTS — a fotky
přitom vidíš ve složce, protože tam zůstávají.

---

## Co se v režimu `api` děje jinak

### Fotka z mobilu bez úprav

Jde z telefonu do R2 a odtud **rovnou do zakázky**. Počítač ji vůbec
nestahuje — jen si odškrtne, že je hotová, a smaže ji z R2.

Podmínkou je, že má technik na telefonu zapnuté přímé odesílání
(`pb_rts_direct`). Když ho zapnuté nemá, fotku pošle počítač.

### Fotka do Malování

Jde vždycky přes počítač, protože do zakázky má dorazit až upravená verze.
Po zavření editoru se přesune do čekací složky a odtud se odešle.

### Když RTS nebere

Fotka zůstane v čekací složce a odesílání se opakuje **donekonečna, po
hodině**. Nic se nezahazuje. Po úspěšném odeslání se soubor smaže.

Do `api_queue/failed/` jde jen to, co RTS **odmítne** — tedy skutečná chyba,
ne výpadek.

---

## Čekací složka

```
%APPDATA%\PhotoBridge\cekajici_rts        (Windows)
~/.config/photobridge/cekajici_rts        (Linux)
```

Chová se jako `M:\UploadScan` — stejné názvy souborů, stejné číslování — jen
ji nikdo nesdílí a vyprazdňuje ji odeslání do zakázky.

**Názvy musí zůstat finální** (`SD_1234567A.png`). `api-upload.js` z nich čte
číslo zakázky i typ dokumentu; přejmenovaný soubor se nikam nedostane.

Podsložky zakázek se v ní nedělají — fotka tam leží jen do odeslání.

### Proč ne `paint_temp`

`paint_temp` je pracovní plocha editoru a `reportStuckFiles()` při startu
hlásí její obsah jako uvízlé soubory. Fotky čekající na RTS by se hlásily jako
chyba po každém spuštění a ta hláška by přestala něco znamenat.

### Proč `userData` a ne složka aplikace

Fotka tam může ležet i několik dní. `userData` přežije aktualizaci
i přeinstalaci, složka aplikace ne.

---

## Osobní účet a použití doma

Aplikace jde použít i mimo firmu — účet označený jako osobní žádnou zakázku
nemá a čeká se od ní jen uložení fotky do zvolené složky.

**Osobní fotky se do RTS neposílají nikdy**, v žádném režimu. V režimu `api`
se navíc ukládají do běžné cílové složky, ne do čekací — ta je jen pro fotky,
které mají odejít do zakázky.

Rozpoznává se to dvakrát nezávisle na sobě:

1. `supabase.js` ví z cesty (`personal/...`), že jde o osobní fotku,
   a do fronty na RTS ji nezařadí.
2. `api-upload.js` navíc kontroluje tvar názvu. Do zakázky jde jen soubor
   pojmenovaný `TYP_ZAKÁZKAPÍSMENO` (`SD_1234567A`). Cokoli jiného odmítne.

Ta druhá kontrola není zbytečná opatrnost. Původně se ptala jen „má název
nějaké šestimístné číslo?" a na fotce z telefonu `IMG_20260812_193045.png`
si za číslo zakázky vzala **datum** — fotka by šla do cizí zakázky.

## Ukazatel v hlavním okně

Pod polem se zakázkou se objeví, kolik fotek čeká na odeslání a jak dlouho.
Kliknutím se otevře složka, kde leží.

- Počítají se jen položky **starší 10 minut** — fotka, která se právě odesílá,
  není problém a číslo by blikalo při každém vyfocení.
- Nad **3 hodiny** zčervená.
- V režimu `disk` se nezobrazuje vůbec, protože žádná fronta neexistuje.

Fronta do RTS je něco jiného než **Moje fronta** v Nastavení. Ta ukazuje fotky,
které ještě nedorazily z mobilu do počítače.

---

## Postup v den vypnutí UploadScanu

1. **Ověřit, že RTS bere** — na jednom počítači přepnout cílovou složku na
   lokální disk a zapnout `both`. Vyfotit do zkušební zakázky a podívat se,
   jestli tam fotka je a má správný typ dokumentu.
2. **Přepnout režim na `api`** na všech počítačích.
3. **Zapnout přímé odesílání na telefonech** (`pb_rts_direct`), ať fotky bez
   úprav nechodí zbytečně přes počítač.
4. **Zkontrolovat ukazatel** — po pár hodinách provozu by měl být skrytý.
   Když svítí a číslo roste, RTS něco odmítá a je potřeba se podívat do logu.

### Centrální přepínač (připravuje se, v3.3.13)

Režim se dnes nastavuje v každém počítači zvlášť. Chystá se řízení přes
`pb_settings`, aby se dalo přepnout z Admin centra najednou pro všechny –
počítače i telefony.

**Přepínač musí fungovat OBĚMA SMĚRY.** Po přepnutí na RTS se může stát, že
se UploadScan bude ještě chvíli potřebovat – návrat proto nesmí znamenat
rozesílání nové verze na padesát počítačů. Jedno kliknutí tam, jedno zpátky.

Zároveň platí, že centrální nastavení přebíjí to lokální. Jakmile je
`rts_mode` v `pb_settings` nastavené, rozbalovací seznam v Nastavení se
zašedne, aby si technik nepřepínal něco jiného, než platí pro firmu.

---

## Známý problém, dokud běží obojí

Přepínač na telefonu (`pb_rts_direct`) je **nezávislý** na režimu v počítači —
je uložený v paměti prohlížeče každého telefonu zvlášť.

Když si ho technik zapne a jeho počítač je v režimu `disk`, fotka půjde do
zakázky z RTS **a zároveň** přes `M:` z UploadScanu. V zakázce bude dvakrát.

Dokud běží UploadScan, ať si technici přímé odesílání na telefonu
**nezapínají**.

---

## Kde se to v kódu odehrává

| Co | Kde |
|---|---|
| Rozhodnutí o režimu | `api-upload.js` — `getMode`, `isDiskEnabled`, `isApiEnabled` |
| Cíl ukládání | `supabase.js` — `_processFilePath`, proměnná `jenRts` |
| Přeskočení stahování | `supabase.js` — `jenRts && rtsAlreadySent` |
| Cíl po editoru | `paint.js` — `_moveFileToFinal` |
| Fronta a opakování | `api-upload.js` — `processQueue`, `RETRY_DELAYS_MS` |
| Úklid po odeslání | `api-upload.js` — `_uklidOdeslany` |
| Ukazatel | `index.html` (inline skript) + `main-tray.js` — `ipc:rts:queue` |
| Rozhodnutí mobilu | `templates/index.html` — `pb_rts_direct`, sloupec `rts_sent` |

**Pozor na `_pending_savedir`**: ta pojistka čeká na *disk*, ne na RTS. V režimu
`api` se přeskakuje — jinak by se v ní fotka zasekla, i kdyby RTS mezitím
naběhlo.
