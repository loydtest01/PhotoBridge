/* ════════════════════════════════════════════════════════════
   PhotoBridge – main-tray.js
   Fáze 9 – Tray menu (plné), minimalizace do tray,
   IPC handlery pro Phase 9 (drag & drop, soubory, notifikace)

   Tento soubor se importuje / volá z main.js:
     const { setupTray, registerPhase9IpcHandlers } = require('./src/main/main-tray');
     app.whenReady().then(() => {
       setupTray(mainWindow);
       registerPhase9IpcHandlers(mainWindow);
     });
   ════════════════════════════════════════════════════════════ */

'use strict';

const { app, BrowserWindow, Tray, Menu, shell, dialog, nativeImage, clipboard, Notification, ipcMain } = require('electron');
const path   = require('path');
const os     = require('os');
const fs     = require('fs');

// Interní moduly (musí být již inicializovány z Fáze 2–6)
let config, utils, supabase, paintMod;
try { config   = require('./config');   } catch (_) { config   = {}; }
try { utils    = require('./utils');    } catch (_) { utils    = {}; }
try { supabase = require('./supabase'); } catch (_) { supabase = {}; }
try { paintMod = require('./paint');    } catch (_) { paintMod = null; }

let _updaterMod = null;
function getUpdater() {
  if (!_updaterMod) try { _updaterMod = require('./updater'); } catch (_) {}
  return _updaterMod || { checkForUpdates: () => Promise.resolve() };
}

const log        = utils.log        || ((...a) => console.log(...a));
const STATE      = utils.STATE      || {};
const loadState  = utils.loadState  || (() => ({}));
const saveState  = utils.saveState  || (() => {});
const readConfig = config.readConfig || (() => ({}));

/* ══════════════════════════════════════════════════════════
   TRAY IKONA
   ══════════════════════════════════════════════════════════ */

/** Načte tray ikonu – PNG z resources, fallback na nativeImage */
function loadTrayIcon() {
  const candidates = [
    path.join(__dirname, '../../resources/tray-icon.png'),
    path.join(__dirname, '../../assets/tray-icon.png'),
    path.join(app.getAppPath(), 'resources', 'tray-icon.png'),
    path.join(process.resourcesPath || '', 'tray-icon.png'),
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) {
      const img = nativeImage.createFromPath(c);
      if (!img.isEmpty()) return img;
    }
  }
  // Fallback: 16×16 černá ikona vygenerovaná za běhu
  return nativeImage.createFromDataURL(
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAZklEQVQ4jWNgYGD4z0ABYBo1gHoAAHuYAAW4cJAAAAABJRU5ErkJggg=='
  );
}

/**
 * Ikona s červenou tečkou v rohu – signalizuje, že přihlášení do RTS
 * vypršelo nebo chybí. Bez ní technik zjistí problém až u fotky, která
 * neodešla. Tečka se kreslí do plátna nad původní ikonu, takže funguje
 * s jakoukoli ikonou z resources.
 */
/**
 * Ikona s červeným pruhem dole – signalizuje, že přihlášení do RTS vypršelo.
 *
 * POZOR: Electron neumí v nativeImage vykreslit SVG. Skládáme proto přes
 * surová data obrázku (toBitmap), ne přes data URL s SVG.
 * Když se cokoli nepovede, vrací null a volající nechá původní ikonu –
 * prázdná ikona v liště je horší než chybějící zvýraznění.
 */
function _iconWithWarning(baseIcon) {
  try {
    if (!baseIcon || baseIcon.isEmpty()) return null;

    const { width, height } = baseIcon.getSize();
    if (!width || !height) return null;

    const bmp = Buffer.from(baseIcon.toBitmap());   // BGRA
    if (bmp.length < width * height * 4) return null;

    // Pruh přes spodní čtvrtinu – v liště je dobře vidět i u malé ikony
    const odRadku = Math.max(0, height - Math.max(3, Math.round(height * 0.28)));
    for (let y = odRadku; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        bmp[i]     = 0x4d;   // B
        bmp[i + 1] = 0x48;   // G
        bmp[i + 2] = 0xe5;   // R
        bmp[i + 3] = 0xff;   // A
      }
    }

    const out = nativeImage.createFromBitmap(bmp, { width, height });
    return (out && !out.isEmpty()) ? out : null;
  } catch (_) {
    return null;
  }
}

/**
 * Nastaví ikonu a popisek v liště podle stavu přihlášení do RTS.
 * Volá se z hlídače v rts-auth.js po každé kontrole.
 */
function updateTrayRtsState() {
  if (!_tray) return;
  try {
    // Upozorňovat má smysl jen tehdy, když fotky do zakázek posílá RTS.
    // Dokud jede UploadScan, je přihlášení do RTS technikovi k ničemu
    // a červená ikona by ho jen mátla.
    // API_MODE: disk = jen UploadScan | both = disk+API | api = jen API
    // Upozorňovat má smysl jen tam, kde fotky opravdu chodí přes RTS.
    let rtsSeUziva = false;
    try {
      const c    = readConfig();
      const mode = String(c.API_MODE || 'disk').toLowerCase();
      rtsSeUziva = (mode === 'api' || mode === 'both')
                && String(c.API_TARGET || 'rts').toLowerCase() === 'rts';
    } catch (_) {}

    if (!rtsSeUziva) {
      if (_trayIkona && !_trayIkona.isEmpty()) _tray.setImage(_trayIkona);
      _tray.setToolTip('PhotoBridge');
      return;
    }

    const rtsAuth = require('./rts-auth');
    const left    = rtsAuth.msLeft ? rtsAuth.msLeft() : 0;
    const ok      = left > 0;

    if (ok) {
      const h = Math.floor(left / 3600000);
      const m = Math.floor((left % 3600000) / 60000);
      _tray.setToolTip(`PhotoBridge – RTS přihlášen, zbývá ${h} h ${m} min`);
      if (_trayIkona && !_trayIkona.isEmpty()) _tray.setImage(_trayIkona);
    } else {
      _tray.setToolTip('PhotoBridge – ⚠ nepřihlášen do RTS, fotky se neuloží do zakázek');
      const varovna = _iconWithWarning(_trayIkona);
      // Když se varovnou ikonu nepodaří složit, RADĚJI NECH PŮVODNÍ.
      // Prázdná ikona v liště je horší než žádné zvýraznění – upozorní
      // i popisek a položka v nabídce.
      if (varovna && !varovna.isEmpty()) _tray.setImage(varovna);
      else if (_trayIkona && !_trayIkona.isEmpty()) _tray.setImage(_trayIkona);
    }

    try { _refreshTrayMenu(_trayWin); } catch (_) {}
  } catch (_) {}
}

/* ══════════════════════════════════════════════════════════
   SESTAVENÍ TRAY MENU (Phase 9 – plné menu)
   ══════════════════════════════════════════════════════════ */

/**
 * Sestaví kontextové menu pro tray ikonu.
 * @param {BrowserWindow} win    - Hlavní okno aplikace
 * @param {object}        opts   - { job, qrActive, serverRunning, vercelMode }
 */
function buildTrayMenu(win, opts = {}) {
  const { job, qrActive, serverRunning, vercelMode } = opts;
  const cfg = readConfig();

  const isLoggedIn   = !!STATE.sbAccessToken;
  const pollerActive = !!STATE.pollerJob;

  // ── Stav přihlášení do RTS ────────────────────────────────
  // RTS nevydává refresh_token, přihlášení vyprší po ~23 h. Technik to musí
  // vidět dřív, než mu přestanou odcházet fotky do zakázek.
  let rtsLabel = null, rtsExpired = false;
  try {
    const mode = String(cfg.API_MODE || 'disk').toLowerCase();
    const cil  = String(cfg.API_TARGET || 'rts').toLowerCase();
    if (!((mode === 'api' || mode === 'both') && cil === 'rts')) {
      throw new Error('RTS se nepoužívá – položku nezobrazuj');
    }
    const left = require('./rts-auth').msLeft();
    if (left > 0) {
      const h = Math.floor(left / 3600000);
      const m = Math.floor((left % 3600000) / 60000);
      rtsLabel = `RTS: přihlášen · zbývá ${h > 0 ? `${h} h ${m} min` : `${m} min`}`;
    } else {
      rtsLabel   = 'RTS: ⚠ nepřihlášen – fotky nejdou do zakázek';
      rtsExpired = true;
    }
  } catch (_) {}

  return Menu.buildFromTemplate([
    // ── Hlavička – stav aplikace ──────────────────────────
    {
      label: job
        ? `PhotoBridge  •  ${job}`
        : 'PhotoBridge',
      enabled: false,
    },
    ...(rtsLabel ? [{ label: rtsLabel, enabled: false }] : []),
    {
      // Prodloužit stávající token nejde – RTS refresh nevydává. Přihlásíme
      // se tedy znovu. Okno drží trvalou session, takže to bývá jedno kliknutí
      // bez psaní hesla a technik může pokračovat v práci.
      label: rtsExpired ? 'Přihlásit se do RTS…' : 'Obnovit přihlášení do RTS…',
      click: async () => {
        try {
          const r = await require('./rts-auth').login();
          try { updateTrayRtsState(); } catch (_) {}
          try { _refreshTrayMenu(win); } catch (_) {}
          if (Notification && Notification.isSupported()) {
            new Notification({
              title: 'PhotoBridge – RTS',
              body:  (r && r.ok)
                ? `Přihlášení obnoveno${r.user ? ` – ${r.user}` : ''}. Platí dalších ~23 h.`
                : `Přihlášení se nezdařilo: ${(r && r.error) || 'neznámá chyba'}`,
            }).show();
          }
        } catch (e) {
          log('WARN', 'Tray', `Obnovení RTS selhalo: ${e.message}`);
        }
      },
    },
    { type: 'separator' },

    // ── Základní akce ─────────────────────────────────────
    {
      label: 'Zobrazit',
      click: () => showWindow(win),
    },
    {
      label: 'Zadat zakázku…',
      click: () => {
        showWindow(win);
        win.webContents.send('tray:focusJob');
      },
    },

    { type: 'separator' },

    // ── Stav příjmu ───────────────────────────────────────
    {
      label: pollerActive ? `● Příjem aktivní  (${STATE.pollerJob})` : '○ Příjem neaktivní',
      enabled: false,
    },

    { type: 'separator' },

    // ── Nastavení / Aktualizace ───────────────────────────
    {
      label: 'Nastavení…',
      accelerator: 'CmdOrCtrl+,',
      click: () => {
        showWindow(win);
        // Krátká prodleva aby se okno stihlo zobrazit před odesláním eventu
        setTimeout(() => win.webContents.send('settings:openFromTray'), 150);
      },
    },
    {
      label: 'Zkontrolovat aktualizace',
      click: () => {
        try { getUpdater().checkForUpdates(true); } catch (e) { log('WARN', 'tray update check', e.message); }
      },
    },

    { type: 'separator' },

    // ── Ukončit ───────────────────────────────────────────
    {
      label: 'Ukončit PhotoBridge',
      accelerator: 'CmdOrCtrl+Q',
      click: () => {
        log('INFO', 'Tray: quit requested');
        app.isQuitting = true;
        app.quit();
      },
    },
  ]);
}

/* ══════════════════════════════════════════════════════════
   SETUP TRAY
   ══════════════════════════════════════════════════════════ */

let _tray      = null;    // Singleton Tray instance
let _trayOpts  = {};      // Aktuální stav pro menu
let _trayWin   = null;    // Okno, se kterým se menu sestavilo (kvůli překreslení odpočtu)
let _trayIkona = null;    // PŮVODNÍ ikona z tray – NIKDY ji neskládej znovu přes loadTrayIcon()
let _mainWin   = null;    // Aktuální hlavní okno (může se znovuvytvořit – viz createMainWindow)

/**
 * Nastaví/aktualizuje referenci na hlavní okno.
 * Volá main.js po každém vytvoření okna (a s null po jeho zavření),
 * aby tray nikdy nedržel zničené okno.
 * @param {BrowserWindow|null} win
 */
function setMainWindow(win) {
  _mainWin = win || null;
}

/**
 * Vrátí ŽIVÉ (nezničené) okno k zobrazení.
 * Pořadí: předané win → zapamatované _mainWin → první živé top-level okno.
 * @param {BrowserWindow} [win]
 * @returns {BrowserWindow|null}
 */
function _liveWindow(win) {
  const ok = (w) => {
    try { return !!w && !w.isDestroyed(); } catch (_) { return false; }
  };
  if (ok(win)) return win;
  if (ok(_mainWin)) return _mainWin;
  try {
    const all = BrowserWindow.getAllWindows()
      .filter(w => ok(w) && (() => { try { return !w.getParentWindow(); } catch (_) { return true; } })());
    if (all.length) return all[0];
  } catch (_) {}
  return null;
}

/**
 * Vytvoří tray ikonu a nastaví handlery.
 * Volat jednou po app.whenReady().
 * @param {BrowserWindow} win
 */
function setupTray(win, existingTray = null) {
  if (win) _mainWin = win;   // zapamatuj aktuální okno
  if (_tray) return _tray;  // Singleton

  if (existingTray) {
    // Použij tray vytvořený v main.js – nevytváříme druhý
    _tray = existingTray;
  } else {
    const icon = loadTrayIcon();
    _tray = new Tray(icon);
  }
  _tray.setToolTip('PhotoBridge');

  // Aktualizuj menu s výchozím stavem
  _trayWin = win;
  // Ikonu si zapamatuj z živého tray objektu. loadTrayIcon() tady nepoužívej –
  // v zabalené aplikaci soubor na svých cestách nenajde a vrátí prázdný
  // náhradní obrázek, kterým by přepsala funkční ikonu z main.js.
  try { _trayIkona = _tray.getImage(); } catch (_) { _trayIkona = null; }
  _refreshTrayMenu(win);

  // Kliknutí na ikonu = zobrazit okno (Windows/Linux)
  // POZN.: nevoláme showWindow(win) napevno – okno se může znovuvytvořit,
  // proto showWindow() sám dohledá živé okno.
  _tray.on('click',        () => showWindow());
  _tray.on('double-click', () => showWindow());

  // Pravé tlačítko: přepočítej odpočet těsně před otevřením menu.
  // Hlídač běží jen po 5 minutách, bez tohohle by hodnota mohla být stará.
  _tray.on('right-click', () => { try { updateTrayRtsState(); } catch (_) {} });

  log('INFO', 'Tray ikona vytvořena');
  try { updateTrayRtsState(); } catch (_) {}
  return _tray;
}

/** Překreslí tray menu s aktuálním stavem */
function _refreshTrayMenu(win) {
  if (!_tray) return;
  const target = win || _trayWin;
  if (!target) return;                 // bez okna by menu spadlo na win.webContents
  const menu = buildTrayMenu(target, _trayOpts);
  _tray.setContextMenu(menu);
}

/** Aktualizuje stav tray menu (volá se z IPC handleru nebo z main.js) */
function updateTrayMenu(win, opts) {
  if (win) _trayWin = win;
  Object.assign(_trayOpts, opts);
  _refreshTrayMenu(win);
}

/** Zruší tray ikonu (volá se při quit) */
function destroyTray() {
  if (_tray) {
    try { _tray.destroy(); } catch (_) {}
    _tray = null;
  }
}

/* ══════════════════════════════════════════════════════════
   MINIMALIZACE DO TRAY (Phase 9)
   ══════════════════════════════════════════════════════════ */

let _trayNotifShown = false;  // ukáže se jen jednou za běh aplikace

/** Skryje okno a zobrazí tray notifikaci (jen první použití) */
function hideToTray(win, cfg) {
  const w = _liveWindow(win);
  if (!_tray) setupTray(w || win);
  if (!w) { log('WARN', 'hideToTray: žádné živé okno'); return; }
  try { w.hide(); } catch (_) {}
  log('INFO', 'Okno skryto do tray');

  // Balónová notifikace – jen první použití, pak je jasné kde hledat ikonu
  if (!_trayNotifShown && Notification.isSupported()) {
    _trayNotifShown = true;
    const n = new Notification({
      title: 'PhotoBridge',
      body:  'Aplikace běží na pozadí. Klikni na ikonu v liště.',
      silent: true,
    });
    n.show();
  }
}

/** Obnoví okno ze tray */
function showWindow(win) {
  const w = _liveWindow(win);
  if (!w) { log('WARN', 'showWindow: žádné živé okno k zobrazení'); return; }
  try {
    w.show();
    if (w.isMinimized()) w.restore();
    w.focus();
    // Notifikuj renderer – zaměří pole zakázky
    if (w.webContents && !w.webContents.isDestroyed()) {
      w.webContents.send('window:restored');
    }
    log('INFO', 'Okno obnoveno ze tray');
  } catch (e) {
    log('WARN', 'showWindow selhal: ' + (e && e.message));
  }
}

/* ══════════════════════════════════════════════════════════
   SOUBORY – ULOŽENÍ (Phase 9, IPC handler)
   ══════════════════════════════════════════════════════════ */

/**
 * Pomocné – přípony povolených souborů (shodné s Python originálem)
 */
const ALLOWED_IMG_EXTS   = ['.png', '.jpg', '.jpeg', '.webp'];
const ALLOWED_VIDEO_EXTS = ['.mp4', '.mov', '.m4v', '.avi', '.mkv', '.webm'];
const ALLOWED_PDF_EXTS   = ['.pdf'];
const ALLOWED_ALL_EXTS   = [...ALLOWED_IMG_EXTS, ...ALLOWED_VIDEO_EXTS, ...ALLOWED_PDF_EXTS];

/**
 * Sada cest, které byly plánovány (planOutputPath) ale soubor ještě
 * fyzicky neexistuje na disku (např. čeká ve frontě Paint).
 * Zabraňuje přidělení stejného písmene dvěma souborům v jedné dávce.
 */
const _reservedPaths = new Set();

/** Číslo–písmeno pro dalsi soubor v cílové složce (replika next_letter_for) */
function nextLetterFor(saveDir, job, typ) {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (const letter of letters) {
    const candidates = ALLOWED_IMG_EXTS.concat(ALLOWED_VIDEO_EXTS, ALLOWED_PDF_EXTS)
      .map(ext => path.join(saveDir, `${typ}_${job}${letter}${ext}`));
    // Zkontroluj disk i rezervované (Paint-fronta) cesty
    if (!candidates.some(p => fs.existsSync(p) || _reservedPaths.has(p))) return letter;
  }
  return 'A';
}

/** Vypočte výstupní cestu souboru (replika Python logiky) */
function planOutputPath(saveDir, job, typ, srcPath) {
  const ext = path.extname(srcPath).toLowerCase() || '.png';
  const isVideo = ALLOWED_VIDEO_EXTS.includes(ext);
  const isPdf   = ALLOWED_PDF_EXTS.includes(ext);
  const isImg   = !isVideo && !isPdf;

  const outExt = isImg ? '.png' : ext;

  if (typ === 'SN') {
    let base = path.join(saveDir, `SN_${job}${outExt}`);
    let n = 1;
    while (fs.existsSync(base)) {
      base = path.join(saveDir, `SN_${job}_${n}${outExt}`);
      n++;
    }
    return base;
  }
  if (typ === 'SDX') {
    let base = path.join(saveDir, `SD_${job}X${outExt}`);
    let n = 2;
    while (fs.existsSync(base)) {
      base = path.join(saveDir, `SD_${job}X_${n}${outExt}`);
      n++;
    }
    return base;
  }
  // SD, VT, SP → s písmenem
  const letter = nextLetterFor(saveDir, job, typ);
  const outPath = path.join(saveDir, `${typ}_${job}${letter}${outExt}`);
  // Rezervuj cestu okamžitě, aby ji další soubor v dávce nedostal také
  _reservedPaths.add(outPath);
  return outPath;
}

/* ══════════════════════════════════════════════════════════
   REGISTRACE IPC HANDLERŮ – PHASE 9
   ══════════════════════════════════════════════════════════ */

/**
 * Registruje všechny IPC handlery specifické pro Phase 9.
 * Volat z main.js po app.whenReady().
 * @param {BrowserWindow} win
 */
function registerPhase9IpcHandlers(win) {

  /* ── Tray menu aktualizace ─────────────────────────────── */
  ipcMain.handle('tray:updateMenu', (_, opts) => {
    updateTrayMenu(win, {
      job:           opts.job           || null,
      qrActive:      !!opts.qrActive,
      serverRunning: STATE.running      || false,
      vercelMode:    !!(readConfig().VERCEL_URL || '').trim(),
    });
  });

  /* ── Skrýt okno do tray ────────────────────────────────── */
  ipcMain.handle('window:hideToTray', () => {
    const cfg = readConfig();
    hideToTray(win, cfg);
  });

  /* ── Zobrazit okno ze tray ─────────────────────────────── */
  ipcMain.handle('window:show', () => showWindow(win));

  /* ── Nastavit titulek okna ─────────────────────────────── */
  ipcMain.handle('window:setTitle', (_, title) => {
    try { win.setTitle(String(title)); } catch (_e) {}
  });

  /* ── Kopírovat do schránky ─────────────────────────────── */
  ipcMain.handle('clipboard:write', (_, text) => {
    const { clipboard } = require('electron');
    clipboard.writeText(String(text));
  });

  /* ── Otevřít URL v prohlížeči ──────────────────────────── */
  ipcMain.handle('shell:openExternal', (_, url) => {
    shell.openExternal(String(url)).catch(e => log('WARN', 'shell.openExternal', String(e)));
  });

  /* ── Drag & Drop – přijaté soubory ────────────────────────
     Validuje přípony a token, vrátí seznam platných souborů. */
  /** Předá hotový soubor modulu api-upload (odeslání do API servisu). */
  function _apiEnqueue(outPath) {
    try { require('./api-upload').enqueueFile(outPath); }
    catch (e) { log('WARN', 'API_UPLOAD hook (manual)', String(e).split('\n')[0]); }
  }

  // Test spojení s RTS API (tlačítko v Nastavení).
  // Přijme rozpracované hodnoty z formuláře, uloží je do configu a zkusí /api/v4/User.
  // Přihlášení technika do RTS (OAuth2 + PKCE)
  ipcMain.handle('ipc:rts:login', async () => {
    try { return await require('./rts-auth').login(); }
    catch (e) { return { ok: false, error: String(e.message || e) }; }
  });
  ipcMain.handle('ipc:rts:logout', async () => {
    try { return require('./rts-auth').logout(); }
    catch (e) { return { ok: false, error: String(e.message || e) }; }
  });
  ipcMain.handle('ipc:rts:status', async () => {
    try { return require('./rts-auth').status(); }
    catch (_) { return { loggedIn: false }; }
  });

  /* ── Kolik fotek čeká na odeslání do zakázky ───────────────
     Ukazatel v hlavním okně. Počítají se jen položky starší než 10 minut –
     fotka, která se právě odesílá, není problém a číslo by kvůli ní blikalo.

     Vrací se i to, jestli se RTS vůbec používá. V režimu 'disk' se ukazatel
     nemá zobrazovat vůbec: fotky končí v cílové složce a žádná fronta
     neexistuje. */
  ipcMain.handle('ipc:rts:queue', async () => {
    try {
      const au   = require('./api-upload');
      const stav = au.stavFronty(10);
      return {
        ok:          true,
        pocet:       stav.pocet,
        nejstarsiMin: stav.nejstarsiMin,
        aktivni:     au.isApiEnabled(),
        jenRts:      !au.isDiskEnabled(),
      };
    } catch (e) {
      return { ok: false, error: String(e.message || e), pocet: 0, aktivni: false };
    }
  });

  /* ── Otevřít složku s čekajícími fotkami ───────────────────
     V režimu 'api' leží fotky v čekací složce, v ostatních v cílové složce.
     Technik očekává, že klik na číslo otevře to, co za tím číslem stojí. */
  ipcMain.handle('ipc:rts:open-queue-folder', async () => {
    try {
      const au  = require('./api-upload');
      const cfg = require('./config');
      const dir = au.isDiskEnabled()
        ? (cfg.readConfig().SAVE_DIR || cfg.CEKAJICI_RTS_DIR)
        : cfg.CEKAJICI_RTS_DIR;

      require('fs').mkdirSync(dir, { recursive: true });
      const err = await shell.openPath(dir);
      if (err) return { ok: false, error: err };
      return { ok: true, dir };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  ipcMain.handle('ipc:rts:test', async (_, partialCfg) => {
    try {
      if (partialCfg && typeof partialCfg === 'object') {
        // POZOR: writeConfig ukládá CELOU konfiguraci → nutno sloučit,
        // jinak by se ostatní klíče přepsaly výchozími hodnotami.
        try {
          const cfgMod = require('./config');
          cfgMod.writeConfig(Object.assign({}, cfgMod.readConfig(), partialCfg));
        } catch (_) {}
      }
      return await require('./rts-api').testConnection();
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  ipcMain.handle('files:drop', async (_, { paths, job }) => {
    try {
      // Pokud je token aktivní, použij token zakázku; jinak přijmi zakázku z rendereru
      const activeJob = STATE.tokenJob || STATE.job || job;
      if (!activeJob) {
        return { error: 'Žádná aktivní zakázka.' };
      }
      // Kontrola tokenu jen pokud existuje – bez tokenu (lokální přetažení) přeskočit
      if (STATE.token) {
        const tokenAge = (Date.now() / 1000) - (STATE.tokenTs || 0);
        const maxAge   = (STATE.tokenMinutes || 480) * 60;
        if (tokenAge > maxAge) {
          return { error: 'Token vypršel. Vygeneruj nový QR.' };
        }
      }
      const valid = (paths || []).filter(p => {
        if (!p) return false;
        const ext = path.extname(p).toLowerCase();
        return fs.existsSync(p) && ALLOWED_ALL_EXTS.includes(ext);
      });
      if (!valid.length) {
        return { error: 'Žádné platné soubory (PNG/JPG/WEBP/MP4/MOV/PDF).' };
      }
      return { files: valid, job: activeJob };
    } catch (e) {
      log('ERROR', 'files:drop handler', String(e));
      return { error: String(e) };
    }
  });

  /* ── Manuální výběr souborů ────────────────────────────── */
  ipcMain.handle('files:manual-select', async (_, { job }) => {
    try {
      const activeJob = STATE.tokenJob || STATE.job || job;
      if (!activeJob) {
        return { error: 'Žádná aktivní zakázka.' };
      }
      if (STATE.token) {
        const tokenAge = (Date.now() / 1000) - (STATE.tokenTs || 0);
        const maxAge   = (STATE.tokenMinutes || 480) * 60;
        if (tokenAge > maxAge) {
          return { error: 'Token vypršel.' };
        }
      }

      // Použij okno, ze kterého přišel požadavek (upload nebo hlavní okno)
      const { BrowserWindow: BW } = require('electron');
      const callerWin = BW.fromWebContents(_.sender) || win;
      const result = await dialog.showOpenDialog(callerWin, {
        title:       `Vyber soubory pro zakázku ${activeJob}`,
        properties:  ['openFile', 'multiSelections'],
        filters: [
          { name: 'Všechny podporované', extensions: ['png','jpg','jpeg','webp','mp4','mov','m4v','avi','mkv','webm','pdf'] },
          { name: 'Obrázky',  extensions: ['png','jpg','jpeg','webp'] },
          { name: 'Videa',    extensions: ['mp4','mov','m4v','avi','mkv','webm'] },
          { name: 'PDF',      extensions: ['pdf'] },
          { name: 'Vše',      extensions: ['*'] },
        ],
      });
      if (result.canceled || !result.filePaths.length) {
        return { files: [] };
      }
      const valid = result.filePaths.filter(p => {
        const ext = path.extname(p).toLowerCase();
        return ALLOWED_ALL_EXTS.includes(ext);
      });
      return { files: valid, job: STATE.tokenJob || STATE.job };
    } catch (e) {
      log('ERROR', 'files:manual-select handler', String(e));
      return { error: String(e) };
    }
  });

  /* ── Uložení souborů z dialogu ─────────────────────────── */
  ipcMain.handle('files:save', async (_, { files, job }) => {
    try {
      const cfg     = readConfig();
      const saveDir = (cfg.SAVE_DIR || '').trim();
      if (!saveDir || !fs.existsSync(saveDir)) {
        return { error: 'Cílová složka není nastavena nebo neexistuje.' };
      }

      const saved = [];

      for (const item of files) {
        let outPath;
        try {
          const { path: srcPath, type, openPaint } = item;
          // Typ „QR" = fotka umazaného QR kódu → editor rovnou spustí modul Oprava QR.
          // QR je jen identifikátor; do zakázky se ukládá jako SD_ (Scan dokumentace).
          const isQrType = (type === 'QR');
          outPath = planOutputPath(saveDir, job, isQrType ? 'SD' : type, srcPath);
          const ext     = path.extname(srcPath).toLowerCase();
          const isVideo = ALLOWED_VIDEO_EXTS.includes(ext);
          const isPdf   = ALLOWED_PDF_EXTS.includes(ext);

          if (isVideo || isPdf) {
            // Video/PDF – přímá kopie
            fs.copyFileSync(srcPath, outPath);
            _reservedPaths.delete(outPath);
            log('INFO', `Saved ${isPdf ? 'PDF' : 'video'}`, path.basename(outPath));
            _apiEnqueue(outPath);
          } else {
            // Obrázek
            // Typ QR otevři v editoru vždy (spustí modul Oprava QR).
            const willOpenPaint = isQrType || type === 'SP' || (openPaint && ['SD','SDX','VT','SN'].includes(type));

            if (willOpenPaint && paintMod && paintMod.createPaintTempCopy) {
              // Přesun přes Paint temp copy – rezervace zůstane do fyzického přesunu
              // (soubor vznikne v paint_temp, _reservedPaths drží místo na disku)
              const raw = fs.readFileSync(srcPath);
              await paintMod.createPaintTempCopy(outPath, raw, isQrType ? { mode: 'qr' } : undefined);
              // Rezervaci odstraníme až Paint přesune soubor – ale pro případ
              // restartu ji uvolníme po návratu z createPaintTempCopy (fronta běží async)
              _reservedPaths.delete(outPath);
              log('INFO', `Saved to temp for Paint (${type})`, path.basename(outPath));
            } else {
              // Přímá kopie / konverze PNG
              fs.copyFileSync(srcPath, outPath);
              _reservedPaths.delete(outPath);
              log('INFO', 'Saved image', path.basename(outPath));
              _apiEnqueue(outPath);
            }
          }

          saved.push(path.basename(outPath));

          // Statistiky
          if (utils.incrementTypeStat) utils.incrementTypeStat(type);

        } catch (fileErr) {
          // Uvolni rezervaci i při chybě
          if (typeof outPath === 'string') _reservedPaths.delete(outPath);
          log('ERROR', `Save failed for ${item.path}`, String(fileErr));
        }
      }

      // Aktualizuj stats a pošli do renderer (jen pokud okno žije)
      const stats = await _buildStats();
      try {
        if (!win.isDestroyed()) win.webContents.send('stats:update', stats);
      } catch (_statsErr) { /* okno skryté nebo zničené – nevadí */ }

      return { saved, stats };

    } catch (e) {
      log('ERROR', 'files:save handler', String(e));
      return { error: String(e) };
    }
  });

  /* ── Nativní D&D oznámení z Electron (windnd ekvivalent) ─ */
  ipcMain.on('files:nativeDropNotify', (_, paths) => {
    win.webContents.send('files:nativeDrop', { files: paths });
  });

  /* ── Vložení obrázku ze schránky (PrintScreen / Ctrl+V) ── */
  ipcMain.handle('files:clipboard-paste', async (_, { job }) => {
    try {
      const activeJob = STATE.tokenJob || STATE.job || job;
      if (!activeJob) {
        return { error: 'Žádná aktivní zakázka.' };
      }
      if (STATE.token) {
        const tokenAge = (Date.now() / 1000) - (STATE.tokenTs || 0);
        const maxAge   = (STATE.tokenMinutes || 480) * 60;
        if (tokenAge > maxAge) {
          return { error: 'Token vypršel. Vygeneruj nový QR.' };
        }
      }

      const img = clipboard.readImage();
      if (img.isEmpty()) {
        return { error: 'Schránka neobsahuje žádný obrázek. Nejprve stiskni PrintScreen (nebo Win+Shift+S).' };
      }

      // Uloži PNG do temp souboru
      const tmpDir  = os.tmpdir();
      const tmpName = `pb_clip_${Date.now()}.png`;
      const tmpPath = path.join(tmpDir, tmpName);
      fs.writeFileSync(tmpPath, img.toPNG());

      log('INFO', 'clipboard-paste', `Saved clipboard image to ${tmpPath}`);
      return { files: [tmpPath], job: activeJob };
    } catch (e) {
      log('ERROR', 'files:clipboard-paste handler', String(e));
      return { error: String(e) };
    }
  });

  /* ── QR expired (oznámení z renderer) ─────────────────── */
  ipcMain.handle('qr:expired', () => {
    log('INFO', 'QR token vypršel (renderer notification)');
    // Tray menu – qrActive = false ale token stále platí pro PC D&D
    updateTrayMenu(win, { qrActive: false });
  });

  /* ── QR rescale ────────────────────────────────────────── */
  ipcMain.handle('qr:rescale', () => {
    // Renderer požaduje překreslení QR na novou velikost
    // Main pošle zpět nová QR data (pokud máme uložená)
    if (STATE._lastQrData) {
      win.webContents.send('qr:data', STATE._lastQrData);
    }
  });

  /* ── Supabase: zastavit poller ─────────────────────────── */
  ipcMain.handle('supabase:stopPoller', () => {
    if (supabase.stopSbPoller) supabase.stopSbPoller();
    updateTrayMenu(win, { job: null, qrActive: false });
    win.webContents.send('poller:status', { job: null });
    log('INFO', 'Poller zastaven z renderer');
  });

  /* ── Supabase: spustit poller ──────────────────────────── */
  ipcMain.handle('supabase:startPoller', async (_, { job }) => {
    const cfg = readConfig();
    let saveDir = (cfg.SAVE_DIR || '').trim();
    if (!saveDir) {
      log('INFO', 'startPoller: SAVE_DIR není nastaveno – otvírám dialog');
      const result = await dialog.showOpenDialog(win, {
        properties: ['openDirectory'],
        title: 'Vyberte složku pro ukládání fotek',
      });
      if (result.canceled || !result.filePaths.length) {
        return { error: 'Cílová složka nebyla vybrána.' };
      }
      saveDir = result.filePaths[0];
      const cfg2 = readConfig();
      cfg2.SAVE_DIR = saveDir;
      if (config.writeConfig) config.writeConfig(cfg2);
      log('INFO', 'startPoller: SAVE_DIR uloženo', saveDir);
    }
    if (supabase.startSbPoller) {
      supabase.startSbPoller(cfg, job, saveDir);
    }
    STATE.pollerJob = job;
    updateTrayMenu(win, { job, qrActive: false, serverRunning: STATE.running });
    win.webContents.send('poller:status', { job });
    log('INFO', 'Poller spuštěn z renderer', `job=${job}`);
    return { ok: true };
  });

  /* ── Supabase: výsledek login z renderer ───────────────── */
  ipcMain.handle('supabase:loginResult', (_, { ok }) => {
    log('INFO', 'supabase:loginResult', `ok=${ok}`);
  });

  log('INFO', 'Phase 9 IPC handlery zaregistrovány');
}

/* ══════════════════════════════════════════════════════════
   HELPER – sestaví statistiky pro renderer
   ══════════════════════════════════════════════════════════ */
async function _buildStats() {
  try {
    const st = loadState ? loadState() : {};
    return {
      total:    st.totalUploads    || 0,
      session:  st.sessionUploads  || 0,
      jobCount: st.todayJobCount   || 0,
    };
  } catch (_) {
    return { total: 0, session: 0, jobCount: 0 };
  }
}

/* ══════════════════════════════════════════════════════════
   INTEGRACE S ELECTRON – MINIMIZE TO TRAY
   ══════════════════════════════════════════════════════════ */

/**
 * Nastaví chování okna při minimalizaci.
 * Volat z main.js po vytvoření mainWindow.
 * @param {BrowserWindow} win
 */
function setupMinimizeToTray(win) {
  // Lazy import float-window (main-side plovoucí ikona)
  let floatWindow = null;
  try { floatWindow = require('./float-window'); } catch (_) {}

  win.on('minimize', () => {
    // Čteme config živě – uživatel mohl změnit nastavení bez restartu
    const cfg2       = readConfig();
    const minimizeTo = (cfg2.MINIMIZE_TO || 'panel').toLowerCase();

    // ── TRAY ──────────────────────────────────────────────
    if (minimizeTo === 'tray') {
      // Tray musí existovat – pokud ne, vytvoř ho
      if (!_tray) setupTray(win);
      setTimeout(() => hideToTray(win, cfg2), 80);
      return;
    }

    // ── FLOAT ─────────────────────────────────────────────
    if (minimizeTo === 'float' && floatWindow) {
      setTimeout(() => {
        win.hide();   // skryj z taskbaru
        floatWindow.showFloat(
          win,
          () => {
            // onRestore callback
            const pos = floatWindow.getFloatPosition();
            if (pos) {
              const c = readConfig();
              c['FLOAT_X'] = String(pos.x);
              c['FLOAT_Y'] = String(pos.y);
              try { require('./config').writeConfig(c); } catch (_) {}
            }
            floatWindow.hideFloat();
            win.show();
            win.restore();
            win.focus();
          },
          cfg2
        );
      }, 80);
      return;
    }

    // ── PANEL (výchozí) ────────────────────────────────────
    // Standardní minimalizace na taskbar – nic neděláme
  });

  // Zavření okna (X) – chování závisí na MINIMIZE_TO
  win.on('close', (e) => {
    if (app.isQuitting) return;  // skutečný quit → nechej zavřít

    const cfg2       = readConfig();
    const minimizeTo = (cfg2.MINIMIZE_TO || 'panel').toLowerCase();

    if (minimizeTo === 'tray') {
      // X → schovat do tray místo ukončení
      e.preventDefault();
      if (!_tray) setupTray(win);
      hideToTray(win, cfg2);
    }
    // float a panel: X = skutečné ukončení (app.quit přes before-quit)
  });
}

/* ══════════════════════════════════════════════════════════
   NOTIFIKACE (Phase 9)
   ══════════════════════════════════════════════════════════ */

/**
 * Zobrazí systémovou notifikaci.
 * @param {string} title
 * @param {string} body
 */
function showNotification(title, body) {
  if (!Notification.isSupported()) return;
  const n = new Notification({ title, body, silent: true });
  n.show();
  log('INFO', 'Notification', `${title}: ${body}`);
}

/**
 * Zobrazí notifikaci při příchodu souboru z mobilu / Supabase.
 * Volá se z server.js nebo supabase.js při každém přijatém souboru.
 * @param {string} filename
 * @param {string} job
 */
function notifyFileReceived(filename, job) {
  showNotification(
    'PhotoBridge – nový soubor',
    `${filename}  (zakázka ${job})`
  );
}

/* ══════════════════════════════════════════════════════════
   EXPORT
   ══════════════════════════════════════════════════════════ */
module.exports = {
  updateTrayRtsState,
  setupTray,
  setMainWindow,
  updateTrayMenu,
  destroyTray,
  hideToTray,
  showWindow,
  setupMinimizeToTray,
  registerPhase9IpcHandlers,
  showNotification,
  notifyFileReceived,
  buildTrayMenu,       // exportováno pro testování
};
