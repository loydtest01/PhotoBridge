'use strict';
// ============================================================
// PhotoBridge – src/main/settings-window.js
// Samostatné okno nastavení (BrowserWindow) + IPC handlery
//
// Fáze: Základ + IP pro QR + Mód přenosu
//   • openSettingsWindow()   – otevře / přenese fokus na okno
//   • registerIpcHandlers()  – registruje všechny settings:* kanály
// ============================================================

const { BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs   = require('fs');

// ── Lazy importy hlavních modulů ──────────────────────────────────────────────
let _config    = null;
let _utils     = null;
let _updater   = null;
let _supabase  = null;
let _server    = null;

function cfg()      { return _config   || (_config   = require('./config'));   }
function utils()    { return _utils    || (_utils    = require('./utils'));     }
function updater()  { return _updater  || (_updater  = require('./updater'));   }
function supabase() { return _supabase || (_supabase = require('./supabase')); }
function server()   { return _server   || (_server   = require('./server'));   }

// ── Singleton reference na okno ──────────────────────────────────────────────
let _win = null;

// ── Cesta k renderer adresáři ─────────────────────────────────────────────────
const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

// ══════════════════════════════════════════════════════════════
// OTEVŘENÍ / FOKUS OKNA
// ══════════════════════════════════════════════════════════════

/**
 * Otevře okno nastavení (nebo mu přenese fokus, pokud již existuje).
 * @param {BrowserWindow} mainWindow  – reference na hlavní okno (pro rodičovský vztah)
 */
function openSettingsWindow(mainWindow) {
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return _win;
  }

  const cfg2 = cfg().readConfig();

  _win = new BrowserWindow({
    width:  780,
    height: 720,
    minWidth:  640,
    minHeight: 500,
    title: 'PhotoBridge – Nastavení',
    icon: path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico'),
    parent: mainWindow || undefined,   // rodičovské okno → settings je vždy nad ním
    modal: false,                      // neblokující; true by zmrazilo hlavní okno
    webPreferences: {
      preload: PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      devTools: (process.argv.includes('--dev') || !require('electron').app.isPackaged),
    },
    show: false,
    backgroundColor: '#cfddf0',
    autoHideMenuBar: true,
    resizable: true,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'settings.html'));

  _win.once('ready-to-show', () => {
    _win.show();
  });

  _win.on('closed', () => {
    _win = null;
  });

  return _win;
}

// ══════════════════════════════════════════════════════════════
// IPC HANDLERY
// ══════════════════════════════════════════════════════════════

let _handlersRegistered = false;

/**
 * Registruje všechny settings:* IPC kanály.
 * Volat jednou po app.whenReady().
 * @param {function} getMainWindow  – getter pro hlavní okno
 */
function registerIpcHandlers(getMainWindow) {
  if (_handlersRegistered) return;
  _handlersRegistered = true;

  // ── settings:open – otevření okna (z hlavního okna nebo tray) ────────────
  ipcMain.handle('settings:open', () => {
    const mw = getMainWindow ? getMainWindow() : null;
    openSettingsWindow(mw);
    return { ok: true };
  });

  // ── settings:load – načtení konfigurace pro formulář ────────────────────
  ipcMain.handle('settings:load', () => {
    try {
      const c    = cfg().readConfig();
      const u    = utils();
      const srv  = server();
      const bm   = cfg().getEngineBackupMeta();

      // Sestavení seznamu dostupných IPv4 s popisky
      let ips = [];
      try {
        ips = u.getLocalIpv4CandidatesWithLabels().map(([ip, label]) => ({
          ip,
          label: `${ip}  (${label})`,
        }));
      } catch (_) {}

      return {
        ok:         true,
        cfg:        c,
        version:    (() => { try { return require('../../package.json').version; } catch { return require('electron').app.getVersion(); } })(),
        port:       u.STATE?.port || parseInt(c.PORT, 10) || 5000,
        ips,
        backupMeta: bm || null,
      };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:save – zápis konfigurace ────────────────────────────────────
  ipcMain.handle('settings:save', (_evt, partial) => {
    try {
      const current = cfg().readConfig();
      const merged  = Object.assign({}, current, partial);
      cfg().writeConfig(merged);

      // Informuj VŠECHNA okna o změně konfigurace (hlavní okno, QR popup, atd.)
      try {
        const { BrowserWindow } = require('electron');
        for (const w of BrowserWindow.getAllWindows()) {
          if (!w.isDestroyed()) {
            w.webContents.send('config:changed', merged);
          }
        }
      } catch (_) {}

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:back – zavře settings okno ──────────────────────────────────
  ipcMain.handle('settings:back', () => {
    if (_win && !_win.isDestroyed()) {
      _win.close();
    }
    return { ok: true };
  });

  // ── settings:pick-folder – dialog pro výběr složky ───────────────────────
  ipcMain.handle('settings:pick-folder', async () => {
    const owner = (_win && !_win.isDestroyed()) ? _win : (getMainWindow ? getMainWindow() : null);
    const result = await dialog.showOpenDialog(owner, {
      properties: ['openDirectory'],
      title: 'Vyberte složku pro ukládání',
    });
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
  });

  // ── settings:test-folder – ověření přístupnosti složky ───────────────────
  ipcMain.handle('settings:test-folder', (_evt, folderPath) => {
    try {
      if (!folderPath) return { ok: false, error: 'Cesta je prázdná.' };
      if (!fs.existsSync(folderPath)) return { ok: false, error: 'Složka neexistuje.' };
      // Ověření zápisu: zkus vytvořit dočasný soubor
      const tmp = path.join(folderPath, `.pb_write_test_${Date.now()}`);
      fs.writeFileSync(tmp, 'test', 'utf8');
      fs.unlinkSync(tmp);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:find-ips – obnovení seznamu dostupných IPv4 ─────────────────
  ipcMain.handle('settings:find-ips', () => {
    try {
      const candidates = utils().getLocalIpv4CandidatesWithLabels();
      // Vrátíme pole { ip, label } a také plochý seznam ip stringů
      const ips = candidates.map(([ip, label]) => ip);
      const detailed = candidates.map(([ip, label]) => ({ ip, label: `${ip}  (${label})` }));
      return { ok: true, ips, detailed };
    } catch (e) {
      return { ok: false, ips: [], error: e.message };
    }
  });

  // ── settings:test-qr – otevře URL v prohlížeči pro ověření QR ────────────
  ipcMain.handle('settings:test-qr', async (_evt, { ip, port }) => {
    try {
      const { shell } = require('electron');
      const url = `http://${ip}:${port}/`;
      shell.openExternal(url);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:check-updates – manuální kontrola aktualizací ──────────────
  ipcMain.handle('settings:check-updates', async (_evt, dir) => {
    try {
      const result = await updater().scanForUpdates(dir !== undefined ? dir : undefined);
      return { ok: true, ...result };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:install-updates – spustí instalaci a restart ────────────────
  ipcMain.handle('settings:install-updates', async (_evt, dir) => {
    try {
      // checkForUpdates(true) = manuální mód → zobrazí dialog Nainstalovat/Odložit/Zrušit
      const result = await updater().checkForUpdates(true);
      return { ok: true, result };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:restore-backup – obnoví zálohu engine souborů ──────────────
  ipcMain.handle('settings:restore-backup', async () => {
    try {
      const result = cfg().restoreEngineBackup();
      if (result.ok) {
        // Restart po krátké prodlevě
        setTimeout(() => {
          require('electron').app.relaunch();
          require('electron').app.quit();
        }, 2000);
      }
      return result;
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:test-login – ověření přihlašovacích údajů ──────────────────
  ipcMain.handle('settings:test-login', async (_evt, { user, pass }) => {
    try {
      if (!user || !pass) return { ok: false, error: 'Vyplň e-mail i heslo.' };
      const c = cfg().readConfig();
      const result = await supabase().sbLogin(c, user, pass);
      if (result && result.ok) {
        // Ulož přihlašovací údaje do konfigurace
        const updated = cfg().readConfig();
        updated.SB_EMAIL = user;
        updated.SB_PASS  = pass;
        cfg().writeConfig(updated);
        // Informuj hlavní okno o přihlášení
        const mw = getMainWindow ? getMainWindow() : null;
        if (mw && !mw.isDestroyed()) {
          mw.webContents.send('supabase:status', {
            loggedIn: true,
            email:    user,
            userId:   result.userId || '',
          });
        }
      }
      return result || { ok: false, error: 'Přihlášení selhalo.' };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:change-password – změna hesla přes Supabase API ────────────
  ipcMain.handle('settings:change-password', async (_evt, { currentPass, newPass }) => {
    try {
      if (!currentPass) {
        return { ok: false, error: 'Zadej původní heslo.' };
      }
      if (!newPass || newPass.length < 6) {
        return { ok: false, error: 'Heslo musí mít alespoň 6 znaků.' };
      }

      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const u    = utils();
      let email  = (c.SB_EMAIL || '').trim();

      // Po cutover/re-loginu bývá SB_EMAIL v configu prázdný, i když je
      // uživatel přihlášený → vezmi e-mail z aktivní session, případně
      // z access tokenu (JWT).
      if (!email) email = (u.STATE && u.STATE.sbEmail ? u.STATE.sbEmail : '').trim();
      if (!email) {
        const tok = u.STATE && u.STATE.sbAccessToken;
        if (tok) {
          try {
            const payload = JSON.parse(Buffer.from(tok.split('.')[1], 'base64').toString('utf8'));
            email = (payload.email || '').trim();
          } catch (_) {}
        }
      }

      if (!email) {
        return { ok: false, error: 'Nepodařilo se zjistit e-mail přihlášeného účtu. Přihlas se prosím znovu a zkus to.' };
      }

      // ── 1. Ověř původní heslo přes re-login ──────────────────────────────
      const loginResp = await fetch(`${url}/auth/v1/token?grant_type=password`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': anon },
        body:    JSON.stringify({ email, password: currentPass }),
      });
      if (!loginResp.ok) {
        return { ok: false, error: 'Původní heslo je nesprávné.' };
      }
      const loginData = await loginResp.json();
      const accessToken = loginData.access_token || u.STATE?.sbAccessToken;

      if (!accessToken) {
        return { ok: false, error: 'Nepodařilo se získat přístupový token.' };
      }

      // ── 2. Změn heslo ─────────────────────────────────────────────────────
      const resp = await fetch(`${url}/auth/v1/user`, {
        method:  'PUT',
        headers: {
          'Content-Type':  'application/json',
          'apikey':        anon,
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ password: newPass }),
      });

      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        return { ok: false, error: body.msg || body.error_description || `HTTP ${resp.status}` };
      }

      // ── 3. Ulož nové heslo lokálně ────────────────────────────────────────
      const updated = cfg().readConfig();
      updated.SB_EMAIL = email;   // doplň e-mail do configu (po cutover chyběl)
      updated.SB_PASS = newPass;
      cfg().writeConfig(updated);

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:reset-password – odešle reset email přes Supabase ───────────
  ipcMain.handle('settings:reset-password', async () => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();

      if (!url || !anon) {
        return { ok: false, error: 'Supabase URL nebo klíč není nastaven.' };
      }

      // Zkus email z JWT tokenu (přihlášený uživatel) → fallback na config
      let email = '';
      try {
        const token = utils().STATE?.sbAccessToken;
        if (token) {
          const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString('utf8'));
          email = payload.email || '';
        }
      } catch (_) {}

      if (!email) email = (c.SB_EMAIL || '').trim();

      if (!email) {
        return { ok: false, error: 'Nepodařilo se zjistit email. Zadej ho v poli E-mail a ulož.' };
      }

      const resp = await fetch(`${url}/auth/v1/recover`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': anon },
        body:    JSON.stringify({ email }),
      });

      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        return { ok: false, error: body.msg || body.error_description || `HTTP ${resp.status}` };
      }

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });
}

// ══════════════════════════════════════════════════════════════
// EXPORT
// ══════════════════════════════════════════════════════════════

module.exports = {
  openSettingsWindow,
  registerIpcHandlers,
  getSettingsWindow: () => _win,
};
