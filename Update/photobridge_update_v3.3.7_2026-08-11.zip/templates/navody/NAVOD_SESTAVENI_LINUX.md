# Jak sestavit PhotoBridge pro Linux

Postup pro člověka, který na Windows a příkazovou řádku nerad.
Stav k 11. 8. 2026, PhotoBridge v3.2.6.

---

> ## ⛔ NEŽ ZAČNEŠ — PŘEČTI SI TOHLE
>
> **Sestavení AppImage se bez příkazové řádky neobejde.** Není to volba, je to
> vlastnost nástroje. Postup níž se dá zkopírovat po řádcích, ale příkazy tam
> budou.

```diff
- ! WINDOWSOVOU VERZI SESTAVUJ NA WINDOWS, LINUXOVOU VE WSL.
-   Opačně to nefunguje spolehlivě.
-
- ! OBĚ VERZE ZE STEJNÉHO package.json.
-   Verze se bere odtud a je pro obě platformy společná.
-
- ! PRVNÍ SESTAVENÍ STÁHNE ~300 MB (Electron + nástroje). Počítej s tím.
```

---

## Která cesta

| | Kdy zvolit | Náročnost |
|---|---|---|
| **WSL** | máš zdrojáky na svém PC (tvůj případ) | střední, jednorázově |
| **GitHub Actions** | chceš to mít automatické a zdrojáky v repozitáři | vyšší nastavení, pak nulová práce |
| **Linuxový počítač** | máš ho po ruce | nejjednodušší |

Níž je popsaná **cesta přes WSL**, protože ta odpovídá tomu, jak to máš dnes.
GitHub Actions je popsaná v kapitole 6 jako lepší řešení do budoucna.

---

## 1. Nainstalovat WSL (jednorázově)

Otevři **PowerShell jako správce** (pravý klik na Start → Terminál (správce)):

```powershell
wsl --install -d Ubuntu
```

Restartuj počítač. Po restartu se sám otevře Ubuntu a zeptá se na uživatelské
jméno a heslo — vymysli si cokoliv, s Windows to nesouvisí. **Heslo se při
psaní nezobrazuje**, to je normální.

Ověření, že to běží:

```bash
lsb_release -a
```

---

## 2. Připravit prostředí (jednorázově)

V okně Ubuntu:

```bash
sudo apt update
sudo apt install -y nodejs npm unzip zip
```

Zkontroluj verzi Node:

```bash
node -v
```

**Musí být alespoň v18.** Když je nižší, doinstaluj novější:

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

---

## 3. Dostat se ke zdrojákům

WSL vidí disky Windows pod `/mnt/`. Tvoje aplikace je tedy zde:

```bash
cd /mnt/c/Users/opapez/Desktop/PhotoBridgeE/resources/app
```

Ověř, že jsi na správném místě:

```bash
cat package.json | grep version
```

> **Tip:** kopírovat zdrojáky do Linuxu není potřeba, ale sestavení
> z `/mnt/c/` je pomalejší. Když tě to bude štvát, zkopíruj si je:
> ```bash
> cp -r /mnt/c/Users/opapez/Desktop/PhotoBridgeE/resources/app ~/photobridge
> cd ~/photobridge
> ```

---

## 4. Sestavit

```bash
npm install
npm run build:linux
```

První `npm install` trvá i několik minut a stáhne stovky megabajtů. Podruhé
už je to rychlé.

Výsledek najdeš v `dist/`:

```bash
ls -lh dist/
```

Hledáš:

```
PhotoBridge-Linux-3.2.6.AppImage
```

---

## 5. Vyzkoušet

```bash
chmod +x dist/PhotoBridge-Linux-3.2.6.AppImage
./dist/PhotoBridge-Linux-3.2.6.AppImage
```

WSL nemá grafické prostředí ve výchozím stavu, takže se okno nemusí otevřít.
Na Windows 11 s WSLg by mělo. Když ne, nevadí — soubor je hotový a otestuje
se až na skutečném Linuxu.

Zkopírovat výsledek zpátky do Windows:

```bash
cp dist/PhotoBridge-Linux-*.AppImage /mnt/c/Users/opapez/Desktop/
```

---

## 6. Lepší cesta do budoucna: GitHub Actions

Tohle je práce navíc jednou, ale pak už se o sestavení nestaráš vůbec —
GitHub ho udělá sám a rovnou vydá Release.

**Podmínka:** zdrojáky musí být v repozitáři. Dnes tam máš jen `Update/`
a `index.html`.

Postup:

1. Nahrát zdrojáky do repozitáře (bez `node_modules`, `backup/`, `dist/`)
2. Vytvořit soubor `.github/workflows/build.yml` (obsah v kapitole 7)
3. Vydat verzi označením: Releases → Draft → tag `v3.2.6` → Publish

GitHub pak sestaví **Windows i Linux zároveň** a připojí oba soubory
k tomu Release. Ty jen počkáš deset minut.

**Výhoda navíc:** zdrojáky v repozitáři znamenají historii změn. Dnes žádnou
nemáš — kdyby se něco pokazilo, nedá se zjistit, co přesně se změnilo a kdy.

**Na co pozor:** kdyby byl repozitář veřejný, zdrojáky uvidí kdokoliv.
Zkontroluj, že v nich nejsou klíče. `service_role` klíč ani `client_secret`
tam nejsou (čtou se za běhu ze Supabase), ale projdi si to.

---

## 7. Soubor pro GitHub Actions

Ulož jako `.github/workflows/build.yml`:

```yaml
name: Sestavení PhotoBridge

# Spustí se, když vydáš Release s označením v*
on:
  release:
    types: [published]

jobs:
  sestavit:
    strategy:
      matrix:
        os: [windows-latest, ubuntu-latest]
    runs-on: ${{ matrix.os }}

    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Instalace závislostí
        run: npm ci

      - name: Sestavení (Windows)
        if: matrix.os == 'windows-latest'
        run: npm run build:win

      - name: Sestavení (Linux)
        if: matrix.os == 'ubuntu-latest'
        run: npm run build:linux

      # Připojí hotové soubory k Release
      - name: Připojit k vydání
        uses: softprops/action-gh-release@v2
        with:
          files: |
            dist/*.exe
            dist/*.AppImage
```

---

## 8. Když to nejde

### `npm install` skončí chybou na `sharp`

Sharp obsahuje nativní kód a potřebuje překladač:

```bash
sudo apt install -y build-essential python3
npm install
```

### `electron-builder` hlásí chybějící ikonu

Zkontroluj, že existuje `templates/icon_512.png`. Cesta je v `package.json`
v sekci `build.linux.icon`.

### AppImage se nespustí

```bash
sudo apt install -y libfuse2
```

Nebo spusť s `--no-sandbox`:

```bash
./PhotoBridge-Linux-3.2.6.AppImage --no-sandbox
```

### Sestavení je pomalé

Zdrojáky na `/mnt/c/` jsou pomalé kvůli překladu mezi systémy souborů.
Zkopíruj je do `~/` podle tipu v kapitole 3.

### Chyba o chybějící složce `engine`

Už je opravená ve v3.2.6 — `extraResources` odkazovalo na složku, která
neexistuje. Když se objeví na starší verzi, smaž v `package.json`
z `build.extraResources` položku s `engine`.

---

## 9. Co po sestavení

Soubor patří do **Releases**, ne do repozitáře — podrobnosti
v `NAVOD_RELEASES.md`.

Na cílovém Linuxu:

```bash
sudo apt install -y unzip zip libfuse2
chmod +x PhotoBridge-Linux-3.2.6.AppImage
./PhotoBridge-Linux-3.2.6.AppImage
```

Rozdíly proti Windows (tisk, editor, cesty) jsou v `NAVOD_LINUX.md`.
