# Co nasadit — postup krok za krokem

Stav k 10. 8. 2026. Hotový máš zatím jen účet správce.

---

> ## ⛔ POŘADÍ JE ZÁVAZNÉ
>
> Kroky 1–3 jsou příprava a musí být hotové dřív, než nasadíš aplikaci.
> Krok 8 (záchrana fotek) až úplně nakonec — před opravou by se problém zopakoval.

---

## 1. Supabase — signál k aktualizaci

**Soubor:** `supabase_signal_aktualizace.sql`
**Kam:** SQL Editor → celé najednou

Zapne Realtime pro `pb_settings` a založí klíč `urgent_version`.

**Ověř na konci:**
- `select value from pb_settings where key='urgent_version'` → vrátí prázdno (to je správně)
- druhý dotaz na `pg_publication_tables` → **musí vrátit jeden řádek**. Když nic, `alter publication` neproběhl a signál nikdy nedorazí.

---

## 2. Edge Funkce

**Supabase → Edge Functions**

| Funkce | Co s ní |
|---|---|
| `admin-queue` | přenasadit obsahem `admin-queue.ts` — přibyla akce „signal" a úklid fronty |
| `Delete-account` | **smazat a založit znovu jako `delete-account`** malými písmeny — jinak vrací 404 |
| `rts-sso` | nechat, pokud jsi ji nasadil; obsah je v `rts-sso-index.ts` |

**Po každém Deploy zkontroluj u všech tří:**
Details → **Verify JWT with legacy secret** → **vypnuto**. Zapíná se samo.

---

## 3. Cloudflare Worker

**Soubor:** `photobridge-r2-worker.js`
**Kam:** Cloudflare → Workers & Pages → `photobridge-r2` → Edit code → nahradit celý obsah → Deploy

Pak **Settings → Variables → Add variable**:

```
SUPABASE_ANON_KEY = <anon klíč projektu>
```

Anon klíč je veřejný, může být jako plain text. **Bez něj vrací kontrola úložiště 403.**

---

## 4. Aplikace

**Soubor:** `photobridge_update_v3.1.95_2026-08-10.zip` → do složky `Update/`
**Soubor:** `urgent.json` → do složky `Update/`

Pak v aplikaci Nastavení → Zkontrolovat aktualizace.

Tuhle poslední verzi rozešli postaru. **Od příště už stačí tlačítko v Admin centru.**

---

## 5. Mobilní stránka

Do **kořene** repozitáře `loydtest01/PhotoBridge`, **oba soubory zároveň**:

- `index.html` (v1.4.3)
- `sw.js` (cache `pb-v1.0.19`)

Když nahraješ jen jeden, telefonům se změna neprojeví — service worker jim podstrčí starou verzi z mezipaměti.

**Ověř na telefonu:** zavřít a otevřít aplikaci, dole musí být **v1.4.3**.

---

## 6. Kontrola, že to běží

V aplikaci po restartu:

- Nastavení → **🛡️ Admin centrum** se ukáže a **jde rozkliknout**
- v logu `updater  Kontrola urgentních aktualizací aktivní (á 30 min)`
- v logu `SB_REALTIME subscribe OK`

Když se Admin centrum neukáže, znovu otevři okno Nastavení — seznam správců se načítá při otevření.

---

## 7. Zkouška signálu

Admin centrum → **Vyhlásit okamžitou aktualizaci** → zadat `3.1.95` → Vyhlásit.

Aplikace, které už 3.1.95 mají, neudělají nic — do logu napíšou:

```
updater  Signál na 3.1.95, ale mám už 3.1.95 – neinstaluji
```

Tím ověříš, že signál prochází, aniž bys cokoli instaloval.

---

## 8. Záchrana uvízlých fotek

**Až teprve teď**, když všechno výše běží.

Admin centrum → **Fotky uvízlé v úložišti** → Starší než: *1 hodinu* → **Zkontrolovat**

Nálezy se roztřídí do tří skupin. Pak:

- **Označeno jako hotové** → *Vrátit do fronty*. Stáhnou si je PC techniků samy.
- **Chybí ve frontě** → *Stáhnout ke mně*. Aplikace o nich neví, jinak k nim není cesta.
- **Čeká na zpracování** → nesahat.

Až budeš mít jistotu, že jsou fotky v pořádku zpracované, můžeš použít *Stáhnout a smazat z úložiště*.

**Soubory `supabase_zachrana_r2.sql` a `supabase_doplneni_fronty.sql` už pak nepotřebuješ** — tlačítko zvládne i účet `ac4d9a84`, na který jsem neměl seznam souborů.

---

## Co zbývá otevřené

**Luboš** — povolení `https://loydtest01.github.io/PhotoBridge/` jako redirect_uri a nové client_id pro mobil. Až dorazí, spustíš `supabase_mobilni_klient.sql`.

**Mobilní SSO** — `rts_sso_enabled` je pořád `off`. Zapni až po Lubošovi:
```sql
update public.pb_settings set value='on' where key='rts_sso_enabled';
```

**Výchozí heslo `Britex2026`** — účty, které si ho nezměnily, jsou k němu stále přístupné. Odloženo po dohodě.

**Návody** k uložení do repozitáře: `NAVOD_britex_prihlaseni.md`, `NAVOD_LINUX.md`, `NAVOD_AKTUALIZACE.md`.
