'use strict';
// ============================================================
// PhotoBridge Editor Window v3.1.1 – správa Electron okna s editor.html
//
// Klíčový vzor:
//   openEditor(filePath) vrací Promise, která se resolvne až
//   editor okno zavře (uložením nebo bez uložení). Tím se chová
//   stejně jako mspaint flow – paint.js volá v cyklu a každý
//   editor blokuje frontu dokud uživatel nedokončí editaci.
// ============================================================

const { BrowserWindow, ipcMain, app } = require('electron');
const path = require('path');
const fs   = require('fs');
const { spawn } = require('child_process');

let _editorWindow = null;
let _currentFilePath = null;
let _resolveCurrent = null;   // resolve fce pro Promise vrácenou z openEditor
let _log = null;

function setLogger(logFn) { _log = logFn; }
function log(level, ctx, msg) { if (_log) _log(level, ctx, msg); }

// ── PUBLIC API ───────────────────────────────────────────
/**
 * Otevře editor pro daný soubor a počká na jeho dokončení.
 * @param {string} filePath
 * @returns {Promise<boolean>} true po úspěšném dokončení editace
 */
function openEditor(filePath, opts) {
  return new Promise((resolve) => {
    if (!filePath || !fs.existsSync(filePath)) {
      log('WARN', 'editor', `openEditor: soubor neexistuje ${filePath}`);
      return resolve(false);
    }

    // Pokud okno už existuje (vzácný edge case), zavři ho silově
    if (_editorWindow && !_editorWindow.isDestroyed()) {
      log('WARN', 'editor', 'Editor okno již existuje – zavírám předchozí');
      try { _editorWindow.destroy(); } catch (_) {}
      _editorWindow = null;
      if (_resolveCurrent) { _resolveCurrent(false); _resolveCurrent = null; }
    }

    _currentFilePath = filePath;
    _resolveCurrent  = resolve;

    _createEditorWindow(filePath, opts);
  });
}

// ── INTERNAL ─────────────────────────────────────────────
function _createEditorWindow(initialFile, opts) {
  _editorWindow = new BrowserWindow({
    width: 1400, height: 900,
    minWidth: 1000, minHeight: 600,
    title: 'PhotoBridge Editor',
    show: false,   // zobrazíme až po maximalizaci (bez bliknutí)
    icon: path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'editor-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webSecurity: false,   // umožní fetch na api.groq.com z file:// originu (AI narovnání)
    },
  });

  // Maximalizuj okno hned po vytvoření (uživatel chce velké okno na portrét fotky)
  _editorWindow.maximize();
  _editorWindow.once('ready-to-show', () => {
    _editorWindow.show();
    _editorWindow.focus();
    // Editor se musí otevřít VŽDY navrchu. Když je v popředí jiná aplikace,
    // Windows novému oknu odepře fokus a editor zůstane vzadu. Krátký
    // alwaysOnTop "blik" donutí OS dát okno do popředí; po chvíli ho zase
    // vypneme, ať se editor chová jako normální okno (nezůstane nad vším).
    try {
      _editorWindow.setAlwaysOnTop(true);
      _editorWindow.focus();
      setTimeout(() => {
        if (_editorWindow && !_editorWindow.isDestroyed()) {
          _editorWindow.setAlwaysOnTop(false);
          _editorWindow.focus();
        }
      }, 400);
    } catch (_) {}
  });

  _editorWindow._currentFile = initialFile;
  _editorWindow._allowClose = false;   // dokud uživatel nepotvrdí, bráníme zavření

  const _modeParam = (opts && opts.mode === 'qr') ? '&mode=qr' : '';
  const url = `file://${path.join(__dirname, '..', 'renderer', 'editor.html')}?file=${encodeURIComponent(initialFile)}${_modeParam}`;
  _editorWindow.loadURL(url);
  _editorWindow.setMenuBarVisibility(false);

  // Zachytit kliknutí na křížek (X) – zeptat se rendereru na potvrzení
  _editorWindow.on('close', (e) => {
    const win = _editorWindow;
    if (!win || win._allowClose) return;   // už potvrzeno → nech zavřít
    e.preventDefault();   // zatím nezavírat
    // Pošli rendereru zprávu aby ukázal potvrzovací dialog
    try {
      win.webContents.send('editor:close-requested');
    } catch (_) {
      // Pokud renderer nereaguje, povol zavření (fallback)
      win._allowClose = true;
      win.close();
    }
  });

  _editorWindow.on('closed', () => {
    log('INFO', 'editor', `Editor okno zavřeno: ${path.basename(_currentFilePath || '')}`);
    _editorWindow = null;
    const resolveFn = _resolveCurrent;
    _resolveCurrent = null;
    _currentFilePath = null;
    if (resolveFn) resolveFn(true);
  });

  log('INFO', 'editor', `Otevírám editor pro: ${path.basename(initialFile)}`);
}

// ── IPC HANDLERY ─────────────────────────────────────────
function registerIpcHandlers() {
  // Načtení obsahu souboru → data URL pro <img>
  ipcMain.handle('editor:readFile', async (_e, filePath) => {
    try {
      if (!filePath || !fs.existsSync(filePath)) return { ok: false, error: 'Soubor neexistuje' };
      const buf = fs.readFileSync(filePath);
      const ext = (path.extname(filePath).slice(1) || 'png').toLowerCase();
      const mime = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
      const dataUrl = `data:${mime};base64,${buf.toString('base64')}`;
      return { ok: true, dataUrl };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // Uložení (přepsání) souboru – stejně jako mspaint by zapsal po Ctrl+S
  ipcMain.handle('editor:saveFile', async (_e, filePath, dataArr) => {
    try {
      if (!filePath) return { ok: false, error: 'filePath chybí' };
      const buf = Buffer.from(dataArr);
      fs.writeFileSync(filePath, buf);
      log('INFO', 'editor', `Uložen (přepis): ${path.basename(filePath)} (${buf.length} B)`);
      return { ok: true, path: filePath };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // Tisk přes mspaint /p
  ipcMain.handle('editor:printFile', async (_e, dataArr, suggestedName) => {
    try {
      const tmpDir = app.getPath('temp');
      const tmpName = `pb_print_${Date.now()}_${(suggestedName || 'photo.png').replace(/[^\w.\-]/g, '_')}`;
      const tmpPath = path.join(tmpDir, tmpName);
      fs.writeFileSync(tmpPath, Buffer.from(dataArr));
      if (process.platform === 'win32') {
        const proc = spawn('mspaint.exe', ['/p', tmpPath], {
          detached: true, stdio: 'ignore', windowsHide: false,
        });
        proc.unref();
        log('INFO', 'editor', `Tisk přes mspaint: ${tmpPath}`);
      } else {
        // Linux/macOS: mspaint neexistuje. Otevřeme obrázek v systémové
        // prohlížečce, tisk spustí uživatel sám (Ctrl+P).
        const { shell } = require('electron');
        await shell.openPath(tmpPath);
        log('INFO', 'editor', `Otevřeno k tisku v systému: ${tmpPath}`);
      }
      setTimeout(() => { try { fs.unlinkSync(tmpPath); } catch (_) {} }, 60_000);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // Queue API - editor v této verzi vždy jen jedna fotka, paint.js drží frontu
  ipcMain.handle('editor:getQueue', () => ({ count: 0 }));
  ipcMain.handle('editor:nextInQueue', () => null);

  // Načte aktuální soubor (předaný při vytvoření okna)
  ipcMain.handle('editor:currentFile', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    return win && win._currentFile ? { path: win._currentFile } : null;
  });

  // Zavře editor okno – tím se resolve Promise z openEditor a paint.js
  // posune frontu na další fotku. Renderer volá tohle AŽ po potvrzení dialogu.
  ipcMain.handle('editor:close', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (win) {
      win._allowClose = true;   // přeskočí close-requested dialog
      win.close();
    }
    return { ok: true };
  });
}

module.exports = {
  openEditor,
  registerIpcHandlers,
  setLogger,
};
