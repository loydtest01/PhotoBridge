// ============================================================================
//  appimage-update.js – aktualizace AppImage na Linuxu
// ============================================================================
//
//  PROČ TENHLE MODUL EXISTUJE
//  AppImage je jeden zapečetěný soubor připojený JEN PRO ČTENÍ. Přepsat v něm
//  soubory nelze – instalace rozdílového balíčku skončí:
//      EROFS: read-only file system, unlink '.../resources/app/main.js'
//
//  Nedá se ale rozbalit, upravit a zabalit zpátky. Přesně to tenhle modul dělá,
//  takže rozdílové balíčky fungují i na Linuxu a nemusí se vydávat celý nový
//  AppImage u každé verze.
//
//  POSTUP
//    1. rozbalit stávající AppImage           (--appimage-extract)
//    2. vlepit do něj rozdílové balíčky        (unzip, stejné jako na Windows)
//    3. zabalit zpátky                         (appimagetool)
//    4. OVĚŘIT, že nový soubor vznikl a je použitelný
//    5. původní odložit do zálohy, nahradit novým
//    6. restartovat aplikaci
//
//  BEZPEČNOST
//  Původní soubor se přepisuje AŽ PO OVĚŘENÍ, že nový vznikl. Když cokoli
//  selže dřív, zůstane vše jak bylo a aplikace běží dál.
//
//  Záloha se maže až DEN PO ÚSPĚŠNÉM SPUŠTĚNÍ nové verze, ne po instalaci.
//  Kdyby nová verze nenaběhla, záloha je pořád k dispozici.
// ============================================================================

const fs   = require('fs');
const os   = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { app } = require('electron');

function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

const APPIMAGETOOL_URL =
    'https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage';

/** Kde leží běžící AppImage. Prázdné, když aplikace neběží jako AppImage. */
function cestaKAppImage() {
    return process.env.APPIMAGE || '';
}

function slozkaZaloh() {
    return path.join(app.getPath('userData'), 'backups', 'appimage');
}

/** Soubor, podle kterého se pozná, že se čeká na potvrzení úspěšného startu. */
function souborCekaniNaStart() {
    return path.join(app.getPath('userData'), 'appimage_update_pending.json');
}

// ── Nástroj na zabalení ──────────────────────────────────────────────────────

/**
 * Zajistí appimagetool. Stáhne se jen jednou a uloží do složky uživatele –
 * do instalace se nepřibaluje, ať se nezvětšuje o 10 MB kvůli něčemu,
 * co většina lidí nikdy nepotřebuje.
 */
async function zajistiAppImageTool() {
    const cil = path.join(app.getPath('userData'), 'appimagetool');

    if (fs.existsSync(cil)) {
        try { fs.accessSync(cil, fs.constants.X_OK); return cil; } catch (_) {}
    }

    log('INFO', 'APPIMG', 'Stahuji appimagetool…');
    const resp = await fetch(APPIMAGETOOL_URL, { redirect: 'follow' });
    if (!resp.ok) throw new Error(`appimagetool se nepodařilo stáhnout (HTTP ${resp.status})`);

    const buf = Buffer.from(await resp.arrayBuffer());
    if (buf.length < 1_000_000) throw new Error('Stažený appimagetool je podezřele malý');

    fs.writeFileSync(cil, buf);
    fs.chmodSync(cil, 0o755);
    log('INFO', 'APPIMG', `appimagetool uložen (${(buf.length / 1024 / 1024).toFixed(1)} MB)`);
    return cil;
}

// ── Hlavní postup ────────────────────────────────────────────────────────────

/**
 * Vyrobí novou verzi AppImage z rozdílových balíčků a nahradí tu stávající.
 *
 * @param {string[]} zipy  cesty ke staženým rozdílovým balíčkům, v pořadí instalace
 * @param {string}   novaVerze
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function aktualizuj(zipy, novaVerze) {
    const puvodni = cestaKAppImage();
    if (!puvodni) return { ok: false, error: 'Aplikace neběží jako AppImage.' };
    if (!Array.isArray(zipy) || !zipy.length) return { ok: false, error: 'Žádné balíčky k instalaci.' };

    const pracovni = fs.mkdtempSync(path.join(os.tmpdir(), 'pb_appimg_'));
    log('INFO', 'APPIMG', `Pracovní složka: ${pracovni}`);

    try {
        // ── 1. Rozbalit stávající AppImage ──────────────────────────────────
        log('INFO', 'APPIMG', 'Rozbaluji stávající AppImage…');
        const r1 = spawnSync(puvodni, ['--appimage-extract'], {
            cwd: pracovni, encoding: 'utf8', timeout: 180_000,
        });
        if (r1.status !== 0) {
            throw new Error(`Rozbalení selhalo: ${(r1.stderr || '').slice(0, 200)}`);
        }

        const koren  = path.join(pracovni, 'squashfs-root');
        const appDir = path.join(koren, 'resources', 'app');
        if (!fs.existsSync(appDir)) {
            throw new Error('V rozbaleném AppImage chybí resources/app');
        }

        // ── 2. Vlepit rozdílové balíčky ─────────────────────────────────────
        // Stejný obsah jako na Windows – přepisují se jen změněné soubory.
        for (const zip of zipy) {
            log('INFO', 'APPIMG', `Rozbaluji ${path.basename(zip)}…`);
            const r2 = spawnSync('unzip', ['-o', '-q', zip, '-d', appDir], {
                encoding: 'utf8', timeout: 120_000,
            });
            if (r2.status !== 0) {
                throw new Error(`Balíček ${path.basename(zip)} se nepodařilo rozbalit `
                              + `(je nainstalovaný unzip?): ${(r2.stderr || '').slice(0, 200)}`);
            }
        }

        // ── 3. Zabalit zpátky ───────────────────────────────────────────────
        const nastroj = await zajistiAppImageTool();
        const novy    = path.join(pracovni, 'PhotoBridge-Linux-novy.AppImage');

        log('INFO', 'APPIMG', 'Zabaluji novou verzi… (chvíli to trvá)');
        const r3 = spawnSync(nastroj, ['--no-appstream', koren, novy], {
            encoding: 'utf8', timeout: 600_000,
            env: { ...process.env, ARCH: 'x86_64' },
        });
        if (r3.status !== 0) {
            throw new Error(`Zabalení selhalo: ${(r3.stderr || r3.stdout || '').slice(0, 300)}`);
        }

        // ── 4. Ověřit, že to má hlavu a patu ────────────────────────────────
        // Bez téhle kontroly bychom mohli přepsat funkční aplikaci nefunkční.
        if (!fs.existsSync(novy)) throw new Error('Nový AppImage nevznikl');
        const velikost = fs.statSync(novy).size;
        const puvodniVelikost = fs.statSync(puvodni).size;
        if (velikost < puvodniVelikost * 0.5) {
            throw new Error(`Nový AppImage je podezřele malý `
                          + `(${(velikost / 1024 / 1024).toFixed(1)} MB proti `
                          + `${(puvodniVelikost / 1024 / 1024).toFixed(1)} MB)`);
        }
        fs.chmodSync(novy, 0o755);

        // ── 5. Odložit původní do zálohy a nahradit ─────────────────────────
        const zalohy = slozkaZaloh();
        fs.mkdirSync(zalohy, { recursive: true });

        const razitko = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const zaloha  = path.join(zalohy, `PhotoBridge-Linux_${app.getVersion()}_${razitko}.AppImage`);

        fs.copyFileSync(puvodni, zaloha);
        fs.chmodSync(zaloha, 0o755);
        log('INFO', 'APPIMG', `Původní verze odložena: ${zaloha}`);

        // Zápis přes dočasný soubor a přejmenování – kdyby to spadlo uprostřed,
        // nezůstane napůl přepsaný nepoužitelný soubor.
        const docasny = `${puvodni}.novy`;
        fs.copyFileSync(novy, docasny);
        fs.chmodSync(docasny, 0o755);
        fs.renameSync(docasny, puvodni);
        log('INFO', 'APPIMG', `Nahrazeno verzí ${novaVerze}`);

        // ── 6. Poznamenat, že čekáme na potvrzení úspěšného startu ──────────
        // Záloha se smaže až DEN PO TOM, co nová verze skutečně naběhne.
        fs.writeFileSync(souborCekaniNaStart(), JSON.stringify({
            verze:       novaVerze,
            zaloha,
            nainstalovano: Date.now(),
        }, null, 2), 'utf8');

        // ── 7. Restart ──────────────────────────────────────────────────────
        naplanujRestart(puvodni);
        return { ok: true };

    } catch (e) {
        log('ERROR', 'APPIMG', `Aktualizace selhala: ${e.message}`);
        return { ok: false, error: e.message };
    } finally {
        // Pracovní složka je velká (stovky MB), ať nezůstává v /tmp
        try { fs.rmSync(pracovni, { recursive: true, force: true }); } catch (_) {}
    }
}

/** Počká na ukončení aplikace a spustí novou verzi. */
function naplanujRestart(cesta) {
    const skript = path.join(os.tmpdir(), 'photobridge_appimg_restart.sh');
    const pid    = process.pid;

    const radky = [
        '#!/bin/sh',
        `while kill -0 ${pid} 2>/dev/null; do sleep 1; done`,
        'sleep 1',
        `"${cesta}" >/dev/null 2>&1 &`,
        'rm -- "$0"',
    ];
    fs.writeFileSync(skript, radky.join('\n'), { encoding: 'utf8', mode: 0o755 });
    spawn('/bin/sh', [skript], { detached: true, stdio: 'ignore' }).unref();

    log('INFO', 'APPIMG', 'Restart naplánován, ukončuji aplikaci');
    setTimeout(() => { try { app.quit(); } catch (_) {} }, 500);
}

// ── Úklid záloh ──────────────────────────────────────────────────────────────

/**
 * Volá se při startu. Když se aplikace rozběhla po aktualizaci, poznamená to –
 * a zálohu smaže až po 24 hodinách.
 *
 * ZÁMĚRNĚ SE NEMAŽE HNED. Kdyby nová verze padala až po chvíli běhu, byla by
 * záloha to jediné, čím se dá vrátit zpět.
 */
function uklidPoStartu() {
    try {
        const soubor = souborCekaniNaStart();
        if (fs.existsSync(soubor)) {
            const zaznam = JSON.parse(fs.readFileSync(soubor, 'utf8'));

            if (!zaznam.prvniStart) {
                // První úspěšný start po aktualizaci
                zaznam.prvniStart = Date.now();
                fs.writeFileSync(soubor, JSON.stringify(zaznam, null, 2), 'utf8');
                log('INFO', 'APPIMG',
                    `Nová verze ${zaznam.verze} naběhla. Záloha se smaže za 24 h.`);
            } else if (Date.now() - zaznam.prvniStart > 24 * 3600 * 1000) {
                // Běží déle než den → záloha už není potřeba
                try { fs.unlinkSync(zaznam.zaloha); } catch (_) {}
                fs.unlinkSync(soubor);
                log('INFO', 'APPIMG', 'Záloha po aktualizaci smazána (verze běží přes den).');
            }
        }

        // Pojistka: zálohy starší než týden pryč, ať se disk neplní
        const zalohy = slozkaZaloh();
        if (fs.existsSync(zalohy)) {
            const tyden = 7 * 24 * 3600 * 1000;
            for (const f of fs.readdirSync(zalohy)) {
                const p = path.join(zalohy, f);
                try {
                    if (Date.now() - fs.statSync(p).mtimeMs > tyden) {
                        fs.unlinkSync(p);
                        log('INFO', 'APPIMG', `Stará záloha smazána: ${f}`);
                    }
                } catch (_) {}
            }
        }
    } catch (e) {
        log('WARN', 'APPIMG', `Úklid záloh selhal: ${e.message}`);
    }
}

module.exports = { aktualizuj, uklidPoStartu, cestaKAppImage, slozkaZaloh };
