'use strict';
// ============================================================
// src/main/backup.js – Záloha a obnova před aktualizací
//
// V2.9.0:
//   • Selektivní záloha (createSelectiveBackup) – zazálohuje JEN ty
//     soubory, které ZIP přepíše. Struktura zachována od kořene
//     resources/app/, takže lze ručně Ctrl+C / Ctrl+V vrátit.
//   • Blacklist – po obnově zálohy se basename "špatné" verze
//     uloží do update_blacklist.json a updater ji už nikdy nenabídne.
//   • createBackupAsync (alias) – kompatibilita s updater.js, který
//     historicky volal async variantu (ta dříve neexistovala → záloha
//     se po posledních verzích neudělala vůbec).
//
// Adresářová struktura (packaged):
//   PhotoBridge.exe
//   resources/app/          ← updater přepisuje
//   backup/                 ← sestra resources/, nikdy se nepřepisuje
//     meta.json
//     app/                  ← záloha (zachovaná stromová struktura)
//
// Blacklist:
//   %APPDATA%\PhotoBridge\update_blacklist.json
//   { "blocked": ["photobridge_update_v2.8.5_2026-05-10.zip", ...] }
// ============================================================

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { app, BrowserWindow, ipcMain } = require('electron');
const { spawn } = require('child_process');

const _log = (level, msg, detail = '') => {
  try { require('./utils').log(level, 'backup', msg + (detail ? ' | ' + detail : '')); }
  catch { console.log(`[${level}] [backup] ${msg}`, detail || ''); }
};

// ── Cesty ──────────────────────────────────────────────────────────────────────
function _appDir() {
  return app.isPackaged
    ? path.join(path.dirname(app.getPath('exe')), 'resources', 'app')
    : path.resolve(__dirname, '..', '..');
}

function _backupDir() {
  return app.isPackaged
    ? path.join(path.dirname(app.getPath('exe')), 'backup')
    : path.join(path.resolve(__dirname, '..', '..', '..'), 'backup');
}

function _pendingPath() {
  return path.join(app.getPath('userData'), 'update_pending.json');
}

function _blacklistPath() {
  return path.join(app.getPath('userData'), 'update_blacklist.json');
}

// ── Blacklist API ─────────────────────────────────────────────────────────────
function _readBlacklist() {
  try {
    const p = _blacklistPath();
    if (!fs.existsSync(p)) return { blocked: [] };
    const d = JSON.parse(fs.readFileSync(p, 'utf8'));
    if (!d || !Array.isArray(d.blocked)) return { blocked: [] };
    return d;
  } catch (e) {
    _log('WARN', 'Blacklist nelze přečíst', e.message);
    return { blocked: [] };
  }
}

function _writeBlacklist(data) {
  try {
    fs.writeFileSync(_blacklistPath(), JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    _log('ERROR', 'Blacklist nelze zapsat', e.message);
    return false;
  }
}

function getBlacklist() {
  return _readBlacklist().blocked;
}

function isBlacklisted(basename) {
  if (!basename) return false;
  return _readBlacklist().blocked.includes(basename);
}

function addToBlacklist(basename) {
  if (!basename) return false;
  const data = _readBlacklist();
  if (data.blocked.includes(basename)) return true;
  data.blocked.push(basename);
  const ok = _writeBlacklist(data);
  if (ok) _log('INFO', `Blacklisted: ${basename}`);
  return ok;
}

function removeFromBlacklist(basename) {
  if (!basename) return false;
  const data = _readBlacklist();
  const i = data.blocked.indexOf(basename);
  if (i < 0) return true;
  data.blocked.splice(i, 1);
  return _writeBlacklist(data);
}

function clearBlacklist() {
  return _writeBlacklist({ blocked: [] });
}

// ── Záloha – stávající full backup (z tlačítka v Nastavení) ───────────────────
function hasBackup() {
  return fs.existsSync(path.join(_backupDir(), 'meta.json')) &&
         fs.existsSync(path.join(_backupDir(), 'app'));
}

function getBackupMeta() {
  try {
    const p = path.join(_backupDir(), 'meta.json');
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return null; }
}

/**
 * Plná záloha celé resources/app/ (volá se z tlačítka „Vytvořit zálohu teď").
 * Pro selektivní zálohu před aktualizací použij createSelectiveBackup().
 */
function createBackup(currentVersion) {
  const src  = _appDir();
  const back = _backupDir();
  const dst  = path.join(back, 'app');

  _log('INFO', `Plná záloha v${currentVersion}…`);
  try {
    if (fs.existsSync(back)) {
      fs.rmSync(back, { recursive: true, force: true });
      _log('INFO', 'Stará záloha smazána');
    }
    fs.mkdirSync(dst, { recursive: true });
    _copyDirSync(src, dst);
    fs.writeFileSync(path.join(back, 'meta.json'), JSON.stringify({
      version:    currentVersion,
      backupDate: new Date().toISOString(),
      appDir:     src,
      type:       'full',
    }, null, 2), 'utf8');
    _log('INFO', `Plná záloha OK → ${back}`);
    return { ok: true, type: 'full' };
  } catch (e) {
    _log('ERROR', 'Plná záloha selhala', e.message);
    return { ok: false, error: e.message };
  }
}

/**
 * Selektivní záloha – projde sourceDir (rozbalený ZIP v %TEMP%) a pro
 * každý soubor zazálohuje **stávající verzi téhož souboru** z resources/app/
 * do backup/app/. Soubory které v cíli ještě neexistují (čistě přidávané ZIPem)
 * se zapíší do meta.json jako "added", aby je obnovovací skript mohl smazat.
 *
 * Adresářová struktura v backup/app/ JE STEJNÁ jako v resources/app/, takže
 * uživatel může soubory ručně překopírovat 1:1 zpět.
 *
 * @param {string} currentVersion  – APP_VERSION před instalací
 * @param {string} sourceDir       – cesta k rozbalenému ZIPu (tmpExtract)
 * @param {object} [extra]         – { triggeredByBasename: 'photobridge_update_vX.Y.Z_...zip' }
 */
function createSelectiveBackup(currentVersion, sourceDir, extra = {}) {
  const appDir   = _appDir();
  const back     = _backupDir();
  const dstRoot  = path.join(back, 'app');

  _log('INFO', `Selektivní záloha v${currentVersion}…`, sourceDir);

  if (!fs.existsSync(sourceDir)) {
    return { ok: false, error: `Zdrojová složka ZIPu neexistuje: ${sourceDir}` };
  }

  try {
    // Smaž starou zálohu (drží se vždy jen jedna – stejně jako u plné)
    if (fs.existsSync(back)) {
      fs.rmSync(back, { recursive: true, force: true });
    }
    fs.mkdirSync(dstRoot, { recursive: true });

    // Projdi rozbalený ZIP rekurzivně, vyjmenuj relativní cesty souborů
    const relFiles = _listFilesRelative(sourceDir);
    _log('INFO', `Soubory ke přepsání: ${relFiles.length}`);

    const overwritten = []; // soubory, které ZIP přepisuje
    const added       = []; // soubory, které ZIP nově přidává

    for (const rel of relFiles) {
      const currentInApp = path.join(appDir, rel);
      const backupDest   = path.join(dstRoot, rel);

      if (fs.existsSync(currentInApp)) {
        // Stávající verze existuje → zazálohuj ji
        fs.mkdirSync(path.dirname(backupDest), { recursive: true });
        fs.copyFileSync(currentInApp, backupDest);
        overwritten.push(rel);
      } else {
        // ZIP přidává soubor, který v cíli ještě nebyl. Při obnově je třeba
        // ho smazat (jinak by zůstal v aplikaci jako artefakt).
        added.push(rel);
      }
    }

    const meta = {
      version:           currentVersion,
      backupDate:        new Date().toISOString(),
      appDir,
      type:              'selective',
      overwrittenFiles:  overwritten,
      addedByUpdateFiles: added,
      triggeredByBasename: extra.triggeredByBasename || null,
    };
    fs.writeFileSync(path.join(back, 'meta.json'), JSON.stringify(meta, null, 2), 'utf8');

    _log('INFO', `Selektivní záloha OK: ${overwritten.length} přepisovaných + ${added.length} přidávaných`);
    return { ok: true, type: 'selective', overwritten: overwritten.length, added: added.length };
  } catch (e) {
    _log('ERROR', 'Selektivní záloha selhala', e.message);
    return { ok: false, error: e.message };
  }
}

/**
 * Alias používaný v updater.js. Historicky existovala async verze, která
 * v aktuálním buildu chyběla → záloha se vůbec nedělala. Tato funkce
 * volá synchronní createBackup() v Promise wrapperu (aby šlo "await").
 *
 * Pokud updater dodá `sourceDir`, použije se selektivní záloha.
 */
async function createBackupAsync(currentVersion, sourceDir = null, extra = {}) {
  return sourceDir
    ? createSelectiveBackup(currentVersion, sourceDir, extra)
    : createBackup(currentVersion);
}

// ── Update pending tracking ───────────────────────────────────────────────────
function markUpdatePending(newVersion, changelog = null) {
  try {
    fs.writeFileSync(_pendingPath(), JSON.stringify({
      newVersion,
      startedAt: new Date().toISOString(),
      changelog: changelog || null,
    }, null, 2), 'utf8');
    _log('INFO', `update_pending zapsán (→ v${newVersion})`);
  } catch (e) { _log('ERROR', 'Nelze zapsat update_pending', e.message); }
}

function clearUpdatePending() {
  try {
    const p = _pendingPath();
    if (fs.existsSync(p)) { fs.unlinkSync(p); _log('INFO', 'update_pending smazán (update OK)'); }
  } catch (e) { _log('ERROR', 'Nelze smazat update_pending', e.message); }
}

function getUpdatePending() {
  try {
    const p = _pendingPath();
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return null; }
}

/**
 * Obnova zálohy přes PowerShell s UAC.
 * Pokud meta.triggeredByBasename existuje, basename se přidá na blacklist
 * PŘED restartem aplikace – aby se ten ZIP už nikdy nenabídnul.
 */
function runRestore() {
  const meta = getBackupMeta();
  if (!meta) return { ok: false, error: 'Záloha neexistuje.' };
  const backupApp = path.join(_backupDir(), 'app');
  if (!fs.existsSync(backupApp)) return { ok: false, error: 'Záloha je neúplná.' };

  // ── BLACKLIST: zablokuj basename ZIPu, který způsobil tu špatnou verzi ────
  if (meta.triggeredByBasename) {
    addToBlacklist(meta.triggeredByBasename);
    _log('INFO', `Blacklisted (restore): ${meta.triggeredByBasename}`);
  }

  const esc      = s => s.replace(/'/g, "''");
  const psScript = path.join(os.tmpdir(), 'pb_restore.ps1');
  const vbsPath  = path.join(os.tmpdir(), 'pb_restore_uac.vbs');
  const psLog    = path.join(os.tmpdir(), 'pb_restore.log');

  // Soubory přidané UPDATEM (existovaly jen v ZIPu, ne v původní app) –
  // ty je třeba PŘI obnově **smazat**, jinak by zůstaly jako artefakty.
  const filesToDelete = Array.isArray(meta.addedByUpdateFiles) ? meta.addedByUpdateFiles : [];
  const deleteCmds = filesToDelete.map(rel => {
    const full = path.join(_appDir(), rel);
    return `if(Test-Path '${esc(full)}'){Remove-Item '${esc(full)}' -Force -ErrorAction SilentlyContinue}`;
  });

  const ps = [
    `$log='${esc(psLog)}'`,
    `$src='${esc(backupApp)}'`,
    `$dst='${esc(_appDir())}'`,
    `$exe='${esc(app.getPath('exe'))}'`,
    `$pend='${esc(_pendingPath())}'`,
    `function L($m){Add-Content $log "$(Get-Date -f 'HH:mm:ss') $m"}`,
    `L 'START restore v${meta.version} (type=${meta.type || 'full'})'`,
    `Start-Sleep -Seconds 2`,
    `try{`,
    // Selektivní: jen překopíruj soubory ZE zálohy do app (struktura sedí 1:1).
    // Plná: smazat celý $dst a překopírovat čistě.
    meta.type === 'selective'
      ? `  Copy-Item -Path "$src\\*" -Destination $dst -Recurse -Force -ErrorAction Stop`
      : `  if(Test-Path $dst){Remove-Item $dst -Recurse -Force -ErrorAction Stop}\r\n  New-Item -ItemType Directory -Path $dst -Force|Out-Null\r\n  Copy-Item -Path "$src\\*" -Destination $dst -Recurse -Force -ErrorAction Stop`,
    `  L 'Kopírování OK'`,
    // Smaž soubory přidané updatem (jen u selektivní zálohy)
    ...deleteCmds,
    deleteCmds.length ? `  L 'Smazány nově přidané soubory: ${deleteCmds.length}'` : `  L 'Žádné soubory ke smazání'`,
    `  if(Test-Path $pend){Remove-Item $pend -Force}`,
    `  L 'Spouštím aplikaci...'`,
    `  Start-Process $exe`,
    `  L 'HOTOVO'`,
    `}catch{`,
    `  L "CHYBA: $_"`,
    `  Add-Type -AssemblyName System.Windows.Forms`,
    `  [System.Windows.Forms.MessageBox]::Show("Obnova selhala: $_","PhotoBridge Restore")`,
    `}`,
  ].join('\r\n');

  // ── Mimo Windows: totéž co PowerShell výš, jen shellem ────────────────────
  // Povýšení práv (UAC) tu není potřeba – aplikace běží v domovském adresáři.
  if (process.platform !== 'win32') {
    try {
      const shPath  = path.join(os.tmpdir(), 'pb_restore.sh');
      const dst     = _appDir();
      const exePath = app.getPath('exe');
      const pend    = _pendingPath();

      const kopirovani = meta.type === 'selective'
        ? [`cp -a "$SRC/." "$DST/"`]
        : [`rm -rf "$DST"`, `mkdir -p "$DST"`, `cp -a "$SRC/." "$DST/"`];

      // Soubory přidané aktualizací se u selektivní zálohy mažou
      const smaz = filesToDelete.map(
        (rel) => `rm -f "$DST/${String(rel).replace(/"/g, '\\"')}"`,
      );

      const lines = [
        '#!/bin/sh',
        `LOG="${psLog}"`,
        `SRC="${backupApp}"`,
        `DST="${dst}"`,
        `PEND="${pend}"`,
        `L(){ echo "$(date +%T) $1" >> "$LOG"; }`,
        `L "START restore v${meta.version} (type=${meta.type || 'full'})"`,
        'sleep 2',
        ...kopirovani,
        `if [ $? -ne 0 ]; then L "CHYBA: kopírování selhalo"; exit 1; fi`,
        'L "Kopírování OK"',
        ...smaz,
        `[ -f "$PEND" ] && rm -f "$PEND"`,
        'L "Spouštím aplikaci..."',
        `"${exePath}" >/dev/null 2>&1 &`,
        'L "HOTOVO"',
      ];

      fs.writeFileSync(shPath, lines.join('\n'), { encoding: 'utf8', mode: 0o755 });
      spawn('/bin/sh', [shPath], { detached: true, stdio: 'ignore' }).unref();

      _log('INFO', 'Restore skript spuštěn (Linux/macOS), ukončuji app...');
      app.quit();
      return { ok: true, blacklisted: meta.triggeredByBasename || null };
    } catch (e) {
      _log('ERROR', 'Spuštění restore selhalo', e.message);
      return { ok: false, error: e.message };
    }
  }

  try {
    fs.writeFileSync(psScript, ps, 'utf8');
    fs.writeFileSync(vbsPath, [
      'Set o=CreateObject("Shell.Application")',
      `o.ShellExecute "powershell.exe","-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & "${psScript}" & """","","runas",0`,
    ].join('\r\n'), 'utf8');

    spawn('wscript.exe', [vbsPath], {
      detached: true, stdio: 'ignore', windowsHide: true,
    }).unref();

    _log('INFO', 'Restore PS spuštěn, ukončuji app...');
    app.quit();
    return { ok: true, blacklisted: meta.triggeredByBasename || null };
  } catch (e) {
    _log('ERROR', 'Spuštění restore selhalo', e.message);
    return { ok: false, error: e.message };
  }
}

// ── Restore okno (z běžící app) ───────────────────────────────────────────────
let _restoreWin = null;

function showRestoreWindow(opts = {}) {
  if (_restoreWin && !_restoreWin.isDestroyed()) { _restoreWin.focus(); return; }

  _restoreWin = new BrowserWindow({
    width: 620, height: 520, minWidth: 540, minHeight: 440,
    resizable: true, maximizable: false, fullscreenable: false,
    title: 'PhotoBridge – Záchranný režim',
    show: false, backgroundColor: '#141414',
    webPreferences: {
      preload: path.join(__dirname, '../../preload.js'),
      contextIsolation: true, nodeIntegration: false,
    },
  });
  _restoreWin.loadFile(path.join(__dirname, '../renderer/restore.html'));
  _restoreWin.setMenuBarVisibility(false);
  _restoreWin.once('ready-to-show', () => {
    _restoreWin.show();
    _restoreWin.center();
    _restoreWin.webContents.send('restore:context', {
      isBadUpdate: !!opts.isBadUpdate,
      meta: getBackupMeta(),
    });
  });
  _restoreWin.on('closed', () => { _restoreWin = null; });
}

// ── IPC handlery ───────────────────────────────────────────────────────────────
function registerIpc() {
  ipcMain.handle('backup:get-meta',    () => getBackupMeta());
  ipcMain.handle('backup:has-backup',  () => hasBackup());
  ipcMain.handle('backup:run-restore', () => runRestore());
  ipcMain.handle('backup:get-pending', () => getUpdatePending());

  // Blacklist IPC – pro UI v Nastavení (zobrazení/odstranění blokovaných verzí)
  ipcMain.handle('backup:get-blacklist',    () => getBlacklist());
  ipcMain.handle('backup:add-blacklist',    (_e, basename) => addToBlacklist(basename));
  ipcMain.handle('backup:remove-blacklist', (_e, basename) => removeFromBlacklist(basename));
  ipcMain.handle('backup:clear-blacklist',  () => clearBlacklist());

  ipcMain.handle('backup:create-now', () => {
    try {
      let ver = 'neznámá';
      try {
        const pkg = path.join(_appDir(), 'package.json');
        if (fs.existsSync(pkg)) ver = JSON.parse(fs.readFileSync(pkg, 'utf8')).version || ver;
      } catch (_) {}
      return createBackup(ver);
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });
}

// ── Helpery ───────────────────────────────────────────────────────────────────
function _copyDirSync(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? _copyDirSync(s, d) : fs.copyFileSync(s, d);
  }
}

/** Vrátí všechny soubory v `root` jako relativní cesty (oddělovač "/"). */
function _listFilesRelative(root) {
  const out = [];
  function walk(dir, prefix) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      const rel  = prefix ? path.join(prefix, e.name) : e.name;
      if (e.isDirectory()) walk(full, rel);
      else out.push(rel);
    }
  }
  walk(root, '');
  return out;
}

module.exports = {
  // Stávající API
  hasBackup, getBackupMeta, createBackup,
  markUpdatePending, clearUpdatePending, getUpdatePending,
  runRestore, showRestoreWindow, registerIpc,
  // Nové API
  createSelectiveBackup,
  createBackupAsync,
  getBlacklist, isBlacklisted, addToBlacklist, removeFromBlacklist, clearBlacklist,
};
