'use strict';
// ============================================================
// PhotoBridge – src/main/login-window.js
// Samostatné přihlašovací okno (BrowserWindow) + IPC handlery
//
//   • openLoginWindow(mainWindow)  – otevře okno, vrátí Promise<bool>
//   • registerIpcHandlers()        – registruje login:* kanály
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

// Singleton reference na okno
let _win     = null;
// Resolve funkce pro aktuálně čekající Promise
let _resolve = null;

// ──────────────────────────────────────────────────────────────
// Otevření okna — vrací Promise<{ ok, accountType } | false>
// ──────────────────────────────────────────────────────────────
function openLoginWindow(mainWindow) {
  // Pokud už okno existuje, přenes fokus a vrať nový Promise
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return _makePromise();
  }

  _win = new BrowserWindow({
    // Okno musí být ZNATELNĚ větší než karta (380 px), jinak není tapetu kde
    // ukázat. Ve v3.3.3 bylo 404 px, tedy 12 px navíc – tapeta se smrskla
    // na dva pixely po stranách a vypadala, že tam vůbec není.
    // Rámeček kolem karty má teď ~50 px na každé straně.
    width:           480,
    height:          760,
    resizable:       false,
    minimizable:     false,
    maximizable:     false,
    fullscreenable:  false,
    frame:           false,
    transparent:     true,
    hasShadow:       true,
    titleBarStyle:   'hidden',
    parent:          mainWindow || null,
    modal:           true,
    show:            false,
    skipTaskbar:     true,
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
    },
  });

  _win.loadFile(path.join(RENDERER_DIR, 'login.html'));

  _win.once('ready-to-show', () => {
    _win.show();
    _win.focus();
  });

  _win.on('closed', () => {
    _win = null;
    // Pokud okno zavřou bez výsledku → resolve false
    if (_resolve) { _resolve(false); _resolve = null; }
  });

  return _makePromise();
}

function _makePromise() {
  return new Promise(resolve => {
    // Přepiš starý resolve (jen jedno přihlášení najednou)
    if (_resolve) _resolve(false);
    _resolve = resolve;
  });
}

// ──────────────────────────────────────────────────────────────
// IPC handlery
// ──────────────────────────────────────────────────────────────
function registerIpcHandlers() {
  // Renderer oznamuje úspěšné přihlášení
  ipcMain.handle('login:success', (_evt, { accountType } = {}) => {
    const result = { ok: true, accountType: accountType || 'business' };
    // Informuj hlavní okno
    const { BrowserWindow: BW } = require('electron');
    BW.getAllWindows().forEach(w => {
      if (w !== _win && !w.isDestroyed()) {
        w.webContents.send('login:result', result);
      }
    });
    if (_resolve) { _resolve(result); _resolve = null; }
    if (_win && !_win.isDestroyed()) _win.close();
    return { ok: true };
  });

  // Renderer nebo uživatel zrušil přihlášení
  ipcMain.handle('login:cancel', () => {
    if (_resolve) { _resolve(false); _resolve = null; }
    if (_win && !_win.isDestroyed()) _win.close();
    return { ok: false };
  });

  // Hlavní okno žádá otevření přihlašovacího okna (volitelné)
  ipcMain.handle('login:open', (_evt, { parentId } = {}) => {
    const { BrowserWindow: BW } = require('electron');
    const parent = parentId ? BW.fromId(parentId) : null;
    // openLoginWindow vrátí Promise, ale IPC handler ji nečeká
    // — výsledek přijde přes login:success / login:cancel
    openLoginWindow(parent);
    return { ok: true };
  });
}

// ──────────────────────────────────────────────────────────────
// Zavření okna zvenčí (např. z prohlídky když přejde na další krok)
// ──────────────────────────────────────────────────────────────
function closeLoginWindow() {
  try {
    if (_win && !_win.isDestroyed()) _win.close();
  } catch (_) {}
}

module.exports = { openLoginWindow, closeLoginWindow, registerIpcHandlers };
