// ============================================================================
//  britex-sso.js – firemní přihlášení přes RTS (bez Custom Auth Providers)
// ============================================================================
//
//  Náhrada za britex-login.js. Ten spoléhal na vlastního poskytovatele
//  v Supabase, jehož callback padá na „missing provider id“ – chyba na straně
//  Supabase, kterou nemáme jak opravit (ověřeno dvěma poskytovateli, s PKCE
//  i bez, s různými scopes).
//
//  POSTUP
//    1. Přihlásit do RTS – používáme rts-auth.login(), který funguje
//    2. Získaný token poslat Edge Funkci rts-sso
//    3. Funkce ověří u RTS, komu token patří, a vrátí token_hash
//    4. Ten vyměnit za session přes POST /auth/v1/verify
//
//  Technik klikne jednou a má účet v PhotoBridge i právo ukládat do zakázek.
// ============================================================================

const FUNCTION_NAME = 'rts-sso';

function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

/**
 * Provede celé firemní přihlášení.
 * @param {object} cfg – konfigurace aplikace (SB_URL, SB_ANON)
 * @returns {Promise<{ok:boolean, error?:string, session?:object, rtsReady?:boolean}>}
 */
async function login(cfg) {
    const sbUrl  = String(cfg?.SB_URL  || '').replace(/\/+$/, '');
    const sbAnon = String(cfg?.SB_ANON || '').trim();
    if (!sbUrl || !sbAnon) {
        return { ok: false, error: 'Chybí nastavení Supabase (SB_URL / SB_ANON)' };
    }

    // ── 1. Přihlášení do RTS ────────────────────────────────────────────────
    log('INFO', 'BRITEX_SSO', 'Otevírám přihlášení do RTS');
    const rtsAuth = require('./rts-auth');
    const rtsApi  = require('./rts-api');

    let rtsResult;
    try {
        rtsResult = await rtsAuth.login();
    } catch (e) {
        return { ok: false, error: `Přihlášení do RTS selhalo: ${e.message}` };
    }
    if (!rtsResult || !rtsResult.ok) {
        return { ok: false, error: rtsResult?.error || 'Přihlášení do RTS se nezdařilo' };
    }
    log('INFO', 'BRITEX_SSO', `RTS přihlášen – ${rtsResult.user || '(bez jména)'}`);

    const rtsToken = await rtsApi.getToken();
    if (!rtsToken) return { ok: false, error: 'RTS token se nepodařilo načíst' };

    // ── 2. Edge Funkce ověří totožnost a připraví přihlášení ────────────────
    log('INFO', 'BRITEX_SSO', 'Ověřuji totožnost přes Edge Funkci');
    let out;
    try {
        const resp = await fetch(`${sbUrl}/functions/v1/${FUNCTION_NAME}`, {
            method:  'POST',
            headers: {
                'Content-Type':  'application/json',
                'apikey':        sbAnon,
                'Authorization': `Bearer ${sbAnon}`,
            },
            body: JSON.stringify({ rts_token: rtsToken }),
        });
        const txt = await resp.text();
        try { out = JSON.parse(txt); }
        catch { return { ok: false, error: `Neplatná odpověď funkce (HTTP ${resp.status})` }; }

        if (!resp.ok || !out.ok) {
            const detail = out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
            log('WARN', 'BRITEX_SSO', `Funkce vrátila chybu: ${out.error || resp.status}${detail}`);
            return { ok: false, error: (out.error || `HTTP ${resp.status}`) + detail };
        }
    } catch (e) {
        return { ok: false, error: `Edge Funkce nedostupná: ${e.message}` };
    }

    if (out.created) log('INFO', 'BRITEX_SSO', `Založen nový účet: ${out.email}`);
    else             log('INFO', 'BRITEX_SSO', `Nalezen účet: ${out.email}`);

    // ── 3. Výměna za session ────────────────────────────────────────────────
    let sess;
    try {
        const resp = await fetch(`${sbUrl}/auth/v1/verify`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json', 'apikey': sbAnon },
            body:    JSON.stringify({ type: 'magiclink', token_hash: out.token_hash }),
        });
        sess = await resp.json().catch(() => null);
        if (!resp.ok || !sess?.access_token) {
            const why = sess?.error_description || sess?.msg || `HTTP ${resp.status}`;
            log('WARN', 'BRITEX_SSO', `Výměna za session selhala: ${why}`);
            return { ok: false, error: `Přihlášení se nedokončilo: ${why}` };
        }
    } catch (e) {
        return { ok: false, error: `Výměna za session selhala: ${e.message}` };
    }

    log('INFO', 'BRITEX_SSO', `Přihlášeno jako ${sess.user?.email || out.email}`);

    return {
        ok: true,
        rtsReady: true,          // do RTS jsme přihlášeni už z kroku 1
        session: {
            accessToken:  sess.access_token,
            refreshToken: sess.refresh_token,
            user:         sess.user,
        },
    };
}

module.exports = { login, FUNCTION_NAME };
