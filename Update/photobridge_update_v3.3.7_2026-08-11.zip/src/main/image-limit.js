// ============================================================================
//  image-limit.js – hlídá, aby fotka nepřesáhla nastavený strop
// ============================================================================
//
//  PROČ TO EXISTUJE
//  Sken se přikládá k PDF (CN a další). Nad 15 MB se e-mail nemusí doručit,
//  nad 25 MB se neodešle vůbec. Mobilní stránka si strop hlídá sama od
//  verze 1.4.1, ale fotky, které do aplikace přidá technik na PC, tudy
//  neprojdou – proto tenhle modul.
//
//  POZOR: nastavení MAX_IMG_MB existovalo od začátku, ale NIC ho nepoužívalo.
//  Pole v Nastavení slibovalo něco, co se nedělo.
//
//  CHOVÁNÍ
//  Soubor pod stropem se NESAHÁ – žádná ztráta kvality zbytečně.
//  Nad stropem se snižuje kvalita JPEG, a když ani to nestačí, rozměr.
//  Rozměr se obětuje až nakonec, ať zůstane sken čitelný.
//
//  Když se cokoli nepovede, vrací se původní soubor. Velká fotka je pořád
//  lepší než žádná.
// ============================================================================

const fs   = require('fs');
const path = require('path');

function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

const KVALITY   = [85, 75, 65, 55, 45];
const MIN_SIRKA = 1200;          // pod tohle nejdeme, sken by přestal být čitelný

/** Přípony, které umíme zmenšit. Ostatní (PDF, video…) necháváme být. */
function _jeObrazek(p) {
    return ['.jpg', '.jpeg', '.png', '.webp'].includes(path.extname(p).toLowerCase());
}

/**
 * Zmenší soubor tak, aby se vešel pod strop. Přepisuje ho na místě.
 *
 * @param {string} filePath  cesta k souboru
 * @param {number} maxMB     strop v MB (výchozí z configu MAX_IMG_MB)
 * @returns {Promise<{zmenseno: boolean, pred: number, po: number}>}
 */
async function ensureUnderLimit(filePath, maxMB) {
    const vysledek = { zmenseno: false, pred: 0, po: 0 };

    try {
        if (!fs.existsSync(filePath) || !_jeObrazek(filePath)) return vysledek;

        let strop = Number(maxMB);
        if (!strop || strop <= 0) {
            try { strop = Number(require('./config').readConfig().MAX_IMG_MB) || 3; }
            catch (_) { strop = 3; }
        }
        const maxBytes = strop * 1024 * 1024;

        const puvodni = fs.statSync(filePath).size;
        vysledek.pred = puvodni;
        vysledek.po   = puvodni;

        if (puvodni <= maxBytes) return vysledek;      // vejde se, nesaháme

        let sharp;
        try { sharp = require('sharp'); }
        catch (e) {
            log('WARN', 'IMG_LIMIT', `sharp není dostupný, nechávám původní: ${e.message}`);
            return vysledek;
        }

        const meta = await sharp(filePath).metadata();
        let sirka  = meta.width  || 0;
        const pomer = (meta.width && meta.height) ? meta.height / meta.width : 0;
        if (!sirka) return vysledek;

        for (let pokus = 0; pokus < 12; pokus++) {
            const kvalita = KVALITY[Math.min(pokus, KVALITY.length - 1)];

            let obraz = sharp(filePath).rotate();       // rotate() respektuje EXIF
            if (sirka < (meta.width || 0)) obraz = obraz.resize({ width: Math.round(sirka) });

            const buf = await obraz.jpeg({ quality: kvalita, mozjpeg: true }).toBuffer();

            if (buf.length <= maxBytes) {
                fs.writeFileSync(filePath, buf);
                vysledek.zmenseno = true;
                vysledek.po       = buf.length;
                log('INFO', 'IMG_LIMIT',
                    `${path.basename(filePath)}: ${_mb(puvodni)} → ${_mb(buf.length)} `
                    + `(kvalita ${kvalita}${sirka < meta.width ? `, šířka ${Math.round(sirka)} px` : ''})`);
                return vysledek;
            }

            // Nejdřív dojedeme kvalitu, teprve pak zmenšujeme rozměr
            if (pokus >= KVALITY.length - 1) {
                if (sirka <= MIN_SIRKA) {
                    // Dál už bychom sken znečitelnili – uložíme to nejmenší, co máme
                    fs.writeFileSync(filePath, buf);
                    vysledek.zmenseno = true;
                    vysledek.po       = buf.length;
                    log('WARN', 'IMG_LIMIT',
                        `${path.basename(filePath)}: nešlo pod ${strop} MB bez ztráty čitelnosti, `
                        + `uloženo ${_mb(buf.length)}`);
                    return vysledek;
                }
                sirka = Math.round(sirka * 0.8);
            }
        }
        return vysledek;

    } catch (e) {
        log('WARN', 'IMG_LIMIT', `Zmenšení selhalo, nechávám původní: ${e.message}`);
        return vysledek;
    }
}

function _mb(b) { return `${(b / 1024 / 1024).toFixed(2)} MB`; }

const PRIPONY_VIDEO = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.3gp', '.m4v'];

/**
 * Zkontroluje velikost videa. NEZMENŠUJE ho.
 *
 * PROČ SE VIDEO NEZMENŠUJE
 * Zmenšit video znamená ho překódovat a na to je potřeba ffmpeg. Ten mezi
 * závislostmi není a přidávat kvůli tomu ~80 MB do každé instalace nedává
 * smysl. Nastavení MAX_VIDEO_MB proto funguje jako STROP, ne jako komprese –
 * větší video se pošle, ale zapíše se varování a technik dostane upozornění.
 *
 * @returns {{jeVideo: boolean, vejdeSe: boolean, velikostMb: number, stropMb: number}}
 */
function checkVideoLimit(filePath, maxMB) {
    const out = { jeVideo: false, vejdeSe: true, velikostMb: 0, stropMb: 0 };
    try {
        if (!fs.existsSync(filePath)) return out;
        if (!PRIPONY_VIDEO.includes(path.extname(filePath).toLowerCase())) return out;
        out.jeVideo = true;

        let strop = Number(maxMB);
        if (!strop || strop <= 0) {
            try { strop = Number(require('./config').readConfig().MAX_VIDEO_MB) || 30; }
            catch (_) { strop = 30; }
        }
        out.stropMb = strop;

        const bajty = fs.statSync(filePath).size;
        out.velikostMb = Math.round(bajty / 1024 / 1024 * 100) / 100;
        out.vejdeSe = bajty <= strop * 1024 * 1024;

        if (!out.vejdeSe) {
            log('WARN', 'VIDEO_LIMIT',
                `${path.basename(filePath)}: ${out.velikostMb} MB překračuje strop ${strop} MB. `
                + 'Video se nezmenšuje – zvaž kratší záznam nebo nižší rozlišení na telefonu.');
        }
        return out;
    } catch (e) {
        log('WARN', 'VIDEO_LIMIT', `Kontrola selhala: ${e.message}`);
        return out;
    }
}

module.exports = { ensureUnderLimit, checkVideoLimit };
