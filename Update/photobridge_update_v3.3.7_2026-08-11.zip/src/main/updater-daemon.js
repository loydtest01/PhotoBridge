'use strict';
// ============================================================
// PhotoBridge – updater-daemon.js
// Samostatný aktualizační démon (NEZÁVISÍ na Electron / hlavní app)
//
// Spouští se z main.js jako DETACHED child process při startu aplikace.
// Přežije pád hlavní aplikace a zajistí:
//   1. Watchdog  – sleduje PID hlavní app; pokud app crashi s
//                  update_pending.json přítomným, automaticky spustí
//                  PB_restore.bat (zálohu) a restartuje app.
//   2. Downloader – každých POLL_INTERVAL minut zkontroluje GitHub /
//                   lokální složku pro nové aktualizace.
//                   Pokud hlavní app BĚŽÍ → zapíše update_ready.json
//                   (app ho přečte a zobrazí dialog uživateli).
//                   Pokud hlavní app NEBĚŽÍ → stáhne + rozbalí ZIP
//                   přímo a restartuje app bez Electron dialogu.
//
// Spuštění z main.js:
//   const daemon = spawn(process.execPath, [daemonScript, ...args], {
//     detached: true, stdio: 'ignore'
//   });
//   daemon.unref();
//
// Argumenty (předávány přes process.argv):
//   --userData=<path>    %APPDATA%\PhotoBridge
//   --pid=<number>       PID hlavní aplikace
//   --exe=<path>         Cesta k PhotoBridge.exe
//   --appDir=<path>      Složka kde leží PhotoBridge.exe
//   --version=<string>   Aktuální verze např. "2.3.1"
//   --poll=<minutes>     Interval kontroly aktualizací (výchozí: 60)
//
// Komunikace:
//   %userData%/update_ready.json   – démon zapíše, hlavní app čte
//   %userData%/update_pending.json – hlavní app zapíše před updatem
//   %userData%/daemon_state.json   – démon zapíše svůj stav (PID, čas)
//   %userData%/backups/PB_restore.bat – auto-obnova
// ============================================================

const fs    = require('fs');
const path  = require('path');
const https = require('https');
const os    = require('os');
const { spawn, spawnSync } = require('child_process');

// ── Argumenty ─────────────────────────────────────────────────────────────────
function _arg(name, fallback = '') {
  const prefix = `--${name}=`;
  const found  = process.argv.find(a => a.startsWith(prefix));
  return found ? found.slice(prefix.length) : fallback;
}

const USER_DATA    = _arg('userData', path.join(os.homedir(), 'AppData', 'Roaming', 'PhotoBridge'));
const MAIN_PID     = parseInt(_arg('pid', '0'), 10);
const MAIN_EXE     = _arg('exe', '');
const APP_DIR      = _arg('appDir', MAIN_EXE ? path.dirname(MAIN_EXE) : '');
const APP_VERSION  = _arg('version', '0.0.0');
const POLL_MIN     = Math.max(5, parseInt(_arg('poll', '60'), 10));

// ── Soubory ──────────────────────────────────────────────────────────────────
const READY_PATH   = path.join(USER_DATA, 'update_ready.json');
const PENDING_PATH = path.join(USER_DATA, 'update_pending.json');
const STATE_PATH   = path.join(USER_DATA, 'daemon_state.json');
const LOG_PATH     = path.join(USER_DATA, 'logs', 'updater_daemon.log');
const CONFIG_PATH  = path.join(USER_DATA, 'config.json');
const RESTORE_BAT  = path.join(USER_DATA, 'backups',
  process.platform === 'win32' ? 'PB_restore.bat' : 'PB_restore.sh');

// ── GitHub konstanty ──────────────────────────────────────────────────────────
const GH_OWNER   = 'loydtest01';
const GH_REPO    = 'PhotoBridge';
const GH_BRANCH  = 'main';
const GH_FOLDER  = 'Update';
const APP_SLUG   = 'photobridge';

// ── ZIP regex (stejný jako v updater.js) ─────────────────────────────────────
const slugEsc  = APP_SLUG.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ZIP_REGEX = new RegExp(
  `^${slugEsc}_update_(?:v([\\d.]+)_)?(\\d{4}-\\d{2}-\\d{2})(?:_(\\d+))?\\.zip$`
);

// ── Logging ───────────────────────────────────────────────────────────────────
function _log(msg) {
  const line = `${new Date().toISOString().replace('T', ' ').slice(0, 23)}  ${msg}\n`;
  process.stdout.write(line);
  try {
    fs.mkdirSync(path.dirname(LOG_PATH), { recursive: true });
    fs.appendFileSync(LOG_PATH, line, 'utf8');
  } catch (_) {}
}

// ── Stav démona ───────────────────────────────────────────────────────────────
function _writeState(extra = {}) {
  try {
    fs.writeFileSync(STATE_PATH, JSON.stringify({
      pid:         process.pid,
      mainPid:     MAIN_PID,
      version:     APP_VERSION,
      startedAt:   new Date().toISOString(),
      ...extra,
    }, null, 2), 'utf8');
  } catch (_) {}
}

// ── Čtení konfigurace ─────────────────────────────────────────────────────────
function _readConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
  } catch (_) {}
  return {};
}

// ── Detekce zda proces běží ───────────────────────────────────────────────────
function _pidAlive(pid) {
  if (!pid || pid <= 0) return false;
  try {
    process.kill(pid, 0);   // signal 0 = jen otestuj existenci
    return true;
  } catch (_) {
    return false;
  }
}

// ── Porovnání verzí ───────────────────────────────────────────────────────────
function _compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

// ── HTTPS GET → string ────────────────────────────────────────────────────────
function _httpsGet(url, pat = '') {
  return new Promise((resolve, reject) => {
    const headers = { 'User-Agent': `PhotoBridgeDaemon/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        return resolve(_httpsGet(res.headers.location, pat));
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.setTimeout(15000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', reject);
  });
}

// ── HTTPS stahování souboru ───────────────────────────────────────────────────
function _httpsDownload(url, dest, pat = '') {
  return new Promise((resolve, reject) => {
    const file    = fs.createWriteStream(dest);
    const headers = { 'User-Agent': `PhotoBridgeDaemon/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        file.close();
        return resolve(_httpsDownload(res.headers.location, dest, pat));
      }
      if (res.statusCode !== 200) {
        file.close();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(dest); });
      file.on('error', reject);
    });
    req.setTimeout(180000, () => { req.destroy(); reject(new Error('Timeout stahování')); });
    req.on('error', reject);
  });
}

// ── GitHub check: vrátí nejnovější ZIP novější než currentVersion ─────────────
async function _checkGitHub(currentVersion, pat = '') {
  const apiUrl = `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${GH_FOLDER}?ref=${GH_BRANCH}`;
  let items;
  try {
    const body = await _httpsGet(apiUrl, pat);
    items = JSON.parse(body);
  } catch (e) {
    _log(`GitHub check selhal: ${e.message}`);
    return [];
  }

  if (!Array.isArray(items)) return [];

  const results = [];
  for (const item of items) {
    if (item.type !== 'file') continue;
    const match = item.name.match(ZIP_REGEX);
    if (!match) continue;
    const [, ver, date, build] = match;
    if (ver && _compareVersions(ver, currentVersion) <= 0) continue;  // ne novější
    results.push({
      basename:    item.name,
      version:     ver || '',
      date,
      build:       build ? parseInt(build, 10) : -1,
      downloadUrl: item.download_url,
    });
  }

  // Seřaď vzestupně (nejstarší → nejnovější)
  results.sort((a, b) => {
    if (a.version && b.version) return _compareVersions(a.version, b.version);
    return a.date < b.date ? -1 : a.date > b.date ? 1 : 0;
  });

  _log(`GitHub: nalezeno ${results.length} novějších ZIP(ů) (aktuální: v${currentVersion})`);
  return results;
}

// ── Lokální složka check ──────────────────────────────────────────────────────
function _checkLocal(updateDir, currentVersion) {
  try {
    const entries = fs.readdirSync(updateDir);
    const results = [];
    for (const f of entries) {
      const match = f.match(ZIP_REGEX);
      if (!match) continue;
      const [, ver, date, build] = match;
      if (ver && _compareVersions(ver, currentVersion) <= 0) continue;
      results.push({
        basename:  f,
        version:   ver || '',
        date,
        build:     build ? parseInt(build, 10) : -1,
        localPath: path.join(updateDir, f),
      });
    }
    results.sort((a, b) => {
      if (a.version && b.version) return _compareVersions(a.version, b.version);
      return a.date < b.date ? -1 : a.date > b.date ? 1 : 0;
    });
    _log(`Lokální: nalezeno ${results.length} novějších ZIP(ů)`);
    return results;
  } catch (_) {
    return [];
  }
}

// ── Zápis update_ready.json (hlavní app si ho přečte) ─────────────────────────
function _writeUpdateReady(chain) {
  try {
    const last = chain[chain.length - 1];
    fs.writeFileSync(READY_PATH, JSON.stringify({
      detectedAt:  new Date().toISOString(),
      count:       chain.length,
      latestVersion: last.version || last.date,
      chain: chain.map(c => ({ basename: c.basename, version: c.version || null, date: c.date })),
    }, null, 2), 'utf8');
    _log(`update_ready.json zapsán (${chain.length} ZIPů, poslední: v${last.version || last.date})`);
  } catch (e) {
    _log(`CHYBA zápisu update_ready.json: ${e.message}`);
  }
}

// ── Stažení ZIP do cache ──────────────────────────────────────────────────────
async function _downloadZip(c, pat = '') {
  if (c.localPath) return c.localPath;    // lokální soubor – nepotřebujeme stáhnout

  const cacheDir = path.join(os.tmpdir(), `${APP_SLUG}_daemon_zip`);
  try { fs.mkdirSync(cacheDir, { recursive: true }); } catch (_) {}
  const dest = path.join(cacheDir, c.basename);

  if (fs.existsSync(dest)) {
    _log(`ZIP v cache: ${dest}`);
    return dest;
  }

  _log(`Stahuji: ${c.basename}`);
  await _httpsDownload(c.downloadUrl, dest, pat);
  _log(`Staženo: ${dest}`);
  return dest;
}

// ── Rozbalení celého chainu do tmpExtract ─────────────────────────────────────
async function _applyChain(chain, tmpExtract, pat = '') {
  if (fs.existsSync(tmpExtract)) {
    try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch (_) {}
  }
  fs.mkdirSync(tmpExtract, { recursive: true });

  for (let i = 0; i < chain.length; i++) {
    const c    = chain[i];
    const label = c.version ? `v${c.version}` : c.date;
    _log(`Rozbaluji [${i + 1}/${chain.length}]: ${c.basename}`);

    const zipPath = await _downloadZip(c, pat);
    const cmd = `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${tmpExtract.replace(/'/g, "''")}' -Force`;

    const _isWin = process.platform === 'win32';
    await new Promise((resolve, reject) => {
      // Windows: PowerShell. Jinde: unzip. Windowsová větev beze změny.
      const child = _isWin
        ? spawn('powershell.exe', [
            '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd,
          ], { stdio: 'pipe' })
        : spawn('unzip', ['-o', '-q', zipPath, '-d', tmpExtract], { stdio: 'pipe' });

      let stderr = '';
      child.stderr && child.stderr.on('data', d => { stderr += d.toString(); });

      const t = setTimeout(() => { try { child.kill(); } catch (_) {} reject(new Error(`Timeout rozbalování ${label}`)); }, 180000);
      child.on('close', code => {
        clearTimeout(t);
        code !== 0
          ? reject(new Error(`${_isWin ? 'PowerShell' : 'unzip'} exit ${code}: ${stderr.trim()}`))
          : resolve();
      });
      child.on('error', err => { clearTimeout(t); reject(err); });
    });

    _log(`Rozbaleno OK: ${label}`);
  }

  _log(`Chain rozbalení hotovo → ${tmpExtract}`);
}

// ── Kopírování souborů (Node.js async) ────────────────────────────────────────
async function _copyFiles(src, dst) {
  await fs.promises.cp(src, dst, { recursive: true, force: true });
  _log(`Zkopírováno: ${src} → ${dst}`);
}

// ── BAT restart aplikace ──────────────────────────────────────────────────────
function _spawnBatRestart(exePath, waitForPid = 0) {
  // ── Linux/macOS: shell skript místo BAT ─────────────────────────────────
  if (process.platform !== 'win32') {
    const shPath = path.join(os.tmpdir(), `${APP_SLUG}_daemon_restart.sh`);
    const shLines = [
      '#!/bin/sh',
      waitForPid > 0 ? `while kill -0 ${waitForPid} 2>/dev/null; do sleep 1; done` : '',
      `"${exePath}" >/dev/null 2>&1 &`,
      'rm -- "$0"',
    ].filter(Boolean);
    fs.writeFileSync(shPath, shLines.join('\n'), { encoding: 'utf8', mode: 0o755 });
    spawn('/bin/sh', [shPath], { detached: true, stdio: 'ignore' }).unref();
    _log(`SH restart spuštěn (čeká na PID ${waitForPid}, pak spustí: ${exePath})`);
    return;
  }

  const batPath = path.join(os.tmpdir(), `${APP_SLUG}_daemon_restart.bat`);
  const lines   = [
    '@echo off',
    'if "%1"=="hidden" goto main',
    `start /MIN "" cmd.exe /C "%~f0" hidden`,
    'exit',
    ':main',
    waitForPid > 0 ? `:wait\ntasklist /FI "PID eq ${waitForPid}" 2>NUL | find /I "${waitForPid}" >NUL\nif not errorlevel 1 (ping -n 2 127.0.0.1 >NUL & goto wait)` : '',
    `start "" "${exePath}"`,
    `del "%~f0" 2>NUL`,
  ].filter(Boolean);

  fs.writeFileSync(batPath, lines.join('\r\n'), 'utf8');
  const proc = spawn('cmd.exe', ['/C', batPath], {
    detached: true, stdio: 'ignore', windowsHide: true, shell: false,
  });
  proc.unref();
  _log(`BAT restart spuštěn (čeká na PID ${waitForPid}, pak spustí: ${exePath})`);
}

// ── Tichá instalace bez běžící hlavní app ─────────────────────────────────────
async function _silentInstall(chain, pat = '') {
  if (!APP_DIR) { _log('CHYBA: APP_DIR neznámý, nelze instalovat'); return false; }

  const tmpExtract = path.join(os.tmpdir(), `${APP_SLUG}_daemon_pending`);
  const targetDir  = path.join(APP_DIR, 'resources', 'app');

  try {
    await _applyChain(chain, tmpExtract, pat);

    _log(`Kopíruji do ${targetDir}…`);
    await _copyFiles(tmpExtract, targetDir);

    // Zrcadlení index.html
    const htmlSrc = path.join(targetDir, 'src', 'renderer', 'index.html');
    if (fs.existsSync(htmlSrc)) {
      try {
        fs.copyFileSync(htmlSrc, path.join(APP_DIR, 'resources', 'index.html'));
        _log('index.html zkopírován do resources/');
      } catch (_) {}
    }

    // Úklid
    try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch (_) {}

    const last = chain[chain.length - 1];
    _log(`Tichá instalace HOTOVA → v${last.version || last.date}. Spouštím app…`);

    if (MAIN_EXE && fs.existsSync(MAIN_EXE)) {
      _spawnBatRestart(MAIN_EXE, 0);
    }
    return true;
  } catch (e) {
    _log(`CHYBA tichá instalace: ${e.message}`);
    return false;
  }
}

// ── WATCHDOG: sleduje zdraví hlavní aplikace ──────────────────────────────────
// Volá se každých WATCHDOG_INTERVAL sekund.
// Pokud PID zmizel a existuje update_pending.json → auto-restore.
const WATCHDOG_INTERVAL_MS = 10_000;  // 10 sekund
let _mainPid   = MAIN_PID;
let _appAlive  = _pidAlive(_mainPid);
let _restoreAttempted = false;

async function _watchdogTick() {
  const wasAlive = _appAlive;
  _appAlive = _pidAlive(_mainPid);

  if (wasAlive && !_appAlive) {
    _log(`Hlavní app (PID ${_mainPid}) zanikla.`);

    // Zkontroluj update_pending.json → pokud existuje, byl crash po aktualizaci
    let pending = null;
    try {
      if (fs.existsSync(PENDING_PATH)) {
        pending = JSON.parse(fs.readFileSync(PENDING_PATH, 'utf8'));
      }
    } catch (_) {}

    if (pending) {
      _log(`update_pending.json nalezen (verze: ${pending.newVersion}) – spouštím PB_restore.bat…`);
      if (!_restoreAttempted) {
        _restoreAttempted = true;
        _runRestore();
      }
    } else {
      // Normální ukončení (nebo crash bez aktualizace) – jen přestaneme hlídat PID
      _log('Žádný update_pending.json → normální ukončení. Watchdog čeká na restart.');
    }
  } else if (!wasAlive && _appAlive) {
    _log(`Hlavní app znovu běží (PID ${_mainPid}).`);
    _restoreAttempted = false;
  }
}

function _runRestore() {
  if (!fs.existsSync(RESTORE_BAT)) {
    _log(`CHYBA: PB_restore.bat nenalezen (${RESTORE_BAT}) – ruční zásah potřeba`);
    return;
  }

  _log(`Spouštím PB_restore.bat --auto (obnoví zálohu + restartuje app)`);

  const proc = process.platform === 'win32'
    ? spawn('cmd.exe', ['/C', RESTORE_BAT, '--auto'], {
        detached: true, stdio: 'ignore', windowsHide: false, shell: false,
      })
    : spawn('/bin/sh', [RESTORE_BAT, '--auto'], {
        detached: true, stdio: 'ignore',
      });
  proc.unref();

  _log('PB_restore.bat spuštěn. Démon čeká na restart hlavní app…');
}

// ── UPDATE CHECK LOOP ─────────────────────────────────────────────────────────
let _lastCheckedVersion = '';  // posledně detekovaná nejnovější verze (zamezí spam)

async function _updateCheckTick() {
  const cfg        = _readConfig();
  const pat        = (cfg.GITHUB_PAT || '').trim();
  const updateDir  = (cfg.UPD_SERVER_PATH || '').trim();
  const version    = APP_VERSION;

  _log(`Update check (aktuální: v${version})…`);
  _writeState({ lastCheckAt: new Date().toISOString() });

  let chain = [];
  try {
    const github = await _checkGitHub(version, pat);
    const local  = updateDir && fs.existsSync(updateDir) ? _checkLocal(updateDir, version) : [];

    // Sloučení (GitHub preferován)
    const map = new Map();
    for (const c of local)  map.set(c.version || `${c.date}_${c.build}`, c);
    for (const c of github) map.set(c.version || `${c.date}_${c.build}`, c);
    chain = Array.from(map.values()).sort((a, b) => {
      if (a.version && b.version) return _compareVersions(a.version, b.version);
      return a.date < b.date ? -1 : a.date > b.date ? 1 : 0;
    });
  } catch (e) {
    _log(`Update check chyba: ${e.message}`);
    return;
  }

  if (chain.length === 0) {
    _log('Žádné nové aktualizace.');
    // Smaž starý update_ready.json pokud existuje (verze byla mezitím nainstalována)
    try { if (fs.existsSync(READY_PATH)) fs.unlinkSync(READY_PATH); } catch (_) {}
    return;
  }

  const last    = chain[chain.length - 1];
  const lastVer = last.version || last.date;

  // Neopakuj notifikaci pro stejnou verzi
  if (_lastCheckedVersion === lastVer) {
    _log(`Aktualizace v${lastVer} již hlášena, přeskakuji.`);
    return;
  }
  _lastCheckedVersion = lastVer;

  if (_appAlive) {
    // Hlavní app běží → zapíšeme update_ready.json, app si ho přečte a zobrazí dialog
    _writeUpdateReady(chain);
  } else {
    // Hlavní app neběží → tichá instalace
    _log(`Hlavní app není spuštěna – spouštím tichou instalaci v${lastVer}`);
    const cfg2 = _readConfig();
    const pat2 = (cfg2.GITHUB_PAT || '').trim();
    const ok   = await _silentInstall(chain, pat2);
    if (ok) _lastCheckedVersion = '';  // reset – příští check ověří novou verzi
  }
}

// ── Start démona ──────────────────────────────────────────────────────────────
async function _main() {
  _log(`=== PhotoBridge Updater Daemon start (pid=${process.pid}, mainPid=${MAIN_PID}, v${APP_VERSION}) ===`);
  _writeState();

  // Okamžitý update check po 30 sekundách (dáme hlavní app čas nastartovat)
  setTimeout(() => {
    _updateCheckTick().catch(e => _log(`Update check chyba: ${e.message}`));
  }, 30_000);

  // Watchdog: každých 10 sekund
  setInterval(() => {
    _watchdogTick().catch(e => _log(`Watchdog chyba: ${e.message}`));
  }, WATCHDOG_INTERVAL_MS);

  // Pravidelný update check
  const pollMs = POLL_MIN * 60 * 1000;
  setInterval(() => {
    _updateCheckTick().catch(e => _log(`Update check chyba: ${e.message}`));
  }, pollMs);

  _log(`Watchdog: každých ${WATCHDOG_INTERVAL_MS / 1000}s | Update check: každých ${POLL_MIN} min`);

  // Udržuj proces naživu (jinak by Node.js skončil bez aktivní smyčky)
  // Interval nemůžeme unref() – chceme aby proces ŽIL
}

_main().catch(e => {
  _log(`KRITICKÁ CHYBA: ${e.message}\n${e.stack || ''}`);
  process.exit(1);
});
