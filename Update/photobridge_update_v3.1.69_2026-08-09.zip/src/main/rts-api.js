'use strict';
// ============================================================
// PhotoBridge – src/main/rts-api.js
// Klient pro RTS API (Britex) – náhrada UploadScanu.
//
// CO UMÍ:
//   • drží OAuth2 přístupový token (obnova přes refresh_token)
//   • POST /api/SandBox/TempFile      – dočasné uložení souboru
//   • POST /api/SandBox/GetTempFile   – stažení dočasného souboru
//   • POST /api/Info21/SavePhotoFile  – ULOŽENÍ FOTKY DO ZAKÁZKY
//
// NEDOŘEŠENÉ BODY (čeká na potvrzení od IT – proto přepínače v configu):
//   1) RTS_ID_MODE     – je "id" u SavePhotoFile číslo zakázky, nebo interní ID?
//   2) RTS_DATA_FIELD  – patří base64 do "data", nebo "content"?
// Až se potvrdí, stačí přepnout v Nastavení; kód se nemění.
// ============================================================

const fs   = require('fs');
const path = require('path');

let _cfgMod = null;
function readCfg() {
    try {
        if (!_cfgMod) _cfgMod = require('./config');
        return _cfgMod.readConfig();
    } catch (_) { return {}; }
}
function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

// ── CENTRÁLNÍ KONFIGURACE ZE SUPABASE ─────────────────────────────
// client_id (a případně secret) se čtou z pb_settings, aby je technici
// nemuseli zadávat a daly se změnit na jednom místě bez nové verze.
// Cache 30 min – stejně jako Groq klíče a AI model.
let _remoteCfg = null, _remoteCfgTime = 0;

async function getRemoteConfig() {
    const now = Date.now();
    if (_remoteCfg && (now - _remoteCfgTime) < 30 * 60 * 1000) return _remoteCfg;
    try {
        const cfg  = readCfg();
        const sbUrl  = String(cfg.SB_URL  || '').replace(/\/+$/, '');
        const sbAnon = String(cfg.SB_ANON || '');
        if (!sbUrl || !sbAnon) return {};
        const url = `${sbUrl}/rest/v1/pb_settings?key=in.(rts_client_id,rts_client_secret)&select=key,value`;
        const resp = await fetch(url, { headers: { apikey: sbAnon, Authorization: `Bearer ${sbAnon}` } });
        if (!resp.ok) return _remoteCfg || {};
        const rows = await resp.json();
        const out = {};
        for (const r of (rows || [])) {
            if (r.key === 'rts_client_id')     out.clientId     = String(r.value || '').trim();
            if (r.key === 'rts_client_secret') out.clientSecret = String(r.value || '').trim();
        }
        _remoteCfg = out; _remoteCfgTime = now;
        log('INFO', 'RTS_CFG',
            `Centrální nastavení ze Supabase: client_id=${out.clientId ? 'OK' : 'CHYBÍ'}`
            + `, secret=${out.clientSecret ? 'vyplněn' : 'prázdný (PKCE)'}`);
        return out;
    } catch (e) {
        log('WARN', 'RTS_CFG', `Načtení ze Supabase selhalo: ${String(e.message || e)}`);
        return _remoteCfg || {};
    }
}

/** client_id: přednost má lokální nastavení, jinak Supabase. */
async function clientId() {
    const local = String(readCfg().RTS_CLIENT_ID || '').trim();
    if (local) return local;
    return (await getRemoteConfig()).clientId || '';
}

/** client_secret: použije se JEN když je vyplněný (PKCE ho nepotřebuje). */
async function clientSecret() {
    const local = String(readCfg().RTS_CLIENT_SECRET || '').trim();
    if (local) return local;
    return (await getRemoteConfig()).clientSecret || '';
}

// ── Základ ───────────────────────────────────────────────────────────────────

/** Kořenová adresa RTS (dev/produkce se přepíná v Nastavení). */
function baseUrl() {
    const u = String(readCfg().RTS_URL || 'https://rts.britex.cz').trim();
    return u.replace(/\/+$/, '');
}

/** Do kterého pole patří base64 obsah souboru ('data' | 'content'). */
function dataField() {
    const f = String(readCfg().RTS_DATA_FIELD || 'data').trim().toLowerCase();
    return (f === 'content') ? 'content' : 'data';
}

/** Jak se určuje "id" u SavePhotoFile ('job' = číslo zakázky | 'internal'). */
function idMode() {
    const m = String(readCfg().RTS_ID_MODE || 'job').trim().toLowerCase();
    return (m === 'internal') ? 'internal' : 'job';
}

// ── OAuth2 token ─────────────────────────────────────────────────────────────

let _token        = null;   // přístupový token
let _tokenExpires = 0;      // ms timestamp
let _refreshToken = null;

/**
 * Vrátí platný přístupový token.
 * Priorita: 1) ruční token z Nastavení (RTS_TOKEN – pro rychlé testování)
 *           2) v paměti, pokud ještě neexpiroval
 *           3) obnova přes refresh_token
 * Přihlašovací (authorization_code) flow řeší okno s přihlášením, ne tento modul.
 */
async function getToken() {
    const cfg = readCfg();

    // 1) Ruční token (vyplněný v Nastavení) – užitečné pro test bez přihlášení
    const manual = String(cfg.RTS_TOKEN || '').trim();
    if (manual) return manual;

    // 2) Platný token v paměti (30 s rezerva)
    if (_token && Date.now() < (_tokenExpires - 30_000)) return _token;

    // 3) Session uložená po přihlášení (přežije restart aplikace)
    if (!_token) {
        try {
            const sess = require('./rts-auth').loadSession();
            if (sess) {
                if (sess.accessToken && Date.now() < (sess.expiresAt - 30_000)) {
                    _token = sess.accessToken; _tokenExpires = sess.expiresAt;
                    _refreshToken = sess.refreshToken || _refreshToken;
                    return _token;
                }
                _refreshToken = sess.refreshToken || _refreshToken;
            }
        } catch (_) {}
    }

    // 4) Obnova přes refresh_token – technik se nemusí přihlašovat znovu
    if (_refreshToken) {
        try {
            const p = {
                grant_type:    'refresh_token',
                refresh_token: _refreshToken,
                client_id:     await clientId(),
            };
            const sec = await clientSecret();
            if (sec) p.client_secret = sec;
            const t = await _requestToken(p);
            if (t) return t;
        } catch (e) {
            log('WARN', 'RTS refresh', String(e.message || e));
        }
    }
    return null;
}

/** Zavolá POST /oauth/Token a uloží výsledek do paměti. */
async function _requestToken(params) {
    const url  = `${baseUrl()}/oauth/Token`;
    const body = new URLSearchParams(params).toString();

    const resp = await fetch(url, {
        method:  'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
        body,
    });
    if (!resp.ok) {
        const txt = await resp.text().catch(() => '');
        throw new Error(`Token HTTP ${resp.status}: ${txt.slice(0, 200)}`);
    }
    const j = await resp.json();
    _token        = j.access_token || j.token || null;
    _refreshToken = j.refresh_token || _refreshToken;
    const ttl     = Number(j.expires_in || 86400);   // RTS drzí přihlášení ~24 h
    _tokenExpires = Date.now() + ttl * 1000;
    log('INFO', 'RTS token', `Získán token, platnost ${Math.round(ttl / 3600)} h`
        + (_refreshToken ? ' (s automatickou obnovou)' : ' (BEZ obnovy – pak nutné nové přihlášení)'));

    // Ulož session, ať přežije restart aplikace
    try {
        require('./rts-auth').saveSession({
            accessToken:  _token,
            refreshToken: _refreshToken,
            expiresAt:    _tokenExpires,
            user:         (j.user && (j.user.email || j.user.username)) || '',
        });
    } catch (_) {}
    return _token;
}

/**
 * Vymění autorizační kód za token (dokončení přihlášení).
 * Volá se z okna, které provedlo /oauth/Authorize.
 */
async function exchangeCode(code, redirectUri, codeVerifier) {
    const cfg = readCfg();
    const p = {
        grant_type:   'authorization_code',
        code,
        redirect_uri: redirectUri || String(cfg.RTS_REDIRECT_URI || ''),
        client_id:    await clientId(),
    };
    if (codeVerifier) p.code_verifier = codeVerifier;   // PKCE – nahrazuje secret
    const sec = await clientSecret();
    if (sec) p.client_secret = sec;                     // jen když je vyplněný
    return _requestToken(p);
}

/** Ruční nastavení tokenu (např. vytaženého z prohlížeče při testování). */
function setToken(token, expiresInSec) {
    _token        = token || null;
    _tokenExpires = Date.now() + (Number(expiresInSec || 3600) * 1000);
}

/** Hlavičky pro autorizované volání. */
async function authHeaders(extra) {
    const t = await getToken();
    const h = Object.assign({ 'Accept': 'application/json' }, extra || {});
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
}

// ── Volání API ───────────────────────────────────────────────────────────────

/**
 * Obecné POST volání na RTS s JSON tělem.
 * @returns {Promise<{ok:boolean, status:number, body:any, error?:string}>}
 */
async function postJson(endpoint, payload, timeoutMs = 60_000) {
    const url  = `${baseUrl()}${endpoint}`;
    const ctrl = new AbortController();
    const to   = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const resp = await fetch(url, {
            method:  'POST',
            headers: await authHeaders({ 'Content-Type': 'application/json' }),
            body:    JSON.stringify(payload),
            signal:  ctrl.signal,
        });
        clearTimeout(to);

        let body = null;
        const txt = await resp.text().catch(() => '');
        try { body = txt ? JSON.parse(txt) : null; } catch (_) { body = txt; }

        if (!resp.ok) {
            return { ok: false, status: resp.status, body,
                     error: (typeof body === 'string' ? body : JSON.stringify(body || '')).slice(0, 300) };
        }
        return { ok: true, status: resp.status, body };
    } catch (e) {
        clearTimeout(to);
        return { ok: false, status: 0, body: null, error: String(e.message || e) };
    }
}

/**
 * Uloží soubor do dočasného úložiště (redis) a vrátí jeho SHA256.
 * Používá se, když má fotku převzít PC (přes SignalR / poll).
 */
async function tempFileUpload(filePath) {
    const b64 = fs.readFileSync(filePath).toString('base64');
    const res = await postJson('/api/SandBox/TempFile', { content: b64 });
    if (!res.ok) {
        log('ERROR', 'RTS TempFile', `${path.basename(filePath)}: ${res.error}`);
        return null;
    }
    const sha = res.body?.sha256 || res.body?.Sha256 || res.body?.hash || null;
    log('INFO', 'RTS TempFile', `${path.basename(filePath)} → sha256=${sha || '(neznámý tvar odpovědi)'}`);
    return { sha256: sha, raw: res.body };
}

/** Stáhne dočasný soubor podle SHA256. */
async function tempFileDownload(sha256) {
    const res = await postJson('/api/SandBox/GetTempFile', { sha256 });
    if (!res.ok) {
        log('ERROR', 'RTS GetTempFile', `${sha256}: ${res.error}`);
        return null;
    }
    return res.body;
}

/**
 * ULOŽÍ FOTKU DO ZAKÁZKY – hlavní operace (náhrada UploadScanu).
 *
 * @param {string} filePath – cesta k hotovému souboru
 * @param {object} meta     – { job, typ, docType }
 */
async function savePhotoFile(filePath, meta) {
    if (!fs.existsSync(filePath)) {
        return { ok: false, error: 'Soubor neexistuje', permanent: true };
    }
    const b64  = fs.readFileSync(filePath).toString('base64');
    const name = path.basename(filePath);

    // Číslo zakázky → "id"
    let id = parseInt(String(meta?.job || '').replace(/\D/g, ''), 10);
    if (idMode() === 'internal') {
        const resolved = await resolveOrderId(meta?.job);
        if (resolved) id = resolved;
    }
    if (!id || Number.isNaN(id)) {
        return { ok: false, error: `Neplatné číslo zakázky: ${meta?.job}`, permanent: true };
    }

    // Data URI (některá .NET API očekávají prefix)
    const ext  = path.extname(name).toLowerCase().replace('.', '') || 'jpeg';
    const mime = (ext === 'png') ? 'image/png' : (ext === 'pdf' ? 'application/pdf' : 'image/jpeg');
    const dataUri = `data:${mime};base64,${b64}`;

    // ── VARIANTY TĚLA ───────────────────────────────────────
    // RTS vrací "Index was outside the bounds of the array" – třídí některý
    // řetězec podle oddělovače. Zkusíme známé tvary a zalogujeme, který projde.
    // POŘADÍ: první je ověřená funkční varianta (test 7. 8. 2026, zakázka 4529812).
    // RTS chce base64 VČETNĚ prefixu "data:image/png;base64," – bez něj padá
    // na "Index was outside the bounds of the array" (server dělí řetězec podle čárky).
    const variants = [
        { label: 'dataUri v data',    file: { name, content: '',      data: dataUri } },
        { label: 'data',              file: { name, content: '',      data: b64 } },
        { label: 'content',           file: { name, content: b64,     data: ''  } },
        { label: 'obe',               file: { name, content: b64,     data: b64 } },
        { label: 'dataUri v content', file: { name, content: dataUri, data: ''  } },
        { label: 'dataUri v obou',    file: { name, content: dataUri, data: dataUri } },
        { label: 'content=typ',       file: { name, content: String(meta?.docType || 'DD_DOC'), data: b64 } },
        { label: 'bez content',       file: { name, data: b64 } },
        { label: 'bez data',          file: { name, content: b64 } },
    ];

    // Když je režim pevně nastavený (auto vypnuto), pošli jen zvolenou variantu
    const auto = String(readCfg().RTS_AUTO_PROBE || 'on').toLowerCase() !== 'off';
    const chosen = String(readCfg().RTS_VARIANT || 'dataUri v data');
    const list   = auto ? variants : variants.filter(v => v.label === chosen);

    let lastErr = null, lastStatus = 0;
    for (const v of list) {
        const res = await postJson('/api/Info21/SavePhotoFile', { files: [v.file], id });
        if (res.ok) {
            log('INFO', 'RTS SavePhotoFile',
                `OK: ${name} → zakázka ${id}` + (auto ? ` ─ varianta "${v.label}"` : ''));
            // Zapamatuj si funkční variantu – příště se pošle rovnou jako první
            try {
                if (auto && chosen !== v.label) {
                    const cfgMod = require('./config');
                    cfgMod.writeConfig(Object.assign({}, cfgMod.readConfig(), { RTS_VARIANT: v.label }));
                }
            } catch (_) {}
            return { ok: true, status: res.status, body: res.body, variant: v.label };
        }
        lastErr = res.error; lastStatus = res.status;
        log('WARN', 'RTS SavePhotoFile',
            `varianta "${v.label}" → HTTP ${res.status}: ${String(res.error || '').slice(0, 160)}`);

        // 401 = token – další varianty nemá smysl zkoušet
        if (res.status === 401) break;
    }

    const permanent = lastStatus >= 400 && lastStatus < 500 &&
                      lastStatus !== 408 && lastStatus !== 429;
    log('ERROR', 'RTS SavePhotoFile',
        `${name} → zakázka ${id}: žádná varianta neuspěla (poslední HTTP ${lastStatus})`);
    return { ok: false, status: lastStatus, error: lastErr, permanent };
}

/**
 * Dohledá interní ID zakázky podle jejího čísla.
 * Použije se jen když RTS_ID_MODE = 'internal'.
 * POZN.: endpoint pro vyhledání zakázky zatím není potvrzen – doplní se
 * po odpovědi od IT. Do té doby vrací null (použije se číslo zakázky).
 */
async function resolveOrderId(job) {
    const n = String(job || '').replace(/\D/g, '');
    if (!n) return null;
    try {
        const url  = `${baseUrl()}/api/v4/ServiceOrder?doc=${encodeURIComponent(n)}`;
        const resp = await fetch(url, { headers: await authHeaders() });
        if (!resp.ok) return null;
        const j = await resp.json();
        const row = Array.isArray(j) ? j[0] : (j?.items?.[0] || j);
        return row?.id || row?.Id || null;
    } catch (_) { return null; }
}

/** Rychlý test spojení a autorizace (pro tlačítko v Nastavení). */
async function testConnection() {
    try {
        const resp = await fetch(`${baseUrl()}/api/v4/User`, { headers: await authHeaders() });
        if (resp.ok) {
            const u = await resp.json().catch(() => null);

            // DIAGNOSTIKA: jak vypadá odpověď /api/v4/User. Potřebujeme vědět,
            // pod jakým názvem je e-mail – na tom stojí ověření v Edge Funkci.
            // Vypisují se jen názvy polí a e-mail; ostatní hodnoty ne, ať se
            // do logu nedostane víc, než je nutné.
            try {
                if (u && typeof u === 'object') {
                    const keys = Object.keys(u);
                    log('INFO', 'RTS_USER', `Pole v odpovědi: ${keys.join(', ')}`);
                    for (const k of keys) {
                        const v = u[k];
                        if (typeof v === 'string' && v.includes('@')) {
                            log('INFO', 'RTS_USER', `E-mail nalezen v poli "${k}": ${v}`);
                        }
                    }
                    if (!keys.some(k => typeof u[k] === 'string' && u[k].includes('@'))) {
                        log('WARN', 'RTS_USER', 'V odpovědi NENÍ žádné pole s e-mailem!');
                        log('INFO', 'RTS_USER', `Celá odpověď: ${JSON.stringify(u).slice(0, 800)}`);
                    }
                } else {
                    log('WARN', 'RTS_USER', `Odpověď není objekt: ${String(u).slice(0, 200)}`);
                }
            } catch (_) {}

            return { ok: true, user: u?.email || u?.username || u?.name || '(přihlášen)' };
        }
        if (resp.status === 401) return { ok: false, error: 'Neplatný nebo chybějící token (401)' };
        return { ok: false, error: `HTTP ${resp.status}` };
    } catch (e) {
        return { ok: false, error: String(e.message || e) };
    }
}

module.exports = {
    baseUrl, getToken, setToken, exchangeCode, authHeaders,
    postJson, tempFileUpload, tempFileDownload, savePhotoFile,
    resolveOrderId, testConnection, dataField, idMode,
    clientId, clientSecret, getRemoteConfig,
};
