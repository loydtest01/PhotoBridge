'use strict';
// ============================================================
// editor-preload.js – context bridge mezi editor.html a main procesem
// ============================================================

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('editorAPI', {
  readFileAsDataUrl: (filePath) => ipcRenderer.invoke('editor:readFile', filePath),
  saveFile: (filePath, dataArr) => ipcRenderer.invoke('editor:saveFile', filePath, dataArr),
  printFile: (dataArr, suggestedName) => ipcRenderer.invoke('editor:printFile', dataArr, suggestedName),
  getQueue: () => ipcRenderer.invoke('editor:getQueue'),
  nextInQueue: () => ipcRenderer.invoke('editor:nextInQueue'),
  // currentFile i loadFile vracejí aktuální soubor (zpětná kompatibilita)
  currentFile: () => ipcRenderer.invoke('editor:currentFile'),
  loadFile: () => ipcRenderer.invoke('editor:currentFile'),
  close: () => ipcRenderer.invoke('editor:close'),
});
