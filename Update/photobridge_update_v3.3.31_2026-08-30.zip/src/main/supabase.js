/**
 * supabase.js – Supabase Auth + Storage poller
 * Fáze 5: přepis Python logiky z photobridge.py (řádky 1690–2110)
 *
 * Exportuje:
 *   sbLogin(cfg, emailOrName, password)  → { ok, error }
 *   sbRegister(cfg, username, password)  → { ok, error }
 *   sbEnsureToken(cfg)                   → access_token string nebo ""
 *   sbListObjects(cfg, bucket, job)      → pole objektů
 *   sbDownload(cfg, bucket, path)        → Buffer
 *   sbDelete(cfg, bucket, path)          → void
 *   startSbPoller(cfg, job, saveDir)     → void
 *   stopSbPoller()                       → void
 *   registerIpcHandlers()                → void  (volat z main.js)
 */

"use strict";

const { ipcMain }  = require("electron");
const fetch        = require("node-fetch");   // npm i node-fetch@2
const https        = require("https");
const fs           = require("fs");
const path         = require("path");
// Importy ze sesterských modulů
const { log, loadState, saveState, STATE } = require("./utils");

// ─── HTTP/HTTPS agenti ────────────────────────────────────────────────────────
// Vlastní Agent pro auth endpointy (login, refresh, signup) – nepoužívá
// globální connection pool, takže se nezasekne když poller drmolil requesty
// před logoutem a auth si nemůže půjčit socket.
// keepAlive: false → každý request má vlastní fresh TCP connection.
const _authAgent = new https.Agent({
    keepAlive:    false,
    maxSockets:   8,
    timeout:      30_000,
});

// Pro pollovací requesty (časté, krátké) zůstává keepAlive aby šetřil overhead
const _pollAgent = new https.Agent({
    keepAlive:    true,
    keepAliveMsecs: 5_000,
    maxSockets:   10,
    timeout:      15_000,
});

// ─── Interní stav polleru ────────────────────────────────────────────────────
let _pollerTimer  = null;       // setInterval handle
let _pollerSeen   = new Set();  // rozpracované / ve frontě zpracování
let _pollerHotovo = new Set();  // ÚSPĚŠNĚ uložené na disk – jen tyhle se smí označit jako done
let _pollerActive = false;

// ─── Realtime websocket ───────────────────────────────────────────────────────
let _rtSocket           = null;       // WebSocket instance
let _rtRef              = 0;          // counter pro Realtime message refs
let _rtHeartbeat        = null;       // setInterval pro heartbeat
let _rtReconnect        = null;       // setTimeout pro reconnect
let _rtConnected        = false;
let _rtHeartbeatSent    = 0;          // počet odeslaných heartbeatů bez odpovědi
let _rtLastHeartbeatRef = "";         // ref poslední odeslané heartbeat zprávy
let _rtTokenTimer       = null;       // setInterval pro obnovu access_tokenu

// ─── Sériová fronta zpracování ────────────────────────────────────────────────
// Když přijde batch fotek (Realtime nebo polling), zpracovávají se postupně –
// nikdy 2 souběžně. To zajišťuje že _nextLetter přiděluje písmena ve správném
// pořadí (A pro nejstarší, B pro další, …) a Malování se otevře sekvenčně,
// ne 5× najednou.
let _processQueue   = [];        // fronta { filePath, rowId }
let _processRunning = false;     // je právě nějaké zpracování v běhu?

// ─── Counter pro fallback Storage scan ────────────────────────────────────────
// Každých N ticků (závisí na intervalu) projdeme Storage přímo, ne jen pb_queue.
// Pokrývá scénář kdy mobil úspěšně nahrál soubor ale pb_queue insert selhal.
let _pollerTickCount = 0;

// ─── CHYTRÁ POJISTKA (egress optimalizace) ────────────────────────────────────
// Fotky chodí OKAMŽITĚ přes Realtime push (postgres_changes na pb_queue).
// Polling už NENÍ doručovací kanál – je to jen záchranná síť pro dva vzácné
// případy: (1) websocket na chvíli vypadl a během toho přišla fotka,
// (2) mobil nahrál do Storage, ale pb_queue insert selhal (žádný event).
//
//   • Websocket PŘIPOJEN  → pomalá kontrola á 2 min (+ scan Storage na orphany).
//                           Po (re)connectu se vždy udělá 1 okamžité „dohnání“.
//   • Websocket ODPOJEN   → krátce á 5 s, než se znovu připojí (reconnect ~10 s).
//
// Tím egress klesá ~o 99 % (z ~1 dotazu/2 s na ~1 dotaz/2 min na PC), latence
// doručení fotek se NEMĚNÍ (jede přes push).
// POZOR NA EGRESS. Free plán Supabase má 5 GB měsíčně. Dotaz á 3 s znamená
// 28 800 dotazů denně NA JEDNO PC – při deseti PC ~3,5 GB měsíčně jen za
// odpovědi s prázdným polem. Proto se při připojeném websocketu zpomaluje:
// fotky chodí okamžitě push zprávou, dotaz je jen záchranná síť.
const POLL_MS_IDLE         = 60_000;    // klid (nikdo nic nenahrává) → á 1 min
const POLL_MS_ACTIVE       = 3_000;     // technik právě pracuje → á 3 s jako dřív
const AKTIVNI_PO_MS        = 3 * 60_000; // jak dlouho po poslední fotce zůstat rychlý
const POLL_MS_STARTUP      = 2_000;     // krátce po startu, než se připojí WS
let _pollSlowMode = false;              // true = websocket připojen (pomalý režim)
let _pollerIntervalMs = 0;              // aktuálně nastavený interval, ať se zbytečně nepřenastavuje
let _posledniAktivita = 0;              // kdy naposledy něco přišlo (fotka nebo push)



// ─── Pomocné funkce ──────────────────────────────────────────────────────────

/**
 * Sestaví hlavičky pro Supabase API volání.
 * @param {string} apikey   – anon klíč nebo access token
 * @param {string} [bearer] – Bearer token (pokud se liší od apikey)
 */
function _sbHeaders(apikey, bearer) {
    return {
        "Content-Type":  "application/json",
        "apikey":        apikey,
        "Authorization": `Bearer ${bearer || apikey}`,
    };
}

/**
 * Dekóduje `exp` claim z JWT bez ověření podpisu.
 * @param {string} token
 * @returns {number} Unix timestamp nebo 0 při chybě
 */
function _jwtExp(token) {
    try {
        const parts   = token.split(".");
        if (parts.length < 2) return 0;
        const payload = Buffer.from(parts[1], "base64url").toString("utf8");
        return Number(JSON.parse(payload).exp || 0);
    } catch {
        return 0;
    }
}

/**
 * Vrátí platnou sb_url bez koncového lomítka.
 * @param {object} cfg
 */
function _sbUrl(cfg) {
    return (cfg.SB_URL || "").trim().replace(/\/$/, "");
}

// ─── AUTH ────────────────────────────────────────────────────────────────────

/**
 * Přihlásí aplikaci do Supabase Auth.
 * Přijímá plnou emailovou adresu.
 * Uloží access_token, refresh_token a user_id do STATE.
 *
 * @param {object} cfg       – konfigurace s SB_URL, SB_ANON
 * @param {string} emailOrName  – plná emailová adresa
 * @param {string} password
 * @returns {Promise<{ok: boolean, error: string}>}
 */
async function sbLogin(cfg, emailOrName, password) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const email  = emailOrName.trim();

    // Pojistka: pokud je nějaký poller/websocket z předchozího uživatele
    // ještě naživu, zastav ho. Bez toho by starý poller mohl chvíli běžet
    // s tokenem předchozího účtu, mít _pollerSeen z předchozího účtu, atd.
    const hadPrevSession = Boolean(STATE.sbAccessToken || _pollerActive || _rtSocket);
    try {
        if (typeof stopSbPoller === "function") stopSbPoller();
    } catch (_) {}
    _pollerSeen   = new Set();
    _pollerHotovo = new Set();
    _processQueue = [];

    // Když jsme zrovna teardownovali předchozí session, dej Node.js 250 ms
    // na uvolnění TCP socketů (jinak by nový login request mohl čekat ve
    // frontě za uzavírajícím se websocketem nebo zbylými fetch requesty
    // předchozího pollera). Tohle vysvětluje "první pokus po logoutu trvá
    // 30 s a spadne timeout, druhý pokus je hned hotov."
    if (hadPrevSession) {
        await new Promise(r => setTimeout(r, 250));
    }

    /**
     * Pošle login request s 25s timeoutem; při síťové chybě 1× zkusí znova
     * po 1 sekundě. Tím odpadne většina „network timeout" chyb na pomalých sítích.
     */
    const doLogin = async () => fetch(`${sbUrl}/auth/v1/token?grant_type=password`, {
        method:  "POST",
        headers: _sbHeaders(sbAnon),
        body:    JSON.stringify({ email, password }),
        timeout: 25_000,
        agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
    });

    try {
        let resp;
        try {
            resp = await doLogin();
        } catch (netErr) {
            // Síťová chyba (timeout, ECONNRESET, …) → 1× retry po 1s
            log("INFO", "SB_AUTH login retry", String(netErr).split("\n")[0]);
            await new Promise(r => setTimeout(r, 1000));
            resp = await doLogin();
        }
        const data = await resp.json();

        if (!data.access_token) {
            const msg = data.error_description || data.msg || data.message || "Přihlášení selhalo";
            log("WARN", "SB_AUTH login", msg);
            return { ok: false, error: msg };
        }

        // Uložit tokeny do STATE
        STATE.sbAccessToken  = data.access_token;
        STATE.sbRefreshToken = data.refresh_token || "";
        STATE.sbUserId       = (data.user || {}).id || "";
        STATE.sbEmail         = emailOrName;  // pro isDomaProfil + UI
        STATE.sbAccountType  = ((data.user || {}).user_metadata || {}).account_type || "";

        log("INFO", "SB_AUTH login OK", `user=${STATE.sbUserId.slice(0, 8)}...`);

        // Persistentně uložit refresh token + email (pro obnovu po restartu)
        try {
            const st         = loadState();
            st.sb_refresh    = STATE.sbRefreshToken;
            st.sb_email      = STATE.sbEmail;      // uložit email pro UI po restartu
            // Také uložit do seznamu nedávných emailů (auto-suggest při dalším loginu)
            const recents    = Array.isArray(st.sb_recent_emails) ? st.sb_recent_emails : [];
            const filtered   = recents.filter(e => e !== STATE.sbEmail);
            filtered.unshift(STATE.sbEmail);
            st.sb_recent_emails = filtered.slice(0, 5);  // max 5 nedávných
            saveState(st);
        } catch { /* nevadí */ }

        // Odeslat případnou frontu crash reportů / zpětné vazby (pády před přihlášením)
        try { await flushFeedbackQueue(cfg); } catch (_) {}

        return { ok: true, error: "" };

    } catch (err) {
        log("WARN", "SB_AUTH login failed", String(err));
        return { ok: false, error: String(err) };
    }
}

/**
 * Převezme hotovou session získanou jinudy než heslem.
 *
 * PROČ TO EXISTUJE
 * sbLogin() si tokeny obstarává sám přes /token?grant_type=password. Firemní
 * přihlášení (BRITEX) je ale dostane už hotové od Supabase, takže se musí
 * uložit stejným způsobem – jinak by aplikace tvářila jako nepřihlášená.
 * Dělá tedy přesně to, co druhá polovina sbLogin(): naplní STATE, uloží
 * refresh token do state.json a odešle případnou frontu crash reportů.
 *
 * @param {object} cfg
 * @param {object} session – { accessToken, refreshToken, user }
 * @returns {Promise<{ok: boolean, error: string, accountType: string}>}
 */
async function sbAdoptSession(cfg, session) {
    const accessToken  = String(session?.accessToken  || "");
    const refreshToken = String(session?.refreshToken || "");
    const user         = session?.user || {};

    if (!accessToken || !user.id) {
        return { ok: false, error: "Neúplná session", accountType: "" };
    }

    // Stejná pojistka jako u sbLogin – zastav poller předchozího uživatele,
    // ať chvíli neběží se starým tokenem a starým _pollerSeen.
    const hadPrevSession = Boolean(STATE.sbAccessToken || _pollerActive || _rtSocket);
    try {
        if (typeof stopSbPoller === "function") stopSbPoller();
    } catch (_) {}
    _pollerSeen   = new Set();
    _pollerHotovo = new Set();
    _processQueue = [];
    if (hadPrevSession) {
        await new Promise(r => setTimeout(r, 250));
    }

    STATE.sbAccessToken  = accessToken;
    STATE.sbRefreshToken = refreshToken;
    STATE.sbUserId       = user.id;
    STATE.sbEmail        = user.email || "";
    // Firemní přihlášení = vždy firemní účet, i kdyby metadata mlčela
    STATE.sbAccountType  = (user.user_metadata || {}).account_type || "business";

    log("INFO", "SB_AUTH adopt OK", `user=${STATE.sbUserId.slice(0, 8)}... (BRITEX)`);

    try {
        const st      = loadState();
        st.sb_refresh = STATE.sbRefreshToken;
        st.sb_email   = STATE.sbEmail;
        st.sb_account_type = STATE.sbAccountType;
        const recents  = Array.isArray(st.sb_recent_emails) ? st.sb_recent_emails : [];
        const filtered = recents.filter(e => e !== STATE.sbEmail);
        if (STATE.sbEmail) filtered.unshift(STATE.sbEmail);
        st.sb_recent_emails = filtered.slice(0, 5);
        saveState(st);
    } catch { /* nevadí */ }

    try { await flushFeedbackQueue(cfg); } catch (_) {}

    return { ok: true, error: "", accountType: STATE.sbAccountType };
}

/**
 * Zaregistruje nového uživatele v Supabase Auth.
 * Přijímá plnou emailovou adresu.
 *
 * @param {object} cfg
 * @param {string} email  – plná emailová adresa
 * @param {string} password
 * @returns {Promise<{ok: boolean, error: string}>}
 */
async function sbRegister(cfg, email, password, accountType = "business") {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    email        = email.trim();
    const username = email.split("@")[0];

    try {
        const resp = await fetch(`${sbUrl}/auth/v1/signup`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon),
            body:    JSON.stringify({
                email,
                password,
                data: { username, email_verified: true, account_type: accountType },
            }),
            timeout: 25_000,
            agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
        });
        const data = await resp.json();

        // ── A) Signup vrátil přímo access_token (Email Confirmations vypnuté) ──
        if (data.access_token) {
            STATE.sbAccessToken  = data.access_token;
            STATE.sbRefreshToken = data.refresh_token || "";
            STATE.sbUserId       = (data.user || {}).id || "";
            STATE.sbEmail        = email;
            STATE.sbAccountType  = accountType || "business";
            log("INFO", "SB_AUTH register OK (auto-login)", `user=${email}`);
            try {
                const st            = loadState();
                st.sb_refresh       = STATE.sbRefreshToken;
                st.sb_email         = STATE.sbEmail;
                st.sb_account_type  = STATE.sbAccountType;
                saveState(st);
            } catch { /* nevadí */ }
            return { ok: true, error: "", accountType: STATE.sbAccountType };
        }

        // ── B) Signup vrátil pouze user (běžné u některých Supabase nastavení) ──
        // Supabase může vrátit user buď jako data.user, NEBO jako samotný root
        // objekt (data.id + data.email) — závisí na verzi a konfiguraci.
        // Obě varianty znamenají, že účet vznikl správně.
        const signupUser = data.user || (data.id && data.email ? data : null);
        if (signupUser) {
            // Pokud Supabase poslal confirmation_sent_at nebo prázdné identities,
            // je vyžadováno potvrzení emailu - NEZKOUŠÍME auto-login (způsoboval
            // dlouhé čekání na timeout), rovnou vrátíme info hlášku.
            const needsConfirm = signupUser.confirmation_sent_at
                || (Array.isArray(signupUser.identities) && signupUser.identities.length === 0);
            if (needsConfirm) {
                log("INFO", "SB_AUTH register: email confirmation required, přeskakuji auto-login", email);
                return {
                    ok:                    false,
                    needsEmailConfirmation: true,
                    error:                 "Účet byl vytvořen. Zkontrolujte e-mail a potvrďte registraci kliknutím na odkaz.",
                };
            }

            // Email confirmation není vyžadováno - zkusime rovnou přihlásit.
            log("INFO", "SB_AUTH register: signup OK, zkouším auto-login", email);
            const loginResult = await sbLogin(cfg, email, password);
            if (loginResult.ok) {
                STATE.sbAccountType = accountType || "business";
                try {
                    const st           = loadState();
                    st.sb_account_type = STATE.sbAccountType;
                    saveState(st);
                } catch { /* nevadí */ }
                log("INFO", "SB_AUTH register OK (login po signup)", email);
                return { ok: true, error: "", accountType: STATE.sbAccountType };
            }

            // Auto-login selhal z neznámého důvodu - ucet ale vznikl spravne.
            log("INFO", "SB_AUTH register: auto-login selhal, ale ucet vznikl", loginResult.error);
            return {
                ok:                    false,
                needsEmailConfirmation: true,
                error:                 "Účet byl vytvořen. Zkontrolujte e-mail a potvrďte registraci kliknutím na odkaz.",
            };
        }

        // ── C) Signup selhal ──
        const msg = data.msg || data.message || data.error_description || "Registrace selhala";
        log("WARN", "SB_AUTH register failed", msg);
        return { ok: false, error: msg };

    } catch (err) {
        log("WARN", "SB_AUTH register failed", String(err));
        return { ok: false, error: String(err) };
    }
}

/**
 * Vrátí platný access_token.
 * Pokud STATE je prázdný nebo expirovaný, zkusí refresh nebo login.
 *
 * @param {object} cfg  – musí obsahovat SB_URL, SB_ANON, SB_EMAIL, SB_PASS
 * @returns {Promise<string>}  access_token nebo ""
 */
async function sbEnsureToken(cfg) {
    const sbUrl       = _sbUrl(cfg);
    const sbAnon      = (cfg.SB_ANON  || "").trim();
    const emailOrName = (cfg.SB_EMAIL || "").trim();
    const password    = (cfg.SB_PASS  || "").trim();

    // Máme platný token v paměti? (s 60 s rezervou)
    if (STATE.sbAccessToken) {
        const exp = _jwtExp(STATE.sbAccessToken);
        if (exp === 0 || exp > Date.now() / 1000 + 60) {
            return STATE.sbAccessToken;
        }
        // Token expiroval – vyčisti
        log("INFO", "SB_AUTH", "Access token expiroval, obnovuji...");
        STATE.sbAccessToken = "";
    }

    // Načti refresh token ze state.json pokud není v paměti
    if (!STATE.sbRefreshToken) {
        try {
            const st = loadState();
            STATE.sbRefreshToken = st.sb_refresh || "";
        } catch { /* nevadí */ }
    }

    // Zkus refresh
    if (STATE.sbRefreshToken && sbUrl && sbAnon) {
        try {
            const resp = await fetch(`${sbUrl}/auth/v1/token?grant_type=refresh_token`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon),
                body:    JSON.stringify({ refresh_token: STATE.sbRefreshToken }),
                timeout: 10_000,
                agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
            });
            const data = await resp.json();

            if (data.access_token) {
                STATE.sbAccessToken  = data.access_token;
                STATE.sbRefreshToken = data.refresh_token || STATE.sbRefreshToken;
                log("INFO", "SB_AUTH token refreshed", "");

                // Uložit aktualizovaný refresh token
                try {
                    const st      = loadState();
                    st.sb_refresh = STATE.sbRefreshToken;
                    saveState(st);
                } catch { /* nevadí */ }

                return STATE.sbAccessToken;
            }
        } catch (err) {
            log("WARN", "SB_AUTH refresh failed", String(err));
            STATE.sbAccessToken  = "";
            STATE.sbRefreshToken = "";
        }
    }

    // Fallback: přihlásit znovu jménem + heslem
    if (emailOrName && password && sbUrl && sbAnon) {
        const { ok } = await sbLogin(cfg, emailOrName, password);
        if (ok) return STATE.sbAccessToken;
    }

    log("WARN", "SB_AUTH", "Nelze získat token – jméno/heslo není nastaveno nebo je chybné");
    return "";
}

// ─── STORAGE OPERACE ─────────────────────────────────────────────────────────

/**
 * Vrátí seznam objektů ve složce job/ v bucketu.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} job
 * @returns {Promise<Array>}
 */
async function sbListObjects(cfg, bucket, job) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();

    try {
        const resp = await fetch(`${sbUrl}/storage/v1/object/list/${bucket}`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon),
            body:    JSON.stringify({ prefix: `${job}/`, limit: 100, offset: 0 }),
            timeout: 8_000,
        });
        return await resp.json();
    } catch (err) {
        log("WARN", "SB list error", String(err));
        return [];
    }
}

/**
 * Stáhne soubor ze Supabase Storage jako Buffer.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} filePath  – cesta uvnitř bucketu
 * @returns {Promise<Buffer>}
 */
async function sbDownload(cfg, bucket, filePath) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const token  = STATE.sbAccessToken || sbAnon;
    const url    = `${sbUrl}/storage/v1/object/${bucket}/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`;

    const resp = await fetch(url, {
        headers: _sbHeaders(sbAnon, token),
        timeout: 30_000,
    });
    if (!resp.ok) throw new Error(`SB download HTTP ${resp.status}`);
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Smaže soubor ze Supabase Storage po zpracování.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} filePath
 * @returns {Promise<void>}
 */
async function sbDelete(cfg, bucket, filePath) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const token  = STATE.sbAccessToken || sbAnon;

    // Správný Supabase Storage batch-delete endpoint:
    //   DELETE /storage/v1/object/{bucket}  body: { prefixes: [path] }
    // Dříve používaný DELETE /object/{bucket}/{path} je endpoint pro stahování.
    try {
        const resp = await fetch(`${sbUrl}/storage/v1/object/${bucket}`, {
            method:  "DELETE",
            headers: _sbHeaders(sbAnon, token),
            body:    JSON.stringify({ prefixes: [filePath] }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            log("WARN", "SB delete error", `HTTP ${resp.status}: ${filePath}`);
        }
    } catch (err) {
        log("WARN", "SB delete error", String(err));
    }
}

// ─── POLLER – pb_queue tabulka ───────────────────────────────────────────────

/**
 * Stáhne řádky z pb_queue kde done=false pro přihlášeného uživatele.
 * RLS politika zajišťuje izolaci – každý uživatel vidí jen svoje řádky.
 */
async function _getQueue(sbUrl, sbAnon, token) {
    // PostgREST: done=is.null  → done IS NULL
    //            done=eq.false → done = false
    //            done=or=(eq.false,is.null) → done = false OR done IS NULL
    //
    // Filtrujeme oba stavy aby řádky s default NULL nebyly přehlédnuté
    // (původní dotaz s pouze done=eq.false řádky s done IS NULL ignoroval).
    const url = `${sbUrl}/rest/v1/pb_queue`
        + `?or=(done.eq.false,done.is.null)`
        + `&order=id.asc`
        + `&limit=50`;

    const resp = await fetch(url, {
        headers: {
            ..._sbHeaders(sbAnon, token),
            Accept: "application/json",
        },
        timeout: 20_000,
    });
    if (!resp.ok) {
        const err = new Error(`HTTP ${resp.status}`);
        err.status = resp.status;
        throw err;
    }
    return resp.json();
}

/**
 * Označí řádek jako done=true.
 */
async function _markDone(sbUrl, sbAnon, token, rowId) {
    try {
        const resp = await fetch(`${sbUrl}/rest/v1/pb_queue?id=eq.${rowId}`, {
            method:  "PATCH",
            headers: {
                ..._sbHeaders(sbAnon, token),
                Prefer: "return=minimal",
            },
            body:    JSON.stringify({ done: true }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            log("WARN", "SB_POLLER mark_done", `HTTP ${resp.status} pro rowId=${rowId}`);
        }
    } catch (err) {
        log("WARN", "SB_POLLER mark_done", String(err));
    }
}

/**
 * Stáhne soubor ze Storage pomocí tokenu přihlášeného uživatele.
 */
async function _downloadWithToken(sbUrl, sbAnon, token, bucket, filePath) {
    const url = `${sbUrl}/storage/v1/object/${bucket}/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`;
    const resp = await fetch(url, {
        headers: _sbHeaders(sbAnon, token),
        timeout: 30_000,
    });
    if (!resp.ok) throw new Error(`Download HTTP ${resp.status}: ${filePath}`);
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Stáhne fotku z přímé URL (Cloudflare R2 / Worker). Posílá i Supabase JWT jako
 * Bearer – Worker ho může ověřit (doporučeno), podepsaná URL ho prostě ignoruje.
 * Tím PC umí OBOJÍ: download_url (R2) i Supabase Storage (fallback výše).
 */
async function _downloadFromUrl(url, token, anon) {
    const headers = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    if (anon)  headers.apikey = anon;
    const resp = await fetch(url, { headers, timeout: 30_000 });
    if (!resp.ok) throw new Error(`R2 download HTTP ${resp.status}: ${url}`);
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Smaže fotku z Cloudflare R2 přes Worker (DELETE /file?key=...).
 * downloadUrl je přímo URL Workeru, kterou telefon uložil do pb_queue.
 */
async function _deleteFromR2(downloadUrl, token) {
    try {
        const resp = await fetch(downloadUrl, {
            method:  "DELETE",
            headers: token ? { Authorization: `Bearer ${token}` } : {},
            timeout: 8_000,
        });
        if (!resp.ok && resp.status !== 404) {
            log("WARN", "R2 delete", `HTTP ${resp.status}: ${downloadUrl}`);
        }
    } catch (e) {
        log("WARN", "R2 delete error", String(e));
    }
}

/**
 * Úklid zpracovaného souboru: u R2 (download_url) maže z R2 přes Worker,
 * jinak ze Supabase Storage (starý formát / fotky bez download_url).
 */
async function _deleteConsumed(downloadUrl, sbUrl, sbAnon, token, bucket, filePath) {
    if (downloadUrl) {
        await _deleteFromR2(downloadUrl, token);
    } else {
        await _deleteWithToken(sbUrl, sbAnon, token, bucket, filePath);
    }
}

/**
 * Smaže soubor ze Storage pomocí tokenu přihlášeného uživatele.
 */
async function _deleteWithToken(sbUrl, sbAnon, token, bucket, filePath) {
    try {
        // Správný Supabase Storage delete endpoint s body { prefixes: [path] }
        const resp = await fetch(`${sbUrl}/storage/v1/object/${bucket}`, {
            method:  "DELETE",
            headers: _sbHeaders(sbAnon, token),
            body:    JSON.stringify({ prefixes: [filePath] }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            const txt = await resp.text().catch(() => '');
            log("WARN", "SB_POLLER delete", `HTTP ${resp.status}: ${filePath} — ${txt.slice(0, 120)}`);
        } else {
            log("DEBUG", "SB_POLLER delete OK", filePath);
        }
    } catch (err) {
        log("WARN", "SB_POLLER delete", String(err));
    }
}

/**
 * Vrátí unikátní cestu k výstupnímu souboru – přidá _2, _3 … pokud soubor existuje.
 *
 * @param {string} dir
 * @param {string} baseName   – bez přípony
 * @param {string} ext        – včetně tečky, např. ".png"
 */
/**
 * Vrátí cílovou složku pro firemní upload (kromě SP).
 *
 * Rozhodnutí přichází z **mobilní aplikace** – fotograf si v Nastavení zapne
 * „Ukládat do podsložky zakázky" a aplikace přidá do uploadové cesty segment
 * `__sub` (např. `{user_id}/{job}/__sub/{file}`). PC pak při detekci tohoto
 * markeru uloží fotku do podsložky `saveDir/{job}/`.
 *
 * SP (Scan poškození) se vždy ukládá přímo do `saveDir`, protože jde přes
 * malování (paint) a podsložka by mu rozbila pracovní tok.
 *
 * Pozn.: název složky se sanitizuje pro Windows-bezpečné znaky.
 */
function _resolveJobDir(saveDir, job, usesSubfolder, typ) {
    if (!usesSubfolder || !job) return saveDir;

    // V čekací složce (režim 'api') se podsložky nedělají. Fotka tam leží
    // jen do odeslání do zakázky a pak se maže – členění by nikomu nepomohlo
    // a technikovi, který si složku otevře z ukazatele, by jen přidalo klikání.
    try {
        const cek = require("./config").CEKAJICI_RTS_DIR;
        if (cek && path.resolve(saveDir).toLowerCase() === path.resolve(cek).toLowerCase()) {
            return saveDir;
        }
    } catch (_) {}
    // SP fotky vždy do hlavní SAVE_DIR (jak mspaint, tak vestavěný editor):
    //   1. paint.js přesouvá z paint_temp do finalPath po dokončení editace
    //   2. M:/Upload synchronizace bere fotky každou minutu - aby nepřišly
    //      do nějaké podsložky kterou tam M:/Upload nezná, SP jde do hlavní
    if (typ === "SP") return saveDir;

    const safe = String(job)
        .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
        .replace(/^[.\s]+|[.\s]+$/g, "")
        .slice(0, 120);
    if (!safe) return saveDir;

    const jobDir = path.join(saveDir, safe);
    try {
        fs.mkdirSync(jobDir, { recursive: true });
    } catch (e) {
        log("WARN", "SB_POLLER mkdir jobDir failed, fallback to saveDir", String(e));
        return saveDir;
    }
    return jobDir;
}

function _uniquePath(dir, baseName, ext) {
    let out = path.join(dir, `${baseName}${ext}`);
    let n   = 2;
    while (fs.existsSync(out)) {
        out = path.join(dir, `${baseName}_${n}${ext}`);
        n++;
    }
    return out;
}

/**
 * Cesta k paint_temp složce – musí odpovídat paint.js PAINT_TEMP_DIR.
 * Skenuje se zde, aby se _nextLetter započítal i soubory čekající v Paintu.
 */
// Musí ukazovat na STEJNOU složku jako paint.js, jinak by sken hledal jinde,
// než kam se soubory ukládají, a písmena v názvech by se opakovala.
const _PAINT_TEMP_DIR_FOR_SCAN = require("./config").resolvePaintTempDir();

/**
 * Persistentní počítadlo písmen pro každou kombinaci (job, typ).
 * Klíč: `${typ}|${job}` → poslední použitý charCode.
 * Načítá se ze state.json a ukládá při každé změně, takže přežije restart.
 */
const _letterCounters = new Map();
let _letterCountersLoaded = false;

/**
 * Při prvním volání načte uložené čítače ze state.json (klíč pb_letter_counters).
 */
function _initLetterCountersFromState() {
    if (_letterCountersLoaded) return;
    _letterCountersLoaded = true;
    try {
        const st = loadState();
        const stored = st.pb_letter_counters || {};
        for (const [k, v] of Object.entries(stored)) {
            if (typeof v === "number") _letterCounters.set(k, v);
        }
    } catch { /* nevadí */ }
}

/**
 * Uloží aktuální stav čítačů zpět do state.json.
 */
function _saveLetterCounters() {
    try {
        const st = loadState();
        const out = {};
        for (const [k, v] of _letterCounters.entries()) out[k] = v;
        st.pb_letter_counters = out;
        saveState(st);
    } catch { /* nevadí */ }
}

/**
 * Naskenuje danou složku a vrátí nejvyšší charCode písmena pro daný (job, typ).
 * X (charCode 88) je rezervované pro SD_X (typ=SDX) a ignoruje se.
 * Vrací 64 ('A' - 1) pokud nic nenajde – další písmeno bude tedy A.
 */
function _scanDirForMaxLetter(dir, job, typ) {
    let maxCode = 64;
    try {
        const files = fs.readdirSync(dir);
        const prefix = `${typ}_${job}`;
        for (const f of files) {
            if (!f.startsWith(prefix)) continue;
            const rest = f.slice(prefix.length); // např. "A.png" nebo "B_2.png"
            if (rest.length > 0 && /^[A-Z]/.test(rest)) {
                const code = rest.charCodeAt(0);
                if (code === 88) continue; // přeskoč X (SD_X má vlastní typ)
                if (code > maxCode) maxCode = code;
            }
        }
    } catch { /* složka neexistuje nebo jiná chyba */ }
    return maxCode;
}

/**
 * Vrátí další volné písmeno (A–Z bez X) pro danou kombinaci (job, typ).
 *
 * Strategie:
 *   1. Pokud máme v paměti persistentní counter pro (job, typ), použij ho.
 *   2. Jinak ho inicializuj jako MAX z (saveDir, paint_temp) – tj. zahrnuje
 *      i soubory, které stále čekají v Paint frontě a ještě nejsou v saveDir.
 *   3. Inkrementuj, přeskoč X, při překročení Z se vrať na A
 *      (_uniquePath dál doplní _2, _3 pokud by reálně vznikla kolize).
 *   4. Ulož counter do state.json – přežije restart aplikace pro stejnou zakázku.
 *
 * Tím se opravuje bug, kdy několik fotek SP_/SD_/VT_ rychle za sebou
 * dostalo všechny stejné písmeno A a přepsaly se navzájem.
 */
function _nextLetter(saveDir, job, typ) {
    _initLetterCountersFromState();
    const key = `${typ}|${job}`;
    let last = _letterCounters.get(key);

    if (last == null) {
        // První soubor pro tento (job, typ) – inicializuj scanováním obou složek
        const codeSave  = _scanDirForMaxLetter(saveDir, job, typ);
        const codePaint = _scanDirForMaxLetter(_PAINT_TEMP_DIR_FOR_SCAN, job, typ);
        last = Math.max(codeSave, codePaint, 64); // 64 = 'A' - 1
    }

    // Inkrementuj na další písmeno, přeskoč X
    let next = last + 1;
    if (next === 88) next = 89; // X (88) → Y (89)
    if (next > 90)   next = 65; // za Z (90) zpět na A (65)

    _letterCounters.set(key, next);
    _saveLetterCounters();

    return String.fromCharCode(next);
}

/**
 * Převede buffer (libovolný obrázek) na PNG Buffer pomocí sharp.
 * @param {Buffer} raw
 * @returns {Promise<Buffer>}
 */
async function _toPng(raw) {
    const sharp = require("sharp"); // lazy – nativní modul, nesmí blokovat load
    // .rotate() BEZ PARAMETRU = srovnej podle EXIF a značku zahoď.
    //
    // PROČ TO TU MUSÍ BÝT
    // PNG formát EXIF nemá. Bez .rotate() se převodem ztratí informace
    // o natočení a v souboru zůstanou surové pixely ze snímače telefonu –
    // fotka je pak v editoru i v zakázce vzhůru nohama.
    //
    // Editor se pak chová správně: přečte EXIF, žádný nenajde, usoudí
    // „nic neotáčet" a vezme obraz tak, jak je.
    //
    // Stejné volání je i v image-limit.js (řádek 80) – tam to někdo řešil,
    // jen se to nedostalo sem, kudy chodí fotky z mobilu.
    return sharp(raw).rotate().png().toBuffer();
}

/**
 * Zmenší PNG pokud přesahuje maxMb megabajtů.
 * Iterativně snižuje kvalitu/rozlišení dokud soubor nepasuje.
 *
 * @param {Buffer} pngBuf
 * @param {number} maxMb
 * @returns {Promise<Buffer>}
 */
async function _shrinkPng(pngBuf, maxMb) {
    const maxBytes = maxMb * 1024 * 1024;
    if (pngBuf.length <= maxBytes) return pngBuf;

    const sharp = require("sharp"); // lazy – nativní modul, nesmí blokovat load
    let img    = sharp(pngBuf);
    const meta = await img.metadata();
    let w      = meta.width  || 4000;
    let h      = meta.height || 3000;

    // Postupně zmenšuj o 20 % dokud nepasuje nebo šířka < 800 px
    while (true) {
        w = Math.floor(w * 0.8);
        h = Math.floor(h * 0.8);
        const buf = await sharp(pngBuf).resize(w, h, { fit: "inside" }).png().toBuffer();
        if (buf.length <= maxBytes || w < 800) return buf;
        pngBuf = buf; // zkus menší
    }
}

/**
 * Extrahuje sortovací klíč z názvu souboru, aby fronta zpracování zachovala
 * pořadí cvaknutí spouště v mobilu i při paralelních uploadech.
 *
 * Mobil generuje názvy:
 *   firemní:  "SP_4567895_1777903239672_001.jpg"
 *               typ_zakázka_batchTs_seq.ext
 *   osobní:   "20260504_135938_001.jpg"
 *               YYYYMMDD_HHMMSS_seq.ext
 *
 * Sort key = batchTs * 1000 + seq pro firemní; YYYYMMDDHHMMSS * 1000 + seq pro osobní.
 * Pro starší soubory bez _seq vrací prostě timestamp.
 */
function _sortKeyFromFilePath(filePath) {
    const name = (filePath || "").split("/").pop();
    const dotIdx = name.lastIndexOf(".");
    const base = dotIdx >= 0 ? name.slice(0, dotIdx) : name;
    // Strip _PAINT suffix
    const cleanBase = base.replace(/_PAINT$/, "");
    const parts = cleanBase.split("_");
    if (parts.length === 0) return 0;

    // Poslední část by měla být _seq (3 číslice)
    const last = parts[parts.length - 1];
    let seq = 0;
    let tsPart = cleanBase;
    if (/^\d{1,3}$/.test(last)) {
        seq = parseInt(last, 10);
        tsPart = parts.slice(0, -1).join("_");
    }
    // Najdi numerickou složku (timestamp)
    const tsMatches = tsPart.match(/(\d{10,})/);
    if (tsMatches) {
        return parseInt(tsMatches[1], 10) * 1000 + seq;
    }
    // Fallback: osobní formát YYYYMMDD_HHMMSS
    const dateMatches = tsPart.match(/(\d{8})_(\d{6})/);
    if (dateMatches) {
        return parseInt(dateMatches[1] + dateMatches[2], 10) * 1000 + seq;
    }
    return 0;
}

/**
 * Přidá soubor do fronty zpracování. Spustí processor pokud neběží.
 * Cfg/saveDir/sbCtx/tok jsou potřeba, použijeme je až ve worker funkci.
 */
function _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId, downloadUrl = null, force = false, rtsSent = false) {
    // force=true → záchranný retry uvízlých fotek: _pollerSeen se ignoruje,
    // protože soubor už jednou "viděn" byl, ale do zakázky nedorazil.
    if (force && filePath) _pollerSeen.delete(filePath);
    if (!filePath || _pollerSeen.has(filePath)) {
        // POZOR – tady vznikala ztráta fotek.
        // Dřív se řádek označil jako hotový vždycky, i když se fotka teprve
        // zpracovávala. Když zpracování pak selhalo, řádek už byl done=true
        // a nikdy se nezopakoval → soubor zůstal v R2 a do zakázky nedorazil.
        // Nově se označuje jen to, co se OPRAVDU uložilo na disk.
        if (rowId && filePath && _pollerHotovo.has(filePath)) {
            sbEnsureToken(cfg).then(tok => {
                if (tok) _markDone(sbUrl, sbAnon, tok, rowId).catch(() => {});
            }).catch(() => {});
        }
        return;
    }
    _pollerSeen.add(filePath);
    // Přišla fotka → technik pracuje. Drž rychlý dotazovací režim,
    // ať další fotky nečekají na minutový interval.
    _posledniAktivita = Date.now();
    try { _prenastavPoller(cfg, saveDir); } catch (_) {}

    _processQueue.push({ cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId, downloadUrl, rtsSent });
    // Seřaď podle sortKey – starší (menší) první. Tím SP_xxx_1234_001 dostane
    // písmeno A, SP_xxx_1234_002 písmeno B, atd. Funguje i pro mix batchů.
    _processQueue.sort((a, b) => _sortKeyFromFilePath(a.filePath) - _sortKeyFromFilePath(b.filePath));
    _runProcessQueue();
}

/**
 * Worker, který sériově zpracuje jeden soubor po druhém z _processQueue.
 * Zaručuje:
 *   - správné pořadí písmen (_nextLetter dostane volání postupně)
 *   - sériové otevírání Malování (paint-window otevírá max 1 instance)
 */
async function _runProcessQueue() {
    if (_processRunning) return;
    _processRunning = true;
    try {
        while (_processQueue.length > 0 && _pollerActive) {
            const job = _processQueue.shift();
            const tok = await sbEnsureToken(job.cfg);
            if (!tok) {
                // Token expirovaný – vrať položku zpět a počkej na další tick
                _processQueue.unshift(job);
                _pollerSeen.delete(job.filePath);
                break;
            }
            try {
                await _processFilePath(
                    job.cfg, job.saveDir, job.sbUrl, job.sbAnon, tok, job.sbBucket,
                    job.filePath, job.rowId, job.downloadUrl, job.rtsSent === true,
                );
            } catch (err) {
                log("ERROR", "SB_QUEUE process", `${job.filePath}: ${err}`);
            }
        }
    } finally {
        _processRunning = false;
    }
}

/**
 * Přenastaví interval dotazů podle toho, jestli běží websocket.
 *
 * Připojený websocket = fotky chodí push zprávou okamžitě, dotaz je jen
 * záchranná síť pro případ, že push nedorazí. Stačí tedy á minutu a ušetří
 * to ~95 % egressu. Spadlý websocket = dotaz je jediná cesta, zrychlit.
 */
function _prenastavPoller(cfg, saveDir) {
    if (!_pollerActive || !_pollerTimer) return;

    // Spadlý websocket = dotaz je jediná cesta, vždy rychle.
    // Jinak: rychle po dobu, kdy se pracuje; v klidu pomalu.
    const pracujeSe = (Date.now() - _posledniAktivita) < AKTIVNI_PO_MS;
    const chtene = (!_pollSlowMode || pracujeSe) ? POLL_MS_ACTIVE : POLL_MS_IDLE;
    if (_pollerIntervalMs === chtene) return;

    clearInterval(_pollerTimer);
    _pollerIntervalMs = chtene;
    _pollerTimer = setInterval(() => _pollerTick(cfg, saveDir), chtene);
    const duvod = !_pollSlowMode ? "websocket spadlý"
                : (chtene === POLL_MS_ACTIVE ? "právě se nahrává" : "klid, šetříme egress");
    log("INFO", "SB_POLLER", `Interval dotazů → ${Math.round(chtene / 1000)} s (${duvod})`);
}

/**
 * Hlavní smyčka polleru – volaná přes setInterval.
 * Stahuje VŠE pro přihlášený účet:
 *   1. Primárně z pb_queue tabulky (rychlé, přesné)
 *   2. Každých 10 ticků fallback scan Storage (řeší selhané pb_queue inserty)
 */
async function _pollerTick(cfg, saveDir) {
    if (!_pollerActive) return;

    // Po odmlce se vrať k pomalému dotazování. Kontroluje se tady, protože
    // tick běží pravidelně – jinak by rychlý režim zůstal viset navždy.
    try { _prenastavPoller(cfg, saveDir); } catch (_) {}

    // Pojistka: přesun offline-uložených fotek do SAVE_DIR, jakmile je zase dostupný
    await _flushPendingSaveDir();

    const sbUrl    = _sbUrl(cfg);
    const sbAnon   = (cfg.SB_ANON    || "").trim();
    const sbBucket = (cfg.SB_BUCKET  || "pb-uploads").trim();

    try {
        // Obnov token pokud expiroval
        const tok = await sbEnsureToken(cfg);
        if (!tok) return;

        // ── 1) Primární cesta: pb_queue ─────────────────────────────────────
        let rows;
        try {
            rows = await _getQueue(sbUrl, sbAnon, tok);
        } catch (err) {
            if (err.status === 401 || err.status === 403) {
                log("WARN", "SB_POLLER", `HTTP ${err.status} z pb_queue – čistím token`);
                STATE.sbAccessToken = "";
            } else if (String(err).includes("timeout") || String(err).includes("network")) {
                log("DEBUG", "SB_POLLER", `queue timeout (${String(err).split("\n")[0]})`);
            } else {
                log("WARN", "SB_POLLER queue error", String(err));
            }
            // i když pb_queue selže, zkus alespoň fallback scan níže
            rows = [];
        }

        for (const row of rows) {
            if (!_pollerActive) break;
            const rowId       = row.id;
            const filePath    = row.file_path || "";
            const downloadUrl = row.download_url || null;   // R2/Worker URL (když ji telefon nastaví)
            // rts_sent=true → fotku do zakázky už poslal mobil, PC ji tam neposílá znovu
            const rtsSent     = row.rts_sent === true;
            // Místo přímého _processFilePath dáme do fronty – worker zpracuje
            // sériově a v pořadí podle sortKey (zachová pořadí cvaknutí spouště).
            _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId, downloadUrl, false, rtsSent);
        }

        // ── 1b) Záchranný retry fotek uvízlých v R2 (>23 h) ───────────────
        // Běží max. jednou za 30 min, takže poller nezatěžuje.
        await _retryStuckR2(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket);

        // ── 2) Fallback Storage scan – řeší osiřelé soubory ────────────────
        // Orphan = mobil nahrál do Storage, ale pb_queue insert selhal → žádný
        // Realtime event nikdy nepřijde, najde to jedině scan Storage.
        //   • Pomalý režim (WS připojen): scan KAŽDÝ tick (= á 2 min) – levné.
        //   • Rychlý režim (WS spadlý):   scan každých 10 ticků jako dřív.
        // R2 MIGRACE (v3.1.29): mobil už nahrává do Cloudflare R2, ne do Supabase
        // Storage → scénář "osiřelý soubor ve Storage" nemůže nastat a fallback
        // sken Storage jen plýtval requesty. Vypnuto. Doručování fotek (pb_queue
        // poll á 3 s + Realtime push) zůstává beze změny.
        // if (_pollSlowMode) {
        //     await _fallbackStorageScan(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket);
        // } else {
        //     _pollerTickCount = (_pollerTickCount + 1) % 90;
        //     if (_pollerTickCount === 0) {
        //         await _fallbackStorageScan(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket);
        //     }
        // }

    } catch (err) {
        log("WARN", "SB_POLLER loop error", String(err));
    }
}

/**
 * Fallback: naskenuje Storage bucket a najde soubory které nejsou v _pollerSeen.
 * Volá se každých 10 ticků (≈5 s). Řeší scénář kdy pb_queue insert na mobilu
 * selhal a soubor zůstal v Storage osamocený.
 *
 * Skenuje:
 *   - personal/  složku (osobní fotky)
 *   - všechny {číslo zakázky}/  složky
 */
async function _fallbackStorageScan(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket) {
    try {
        const userId = STATE.sbUserId || "";

        // 1) Vylistuj kořen bucketu – dostaneme všechny složky (NOVÝ formát:
        //    pouze {user_id}, STARÝ formát: jobs + personal). Storage RLS nás
        //    omezí jen na naše soubory tak jako tak, ale listing kořene vrátí
        //    všechny vlastníkovy složky.
        //
        //    Když ale máme user_id, můžeme rovnou listovat {user_id}/ a získat
        //    seznam podsložek (personal, 1234567, …) – efektivnější.
        const folderNames = [];

        if (userId) {
            // NOVÝ formát: vylistuj {user_id}/ a získej podsložky
            const myResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon, tok),
                body:    JSON.stringify({ prefix: `${userId}/`, limit: 200, offset: 0 }),
                timeout: 8_000,
                agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
            });
            if (myResp.ok) {
                const items = await myResp.json();
                if (Array.isArray(items)) {
                    for (const it of items) {
                        if (it && it.name && (it.id === null || it.id === undefined)) {
                            folderNames.push(`${userId}/${it.name}`);
                        }
                    }
                }
            }
        }

        // 2) Také zkusíme STARÝ formát (kořen bucketu) – Storage RLS odfiltruje
        //    cizí soubory; vlastní staré soubory ještě nahnijí dokud RETENTION_DAYS
        //    je nesmažo.
        const rootListResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon, tok),
            body:    JSON.stringify({ prefix: "", limit: 200, offset: 0 }),
            timeout: 8_000,
            agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
        });
        if (rootListResp.ok) {
            const rootItems = await rootListResp.json();
            if (Array.isArray(rootItems)) {
                for (const it of rootItems) {
                    if (it && it.name && (it.id === null || it.id === undefined)) {
                        // Vyloučíme {user_id} (už jsme listovali výše) – aby
                        // se neopakovalo pod novým formátem
                        if (it.name !== userId) {
                            folderNames.push(it.name);
                        }
                    }
                }
            }
        }

        if (folderNames.length === 0) return;

        let foundCount = 0;
        for (const folder of folderNames) {
            if (!_pollerActive) break;

            // Vylistuj obsah složky
            const folderResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon, tok),
                body:    JSON.stringify({ prefix: `${folder}/`, limit: 100, offset: 0 }),
                timeout: 8_000,
                agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
            });
            if (!folderResp.ok) continue;
            const items = await folderResp.json();
            if (!Array.isArray(items)) continue;

            for (const it of items) {
                if (!_pollerActive) break;
                // Jen reálné soubory (id !== null), s názvem
                if (!it || !it.name || it.id === null || it.id === undefined) continue;
                const filePath = `${folder}/${it.name}`;
                if (_pollerSeen.has(filePath)) continue;

                log("INFO", "SB_POLLER fallback found", `${filePath} (chybí v pb_queue)`);
                foundCount++;
                // Zpracuj přes frontu (rowId=null = nemažeme z queue, jen ze Storage)
                _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, null);
            }
        }

        if (foundCount > 0) {
            log("INFO", "SB_POLLER fallback scan", `zpracováno ${foundCount} souborů ze Storage`);
        }
    } catch (err) {
        log("DEBUG", "SB_POLLER fallback scan err", String(err));
    }
}

// ── ZÁCHRANNÝ RETRY UVÍZLÝCH FOTEK V R2 ─────────────────────────────────────
// Scénář: fotka se nahrála do R2, ve frontě se (i omylem) označila jako done,
// ale do zakázky nikdy nedošla – soubor zůstal v R2. Denní hlídač na to
// upozorní až po 24 h. Tohle to zkusí doručit SAMO po RETRY_STUCK_HOURS
// hodinách, tedy ještě než upozornění odejde.
//
// Klíčový trik: doručená fotka se z R2 MAŽE. Když tam soubor po 23 h pořád je,
// znamená to, že doručení neproběhlo → stáhneme ho znovu. (Pokud se náhodou
// jen nepovedlo mazání a fotka v zakázce už je, vznikne duplicita – to je
// vědomě přijaté: chybějící fotka je horší než fotka dvakrát.)
const RETRY_STUCK_HOURS   = 23;
const RETRY_CHECK_EVERY_MS = 30 * 60 * 1000;   // kontrolovat jednou za půl hodiny
let _lastStuckCheck = 0;

async function _retryStuckR2(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket) {
    if (Date.now() - _lastStuckCheck < RETRY_CHECK_EVERY_MS) return;
    _lastStuckCheck = Date.now();
    try {
        const cutoff = new Date(Date.now() - RETRY_STUCK_HOURS * 3600 * 1000).toISOString();
        // POZOR NA done=is.false
        // Do v3.3.30 tahle podmínka CHYBĚLA – braly se prostě nejnovější
        // řádky starší než 23 h bez ohledu na to, že už jsou uzavřené.
        // Kontrola tak každou půlhodinu prošla těch samých padesát fotek,
        // na každou poslala dotaz do úložiště a znovu je „uzavírala".
        // V logu to vypadalo, že se něco děje pořád dokola – a taky ano.
        //
        // is.false (ne eq.false) chytá i řádky, kde je done NULL.
        const url = `${sbUrl}/rest/v1/pb_queue`
            + `?done=is.false`
            + `&created_at=lt.${encodeURIComponent(cutoff)}`
            + `&download_url=not.is.null`
            + `&order=id.desc&limit=50`;
        const resp = await fetch(url, {
            headers: { ..._sbHeaders(sbAnon, tok), Accept: "application/json" },
            timeout: 20_000,
        });
        if (!resp.ok) return;
        const rows = await resp.json();
        if (!Array.isArray(rows) || !rows.length) return;

        let retried = 0;
        for (const row of rows) {
            if (!_pollerActive) break;
            const filePath    = row.file_path || "";
            const downloadUrl = row.download_url || null;
            if (!filePath || !downloadUrl) continue;

            // Existuje soubor v R2 ještě? Když ano → nedoručeno, zkusíme znovu.
            let stillThere = false;
            try {
                const head = await fetch(downloadUrl, {
                    method: "HEAD",
                    headers: tok ? { Authorization: `Bearer ${tok}` } : {},
                    timeout: 10_000,
                });
                stillThere = head.ok;
            } catch (_) { continue; }   // síť neodpovídá → zkusíme příští kolo

            if (!stillThere) {
                // Soubor v úložišti není – doručeno a uklizeno, nebo stažen
                // ručně. Držet takový řádek jako nezpracovaný nemá smysl:
                // není co stáhnout a jen by strašil v přehledu front
                // a v ranním e-mailu o uvízlých fotkách.
                if (row.id) {
                    // Chyba uzavření se dřív ztrácela v prázdném catch –
                    // řádek pak zůstal otevřený a hlásil se pořád dokola.
                    await _markDone(sbUrl, sbAnon, tok, row.id)
                        .catch(e => log("WARN", "SB_RETRY_STUCK",
                            `Řádek ${row.id} nelze uzavřít: ${e.message}`));
                    log("INFO", "SB_RETRY_STUCK",
                        `${filePath} už v úložišti není – uzavírám řádek`);
                }
                continue;
            }

            log("WARN", "SB_RETRY_STUCK",
                `${filePath} je v R2 déle než ${RETRY_STUCK_HOURS} h → zkouším doručit znovu`);
            _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, row.id, downloadUrl, true);
            retried++;
        }
        if (retried) log("INFO", "SB_RETRY_STUCK", `Znovu zařazeno ${retried} uvízlých fotek`);
    } catch (e) {
        log("DEBUG", "SB_RETRY_STUCK err", String(e).split("\n")[0]);
    }
}

/**
 * Zpracuje jeden filePath ze Supabase Storage – stáhne, přejmenuje, uloží,
 * smaže ze Storage a (pokud byl z pb_queue) označí řádek jako done.
 *
 * @param {string|null} rowId  – id řádku v pb_queue, nebo null pokud přišlo z fallback scanu
 */
async function _processFilePath(cfg, _saveDirCaptured, sbUrl, sbAnon, tok, sbBucket, filePath, rowId, downloadUrl = null, rtsAlreadySent = false) {
    _pollerSeen.add(filePath);
    const maxImgMb = STATE.maxImgMb || 8;

    // ── SAVE_DIR LIVE READ (v3.0.2 s diagnostikou) ─────────────────────────
    // Záměrně NEPOUŽÍVÁME _saveDirCaptured (parametr) – ten je zachycen v
    // closure pollerTimer/WebSocket handleru a v _processQueue jobech.
    // Když uživatel změní cílovou složku za běhu (ipc:config:set v main.js
    // NEBO app:ensure-save-dir), hodnoty v closure zůstanou STARÉ.
    //
    // Fallback chain (v pořadí priority):
    //   1. STATE.saveDir       – aktualizováno main.js při změně přes Nastavení
    //   2. cfg.SAVE_DIR        – čerstvě načtené z config.json (chytá app:ensure-save-dir)
    //   3. _saveDirCaptured    – původní zachycená hodnota (legacy fallback)
    let _freshCfgSaveDir = '';
    try {
        _freshCfgSaveDir = (require("./config").readConfig().SAVE_DIR || '').trim();
    } catch (_) {}
    const saveDirCfg = (STATE.saveDir || _freshCfgSaveDir || _saveDirCaptured || '').trim();

    // ── Kam se fotka uloží ───────────────────────────────────────────────
    // V režimu 'api' (UploadScan vypnutý) se neukládá do sdílené složky, ale
    // do čekací složky v userData. Odtud ji vyzvedne api-upload a po odeslání
    // do zakázky ji smaže. Názvy zůstávají stejné jako na M:\UploadScan –
    // api-upload z nich čte číslo zakázky i typ dokumentu.
    let saveDir = saveDirCfg;
    let jenRts  = false;
    try {
        const au = require("./api-upload");
        if (!au.isDiskEnabled()) {
            saveDir = require("./config").CEKAJICI_RTS_DIR;
            jenRts  = true;
        }
    } catch (_) { /* při chybě zůstává původní chování – ukládání na disk */ }

    // DIAGNOSTICKÝ LOG – pomáhá identifikovat zda STATE.saveDir nebo cfg byly aktuální
    log("DEBUG", "SB_SAVEDIR_TRACE",
        `state="${STATE.saveDir || ''}" cfg="${_freshCfgSaveDir}" captured="${_saveDirCaptured || ''}" → použito="${saveDir}"${jenRts ? ' (režim api – čekací složka)' : ''}`);

    if (!saveDir) {
        log("ERROR", "SB_POLLER", `SAVE_DIR prázdné při zápisu ${filePath} – přeskakuji`);
        _pollerSeen.delete(filePath);
        return;
    }

    // ── Rozpoznání path schema ──────────────────────────────────────────
    // NOVÝ formát (Cesta 1):  {user_id}/personal/{name}        nebo  {user_id}/{job}/{name}
    // STARÝ formát (Cesta 2): personal/{name}                  nebo  {job}/{name}
    //
    // Detekce: pokud první segment vypadá jako UUID (36 znaků s pomlčkami),
    // jde o nový formát a první segment přeskočíme. Jinak starý formát.
    const segments = filePath.split("/");
    let workPath = filePath;
    const UUID_RE = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    if (segments.length >= 2 && UUID_RE.test(segments[0])) {
        // Odstraň user_id prefix – zbytek logiky pracuje s "logickou" cestou
        // (personal/... nebo {job}/...) a nezáleží na nové vrstvě bezpečnosti.
        workPath = segments.slice(1).join("/");
    }

    const isPersonal = workPath.startsWith("personal/");
    const name       = workPath.split("/").pop();
    const dotIdx     = name.lastIndexOf(".");
    const extOrig    = dotIdx >= 0 ? name.slice(dotIdx).toLowerCase() : ".jpg";
    const base       = dotIdx >= 0 ? name.slice(0, dotIdx) : name;

    log("INFO", "SB_POLLER process", `${filePath} personal=${isPersonal} src=${rowId ? "queue" : "storage-scan"}`);

    // ── Osobní fotky s RTS nemají nic společného ─────────────────────────
    // Osobní účet nemá číslo zakázky a do servisu nic neposílá – aplikaci
    // tak jde použít i doma, kde žádné RTS není a jediné, co se čeká, je
    // uložení fotky do zvolené složky.
    //
    // Bez téhle výjimky by v režimu 'api' osobní fotka skončila v čekací
    // složce, RTS by ji bez zakázky odmítl a soubor by tam zůstal navždy –
    // ukazatel by ho počítal jako čekající a uživatel by o fotku přišel.
    if (isPersonal && jenRts) {
        saveDir = saveDirCfg;
        if (!saveDir) {
            log("ERROR", "SB_POLLER",
                `Osobní fotka a SAVE_DIR prázdné – ${filePath} nelze uložit`);
            _pollerSeen.delete(filePath);
            return;
        }
        jenRts = false;   // ať se nepřeskočí ani pojistka pro nedostupný disk
        log("INFO", "SB_POLLER",
            `Osobní fotka – ukládám do zvolené složky, do zakázky se neposílá`);
    }

    // ── Fotku už doručil mobil a disk se nepoužívá → PC nemá co dělat ────
    // V režimu 'api' by stažení nedávalo smysl: fotka je v zakázce, ukládat
    // ji není kam a _apiEnqueue se kvůli rtsAlreadySent přeskočí. Skončila by
    // tedy v čekací složce, odkud by ji nikdo neodeslal ani nesmazal.
    //
    // V režimech 'disk' a 'both' se stahuje dál – tam je cílová složka archiv
    // a patří do ní i to, co mobil poslal napřímo.
    if (jenRts && rtsAlreadySent) {
        log("INFO", "SB_POLLER",
            `Přeskočeno – do zakázky poslal fotku mobil a disk se nepoužívá: ${filePath}`);
        _pollerHotovo.add(filePath);
        if (rowId) {
            try { await _markDone(sbUrl, sbAnon, tok, rowId); } catch (_) {}
        }
        try {
            await _deleteConsumed(downloadUrl, sbUrl, sbAnon, tok, sbBucket, filePath);
        } catch (_) {}
        _pollerSeen.delete(filePath);
        return;
    }

    // Stáhni soubor – z R2/Workeru (download_url), jinak ze Supabase Storage
    let raw;
    try {
        if (downloadUrl) {
            raw = await _downloadFromUrl(downloadUrl, tok, sbAnon);
        } else {
            raw = await _downloadWithToken(sbUrl, sbAnon, tok, sbBucket, filePath);
        }
    } catch (err) {
        log("ERROR", "SB_POLLER download", String(err));
        _pollerSeen.delete(filePath);
        return;
    }

    // wentToPaint = soubor putuje do Malování (uživatel ho dotvoří) → notifikaci
    // pošleme až po zavření Malování (paint.js to udělá), NE teď.
    let outPath = null;
    let wentToPaint = false;

    // ── POJISTKA: SAVE_DIR nedostupný (např. M: není namapovaný) ──────────
    // Když je cílová složka v configu, ale fyzicky nedostupná, NEzůstávej viset
    // v Supabase. Ulož bajty lokálně do _pending_savedir, smaž ze Storage
    // (uvolní bucket) a přesuň po obnově přístupu (_flushPendingSaveDir).
    //
    // V režimu 'api' se tahle větev přeskakuje. Čekací složka je v userData,
    // takže nedostupná být nemůže – a hlavně: _pending_savedir čeká na DISK,
    // ne na RTS. Fotka by se tam zasekla, i kdyby RTS mezitím naběhlo.
    if (!jenRts && !_isSaveDirAccessible(saveDir)) {
        try {
            _stagePending(filePath, raw);
            if (rowId) await _markDone(sbUrl, sbAnon, tok, rowId);
            await _deleteConsumed(downloadUrl, sbUrl, sbAnon, tok, sbBucket, filePath);
            log("WARN", "SB_POLLER SAVE_DIR nedostupný",
                `${filePath} → uloženo do _pending_savedir, přesunu po obnově přístupu`);
        } catch (e) {
            log("ERROR", "SB_POLLER stage-pending", String(e));
            _pollerSeen.delete(filePath);
        }
        return;
    }

    try {
        const res = await _finalizeToDisk(saveDir, filePath, raw, maxImgMb);
        outPath     = res.outPath;
        wentToPaint = res.wentToPaint;
        // Fotky BEZ editace posílej rovnou do API servisu (fotky do Malování
        // pošle paint.js až po zavření editoru – jinak by šla neupravená verze)
        // Fotku, kterou do zakázky poslal už mobil (rts_sent), PC neposílá znovu
        // – jinak by v zakázce byla dvakrát. Fotky do Malování posílá vždy PC
        // (až po úpravě), proto se sem s wentToPaint=true nedostanou.
        if (!wentToPaint && outPath && !rtsAlreadySent && !isPersonal) _apiEnqueue(outPath);
        else if (rtsAlreadySent) log("INFO", "API_UPLOAD", `Přeskočeno – do zakázky už poslal mobil: ${require("path").basename(outPath || filePath)}`);
        else if (isPersonal) log("INFO", "API_UPLOAD", `Osobní fotka – do zakázky se neposílá: ${require("path").basename(outPath || filePath)}`);

        // Uložení proběhlo → teprve teď se smí potvrdit
        _pollerHotovo.add(filePath);

        // Potvrdit zpracování a smazat ze Storage
        if (rowId) {
            await _markDone(sbUrl, sbAnon, tok, rowId);
        }
        await _deleteConsumed(downloadUrl, sbUrl, sbAnon, tok, sbBucket, filePath);

        // Oznámit renderu nový soubor
        _notifyRenderer(outPath);

        // Windows notifikace – jen pro soubory, které NEJDOU do Malování.
        if (!wentToPaint && outPath) {
            _enqueueNotification(outPath);
        }

    } catch (err) {
        // Backstop: zápis selhal ztrátou přístupu k SAVE_DIR uprostřed (M: odpojen)
        const msg = String(err);
        if (/ENOENT|EACCES|EPERM|ENODEV|ENXIO|EBUSY|network/i.test(msg) && !_isSaveDirAccessible(saveDir)) {
            try {
                _stagePending(filePath, raw);
                if (rowId) await _markDone(sbUrl, sbAnon, tok, rowId);
                await _deleteConsumed(downloadUrl, sbUrl, sbAnon, tok, sbBucket, filePath);
                log("WARN", "SB_POLLER SAVE_DIR ztracen při zápisu",
                    `${filePath} → uloženo do _pending_savedir (${msg.split("\n")[0]})`);
            } catch (e2) {
                log("ERROR", "SB_POLLER stage-pending(backstop)", String(e2));
            }
        } else {
            log("ERROR", "SB_POLLER process", `${filePath}: ${err}`);
            // Uvolnit, ať se fotka zkusí při dalším kole znovu. Bez tohohle
            // zůstala navždy v _pollerSeen a už se o ni nikdo nepokusil.
            _pollerSeen.delete(filePath);
        }
    }
}

/**
 * Uloží PNG do dočasné Paint složky (sleduje ji paint.js).
 * Pokud paint.js není k dispozici, uloží soubor přímo.
 *
 * @param {string} finalPath  – konečná cesta (bez přípony _tmp)
 * @param {Buffer} png
 */
/**
 * Zapíše stažené bajty na disk do SAVE_DIR (firemní/osobní logika, paint, číslování).
 * Sdílí ji živé zpracování i _flushPendingSaveDir (přesun po obnově přístupu).
 * Vrací { outPath, wentToPaint }. Při selhání zápisu vyhazuje.
 */
async function _finalizeToDisk(saveDir, filePath, raw, maxImgMb) {
    const segments = filePath.split("/");
    let workPath = filePath;
    const UUID_RE = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    if (segments.length >= 2 && UUID_RE.test(segments[0])) {
        workPath = segments.slice(1).join("/");
    }
    const isPersonal = workPath.startsWith("personal/");
    const name       = workPath.split("/").pop();
    const dotIdx     = name.lastIndexOf(".");
    const extOrig    = dotIdx >= 0 ? name.slice(dotIdx).toLowerCase() : ".jpg";
    const base       = dotIdx >= 0 ? name.slice(0, dotIdx) : name;

    let outPath;
    let wentToPaint = false;

    fs.mkdirSync(saveDir, { recursive: true });

    if (isPersonal) {
        const isVideo = [".mp4", ".mov", ".avi", ".mkv", ".webm", ".3gp", ".m4v"].includes(extOrig);
        const isPdf   = extOrig === ".pdf";

        if (isVideo || isPdf) {
            outPath = _uniquePath(saveDir, base, extOrig);
            fs.writeFileSync(outPath, raw);
        } else {
            outPath = _uniquePath(saveDir, base, ".png");
            let png = await _toPng(raw);
            png     = await _shrinkPng(png, maxImgMb);
            fs.writeFileSync(outPath, png);
        }
        log("INFO", "SB_POLLER saved (personal)", path.basename(outPath));

    } else {
        const job   = workPath.split("/")[0] || "";
        const parts = base.split("_");
        const typ   = (parts[0] || "SP").toUpperCase();
        const openPaint = base.includes("_PAINT");
        // QR = jen identifikace opravy QR; do zakázky se ukládá jako SD_ (Scan dokumentace).
        let nameTyp = (typ === "QR") ? "SD" : typ;

        // Poslední pojistka: VIDEO NIKDY JAKO SP.
        // SP se vkládá do CN, ze kterého se sestavuje PDF – video by ho rozbilo.
        // VT je v pořádku, když si ho technik zvolí sám.
        //
        // NÁHRADA JE VŠAK SD, NE VT – VT SE POSÍLÁ ZÁKAZNÍKOVI. Video
        // přepsané na VT by se k němu dostalo, aniž by o tom kdokoli věděl.
        {
            const jeVideo = [".mp4", ".mov", ".avi", ".mkv", ".webm", ".3gp", ".m4v"]
                .includes(extOrig);
            if (jeVideo && !["VT", "SD"].includes(nameTyp)) {
                log("WARN", "SB_POLLER video u nepovoleného typu",
                    `${base} má typ ${nameTyp}, ukládám jako SD`);
                nameTyp = "SD";
            }
        }

        const usesSubfolder = workPath.split("/").includes("__sub");
        const jobDir = _resolveJobDir(saveDir, job, usesSubfolder, typ);
        if (usesSubfolder && jobDir !== saveDir) {
            log("INFO", "SB_POLLER subfolder mode", `typ=${typ} job=${job} → ${jobDir}`);
        } else if (usesSubfolder && typ === "SP" && jobDir === saveDir) {
            log("INFO", "SB_POLLER SP routed to main (mspaint mode)", `job=${job}`);
        }

        const isVideo = [".mp4", ".mov", ".avi", ".mkv", ".webm"].includes(extOrig);
        const isPdf   = extOrig === ".pdf";

        if (isVideo || isPdf) {
            if (typ === "SN") {
                outPath = _uniquePath(jobDir, `SN_${job}`, extOrig);
            } else if (typ === "SDX") {
                outPath = _uniquePath(jobDir, `SD_${job}X`, extOrig);
            } else {
                const letter = _nextLetter(jobDir, job, nameTyp);
                outPath = _uniquePath(jobDir, `${nameTyp}_${job}${letter}`, extOrig);
            }
            fs.writeFileSync(outPath, raw);
            log("INFO", "SB_POLLER saved", path.basename(outPath));

        } else {
            if (typ === "SDX") {
                outPath = _uniquePath(jobDir, `SD_${job}X`, ".png");
            } else if (typ === "SN") {
                outPath = _uniquePath(jobDir, `SN_${job}`, ".png");
            } else {
                const letter = _nextLetter(jobDir, job, nameTyp);
                outPath = _uniquePath(jobDir, `${nameTyp}_${job}${letter}`, ".png");
            }

            let png = await _toPng(raw);
            png     = await _shrinkPng(png, maxImgMb);

            const willPaint = (typ === "SP") || (typ === "QR") ||
                (openPaint && ["SD", "SDX", "VT", "SN", "FA"].includes(typ));

            if (willPaint) {
                await _savePaintTemp(outPath, png, typ === "QR" ? { mode: "qr" } : undefined);
                wentToPaint = true;
            } else {
                fs.writeFileSync(outPath, png);
            }
            log("INFO", "SB_POLLER saved+paint",
                `${path.basename(outPath)} paint=${willPaint}`);
        }
    }

    return { outPath, wentToPaint };
}

// ── Offline pojistka: lokální staging když SAVE_DIR není dostupný ──────────
// POZOR: userData (ne složka aplikace) – aktualizace/reinstalace složku nesmí zahodit
const _PENDING_SAVEDIR = (() => {
    try { return path.join(require("electron").app.getPath("userData"), "_pending_savedir"); }
    catch (_) { return path.join(__dirname, "..", "..", "_pending_savedir"); }
})();
let _pendingStageSeq = 0;

/** Předá hotový soubor modulu api-upload (odeslání do API servisu). */
function _apiEnqueue(outPath) {
    try { require("./api-upload").enqueueFile(outPath); }
    catch (e) { log("WARN", "API_UPLOAD hook", String(e).split("\n")[0]); }
}

/** Je SAVE_DIR fyzicky dostupný a zapisovatelný? (chytá nenamapovaný M: apod.) */
function _isSaveDirAccessible(dir) {
    if (!dir) return false;
    try {
        fs.mkdirSync(dir, { recursive: true });
        fs.accessSync(dir, fs.constants.W_OK);
        return true;
    } catch (_) {
        return false;
    }
}

/** Uloží stažené bajty + metadata do _pending_savedir (čeká na obnovu SAVE_DIR). */
function _stagePending(filePath, raw) {
    fs.mkdirSync(_PENDING_SAVEDIR, { recursive: true });
    // Fotka NEskončila v zakázce – řekni to nahlas, ať technik nefotí znovu naslepo
    try {
        const { Notification } = require("electron");
        if (Notification && Notification.isSupported()) {
            new Notification({
                title: "PhotoBridge – fotka čeká",
                body:  `Cílová složka není dostupná (M: odpojeno?). Fotka ${String(filePath).split("/").pop()} se doručí automaticky, jakmile bude složka zase dostupná.`,
            }).show();
        }
    } catch (_) {}

    const id = `${Date.now()}_${(_pendingStageSeq++).toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    fs.writeFileSync(path.join(_PENDING_SAVEDIR, `${id}.bin`), raw);
    fs.writeFileSync(path.join(_PENDING_SAVEDIR, `${id}.json`),
        JSON.stringify({ filePath, ts: Date.now() }));
}

/**
 * Přesune nahromaděné offline fotky do SAVE_DIR, jakmile je zase dostupný.
 * Volá se na začátku každého poller ticku – prázdný staging je skoro zdarma.
 */
async function _flushPendingSaveDir() {
    let files;
    try {
        files = fs.readdirSync(_PENDING_SAVEDIR).filter((f) => f.endsWith(".json"));
    } catch (_) { return; }
    if (!files.length) return;

    let cfgSave = "";
    try { cfgSave = (require("./config").readConfig().SAVE_DIR || "").trim(); } catch (_) {}
    const saveDir = (STATE.saveDir || cfgSave || "").trim();
    if (!_isSaveDirAccessible(saveDir)) return;   // pořád nedostupný → zkusíme příště

    const maxImgMb = STATE.maxImgMb || 8;
    let moved = 0;
    for (const metaFile of files) {
        const metaPath = path.join(_PENDING_SAVEDIR, metaFile);
        const binPath  = metaPath.replace(/\.json$/, ".bin");
        let meta;
        try { meta = JSON.parse(fs.readFileSync(metaPath, "utf8")); } catch (_) { continue; }
        let raw;
        try { raw = fs.readFileSync(binPath); }
        catch (_) { try { fs.unlinkSync(metaPath); } catch (_) {} continue; }
        try {
            const res = await _finalizeToDisk(saveDir, meta.filePath, raw, maxImgMb);
            _notifyRenderer(res.outPath);
            if (!res.wentToPaint && res.outPath) { _enqueueNotification(res.outPath); _apiEnqueue(res.outPath); }
            try { fs.unlinkSync(binPath); } catch (_) {}
            try { fs.unlinkSync(metaPath); } catch (_) {}
            moved++;
        } catch (e) {
            log("WARN", "SB_FLUSH", `${meta.filePath}: ${String(e).split("\n")[0]}`);
            break;   // přístup se mohl ztratit uprostřed → necháme na příště
        }
    }
    if (moved) log("INFO", "SB_FLUSH", `Přesunuto ${moved} čekajících fotek do SAVE_DIR`);
}

async function _savePaintTemp(finalPath, png, opts) {
    try {
        // Zkus delegovat na paint.js pokud je načtený
        const paint = require("./paint");
        if (typeof paint.createPaintTempCopy === "function") {
            return paint.createPaintTempCopy(finalPath, png, opts);
        }
    } catch { /* paint.js ještě neexistuje nebo chyba */ }
    // Fallback – ulož přímo
    fs.writeFileSync(finalPath, png);
}

/**
 * Odešle IPC event renderu že byl přijat/uložen nový soubor.
 * Pokud renderer okno není k dispozici, tiše ignoruje.
 *
 * @param {string} filePath
 */
function _notifyRenderer(filePath) {
    try {
        const { BrowserWindow } = require("electron");
        const wins = BrowserWindow.getAllWindows();
        for (const win of wins) {
            if (!win.isDestroyed()) {
                win.webContents.send("supabase:file-received", { path: filePath });
            }
        }
    } catch { /* nevadí */ }
}

// ─── Windows notifikace pro stažené soubory ───────────────────────────────────
// Když přijde najednou víc fotek, batchujeme je do jedné notifikace s celým
// seznamem. Přijde-li další fotka v krátké pauze (1.5 s), STARÁ notifikace
// se ZAVŘE a okamžitě se otevře NOVÁ s rozšířeným seznamem – vizuálně to
// vypadá jako že se „přidává řádek do otevřené notifikace".
//
// Reset notifikací po Windows „auto-hide" (~5 s) – další upload pak začne
// nový batch (nová notifikace).
let _notifyBatch     = [];           // názvy souborů v aktuálním batchi
let _notifyBatchDir  = "";           // adresář posledního nahraného souboru (pro klikatelnou notifikaci)
let _lastReceivedFile = "";          // PERZISTENTNÍ – plná cesta k naposledy přijatému souboru
                                     // (přežívá batch reset, použije se v notifikační click handleru)
let _notifyTimer     = null;         // debounce timer pro zobrazení
let _notifyResetTimer = null;        // po 6 s ticha vyresetuj batch (nový soubor = nová notifikace)
let _lastNotification = null;         // reference na poslední Notification instance (pro close)
const NOTIFY_DEBOUNCE_MS = 1500;
const NOTIFY_RESET_MS    = 6000;     // o trochu déle než výchozí Windows zobrazení (~5 s)

/**
 * Zařadí stažený soubor do fronty. Po 1.5 s ticha se zobrazí jedna souhrnná
 * Windows toast notifikace se seznamem všech přijatých souborů.
 *
 * Soubory které jdou do Malování (SP / *_PAINT) se NEvolají – jejich
 * notifikace přijde až po zavření Malování (řeší paint.js).
 */
function _enqueueNotification(filePath) {
    if (!filePath) return;

    // Respektuj NOTIFY_ENABLED v configu
    try {
        const cfg = require("./config").readConfig();
        if (String(cfg.NOTIFY_ENABLED || "true").toLowerCase() === "false") return;
    } catch { /* nevadí */ }

    const name = path.basename(filePath);
    _notifyBatch.push(name);

    // Zapamatuj adresář pro klikatelnou notifikaci (složka kde je soubor uložen)
    _notifyBatchDir = path.dirname(filePath);
    _lastReceivedFile = filePath;   // persistentní (přežije batch reset)

    if (_notifyTimer) clearTimeout(_notifyTimer);
    if (_notifyResetTimer) clearTimeout(_notifyResetTimer);

    _notifyTimer = setTimeout(() => {
        _notifyTimer = null;
        _showWindowsNotification(_notifyBatch.slice());

        // Po 6 s ticha vyresetuj batch – další upload startuje novou notifikaci
        _notifyResetTimer = setTimeout(() => {
            _notifyBatch = [];
            _notifyBatchDir = "";
            _notifyResetTimer = null;
            _lastNotification = null;
        }, NOTIFY_RESET_MS);
    }, NOTIFY_DEBOUNCE_MS);
}

/**
 * Zobrazí Windows toast s aktuálním seznamem souborů.
 * Pokud již nějaká notifikace visí na obrazovce, ZAVŘE ji a okamžitě
 * zobrazí novou s aktualizovaným obsahem.
 *
 * Délku zobrazení řídí Windows (System → Notifications), my ji neovlivníme.
 * Křížek pro zavření má notifikace nativně.
 */
function _showWindowsNotification(filenames) {
    if (!filenames || filenames.length === 0) return;
    try {
        const { Notification, shell } = require("electron");
        if (!Notification.isSupported()) {
            log("DEBUG", "SB_NOTIFY", "Notification API není v této platformě podporováno");
            return;
        }

        // Zavři předchozí notifikaci aby se nová mohla okamžitě zobrazit
        // s aktualizovaným seznamem (vypadá to jako přidání řádku).
        if (_lastNotification) {
            try { _lastNotification.close(); } catch (_) {}
            _lastNotification = null;
        }

        const count = filenames.length;
        const title = count === 1
            ? "PhotoBridge – Nahrán soubor"
            : `PhotoBridge – Nahráno ${count} souborů`;

        // Body: max 5 řádků, zbytek shrnout jako „… +N dalších"
        let body;
        if (count <= 5) {
            body = filenames.join("\n");
        } else {
            body = filenames.slice(0, 4).join("\n") + `\n… +${count - 4} dalších`;
        }

        const notif = new Notification({
            title,
            body,
            silent: false,   // přehrát standardní Windows zvuk
        });

        // ── Kliknutí na notifikaci ────────────────────────────────────────
        // 1) Aktivuj hlavní okno aplikace (přines do popředí)
        // 2) Otevři Průzkumník Windows se zvýrazněným souborem (showItemInFolder)
        //    nebo aspoň otevři SAVE_DIR složku
        notif.on("click", async () => {
            log("INFO", "SB_NOTIFY click", "Klik na notifikaci - otevírám okno + Průzkumník");
            try {
                // Aktivuj hlavní okno aplikace
                const { BrowserWindow } = require("electron");
                const wins = BrowserWindow.getAllWindows();
                for (const win of wins) {
                    if (!win.isDestroyed()) {
                        if (win.isMinimized()) win.restore();
                        win.show();
                        win.focus();
                        break;   // jen první okno (hlavní)
                    }
                }
            } catch (e) {
                log("WARN", "SB_NOTIFY click - nelze aktivovat okno", String(e));
            }

            // Strategie pro otevření souboru/složky:
            // 1) Pokud máme _lastReceivedFile a existuje → showItemInFolder
            // 2) Jinak _notifyBatchDir (pokud existuje) → openPath
            // 3) Jinak SAVE_DIR z configu → openPath
            // 4) Logujeme každý krok abychom v případě chyby věděli co bylo špatně
            try {
                const fs = require("fs");
                // Krok 1: konkrétní soubor
                if (_lastReceivedFile && fs.existsSync(_lastReceivedFile)) {
                    shell.showItemInFolder(_lastReceivedFile);
                    log("INFO", "SB_NOTIFY click", `showItemInFolder: ${_lastReceivedFile}`);
                    return;
                }
                // Krok 2: composedDir
                if (_notifyBatchDir && fs.existsSync(_notifyBatchDir)) {
                    const result = await shell.openPath(_notifyBatchDir);
                    if (result) {
                        log("WARN", "SB_NOTIFY click - openPath error", result);
                    } else {
                        log("INFO", "SB_NOTIFY click", `openPath OK: ${_notifyBatchDir}`);
                    }
                    return;
                }
                // Krok 3: fallback SAVE_DIR
                let saveDir = "";
                try { saveDir = require("./config").readConfig().SAVE_DIR || ""; } catch {}
                if (saveDir && fs.existsSync(saveDir)) {
                    const result = await shell.openPath(saveDir);
                    if (result) {
                        log("WARN", "SB_NOTIFY click - openPath SAVE_DIR error", result);
                    } else {
                        log("INFO", "SB_NOTIFY click", `openPath SAVE_DIR: ${saveDir}`);
                    }
                    return;
                }
                log("WARN", "SB_NOTIFY click", "Žádný platný cíl - _lastReceivedFile, _notifyBatchDir ani SAVE_DIR neexistují");
            } catch (e) {
                log("ERROR", "SB_NOTIFY click handler exception", String(e));
            }
        });

        notif.show();
        _lastNotification = notif;

        log("INFO", "SB_NOTIFY shown", `${count} files: ${filenames.slice(0, 3).join(", ")}${count > 3 ? "..." : ""}`);
    } catch (err) {
        log("WARN", "SB_NOTIFY error", String(err));
    }
}

/**
 * Veřejná funkce – paint.js ji volá po zavření Malování (po dokončení uživatelem).
 * Tím se notifikace zobrazí i pro SP fotky / _PAINT fotky.
 */
function notifyFileReceived(filePath) {
    _enqueueNotification(filePath);
}

/**
 * Veřejná funkce pro test tlačítko v Nastavení.
 * Zobrazí ukázkovou notifikaci s 3 fiktivními soubory.
 */
function showTestNotification() {
    _showWindowsNotification([
        "SP_4567895A.png",
        "SD_4567895A.png",
        "VT_4567895A.png",
    ]);
}

/**
 * Smaže záznamy starší N dní z pb_queue a Storage.
 * Volá se při každém startu polleru.
 */
async function _cleanupExpiredEntries(sbUrl, sbAnon, token, sbBucket, retentionDays = 7) {
    try {
        const days = Math.max(1, parseInt(retentionDays, 10) || 7);
        const weekAgo = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
        const url = `${sbUrl}/rest/v1/pb_queue`
            + `?done=eq.false`
            + `&created_at=lt.${encodeURIComponent(weekAgo)}`
            + `&select=id,file_path`;
        const resp = await fetch(url, {
            headers: { ..._sbHeaders(sbAnon, token), Accept: "application/json" },
            timeout: 8_000,
        });
        if (!resp.ok) return;
        const rows = await resp.json();
        if (!Array.isArray(rows) || !rows.length) return;
        for (const row of rows) {
            await _markDone(sbUrl, sbAnon, token, row.id);
            if (row.file_path) {
                await _deleteWithToken(sbUrl, sbAnon, token, sbBucket, row.file_path);
            }
        }
        log("INFO", "SB_POLLER cleanup", `Smazáno ${rows.length} expirovaných záznamů (>${days} dní)`);
    } catch (err) {
        log("WARN", "SB_POLLER cleanup", String(err));
    }
}

// ─── PUBLIC API POLLERU ──────────────────────────────────────────────────────

/**
 * Spustí Supabase poller. Zastaví předchozí pokud běžel.
 * Stahuje VŠE pro přihlášený účet (Varianta A) – RLS izoluje uživatele.
 *
 * @param {object} cfg       – konfigurace
 * @param {string} saveDir   – cílová složka pro ukládání fotek
 */
function startSbPoller(cfg, saveDir) {
    stopSbPoller(); // zastav předchozí běh

    _pollerSeen   = new Set();
    _pollerHotovo = new Set();

    const sbUrl    = _sbUrl(cfg);
    const sbAnon   = (cfg.SB_ANON || "").trim();
    const sbBucket = (cfg.SB_BUCKET || "pb-uploads").trim();

    if (!sbUrl || !sbAnon) {
        log("WARN", "SB_POLLER", "Chybí SB_URL nebo SB_ANON v konfiguraci");
        _broadcastPollerStatus(false);
        return;
    }
    if (!saveDir) {
        log("WARN", "SB_POLLER", "Chybí SAVE_DIR – poller se nespustil");
        _broadcastPollerStatus(false);
        return;
    }

    // Načti uložené čítače písmen ze state.json
    _initLetterCountersFromState();

    // Označ jako "spouští se" – až po úspěšném získání tokenu pošleme true
    _pollerActive = true;

    // Úvodní přihlášení před startem smyčky
    sbEnsureToken(cfg).then(async (tok) => {
        if (!tok) {
            log("WARN", "SB_POLLER", "Nelze se přihlásit – přihlas se znovu");
            _pollerActive = false;
            _broadcastPollerStatus(false);
            return;
        }

        // Vyčisti expirované záznamy při každém startu (dle RETENTION_DAYS)
        await _cleanupExpiredEntries(sbUrl, sbAnon, tok, sbBucket, cfg.RETENTION_DAYS);

        // Centrální nastavení RTS. Musí se načíst DŘÍV, než se zpracuje první
        // fotka – jinak by ji první běh uložil podle lokálního nastavení.
        try {
            await _nactiCentralniRts(sbUrl, sbAnon, tok, STATE.sbEmail || cfg.SB_EMAIL);
        } catch (e) {
            log('WARN', 'RTS_REZIM', `Centrální nastavení se nepodařilo načíst: ${e.message} – platí dál to, co bylo`);
        }

        // Automatický úklid fronty. Rozhoduje o něm server, ne tahle aplikace –
        // viz _automatickyUklidFronty. Chyba tady NESMÍ shodit poller.
        try {
            await _automatickyUklidFronty(sbUrl, sbAnon, tok);
        } catch (e) {
            log('WARN', 'QUEUE cleanup', e.message);
        }

        log("INFO", "SB_POLLER started", `bucket=${sbBucket} saveDir=${saveDir}`);

        // Polling jen jako pojistka. Krátce po startu (2 s) než se připojí
        // websocket; po úspěšném subscribe _startRealtime přepne na pomalý
        // režim (2 min). Doručování fotek jede přes Realtime push, ne přes tohle.
        _pollSlowMode = false;
        _pollerIntervalMs = POLL_MS_STARTUP;
        _pollerTimer = setInterval(() => _pollerTick(cfg, saveDir), POLL_MS_STARTUP);

        // Spusť Realtime websocket – pokud Supabase má zapnutou Realtime
        // publication na pb_queue, dostaneme INSERT eventy s <100 ms latencí.
        _startRealtime(cfg, saveDir);

        // Detekce více PC na stejný účet (varuje uživatele – fotky by se
        // jinak mezi PC náhodně rozdělily). Chyba zde NESMÍ shodit poller.
        try {
            require('./device-presence').startPresence(cfg);
        } catch (e) {
            log('WARN', 'PRESENCE init', e.message);
        }

        // Až teď oznam rendereru, že příjem skutečně běží
        _broadcastPollerStatus(true);
    });
}

/**
 * ID přihlášeného účtu.
 *
 * PROČ TO NENÍ JEN STATE.sbUserId
 * Obnova relace po restartu (sbRestoreSession) nastaví jen sbEmail a token,
 * ale sbUserId nechá PRÁZDNÉ – vyplňuje se jen při skutečném přihlášení.
 *
 * Do v3.3.29 na tom tiše ztroskotalo ohlášení verze i evidence fotek
 * vložených v počítači: obě funkce mají na začátku „bez user_id nemá cenu
 * pokračovat" a po každém restartu se tedy neudělalo nic. V logu nebyla
 * ani chyba – jen ticho.
 *
 * Proto se ID dočte z tokenu (claim „sub") a rovnou doplní do stavu.
 */
function _uidUcet() {
    if (STATE.sbUserId) return STATE.sbUserId;
    try {
        const cast = String(STATE.sbAccessToken || "").split(".")[1];
        if (!cast) return "";
        const json = Buffer.from(cast.replace(/-/g, "+").replace(/_/g, "/"), "base64")
            .toString("utf8");
        const uid = JSON.parse(json).sub || "";
        if (uid) {
            STATE.sbUserId = uid;   // ať se to nemusí luštit pokaždé
            log("INFO", "SB_AUTH", `ID účtu doplněno z tokenu: ${uid.slice(0, 8)}...`);
        }
        return uid;
    } catch (_) { return ""; }
}

/**
 * Uloží seznam zakázaných verzí, aby ho updater našel i bez sítě.
 *
 * Formát v pb_settings: verze oddělené čárkou, např. „3.3.21,3.3.22".
 * Prázdná hodnota = nic není zakázané.
 */
function _ulozZakazaneVerze(hodnota) {
    try {
        const { app } = require("electron");
        const p  = require("path").join(app.getPath("userData"), "zakazane_verze.json");
        const fs2 = require("fs");

        const verze = String(hodnota || "")
            .split(/[,;\s]+/).map(x => x.trim()).filter(Boolean);

        fs2.writeFileSync(p, JSON.stringify({ verze, kdy: new Date().toISOString() }, null, 2));
        log("INFO", "UPDATER", verze.length
            ? `Zakázané verze: ${verze.join(", ")}`
            : "Zakázané verze: žádné");
    } catch (e) {
        log("WARN", "UPDATER", `Seznam zakázaných verzí nelze uložit: ${e.message}`);
    }
}

/**
 * Zapíše do pb_queue záznam o fotce vložené PŘÍMO V POČÍTAČI.
 *
 * PROČ TO MUSÍ BÝT
 * Do fronty se zapisovalo jen to, co přišlo z mobilu. Fotky vložené
 * přetažením nebo přes stanoviště šly rovnou do složky a nikde se
 * neevidovaly – takže statistika „Moje fotky" i souhrn v Admin centru
 * je nepočítaly. Na sdíleném stanovišti, kde se vkládá výhradně ručně,
 * ukazovala statistika vždycky nulu.
 *
 * Řádek se zakládá rovnou jako HOTOVÝ (done = true):
 *   • poller stahuje jen řádky s done = false, takže se nic nestáhne
 *   • soubor už v cílové složce je, není co dohánět
 *   • automatický úklid fronty ho po čase smaže jako každý jiný
 *
 * Ukládá se jen NÁZEV souboru, ne cesta – z názvu se čte typ dokumentu
 * a víc statistika nepotřebuje. Cesta na disku by navíc byla u každého
 * počítače jiná a nikomu by nic neřekla.
 *
 * Chyba se NIKDY nepropíše ven. Evidence je doplňková – kdyby selhala,
 * fotka je v pořádku uložená a to je to podstatné.
 */
async function zapisVlozenouFotku(nazevSouboru) {
    try {
        const cfg = require("./config").readConfig();
        const sbUrl  = String(cfg.SB_URL  || "").trim();
        const sbAnon = String(cfg.SB_ANON || "").trim();
        if (!sbUrl || !sbAnon) return;

        const tok = await sbEnsureToken(cfg);
        const uid = _uidUcet();
        if (!tok || !uid) {
            log("INFO", "EVIDENCE", "Nezapsáno – chybí přihlášení");
            return;
        }

        const jmeno = require("path").basename(String(nazevSouboru || ""));
        if (!jmeno) return;

        const resp = await fetch(`${sbUrl}/rest/v1/pb_queue`, {
            method:  "POST",
            headers: { ..._sbHeaders(sbAnon, tok), Prefer: "return=minimal" },
            body: JSON.stringify({
                user_id:    uid,
                file_path:  jmeno,
                done:       true,          // nic se nestahuje, soubor už je uložený
                created_at: new Date().toISOString(),
            }),
        });

        // POZOR: fetch při HTTP 400/401/403 NEVYHODÍ výjimku – vrátí odpověď
        // s chybovým kódem. Do v3.3.28 se výsledek vůbec nekontroloval,
        // takže když zápis selhal (chybějící sloupec, pravidlo RLS),
        // nikde se to neobjevilo a statistika prostě ukazovala nulu.
        if (!resp.ok) {
            const detail = await resp.text().catch(() => "");
            log("WARN", "EVIDENCE",
                `Zápis do fronty selhal: HTTP ${resp.status} ${detail.slice(0, 200)}`);
            return;
        }
        log("INFO", "EVIDENCE", `Zapsáno do fronty: ${jmeno}`);

    } catch (e) {
        // Chyba evidence NESMÍ shodit ukládání fotky – ta je už na disku.
        try { log("WARN", "EVIDENCE", `Nezapsáno do fronty: ${e.message}`); } catch (_) {}
    }
}

/**
 * Zapíše jeden řádek o tomhle počítači do pb_verze.
 *
 * PROČ JEDEN ŘÁDEK NA POČÍTAČ, NE ZÁZNAM ZA ZÁZNAMEM
 * Zajímá nás „co běží teď", ne kdo kdy byl přihlášený. Historie by z toho
 * udělala sledování lidí, což nikdo nechce – a databáze by rostla.
 * Každý počítač proto přepisuje svůj vlastní řádek.
 *
 * device_id je stabilní ID stroje ze state.json, stejné, jaké používá
 * hlídání účtu na více PC.
 */
async function _ohlasVerzi(sbUrl, sbAnon, token) {
    const { app } = require("electron");
    const os      = require("os");

    let deviceId = "";
    try { deviceId = require("./device-presence")._getDeviceIdVerejne?.() || ""; } catch (_) {}
    if (!deviceId) {
        // Nouzově podle jména stroje – ať se ohlásí i tak.
        deviceId = "host-" + String(os.hostname() || "PC").toLowerCase();
    }

    const radek = {
        device_id: deviceId,
        user_id:   _uidUcet(),
        email:     STATE.sbEmail  || "",
        hostname:  os.hostname()  || "",
        verze:     app.getVersion(),
        os:        process.platform,
        kdy:       new Date().toISOString(),
    };
    if (!radek.user_id) {
        // Dřív se tu jen mlčky skončilo a nešlo poznat, co se stalo.
        log("WARN", "VERZE", "Neohlášeno – nepodařilo se zjistit ID účtu");
        return;
    }

    const resp = await fetch(`${sbUrl}/rest/v1/pb_verze`, {
        method:  "POST",
        headers: {
            apikey: sbAnon,
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            // Ohlášení je opakované – při konfliktu se řádek přepíše.
            Prefer: "resolution=merge-duplicates,return=minimal",
        },
        body: JSON.stringify(radek),
    });

    if (!resp.ok) throw new Error(`HTTP ${resp.status} ${(await resp.text()).slice(0, 120)}`);
    log("INFO", "VERZE", `Ohlášeno: ${radek.hostname} / ${radek.verze}`);
}

/**
 * Přečte centrální nastavení RTS z pb_settings a předá ho api-upload.
 *
 * ČTE TŘI KLÍČE
 *   rts_mode          'disk' | 'both' | 'api'   – co platí pro celou firmu
 *   rts_domeny        'britex.cz'               – kdo RTS používá (víc přes čárku)
 *   rts_emaily_navic  'nekdo@seznam.cz'         – výjimky mimo doménu
 *
 * PROČ SE ŘEŠÍ I KOMU RTS PATŘÍ
 * Aplikaci si může stáhnout kdokoli a používat ji doma. RTS ale nemá, takže
 * by mu fotka uvízla v čekací složce, kterou by nikdo nevyprázdnil. Účet mimo
 * firemní doménu proto ukládá do zvolené složky bez ohledu na to, co je
 * centrálně přepnuté.
 *
 * Když se čtení nepovede (bez sítě, chyba serveru), NIC SE NEMĚNÍ – platí dál
 * to, co bylo. Výpadek sítě nesmí přepnout režim celé firmy.
 */
async function _nactiCentralniRts(sbUrl, sbAnon, token, email) {
    const klice = 'rts_mode,rts_domeny,rts_emaily_navic,zakazane_verze';
    const url   = `${sbUrl}/rest/v1/pb_settings?key=in.(${klice})&select=key,value`;

    const resp = await fetch(url, {
        headers: { apikey: sbAnon, Authorization: `Bearer ${token || sbAnon}` },
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

    const rows = await resp.json();
    const n = {};
    for (const r of rows || []) n[String(r.key)] = String(r.value ?? '').trim();

    // Bez nastavených domén se nikomu nic neomezuje – jinak by první spuštění
    // po vydání vypnulo RTS všem, než by se klíč doplnil.
    const mail    = String(email || '').trim().toLowerCase();
    const domeny  = (n.rts_domeny || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
    const emaily  = (n.rts_emaily_navic || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);

    let povoleno = true;
    if (domeny.length || emaily.length) {
        povoleno = emaily.includes(mail)
                || domeny.some(d => mail.endsWith('@' + d));
    }

    require('./api-upload').nastavCentralni(n.rts_mode || null, povoleno);

    // Seznam zakázaných verzí – ať platí hned po startu, ne až po první
    // změně, která přijde Realtime kanálem.
    _ulozZakazaneVerze(n.zakazane_verze || '');
}

/**
 * Automatický úklid zpracovaných záznamů ve frontě.
 *
 * PROČ TO VOLÁ KAŽDÁ APLIKACE, A NE JEN SPRÁVCE
 * Do v3.3.8 to řešilo Nastavení: zaškrtávátko „uklízet jednou týdně",
 * datum posledního běhu v config.json a hranice 90 dní natvrdo v kódu.
 * Mělo to tři vady – uklidilo se jen když někdo otevřel Nastavení, každé PC
 * si vedlo vlastní počítání, a výběr v seznamu „Starší než" se neprojevil.
 *
 * Teď o všem rozhoduje Edge funkce z centrálního nastavení: jestli je úklid
 * zapnutý, jaká je hranice stáří a jestli dnes už neproběhl. Aplikace jen
 * zaklepe. Volající nemá jak ovlivnit, co se smaže, takže může zaklepat
 * kdokoli – a úklid proběhne, i když ten den nikdo ze správců nepřijde.
 *
 * Maže se JEN done=true starší než hranice. Nenahrané fotky nikdy.
 */
async function _automatickyUklidFronty(sbUrl, sbAnon, token) {
    const resp = await fetch(`${sbUrl}/functions/v1/admin-queue`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: sbAnon,
                   Authorization: `Bearer ${token}` },
        body:    JSON.stringify({ action: 'cleanup-auto' }),
    });

    const out = await resp.json().catch(() => null);

    // Stará Edge funkce neznámou akci ignoruje a vrátí výpis fronty.
    // Bez téhle kontroly by to vypadalo jako úspěšný úklid.
    if (!resp.ok || !out || !out.ok || out.action !== 'cleanup-auto') {
        log('INFO', 'QUEUE cleanup',
            'Automatický úklid přeskočen – Edge funkce ho zatím neumí.');
        return;
    }

    if (!out.spusteno) {
        log('INFO', 'QUEUE cleanup', `Neuklízí se: ${out.duvod}`);
        return;
    }
    log('INFO', 'QUEUE cleanup',
        `Smazáno ${out.smazano} zpracovaných záznamů starších ${out.nechano_dni} dní`);
}

/**
 * Připojí se na Supabase Realtime websocket a subscribuje INSERT eventy
 * z tabulky pb_queue. Když přijde event, soubor se okamžitě přidá do fronty
 * (žádné čekání na další polling tick).
 *
 * Pokud připojení selže nebo Realtime není zapnutý na pb_queue, polling
 * (1 s) zachytí všechno – jen pomaleji. Po úspěšném připojení se polling
 * zpomalí na 5 s aby šetřil traffic.
 */
function _startRealtime(cfg, saveDir) {
    _stopRealtime(); // zruš případné předchozí spojení

    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    if (!sbUrl || !sbAnon) return;

    // WebSocket konstruktor. POZOR: Electron 28 běží na Node 18, který NEMÁ
    // globalThis.WebSocket → dřív tu kód bailoval a push nikdy nejel. Bereme
    // balíček 'ws' (je v node_modules jako tranzitivní závislost
    // @supabase/supabase-js). Fallback na globalThis.WebSocket pro novější Node.
    let WS = null;
    try { WS = require("ws"); } catch (_) { WS = null; }
    if (!WS && typeof globalThis.WebSocket === "function") WS = globalThis.WebSocket;
    if (!WS) {
        log("WARN", "SB_REALTIME", "WebSocket (ani 'ws', ani global) není dostupný – jen polling");
        return;
    }

    // Realtime URL (Supabase Phoenix websocket)
    const wsUrl = sbUrl.replace(/^http/, "ws") + `/realtime/v1/websocket?apikey=${encodeURIComponent(sbAnon)}&vsn=1.0.0`;

    let socket;
    try {
        socket = new WS(wsUrl);
    } catch (err) {
        log("WARN", "SB_REALTIME connect", String(err));
        _scheduleRealtimeReconnect(cfg, saveDir);
        return;
    }
    _rtSocket = socket;

    socket.onopen = async () => {
        log("INFO", "SB_REALTIME", "websocket otevřen, subscribuji pb_queue INSERT");
        // Subscribe message – Phoenix protocol
        const tok = await sbEnsureToken(cfg).catch(() => null);
        // POZOR: moderní Supabase Realtime vyžaduje PLNÝ config
        // (broadcast/presence/private) a join_ref – bez nich server join
        // odmítne a subscribe se nikdy nepotvrdí. Tento tvar je ověřený
        // samostatným testem (vrací "subscribe OK" + "Subscribed to PostgreSQL").
        const joinRef = String(++_rtRef);
        const subscribeMsg = {
            topic:   "realtime:public:pb_queue",
            event:   "phx_join",
            payload: {
                config: {
                    broadcast: { ack: false, self: false },
                    presence:  { key: "" },
                    postgres_changes: [
                        { event: "INSERT", schema: "public", table: "pb_queue" }
                    ],
                    private: false,
                },
                access_token: tok || sbAnon,
            },
            ref:      joinRef,
            join_ref: joinRef,
        };
        try { socket.send(JSON.stringify(subscribeMsg)); } catch (_) {}

        // ── Druhý kanál: signál k okamžité aktualizaci ──────────────────────
        // POZOR: téma je "realtime:public:<tabulka>" a server podle NĚJ
        // rozhoduje, co pošle. Přidat druhou tabulku jen do seznamu filtrů
        // nestačí – zprávy by nikdy nedorazily. Musí být vlastní kanál.
        const joinRef2 = String(++_rtRef);
        try {
            socket.send(JSON.stringify({
                topic:   "realtime:public:pb_settings",
                event:   "phx_join",
                payload: {
                    config: {
                        broadcast: { ack: false, self: false },
                        presence:  { key: "" },
                        postgres_changes: [
                            { event: "UPDATE", schema: "public", table: "pb_settings" },
                            { event: "INSERT", schema: "public", table: "pb_settings" }
                        ],
                        private: false,
                    },
                    access_token: tok || sbAnon,
                },
                ref:      joinRef2,
                join_ref: joinRef2,
            }));
        } catch (_) {}

        // Heartbeat každých 25 s (Supabase má 30 s timeout)
        // Hlídáme že Supabase odpovídá – pokud 2× po sobě neodpoví, websocket
        // je mrtvý i když readyState ještě říká OPEN. Zavřeme a reconnect.
        _rtHeartbeatSent = 0;
        _rtHeartbeat = setInterval(() => {
            if (!_rtSocket || _rtSocket.readyState !== 1) return;

            // Pokud je _rtHeartbeatSent >= 2, znamená že 2 předchozí heartbeaty
            // nebyly potvrzeny serverem → websocket je tichý/mrtvý
            if (_rtHeartbeatSent >= 2) {
                log("WARN", "SB_REALTIME", "heartbeat timeout – nucený reconnect");
                try { _rtSocket.close(); } catch (_) {}
                // onclose handler nás restartuje
                return;
            }

            try {
                const ref = String(++_rtRef);
                _rtLastHeartbeatRef = ref;
                _rtSocket.send(JSON.stringify({
                    topic: "phoenix", event: "heartbeat", payload: {}, ref,
                }));
                _rtHeartbeatSent++;
            } catch (_) {}
        }, 25_000);

        // Obnova access_tokenu přes socket každé 4 min. Uživatelský JWT žije
        // ~1 h; bez obnovy by RLS autorizace postgres_changes vypršela a push
        // by tiše přestal doručovat (socket by zůstal „připojený“). Phoenix
        // přijímá event "access_token" pro re-autorizaci kanálu za běhu.
        if (_rtTokenTimer) { clearInterval(_rtTokenTimer); _rtTokenTimer = null; }
        _rtTokenTimer = setInterval(async () => {
            if (!_rtSocket || _rtSocket.readyState !== 1) return;
            const t = await sbEnsureToken(cfg).catch(() => null);
            if (!t) {
                // Obnova tokenu selhala → autorizace kanálu by tiše vypršela a push
                // by přestal doručovat. Radši socket zavři → reconnect s čerstvým tokenem.
                log("WARN", "SB_REALTIME", "obnova tokenu selhala – nucený reconnect");
                try { _rtSocket.close(); } catch (_) {}
                return;
            }
            // Token se musí obnovit na OBOU kanálech. Kdyby se obnovil jen
            // u fotek, druhému by autorizace po hodině tiše vypršela a signál
            // k aktualizaci by přestal chodit, aniž by to bylo poznat.
            for (const t2 of ["realtime:public:pb_queue", "realtime:public:pb_settings"]) {
                try {
                    _rtSocket.send(JSON.stringify({
                        topic:   t2,
                        event:   "access_token",
                        payload: { access_token: t },
                        ref:     String(++_rtRef),
                    }));
                } catch (_) {}
            }
        }, 240_000);
    };

    socket.onmessage = (evt) => {
        let msg;
        try {
            // 'ws' může doručit text jako Buffer → bezpečně převedeme na string.
            const raw = (evt && evt.data !== undefined) ? evt.data : evt;
            msg = JSON.parse(typeof raw === "string" ? raw : raw.toString("utf8"));
        } catch { return; }
        if (!msg) return;

        // Heartbeat reply – Supabase odpověděl, jsme živí
        if (msg.event === "phx_reply" && msg.ref === _rtLastHeartbeatRef) {
            _rtHeartbeatSent = 0;
        }

        // Subscribe potvrzeno → Realtime push teď doručuje fotky okamžitě.
        // Pojistku přepneme na POMALÝ režim (2 min) a hned uděláme JEDNO
        // „dohnání“ – stáhne cokoli, co přišlo před/během připojování.
        if (msg.event === "phx_reply" && msg.payload && msg.payload.status === "ok") {
            if (!_rtConnected) {
                _rtConnected = true;
                _pollSlowMode = true;
                // Interval nastavuje _prenastavPoller() podle toho, jestli se
                // právě pracuje. Dřív se tu přenastavoval ještě jednou natvrdo
                // na konstantu, která už neexistuje – aplikace na tom padala.
                _prenastavPoller(cfg, saveDir);
                log("INFO", "SB_REALTIME",
                    "subscribe OK – push aktivní; fronta se kontroluje podle vytížení");
                // Okamžité dohnání po připojení (nečekáme 2 min na první tick)
                _pollerTick(cfg, saveDir).catch(() => {});
            }
        }

        // INSERT event → okamžitě stáhni soubor
        if (msg.event === "postgres_changes" && msg.payload) {
            const data = msg.payload.data || msg.payload;
            const rec  = data.record || data.new || {};

            // ── Signál k okamžité aktualizaci ────────────────────────────
            // Chodí po vlastním kanálu realtime:public:pb_settings.
            const zNastaveni = data.table === "pb_settings"
                            || String(msg.topic || "").includes("pb_settings");
            // ── Změna režimu RTS ─────────────────────────────────────────
            // Přepnutí z Admin centra se má projevit hned, ne až po restartu.
            if (zNastaveni && ["rts_mode", "rts_domeny", "rts_emaily_navic"].includes(rec.key)) {
                log("INFO", "SB_REALTIME", `Změna nastavení RTS: ${rec.key} = ${rec.value}`);
                // POZOR: `tok` v tomhle místě NEEXISTUJE – obsluha zpráv běží
                // mimo funkci, kde se token načítal. Do v3.3.28 to shodilo
                // spojení výjimkou „tok is not defined". Token si proto
                // vyžádáme tady.
                sbEnsureToken(cfg)
                    .then(t => _nactiCentralniRts(sbUrl, sbAnon, t, STATE.sbEmail || cfg.SB_EMAIL))
                    .catch(e => log("WARN", "RTS_REZIM", `Přenačtení selhalo: ${e.message}`));
                return;
            }

            // ── Dotaz na verzi ───────────────────────────────────────────
            // Správce v Admin centru klikl na „Zjistit verze". Zapíšeme
            // jeden řádek o sobě – nic víc, žádná historie.
            //
            // Chodí to Realtime kanálem, na kterém aplikace stejně visí,
            // takže se nic nového nepřipojuje. Odpovídá se jen na výzvu,
            // ne pravidelně – proto to nic nestojí.
            // ── Zakázané verze ───────────────────────────────────────────
            // Správce zakázal vadný balíček. Uložíme si seznam lokálně, ať
            // platí i po restartu a bez sítě.
            if (zNastaveni && rec.key === "zakazane_verze") {
                _ulozZakazaneVerze(rec.value);
                return;
            }

            if (zNastaveni && rec.key === "verze_dotaz") {
                log("INFO", "VERZE", "Dotaz na verzi – hlásím se");
                sbEnsureToken(cfg)
                    .then(t => _ohlasVerzi(sbUrl, sbAnon, t))
                    .catch(e => log("WARN", "VERZE", `Ohlášení selhalo: ${e.message}`));
                return;
            }

            if (zNastaveni && rec.key === "urgent_version") {
                const chtena = String(rec.value || "").trim();
                log("INFO", "SB_REALTIME", `Signál k aktualizaci na ${chtena || "(prázdné)"}`);
                if (chtena) {
                    try {
                        require("./updater").urgentniSignal(chtena);
                    } catch (e) {
                        log("WARN", "SB_REALTIME", `Aktualizaci se nepodařilo spustit: ${e.message}`);
                    }
                }
                return;
            }

            const filePath = rec.file_path;
            const rowId    = rec.id;
            const downloadUrl = rec.download_url || null;   // R2/Worker URL (když ji telefon nastaví)
            if (filePath) {
                const sbBucket = (cfg.SB_BUCKET || "pb-uploads").trim();
                log("INFO", "SB_REALTIME insert", filePath);
                _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId, downloadUrl);
            }
        }
    };

    socket.onerror = (err) => {
        log("DEBUG", "SB_REALTIME error", String(err && err.message || err));
    };

    socket.onclose = () => {
        if (_rtConnected) log("INFO", "SB_REALTIME", "websocket zavřen");
        _rtConnected = false;
        _rtHeartbeatSent = 0;
        if (_rtHeartbeat) { clearInterval(_rtHeartbeat); _rtHeartbeat = null; }
        if (_rtTokenTimer) { clearInterval(_rtTokenTimer); _rtTokenTimer = null; }
        // Websocket spadl → push nefunguje. Dočasně zrychli pojistku na 5 s,
        // než se znovu připojí (reconnect ~10 s). Žádné 1s mlácení.
        if (_pollerTimer && _pollerActive) {
            clearInterval(_pollerTimer);
            _pollSlowMode = false;
            _prenastavPoller(cfg, saveDir);
        }
        if (_pollerActive) _scheduleRealtimeReconnect(cfg, saveDir);
    };
}

/**
 * Naplánuje reconnect Realtime websocketu za 10 s (s jitterem).
 */
function _scheduleRealtimeReconnect(cfg, saveDir) {
    if (_rtReconnect) return;
    const delay = 10_000 + Math.floor(Math.random() * 5_000);
    _rtReconnect = setTimeout(() => {
        _rtReconnect = null;
        if (_pollerActive) _startRealtime(cfg, saveDir);
    }, delay);
}

/**
 * Zavře Realtime websocket a vyčistí timery.
 */
function _stopRealtime() {
    if (_rtHeartbeat) { clearInterval(_rtHeartbeat); _rtHeartbeat = null; }
    if (_rtTokenTimer) { clearInterval(_rtTokenTimer); _rtTokenTimer = null; }
    if (_rtReconnect) { clearTimeout(_rtReconnect);  _rtReconnect = null; }
    if (_rtSocket) {
        try { _rtSocket.close(); } catch (_) {}
        _rtSocket = null;
    }
    _rtConnected = false;
}

/**
 * Zastaví Supabase poller. Po dokončení by neměl zůstat žádný timer,
 * websocket ani neuvolněné TCP sockety – aby další login byl rychlý.
 */
function stopSbPoller() {
    const wasActive = _pollerActive;
    _pollerActive = false;
    _stopRealtime();
    if (_pollerTimer !== null) {
        clearInterval(_pollerTimer);
        _pollerTimer = null;
        log("INFO", "SB_POLLER stopped", "");
    }
    // Násilně uzavři všechny keepAlive sockety v poll/auth agentech.
    // Bez toho by Node.js držel TCP connection na Supabase ještě desítky
    // sekund a další fetch by čekal ve frontě (= „login trvá dlouho").
    try { _pollAgent.destroy(); } catch (_) {}
    try { _authAgent.destroy(); } catch (_) {}
    // Zastav detekci více PC + ukliď svůj záznam v cloudu
    try { require('./device-presence').stopPresence(); } catch (_) {}
    if (wasActive) _broadcastPollerStatus(false);
}

/**
 * Vrátí true pokud poller skutečně běží (timer aktivní + token načten).
 */
function isSbPollerRunning() {
    return _pollerActive && _pollerTimer !== null;
}

/**
 * Pošle všem oknům aktuální stav polleru.
 */
function _broadcastPollerStatus(running) {
    try {
        const { BrowserWindow } = require("electron");
        for (const win of BrowserWindow.getAllWindows()) {
            if (!win.isDestroyed()) {
                win.webContents.send("poller:status", { job: running ? "auto" : null, running });
            }
        }
    } catch { /* nevadí */ }
}


// ─── OBNOVENÍ SESSION PO RESTARTU ────────────────────────────────────────────

/**
 * Načte uloženou session (refresh token + email) ze state.json a obnoví ji.
 * Volat z main.js hned po app.ready – UI pak správně ukáže přihlášeného technika.
 *
 * Odhlášení propadne POUZE pokud:
 *  - Refresh token vypršel na serveru Supabase (výchozí: velmi dlouhá platnost)
 *  - Technik klikl Odhlásit
 *
 * NIKDY se odhlášení nedeje automaticky jinak.
 *
 * @param {object} cfg  – konfigurace z config.readConfig()
 * @returns {Promise<boolean>}  true = session obnovena, false = není co obnovit
 */
async function sbRestoreSession(cfg) {
    try {
        const st = loadState();
        if (!st.sb_refresh) {
            return false; // Žádná uložená session
        }

        // Obnov email pro UI (i před obnovením tokenu)
        if (st.sb_email && !STATE.sbEmail) {
            STATE.sbEmail = st.sb_email;
        }

        // Obnov account_type
        if (st.sb_account_type && !STATE.sbAccountType) {
            STATE.sbAccountType = st.sb_account_type;
        }

        // Načti refresh token do STATE pokud tam ještě není
        if (!STATE.sbRefreshToken) {
            STATE.sbRefreshToken = st.sb_refresh;
        }

        // Zkus obnovit access token
        const tok = await sbEnsureToken(cfg);
        if (tok) {
            log('INFO', 'SB_AUTH', `Session obnovena po restartu – user=${STATE.sbEmail || '?'}`);
            // Uprav sbEmail pokud sbEnsureToken provedl re-login
            if (!STATE.sbEmail && st.sb_email) STATE.sbEmail = st.sb_email;
            return true;
        }

        // Refresh token propadl – ale NEODHLAŠUJEME automaticky.
        // Zachováme sbEmail pro UI (ukáže "přihlášen jako X, token vypršel")
        // Technik musí zadat heslo znovu ručně.
        log('WARN', 'SB_AUTH', 'Refresh token propadl – je potřeba ruční přihlášení');
        STATE.sbEmail = st.sb_email || STATE.sbEmail; // zachovat email pro UI
        return false;

    } catch (err) {
        log('WARN', 'SB_AUTH sbRestoreSession', String(err));
        return false;
    }
}

// ─── PŘEHLED NESTAŽENÝCH ZAKÁZEK ─────────────────────────────────────────────

/**
 * Vrátí seznam zakázek, které mají v pb_queue řádky s done=false.
 * Výsledek je seřazený seznam { job, count, newestAt } bez duplicit.
 *
 * @param {object} cfg
 * @returns {Promise<Array<{job:string, count:number, newestAt:string|null}>>}
 */
async function sbGetPendingJobs(cfg) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    if (!sbUrl || !sbAnon) throw new Error("Chybí konfigurace Supabase (SB_URL / SB_ANON).");

    const token = await sbEnsureToken(cfg);
    if (!token) throw new Error("Nejste přihlášeni do Supabase.");

    // Načteme až 1000 nestažených řádků (pro reálné nasazení víc než dost)
    const url = `${sbUrl}/rest/v1/pb_queue`
        + `?done=eq.false`
        + `&order=job.asc,id.asc`
        + `&limit=1000`
        + `&select=id,job,file_path,created_at`;

    const resp = await fetch(url, {
        headers: { ..._sbHeaders(sbAnon, token), Accept: "application/json" },
        timeout: 12_000,
    });
    if (!resp.ok) {
        const text = await resp.text().catch(() => "");
        throw new Error(`Supabase HTTP ${resp.status}: ${text.slice(0, 120)}`);
    }
    const rows = await resp.json();
    if (!Array.isArray(rows)) throw new Error("Neočekávaná odpověď ze Supabase.");

    // Seskupení podle job
    const map = {};
    for (const row of rows) {
        const j = row.job || "(bez zakázky)";
        if (!map[j]) map[j] = { job: j, count: 0, newestAt: null };
        map[j].count++;
        if (row.created_at && (!map[j].newestAt || row.created_at > map[j].newestAt)) {
            map[j].newestAt = row.created_at;
        }
    }

    return Object.values(map).sort((a, b) => a.job.localeCompare(b.job));
}

// ─── IPC HANDLERY ────────────────────────────────────────────────────────────

/**
 * Zaregistruje IPC kanály – volat z main.js po app.ready.
 *
 * Kanály:
 *   supabase:login      { sbUrl, sbAnon, emailOrName, password }  → { ok, error }
 *   supabase:register   { sbUrl, sbAnon, username, password }      → { ok, error }
 *   supabase:logout     {}                                         → void
 *   supabase:status     {}                                         → { loggedIn, userId }
 *   supabase:start-poller  { cfg, job, saveDir }                   → void
 *   supabase:stop-poller   {}                                      → void
 */
/**
 * Společná logika odhlášení – sdílí ji ruční odhlášení (tlačítko)
 * i vynucené odhlášení z jiného PC (presence force_logout).
 * @param {string} reason – jen do logu
 */
function _performLogout(reason) {
    // 1) Zastav poller + Realtime websocket (ZÁSADNÍ – jinak by starý
    //    poller chvíli běžel s prázdným tokenem nebo starým stavem)
    try { stopSbPoller(); } catch (_) {}

    // 2) Vyčisti _pollerSeen Set
    _pollerSeen = new Set();
    _pollerHotovo = new Set();

    // 3) Vyčisti procesní frontu
    _processQueue = [];

    // 4) Vymaž STATE proměnné spojené se Supabase identitou
    STATE.sbAccessToken  = "";
    STATE.sbRefreshToken = "";
    STATE.sbUserId       = "";
    STATE.sbEmail        = "";
    STATE.sbAccountType  = "";

    // 5) Persistentně vymaž ze state.json
    try {
        const st = loadState();
        delete st.sb_refresh;
        delete st.sb_email;
        delete st.sb_account_type;
        saveState(st);
    } catch { /* nevadí */ }

    log("INFO", `SB_AUTH logout – ${reason || "?"}`, "stav vyčištěn");

    // 6) Oznam všem oknům že jsme odhlášeni (renderer ukáže přihlášení)
    try {
        const { BrowserWindow } = require("electron");
        for (const w of BrowserWindow.getAllWindows()) {
            if (!w.isDestroyed()) {
                w.webContents.send("supabase:status", { loggedIn: false });
            }
        }
    } catch (_) {}
}

/**
 * Vynucené odhlášení z jiného PC – volá ho device-presence.
 * Dělá přesně totéž co ruční odhlášení.
 */
function forceLogout() {
    _performLogout("remote (force_logout z jiného PC)");
}


function registerIpcHandlers() {
    ipcMain.handle("supabase:login", async (_evt, { cfg, emailOrName, username, password }) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const result = await sbLogin(resolvedCfg, emailOrName || username, password);
        if (result.ok) {
            // Uložit account_type pro persistenci
            try {
                const { loadState, saveState } = require("./utils");
                const st = loadState();
                st.sb_account_type = STATE.sbAccountType || "business";
                saveState(st);
            } catch { /* nevadí */ }
            // Auto-start polleru po přihlášení – ať uživatel nemusí klikat
            const saveDir = resolvedCfg.SAVE_DIR || "";
            if (saveDir && (resolvedCfg.SB_URL || "").trim()) {
                startSbPoller(resolvedCfg, saveDir);
            }
        }
        return { ...result, accountType: STATE.sbAccountType || "business" };
    });

    // Přihlášení firemním účtem BRITEX.
    // Nejde přes Custom Auth Providers – ty mají na straně Supabase chybu
    // („missing provider id“ v callbacku). Místo toho se technik přihlásí
    // do RTS, jeho token ověří Edge Funkce rts-sso a vrátí přihlášení.
    ipcMain.handle("supabase:login-britex", async (_evt, { cfg } = {}) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();

        let out;
        try {
            out = await require("./britex-sso").login(resolvedCfg);
        } catch (e) {
            log("WARN", "SB_AUTH britex", e.message);
            return { ok: false, error: e.message, accountType: "" };
        }
        if (!out || !out.ok) {
            return { ok: false, error: (out && out.error) || "Přihlášení se nezdařilo", accountType: "" };
        }

        const result = await sbAdoptSession(resolvedCfg, out.session);
        if (!result.ok) return result;

        const saveDir = resolvedCfg.SAVE_DIR || "";
        if (saveDir && (resolvedCfg.SB_URL || "").trim()) {
            startSbPoller(resolvedCfg, saveDir);
        }
        return { ...result, rtsReady: Boolean(out.rtsReady) };
    });

    // Zaregistrovat nového uživatele + auto-start polleru
    ipcMain.handle("supabase:register", async (_evt, { cfg, email, emailOrName, username, password, accountType }) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const result = await sbRegister(resolvedCfg, email || emailOrName || username, password, accountType || "business");
        if (result.ok) {
            // Persistuj account_type
            try {
                const st = loadState();
                st.sb_account_type = STATE.sbAccountType || accountType || "business";
                saveState(st);
            } catch { /* nevadí */ }
            // Auto-start polleru po registraci
            const saveDir = resolvedCfg.SAVE_DIR || "";
            if (saveDir && (resolvedCfg.SB_URL || "").trim()) {
                startSbPoller(resolvedCfg, saveDir);
            }
        }
        return { ...result, accountType: STATE.sbAccountType || accountType || "business" };
    });

    // Odhlásit – vymaž tokeny ze STATE
    ipcMain.handle("supabase:logout", () => {
        _performLogout("technician initiated");
    });

    // Vzdálené odhlášení vyžádané z jiného PC (presence broadcast).
    // PC 2 zavolá tohle → my pošleme force_logout na PC 1.
    ipcMain.handle("presence:request-remote-logout", (_evt, targetDeviceId) => {
        try {
            const dp = require("./device-presence");
            const ok = dp.requestRemoteLogout(targetDeviceId);
            return { ok: !!ok };
        } catch (e) {
            log("WARN", "PRESENCE remote-logout", e.message);
            return { ok: false };
        }
    });


    // Vrátit aktuální stav přihlášení
    ipcMain.handle("supabase:status", () => ({
        loggedIn:    Boolean(STATE.sbAccessToken),
        userId:      STATE.sbUserId      || "",
        email:       STATE.sbEmail       || "",
        accountType: STATE.sbAccountType || "business",
    }));

    // Alias – app.js volá supabase:state
    ipcMain.handle("supabase:state", () => ({
        loggedIn:    Boolean(STATE.sbAccessToken),
        userId:      STATE.sbUserId      || "",
        email:       STATE.sbEmail       || "",
        accountType: STATE.sbAccountType || "business",
    }));

    // Vrátit seznam nedávno použitých emailů (pro auto-suggest při loginu).
    // Uloženo v state.json jako pole sb_recent_emails (max 5 položek).
    ipcMain.handle("supabase:recent-emails", () => {
        try {
            const st = loadState();
            const recents = Array.isArray(st.sb_recent_emails) ? st.sb_recent_emails : [];
            // Pro zpětnou kompatibilitu zahrnout také sb_email pokud tam ještě není
            if (st.sb_email && !recents.includes(st.sb_email)) {
                recents.unshift(st.sb_email);
            }
            return recents.slice(0, 5);
        } catch {
            return [];
        }
    });

    // Reset hesla – volá login.html při kliknutí na "Zapomenuté heslo?"
    ipcMain.handle("supabase:reset-password", async (_evt, { email } = {}) => {
        const cfg    = require("../main/config").readConfig();
        const sbUrl  = _sbUrl(cfg);
        const sbAnon = (cfg.SB_ANON || "").trim();
        if (!email || !sbUrl || !sbAnon) {
            return { ok: false, error: "Chybí e-mail nebo konfigurace Supabase." };
        }
        try {
            const resp = await fetch(`${sbUrl}/auth/v1/recover`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon),
                body:    JSON.stringify({ email: email.trim() }),
                timeout: 10_000,
                agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
            });
            if (resp.ok || resp.status === 200) {
                log("INFO", "SB_AUTH reset-password", `Reset email odeslán: ${email}`);
                return { ok: true };
            }
            const data = await resp.json().catch(() => ({}));
            const msg  = data.msg || data.message || data.error_description || `HTTP ${resp.status}`;
            return { ok: false, error: msg };
        } catch (err) {
            log("WARN", "SB_AUTH reset-password", String(err));
            return { ok: false, error: String(err) };
        }
    });

        // Spustit poller (bez job - Varianta A, stahuje vše pro účet)
    ipcMain.handle("supabase:start-poller", (_evt, { cfg, saveDir } = {}) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const resolvedDir = saveDir || resolvedCfg.SAVE_DIR || "";
        startSbPoller(resolvedCfg, resolvedDir);
    });

    // Zastavit poller
    ipcMain.handle("supabase:stop-poller", () => {
        stopSbPoller();
    });

    // Manuálně seznam objektů ze Storage (pro diagnostiku / settings)
    ipcMain.handle("supabase:list-objects", async (_evt, { cfg, bucket, job }) => {
        return sbListObjects(cfg, bucket, job);
    });

    // Přehled nestažených zakázek z pb_queue
    ipcMain.handle("supabase:pending-jobs", async (_evt, { cfg } = {}) => {
        try {
            const resolvedCfg = cfg || require("../main/config").readConfig();
            const jobs = await sbGetPendingJobs(resolvedCfg);
            return { ok: true, jobs };
        } catch (err) {
            log("WARN", "supabase:pending-jobs", String(err));
            return { ok: false, error: String(err), jobs: [] };
        }
    });

    log("INFO", "supabase.js", "IPC handlery zaregistrovány");
}

// ─── EXPORT ──────────────────────────────────────────────────────────────────

/** Uloží aktuální session tokeny do state.json – volá se před app.quit() z updateru */
function persistSession() {
    try {
        if (!STATE.sbRefreshToken) return;
        const { loadState, saveState } = require('./utils');
        const st = loadState();
        st.sb_refresh      = STATE.sbRefreshToken;
        if (STATE.sbEmail)       st.sb_email        = STATE.sbEmail;
        if (STATE.sbAccountType) st.sb_account_type = STATE.sbAccountType;
        saveState(st);
    } catch { /* nevadí */ }
}

// ─────────────────────────────────────────────────────────────────────────────
//  ZPĚTNÁ VAZBA / CRASH REPORTY → tabulka public.feedback (insert-only, RLS)
//  Posílá se jako přihlášený uživatel. Když není token (pád před přihlášením),
//  uloží se do lokální fronty a odešle po nejbližším přihlášení.
// ─────────────────────────────────────────────────────────────────────────────
function _feedbackQueuePath() {
    const { app } = require("electron");
    return require("path").join(app.getPath("userData"), "feedback_queue.json");
}
function _readFeedbackQueue() {
    try {
        const fs = require("fs"); const p = _feedbackQueuePath();
        if (!fs.existsSync(p)) return [];
        const arr = JSON.parse(fs.readFileSync(p, "utf8"));
        return Array.isArray(arr) ? arr : [];
    } catch (_) { return []; }
}
function _writeFeedbackQueue(arr) {
    try { require("fs").writeFileSync(_feedbackQueuePath(), JSON.stringify(arr, null, 2), "utf8"); }
    catch (_) {}
}
function _queueFeedback(row) {
    const arr = _readFeedbackQueue();
    arr.push({ ...row, queued_at: new Date().toISOString() });
    _writeFeedbackQueue(arr.slice(-50));    // max 50 ve frontě
    log("INFO", "FEEDBACK", "uloženo do fronty (odešle se po přihlášení)");
}
async function _postFeedbackRow(cfg, row) {
    const sbUrl = _sbUrl(cfg);
    const anon  = (cfg.SB_ANON || "").trim();
    let token = STATE.sbAccessToken || "";
    if (!token) { try { token = await sbEnsureToken(cfg); } catch (_) {} }
    if (!token) return { ok: false, reason: "no-auth" };
    try {
        const resp = await fetch(`${sbUrl}/rest/v1/feedback`, {
            method:  "POST",
            headers: { ..._sbHeaders(anon, token), Prefer: "return=minimal" },
            body:    JSON.stringify(row),
            timeout: 10_000,
        });
        if (!resp.ok) {
            const t = await resp.text().catch(() => "");
            return { ok: false, reason: `http ${resp.status}`, detail: t };
        }
        return { ok: true };
    } catch (e) { return { ok: false, reason: e.message }; }
}

/**
 * Nahraje přílohu zpětné vazby do bucketu feedback-attachments (jen přihlášený, vlastní složka).
 * @param {object} cfg
 * @param {{name:string, contentType:string, buffer:Buffer}} file
 * @returns {Promise<{ok:boolean, path?:string, name?:string, reason?:string}>}
 */
async function sbUploadFeedbackImage(cfg, file) {
    const sbUrl = _sbUrl(cfg);
    const anon  = (cfg.SB_ANON || "").trim();
    let token = STATE.sbAccessToken || "";
    if (!token) { try { token = await sbEnsureToken(cfg); } catch (_) {} }
    const uid = STATE.sbUserId || "";
    if (!token || !uid) return { ok: false, reason: "no-auth" };

    const safe = String(file.name || "image.png").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-60);
    const objPath = `${uid}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safe}`;
    const url     = `${sbUrl}/storage/v1/object/feedback-attachments/${encodeURIComponent(objPath).replace(/%2F/g, "/")}`;
    try {
        const resp = await fetch(url, {
            method:  "POST",
            headers: {
                apikey:         anon,
                Authorization:  `Bearer ${token}`,
                "Content-Type": file.contentType || "image/png",
                "x-upsert":     "false",
            },
            body:    file.buffer,
            timeout: 30_000,
        });
        if (!resp.ok) {
            const t = await resp.text().catch(() => "");
            return { ok: false, reason: `http ${resp.status}`, detail: t };
        }
        return { ok: true, path: objPath, name: safe };
    } catch (e) { return { ok: false, reason: e.message }; }
}
/**
 * Odešle zpětnou vazbu nebo crash report do tabulky feedback.
 * @param {object} cfg
 * @param {{kind?:string, message:string, appVersion?:string}} opts
 */
async function sbInsertFeedback(cfg, opts = {}) {
    const os  = require("os");
    const row = {
        kind:        opts.kind === "crash" ? "crash" : "feedback",
        message:     String(opts.message || "").slice(0, 20000),
        app_version: opts.appVersion || "",
        hostname:    (() => { try { return os.hostname(); } catch (_) { return ""; } })(),
        email:       STATE.sbEmail || "",
        attachments: Array.isArray(opts.attachments) ? opts.attachments : [],
    };
    const res = await _postFeedbackRow(cfg, row);
    if (res.ok) return { ok: true };
    _queueFeedback(row);   // no-auth i síťová chyba → do fronty, ať se nic neztratí
    return { ok: false, queued: true, reason: res.reason };
}
/** Po přihlášení odešle vše z fronty. */
async function flushFeedbackQueue(cfg) {
    const arr = _readFeedbackQueue();
    if (!arr.length) return;
    const remain = [];
    for (const row of arr) {
        const res = await _postFeedbackRow(cfg, {
            kind: row.kind, message: row.message, app_version: row.app_version,
            hostname: row.hostname, email: row.email || STATE.sbEmail || "",
            attachments: Array.isArray(row.attachments) ? row.attachments : [],
        });
        if (!res.ok) remain.push(row);
    }
    _writeFeedbackQueue(remain);
    if (arr.length !== remain.length)
        log("INFO", "FEEDBACK", `fronta odeslána (${arr.length - remain.length}/${arr.length})`);
}

module.exports = {
    _finalizeToDisk,
    sbRestoreSession,
    sbLogin,
    sbAdoptSession,
    sbRegister,
    sbEnsureToken,
    sbInsertFeedback,
    sbUploadFeedbackImage,
    flushFeedbackQueue,
    sbListObjects,
    sbGetPendingJobs,
    sbDownload,
    sbDelete,
    startSbPoller,
    stopSbPoller,
    isSbPollerRunning,
    forceLogout,
    notifyFileReceived,
    showTestNotification,
    registerIpcHandlers,
    zapisVlozenouFotku,
    persistSession,
};
