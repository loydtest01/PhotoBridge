'use strict';
// ============================================================
// PhotoBridge – src/main/rts-auth.js
// Přihlášení technika do RTS (OAuth2 authorization_code + PKCE).
//
// PROČ PKCE: desktopová aplikace nemůže udržet client_secret v tajnosti –
// kdo rozebere instalaci, dostane se k němu. PKCE tenhle problém řeší:
// aplikace si pro každé přihlášení vygeneruje jednorázový pár
// (code_verifier / code_challenge) a secret nepotřebuje.
// Secret se pošle jen tehdy, když je v konfiguraci vyplněný (záloha,
// kdyby ho RTS vyžadovalo).
//
// TOKEN: přístupový token platí ~24 h. Když RTS vydá refresh_token,
// aplikace si nový token vyzvedne sama na pozadí a technik se
// nepřihlašuje znovu. Když refresh_token nedá, po vypršení se objeví
// výzva k opětovnému přihlášení (místo tichého selhání).
// ============================================================

const crypto = require('crypto');
const path   = require('path');
const fs     = require('fs');

function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

// ── Uložení tokenů (per Windows účet, mimo složku aplikace) ──────────────────

function _tokenPath() {
    const { app } = require('electron');
    return path.join(app.getPath('userData'), 'rts_session.json');
}

function loadSession() {
    try {
        const p = _tokenPath();
        if (!fs.existsSync(p)) return null;
        return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (_) { return null; }
}

function saveSession(sess) {
    try {
        fs.writeFileSync(_tokenPath(), JSON.stringify(sess, null, 2), 'utf8');
        log('INFO', 'RTS_AUTH', `Session uložena (platnost do ${new Date(sess.expiresAt).toLocaleString('cs-CZ')})`);
    } catch (e) {
        log('ERROR', 'RTS_AUTH', `Uložení session selhalo: ${e.message}`);
    }
}

function clearSession() {
    try { fs.unlinkSync(_tokenPath()); } catch (_) {}
}

// ── PKCE ────────────────────────────────────────────────────────────────────

function _b64url(buf) {
    return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function makePkce() {
    const verifier  = _b64url(crypto.randomBytes(32));
    const challenge = _b64url(crypto.createHash('sha256').update(verifier).digest());
    return { verifier, challenge };
}

// ── Přihlašovací okno ───────────────────────────────────────────────────────

/**
 * Otevře okno s přihlášením do RTS a po úspěchu uloží tokeny.
 * @returns {Promise<{ok:boolean, user?:string, error?:string}>}
 */
async function login() {
    const { BrowserWindow } = require('electron');
    const rts = require('./rts-api');
    const cfg = require('./config').readConfig();

    const clientId = String(cfg.RTS_CLIENT_ID || '').trim();
    if (!clientId) return { ok: false, error: 'Chybí client_id (nastavuje se centrálně v Supabase)' };

    // Redirect na adresu, kterou nikam nevede – zachytíme ji dřív, než se načte
    const redirectUri = String(cfg.RTS_REDIRECT_URI || 'https://vfxurqshbibaibqssjyz.supabase.co/auth/v1/callback');
    const pkce  = makePkce();
    const state = _b64url(crypto.randomBytes(16));

    const authUrl = `${rts.baseUrl()}/oauth/Authorize`
        + `?response_type=code`
        + `&client_id=${encodeURIComponent(clientId)}`
        + `&redirect_uri=${encodeURIComponent(redirectUri)}`
        + `&scope=${encodeURIComponent(String(cfg.RTS_SCOPES || 'user'))}`
        + `&state=${encodeURIComponent(state)}`
        + `&code_challenge=${encodeURIComponent(pkce.challenge)}`
        + `&code_challenge_method=S256`;

    return new Promise((resolve) => {
        const win = new BrowserWindow({
            width: 520, height: 700, title: 'Přihlášení do RTS',
            autoHideMenuBar: true,
            webPreferences: { nodeIntegration: false, contextIsolation: true, partition: 'persist:rts' },
        });

        let settled = false;
        const finish = (result) => {
            if (settled) return;
            settled = true;
            try { win.destroy(); } catch (_) {}
            resolve(result);
        };

        // Zachyť přesměrování s kódem
        const onNavigate = async (url) => {
            if (!url || !url.startsWith(redirectUri.split('?')[0])) return;
            try {
                const u    = new URL(url);
                const code = u.searchParams.get('code');
                const err  = u.searchParams.get('error');
                const st   = u.searchParams.get('state');

                if (err)   return finish({ ok: false, error: `RTS: ${err}` });
                if (!code) return;   // ještě není kód – nech běžet
                if (st && st !== state) return finish({ ok: false, error: 'Neplatný state (možný útok)' });

                log('INFO', 'RTS_AUTH', 'Kód přijat, měním za token…');
                const tok = await rts.exchangeCode(code, redirectUri, pkce.verifier);
                if (!tok) return finish({ ok: false, error: 'Výměna kódu za token selhala' });

                const test = await rts.testConnection();
                finish(test.ok
                    ? { ok: true, user: test.user }
                    : { ok: false, error: test.error || 'Token nefunguje' });
            } catch (e) {
                finish({ ok: false, error: String(e.message || e) });
            }
        };

        win.webContents.on('will-redirect',  (_, url) => onNavigate(url));
        win.webContents.on('will-navigate',  (_, url) => onNavigate(url));
        win.webContents.on('did-navigate',   (_, url) => onNavigate(url));
        win.on('closed', () => finish({ ok: false, error: 'Přihlášení zrušeno' }));

        log('INFO', 'RTS_AUTH', `Otevírám přihlášení: ${rts.baseUrl()}/oauth/Authorize`);
        win.loadURL(authUrl).catch((e) => finish({ ok: false, error: String(e.message || e) }));
    });
}

/** Odhlásí technika z RTS (smaže uložené tokeny). */
function logout() {
    clearSession();
    try { require('./rts-api').setToken(null, 0); } catch (_) {}
    log('INFO', 'RTS_AUTH', 'Odhlášeno z RTS');
    return { ok: true };
}

/** Stav přihlášení pro UI. */
function status() {
    const sess = loadSession();
    if (!sess || !sess.accessToken) return { loggedIn: false };
    const valid = Date.now() < (sess.expiresAt || 0);
    return {
        loggedIn:   true,
        user:       sess.user || '',
        expiresAt:  sess.expiresAt || 0,
        expired:    !valid,
        canRefresh: !!sess.refreshToken,
    };
}

module.exports = { login, logout, status, loadSession, saveSession, clearSession, makePkce };
