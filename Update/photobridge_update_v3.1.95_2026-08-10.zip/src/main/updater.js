'use strict';
// ============================================================
// PhotoBridge – src/main/updater.js
// Systém automatických aktualizací přes lokální / síťovou složku
// + pevně zakódovaný GitHub zdroj (loydtest01/PhotoBridge/Update).
//
// Princip (CHAIN UPDATE od v2.2.0):
//   1. Při startu (tiše) nebo na žádost (manuálně z UI) prohledá:
//        a) GitHub repo:   GITHUB_UPDATE_REPO / GITHUB_UPDATE_BRANCH / GITHUB_UPDATE_FOLDER
//        b) Lokální cestu: UPD_SERVER_PATH z konfigurace
//   2. Sbírá VŠECHNY ZIPy novější než aktuální verze (ne jen nejnovější)
//   3. Seřadí je vzestupně (nejstarší první) → např. 2.1.3, 2.1.5, 2.2.0, 2.3.1, 2.3.3
//   4. Stáhne všechny GitHub ZIPy do %TEMP%
//   5. Rozbaluje je jeden po druhém do STEJNÉ temp složky — novější přepíše starší
//      (pokud je settings.html v 2.1.5 i v 2.3.3, vyhraje 2.3.3)
//   6. PowerShell skript zkopíruje sloučenou složku s UAC
//   7. Aplikace se automaticky restartuje
//
// DŮLEŽITÉ: package.json musí mít "asar": false
// ============================================================

const fs       = require('fs');
const path     = require('path');
const os       = require('os');
const https    = require('https');
const { app, dialog, nativeImage, ipcMain, BrowserWindow } = require('electron');
const { spawnSync, spawn }                  = require('child_process');

// ── Lazy import – config a utils se načtou až po jejich inicializaci ──────────
const getConfig = () => require('./config');
const getUtils  = () => { try { return require('./utils'); } catch { return null; } };

// ── Progress okno ─────────────────────────────────────────────────────────────
const RENDERER_DIR  = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH  = path.join(__dirname, '..', '..', 'preload.js');

let _progressWin = null;
let _lastProgress = null;  // buffer – poslední stav pro případ rychlého PC

// Otevře progress okno a vrátí Promise která se splní až je renderer připravený přijímat IPC.
function _openProgressWindow() {
  return new Promise((resolve) => {
    if (_progressWin && !_progressWin.isDestroyed()) { resolve(); return; }

    _progressWin = new BrowserWindow({
      width:           420,
      height:          210,
      resizable:       false,
      maximizable:     false,
      minimizable:     false,
      fullscreenable:  false,
      alwaysOnTop:     true,
      frame:           true,
      autoHideMenuBar: true,
      title:           'PhotoBridge – Aktualizace',
      icon:            resolveIcon('icon.ico'),
      webPreferences: {
        preload:          PRELOAD_PATH,
        contextIsolation: true,
        nodeIntegration:  false,
        sandbox:          false,
        devTools:         false,
      },
      show: false,
    });

    _progressWin.loadFile(path.join(RENDERER_DIR, 'update-progress.html'));

    // Resolve až po ready-to-show + krátký delay.
    // ready-to-show = okno je vizuálně vykresleno, ale renderer JS
    // (ipcRenderer.on listeners) ještě nemusí být zaregistrován.
    // Bez delay přijdou IPC zprávy dřív než renderer naslouchá → zahozeny → 0%.
    // Handshake: renderer pošle 'update-progress:ready' jakmile zaregistruje listener.
    // Po handshake okamžitě přehrajeme poslední stav – na rychlém PC může být update
    // už dokončen dřív než renderer zobrazí první snímek.
    let resolved = false;
    const doResolve = () => { if (!resolved) { resolved = true; resolve(); } };

    ipcMain.once('update-progress:ready', () => {
      // Okamžitě pošli aktuální stav ať renderer neukáže 0%
      if (_lastProgress && _progressWin && !_progressWin.isDestroyed()) {
        try { _progressWin.webContents.send('update-progress', _lastProgress); } catch (_) {}
      }
      doResolve();
    });

    _progressWin.once('ready-to-show', () => {
      if (_progressWin && !_progressWin.isDestroyed()) {
        _progressWin.show();
      } else {
        doResolve();
      }
    });

    _progressWin.on('closed', () => { _progressWin = null; doResolve(); });

    // Záchrana – kdyby renderer nikdy handshake neposlal (5 s)
    setTimeout(doResolve, 5000);
  });
}

function _sendProgress(pct, main, sub = '') {
  _lastProgress = { pct, main, sub };  // vždy ulož, i když okno ještě není
  if (_progressWin && !_progressWin.isDestroyed()) {
    try { _progressWin.webContents.send('update-progress', { pct, main, sub }); } catch (_) {}
  }
}

function _closeProgressWindow() {
  if (_progressWin && !_progressWin.isDestroyed()) {
    try { _progressWin.destroy(); } catch (_) {}
    _progressWin = null;
  }
}

// ── Logování (fallback na console pokud utils ještě není načten) ──────────────
function log(level, context, msg) {
  const u = getUtils();
  if (u && u.log) {
    u.log(level, context, msg);
  } else {
    console.log(`[${new Date().toISOString()}] [${level}] [${context}]`, msg);
  }
}

// ── Persistentní diagnostický log – přežije pád aplikace ─────────────────────
// Soubor: %TEMP%\photobridge_diag.log
// Otevři: notepad %TEMP%\photobridge_diag.log
const _diagLogPath = path.join(os.tmpdir(), 'photobridge_diag.log');
function diagLog(msg) {
  try {
    const line = `${new Date().toISOString().replace('T',' ').substring(0,23)}  ${msg}\n`;
    fs.appendFileSync(_diagLogPath, line, 'utf8');
  } catch (_) {}
  // Také do standardního logu
  log('INFO', 'updater-diag', msg);
}
// Zapíše hlavičku při každém startu modulu
try {
  fs.appendFileSync(_diagLogPath,
    `\n${'='.repeat(72)}\n` +
    `UPDATER START  ${new Date().toISOString()}  pid=${process.pid}\n` +
    `${'='.repeat(72)}\n`, 'utf8');
} catch (_) {}

// ── Konstanty ─────────────────────────────────────────────────────────────────
const APP_SLUG    = 'photobridge';   // prefix názvů update ZIPů
const APP_VERSION = app.getVersion();

// ── GitHub zdroj – pevně zakódovaný (NEZAVISÍ na konfiguraci) ────────────────
const GITHUB_UPDATE_OWNER  = 'loydtest01';
const GITHUB_UPDATE_REPO   = 'PhotoBridge';
const GITHUB_UPDATE_BRANCH = 'main';
const GITHUB_UPDATE_FOLDER = 'Update';

// Klíč v state.json pro zapamatování posledně nainstalované verze
const STATE_KEY_LAST_ZIP = 'lastInstalledZip';

// Midnight scheduler handle
let _midnightTimer = null;
let _updateQuitPending = false;  // TRUE pokud quit = instalace aktualizace (nesmíme smazat update_pending.json)

// ── Ukládání stavu (GET_LAST / SAVE_LAST) ────────────────────────────────────
function _getLastZip() {
  try {
    const u = getUtils();
    if (u && u.loadState) {
      const st = u.loadState();
      return st[STATE_KEY_LAST_ZIP] || '';
    }
  } catch (_) {}
  try {
    const p = path.join(app.getPath('userData'), 'updater_state.json');
    if (fs.existsSync(p)) {
      return JSON.parse(fs.readFileSync(p, 'utf8'))[STATE_KEY_LAST_ZIP] || '';
    }
  } catch (_) {}
  return '';
}

function _saveLastZip(basename) {
  try {
    const u = getUtils();
    if (u && u.loadState && u.saveState) {
      const st = u.loadState();
      st[STATE_KEY_LAST_ZIP] = basename;
      u.saveState(st);
      return;
    }
  } catch (_) {}
  try {
    const p = path.join(app.getPath('userData'), 'updater_state.json');
    const existing = fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : {};
    existing[STATE_KEY_LAST_ZIP] = basename;
    fs.writeFileSync(p, JSON.stringify(existing, null, 2), 'utf8');
  } catch (_) {}
}

// ── Texty dialogů (česky) ─────────────────────────────────────────────────────
const STRINGS = {
  noFolderTitle:  'Aktualizace',
  noFolderMsg:    'Složka pro aktualizace není nastavena nebo neexistuje.',
  noFolderDetail: 'Nastavte cestu ke složce s aktualizacemi v Nastavení → Systém.',
  noUpdateTitle:  'Aktualizace',
  noUpdateMsg:    'Žádná nová aktualizace nenalezena.',
  alreadyTitle:   'Aktualizace',
  alreadyMsg:     (versionLabel, currentVer, basename) =>
    `Verze ${versionLabel} je již nainstalována.\n\nAktuální verze: v${currentVer}\nSoubor: ${basename}`,
  foundTitle:     '🔄 Nalezena aktualizace',
  foundMsgSingle: (versionLabel, date, source) =>
    `Nalezena aktualizace ${versionLabel} (${date})\nZdroj: ${source}`,
  foundMsgChain:  (fromVer, toVer, count, source) =>
    `Nalezeno ${count} aktualizací: v${fromVer} → v${toVer}\nZdroj: ${source}`,
  foundDetail:    'Chcete nainstalovat aktualizaci nyní?\n\n• Nainstalovat hned — aplikace se aktualizuje a restartuje\n• Odložit — připomene se při příštím spuštění\n• Zrušit — aktualizace nebude nainstalována',
  foundDetailChain: (versions) =>
    `Budou nainstalovány v pořadí:\n${versions}\n\n• Nainstalovat hned — aplikace se aktualizuje a restartuje\n• Odložit — připomene se při příštím spuštění\n• Zrušit — aktualizace nebude nainstalována`,
  btnInstall:     'Nainstalovat hned',
  btnDefer:       'Odložit',
  btnCancel:      'Zrušit',
  extractError:   'Chyba při rozbalování ZIPu',
  ok:             'OK',
};

// ── Ikony ─────────────────────────────────────────────────────────────────────
const FALLBACK_ICON_B64 =
  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAbklEQVR42mNk' +
  'YGD4z8BAAAACAAHgAQABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQ' +
  'ABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYA' +
  'JwAoACkAKgArACwALQAuAC8AMAAAAElFTkSuQmCC';

function resolveIcon(filename) {
  const alt = filename.endsWith('.ico')
    ? filename.replace('.ico', '.png')
    : filename.replace('.png', '.ico');

  const candidates = [];
  for (const name of [filename, alt]) {
    candidates.push(
      path.join(__dirname, '../../assets/icons', name),
      path.join(__dirname, '../../../assets/icons', name),
      path.join(process.resourcesPath || '', 'app', 'assets', 'icons', name),
      path.join(process.resourcesPath || '', 'assets', 'icons', name),
      path.join(process.resourcesPath || '', 'assets', name),
      path.join(process.resourcesPath || '', name),
      path.join(path.dirname(app.getPath('exe')), 'assets', 'icons', name),
      path.join(path.dirname(app.getPath('exe')), 'assets', name),
      path.join(__dirname, 'assets', 'icons', name),
      path.join(__dirname, 'assets', name),
    );
  }

  for (const p of candidates) {
    try { if (fs.existsSync(p)) return p; } catch (_) {}
  }
  return null;
}

function resolveIconImage(filename) {
  const iconPath = resolveIcon(filename);
  if (iconPath) {
    const img = nativeImage.createFromPath(iconPath);
    if (!img.isEmpty()) return img;
  }
  return nativeImage.createFromDataURL('data:image/png;base64,' + FALLBACK_ICON_B64);
}

// ── Porovnání verzí (semver) ──────────────────────────────────────────────────
/**
 * @returns {number} 1 pokud a > b, -1 pokud a < b, 0 pokud stejné
 */
function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

// ── Řazení kandidátů vzestupně (nejstarší první) ──────────────────────────────
function _sortAscending(candidates) {
  return [...candidates].sort((a, b) => {
    if (a.version && b.version) {
      const cmp = compareVersions(a.version, b.version);
      if (cmp !== 0) return cmp;
    } else if (a.version && !b.version) return -1;
    else if (!a.version && b.version) return 1;
    if (a.date < b.date) return -1;
    if (a.date > b.date) return 1;
    return (a.build || -1) - (b.build || -1);
  });
}

// ── Regex pro názvy update ZIPů ───────────────────────────────────────────────
const slugEsc  = APP_SLUG.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ZIP_REGEX = new RegExp(
  `^${slugEsc}_update_(?:v([\\d.]+)_)?(\\d{4}-\\d{2}-\\d{2})(?:_(\\d+))?\\.zip$`
);

// ── Pomocník: HTTPS GET → string ─────────────────────────────────────────────
function httpsGet(url, timeoutMs = 10000, pat = '') {
  return new Promise((resolve, reject) => {
    const headers = { 'User-Agent': `PhotoBridge-Updater/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        return resolve(httpsGet(res.headers.location, timeoutMs, pat));
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} pro ${url}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', reject);
  });
}

// ── Pomocník: HTTPS GET → Buffer (stahování souborů) ─────────────────────────
function httpsDownload(url, destPath, timeoutMs = 120000, pat = '') {
  return new Promise((resolve, reject) => {
    const file    = fs.createWriteStream(destPath);
    const headers = { 'User-Agent': `PhotoBridge-Updater/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        file.close();
        return resolve(httpsDownload(res.headers.location, destPath, timeoutMs, pat));
      }
      if (res.statusCode !== 200) {
        file.close();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(destPath); });
      file.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('Timeout stahování')); });
    req.on('error', reject);
  });
}

// ── Hledání VŠECH ZIPů v GitHub složce ───────────────────────────────────────
/**
 * Vrátí VŠECHNY update ZIPy z GitHub složky jako pole kandidátů.
 * @param {string} pat – GitHub Personal Access Token (může být prázdný pro public repo)
 * @returns {Promise<Array>}
 */
async function _findAllInGitHub(pat = '') {
  const apiUrl = `https://api.github.com/repos/${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/contents/${GITHUB_UPDATE_FOLDER}?ref=${GITHUB_UPDATE_BRANCH}`;
  log('INFO', 'updater', `GitHub check: ${apiUrl} ${pat ? '[auth]' : '[no-auth]'}`);

  let items;
  try {
    const body = await httpsGet(apiUrl, 10000, pat);
    items = JSON.parse(body);
  } catch (e) {
    log('WARN', 'updater', `GitHub API nedostupné: ${e.message}${!pat ? ' (tip: nastav GITHUB_PAT pro soukromé repo)' : ''}`);
    return [];
  }

  if (!Array.isArray(items)) {
    log('WARN', 'updater', 'GitHub API vrátilo neočekávaný formát');
    return [];
  }

  const results = [];
  for (const item of items) {
    if (item.type !== 'file') continue;
    const match = item.name.match(ZIP_REGEX);
    if (!match) continue;

    const [, ver, date, build] = match;
    results.push({
      file:     item.download_url,
      version:  ver  || '',
      date:     date,
      build:    build ? parseInt(build, 10) : -1,
      source:   'github',
      basename: item.name,
    });
  }

  log('INFO', 'updater', `GitHub – nalezeno ${results.length} update ZIPů`);
  return results;
}

// ── Hledání VŠECH ZIPů v lokální / síťové složce ─────────────────────────────
/**
 * @param {string} updateDir – absolutní cesta ke složce
 * @returns {Array<{file, version, date, build, source, basename}>}
 */
function _findAllInLocal(updateDir) {
  let entries;
  try { entries = fs.readdirSync(updateDir); } catch (e) {
    log('ERROR', 'updater', `Nelze číst složku aktualizací: ${e.message}`);
    return [];
  }

  const results = [];
  for (const file of entries) {
    const match = file.match(ZIP_REGEX);
    if (!match) continue;

    const [, ver, date, build] = match;
    results.push({
      file:     path.join(updateDir, file),
      version:  ver  || '',
      date:     date,
      build:    build ? parseInt(build, 10) : -1,
      source:   'local',
      basename: file,
    });
  }

  log('INFO', 'updater', `Lokální složka – nalezeno ${results.length} update ZIPů`);
  return results;
}

// ── Deduplikace kandidátů (stejná verze → preferuj github, pak local) ────────
/**
 * Sloučí GitHub a lokální kandidáty: stejná verze → jedna položka (github preferován).
 * @param {Array} github
 * @param {Array} local
 * @returns {Array}
 */
function _mergeAndDedup(github, local) {
  const map = new Map();

  // Nejdříve lokální
  for (const c of local) {
    const key = c.version || `${c.date}_${c.build}`;
    map.set(key, c);
  }
  // GitHub přepíše (preferujeme GitHub jako zdroj)
  for (const c of github) {
    const key = c.version || `${c.date}_${c.build}`;
    map.set(key, c);
  }

  return Array.from(map.values());
}

// ── Filtrování: jen ZIPy NOVĚJŠÍ než aktuální verze ──────────────────────────
/**
 * Z pole všech kandidátů vrátí jen ty novější než `currentVersion`.
 * @param {Array} all
 * @param {string} currentVersion – např. "2.1.2"
 * @returns {Array}
 */
function _filterNewer(all, currentVersion) {
  return all.filter(c => {
    if (c.version) {
      return compareVersions(c.version, currentVersion) > 0;
    }
    // Bez čísla verze: vezmeme vždy (nelze spolehlivě porovnat)
    return true;
  });
}

// ── Stažení GitHub ZIPu do %TEMP% ────────────────────────────────────────────
async function _downloadGitHubZip(downloadUrl, basename, pat = '') {
  const tmpDir  = path.join(os.tmpdir(), `${APP_SLUG}_github_zip`);
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const destPath = path.join(tmpDir, basename);

  if (fs.existsSync(destPath)) {
    log('INFO', 'updater', `GitHub ZIP již v cache: ${destPath}`);
    return destPath;
  }

  log('INFO', 'updater', `Stahuji GitHub ZIP: ${downloadUrl}`);
  await httpsDownload(downloadUrl, destPath, 120000, pat);
  log('INFO', 'updater', `GitHub ZIP stažen: ${destPath}`);
  return destPath;
}

// ── Sekvenční rozbalování chain update ───────────────────────────────────────
/**
 * @param {Array}  chain
 * @param {string} tmpExtract
 * @param {string} pat        – GitHub PAT pro stahování
 */
async function _applyChain(chain, tmpExtract, pat = '', onProgress = null) {
  diagLog(`_applyChain: ${chain.length} ZIPů, tmpExtract=${tmpExtract}`);
  if (fs.existsSync(tmpExtract)) {
    try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch (_) {}
  }
  fs.mkdirSync(tmpExtract, { recursive: true });
  const changelogs = [];

  const total = chain.length;

  for (let i = 0; i < total; i++) {
    const candidate = chain[i];
    const label = candidate.version ? `v${candidate.version}` : candidate.date;
    log('INFO', 'updater', `Chain: rozbaluji ${candidate.basename} [${candidate.source}]`);
    diagLog(`Rozbaluji [${i+1}/${total}]: ${candidate.basename} zdroj=${candidate.source} file=${candidate.file}`);

    if (onProgress) {
      const pct = 15 + (i / total) * 60;
      onProgress(pct, `Rozbaluji aktualizaci… (${i + 1}/${total})`, candidate.basename);
    }

    // Získej lokální cestu k ZIPu
    let zipPath;
    if (candidate.source === 'github') {
      zipPath = await _downloadGitHubZip(candidate.file, candidate.basename, pat);
    } else {
      zipPath = candidate.file;
    }

    // Rozbal do tmpExtract (přepíše existující soubory)
    // DŮLEŽITÉ: spawn() místo spawnSync() – spawnSync blokuje hlavní thread,
    // čímž zamrzne progress okno (alwaysOnTop) a celá Windows shell!
    //
    // Windows: PowerShell Expand-Archive (je všude, nic se neinstaluje).
    // Linux/macOS: unzip -o. Windowsová větev zůstává beze změny.
    const isWin = process.platform === 'win32';
    const extractCmd = `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${tmpExtract.replace(/'/g, "''")}' -Force`;
    await new Promise((resolve, reject) => {
      const child = isWin
        ? spawn(
            'powershell.exe',
            ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', extractCmd],
            { stdio: 'pipe' }
          )
        : spawn('unzip', ['-o', '-q', zipPath, '-d', tmpExtract], { stdio: 'pipe' });

      let stderr = '';
      if (child.stderr) child.stderr.on('data', d => { stderr += d.toString(); });

      // Timeout záchrana – pokud PS visí déle než 3 minuty, zabijem ho
      const timeoutId = setTimeout(() => {
        try { child.kill(); } catch (_) {}
        reject(new Error(`Timeout rozbalování ZIPu (${label}) – ${isWin ? 'PowerShell' : 'unzip'} neodpovídal 3 min`));
      }, 180000);

      child.on('close', code => {
        clearTimeout(timeoutId);
        if (code !== 0) {
          const errMsg = stderr.trim()
            || (isWin ? `PowerShell exit code ${code}`
                      : `unzip exit code ${code} (je unzip nainstalovaný? apt install unzip)`);
          reject(new Error(`${STRINGS.extractError} (${label}): ${errMsg}`));
        } else {
          resolve();
        }
      });

      child.on('error', err => {
        clearTimeout(timeoutId);
        reject(new Error(`${STRINGS.extractError} (${label}): ${err.message}`));
      });
    });

    log('INFO', 'updater', `Chain: ${label} rozbaleno OK`);

    // Přečti changelog z package.json tohoto ZIPu, dokud ho příští ZIP nepřepíše
    try {
      const pkgPath = path.join(tmpExtract, 'package.json');
      if (fs.existsSync(pkgPath)) {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
        if (pkg.changelog) {
          const entries = Array.isArray(pkg.changelog) ? pkg.changelog : [pkg.changelog];
          changelogs.push(...entries);
        }
      }
    } catch (_) {}
  }

  log('INFO', 'updater', `Chain: všech ${chain.length} ZIPů rozbaleno do ${tmpExtract}`);
  return changelogs;
}

// ── Hlavní funkce: checkForUpdates ───────────────────────────────────────────
/**
 * Zkontroluje oba zdroje, sestaví řetěz aktualizací a nabídne sekvenční instalaci.
 *
 * @param {boolean} manual – true = voláno z UI (zobrazí dialog i "nic nového")
 * @returns {Promise<void>}
 */
/**
 * Načte seznam urgentních verzí ze souboru Update/urgent.json v repozitáři.
 *
 * PROČ SOUBOR A NE NÁZEV ZIPU
 * Název balíčku hlídá přísný regulární výraz. Přidat do něj příznak by
 * znamenalo změnit i každou starší instalaci, která ten výraz používá –
 * a ty by pak nové balíčky přestaly vidět. Samostatný soubor je bezpečný:
 * kdo ho neumí přečíst, chová se jako dosud.
 *
 * Tvar:  { "urgent": ["3.1.81", "3.1.85"] }
 */
async function _fetchUrgentList() {
  try {
    const url = `https://raw.githubusercontent.com/${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}`
              + `/${GITHUB_UPDATE_BRANCH}/${GITHUB_UPDATE_FOLDER}/urgent.json?t=${Date.now()}`;
    const resp = await fetch(url, { timeout: 8000 });
    if (!resp.ok) return [];
    const data = await resp.json();
    const list = Array.isArray(data?.urgent) ? data.urgent : [];
    return list.map(v => String(v).trim()).filter(Boolean);
  } catch (_) {
    return [];        // nedostupný soubor = žádná urgentní verze, jedeme postaru
  }
}

async function checkForUpdates(manual = false, autoInstall = false) {
  const S = STRINGS;
  diagLog(`checkForUpdates START (manual=${manual}, autoInstall=${autoInstall}, APP_VERSION=${APP_VERSION})`);

  try {
    const cfg       = getConfig().readConfig();
    const updateDir = (cfg.UPD_SERVER_PATH || '').trim();
    const pat       = (cfg.GITHUB_PAT || '').trim();
    diagLog(`updateDir="${updateDir}", pat=${pat ? 'nastaveno' : 'prázdné'}`);

    // ── 1. Paralelně sesbírej VŠECHNY ZIPy z obou zdrojů ─────────────────
    const [githubAll, localAll] = await Promise.all([
      _findAllInGitHub(pat),
      updateDir && fs.existsSync(updateDir)
        ? Promise.resolve(_findAllInLocal(updateDir))
        : Promise.resolve([]),
    ]);
    diagLog(`GitHub ZIPy nalezeny: ${githubAll.length}, Lokální ZIPy: ${localAll.length}`);

    if (localAll.length === 0 && updateDir) {
      log('WARN', 'updater', `Lokální složka nenalezena nebo prázdná: "${updateDir}"`);
    }

    // ── 2. Slouč (dedup) a vyfiltruj jen novější než aktuální verze ───────
    const allCandidates = _mergeAndDedup(githubAll, localAll);
    const newer         = _filterNewer(allCandidates, APP_VERSION);

    if (newer.length === 0) {
      log('INFO', 'updater', `Žádné nové aktualizace (aktuální: v${APP_VERSION}).`);
      if (manual) {
        const detail = updateDir
          ? `Zkontrolováno:\n• GitHub: ${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/${GITHUB_UPDATE_FOLDER}\n• Lokální složka: ${updateDir}`
          : `Zkontrolováno:\n• GitHub: ${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/${GITHUB_UPDATE_FOLDER}\n• Lokální složka: (nenastavena)`;
        await dialog.showMessageBox({
          type: 'info', title: S.noUpdateTitle,
          message: S.noUpdateMsg,
          detail,
          buttons: [S.ok],
        });
      }
      return;
    }

    // ── 3. Seřaď vzestupně (nejstarší → nejnovější) ───────────────────────
    const chain   = _sortAscending(newer);
    const first   = chain[0];
    const last    = chain[chain.length - 1];
    const lastVer = last.version ? `v${last.version}` : last.date;

    const sourceName = chain.every(c => c.source === 'github')
      ? `GitHub (${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO})`
      : chain.every(c => c.source === 'local')
        ? `Lokální složka`
        : `GitHub + Lokální složka`;

    log('INFO', 'updater', `Chain update: ${chain.length} ZIPů [${chain.map(c => c.basename).join(' → ')}]`);

    // ── 4. Zkontroluj jestli je poslední již nainstalovaná ────────────────
    const lastInstalled = _getLastZip();
    const alreadyByName = (lastInstalled === last.basename);
    const alreadyByVer  = last.version && (compareVersions(APP_VERSION, last.version) >= 0);

    if (alreadyByName || alreadyByVer) {
      log('INFO', 'updater', `Již aktuální: current=v${APP_VERSION}, newest=${lastVer}`);
      if (manual) {
        await dialog.showMessageBox({
          type: 'info', title: S.alreadyTitle,
          message: S.alreadyMsg(lastVer, APP_VERSION, last.basename),
          buttons: [S.ok],
        });
      }
      return;
    }

    // ── 5. Dialog pro uživatele ───────────────────────────────────────────
    let message, detail;

    if (chain.length === 1) {
      message = S.foundMsgSingle(lastVer, last.date, sourceName);
      detail  = S.foundDetail;
    } else {
      const fromVer = first.version || first.date;
      const toVer   = last.version  || last.date;
      message = S.foundMsgChain(fromVer, toVer, chain.length, sourceName);
      const versionList = chain
        .map((c, i) => `  ${i + 1}. ${c.basename}`)
        .join('\n');
      detail = S.foundDetailChain(versionList);
    }

    // ── Urgentní aktualizace ────────────────────────────────────────────
    // Řeší vážnou chybu (fotky neodcházejí apod.) a instaluje se bez ptaní.
    // Stačí, aby urgentní byla KTERÁKOLI verze v řetězu – běžné verze před ní
    // se nainstalují s ní, jinak by se přeskočily a aplikace by se rozbila.
    let jeUrgentni = false;
    try {
      const urgentni = await _fetchUrgentList();
      if (urgentni.length) {
        const vRetezu = chain.map(c => String(c.version || '').trim()).filter(Boolean);
        const nalezene = vRetezu.filter(v => urgentni.includes(v));
        if (nalezene.length) {
          jeUrgentni = true;
          log('INFO', 'updater',
            `URGENTNÍ aktualizace (${nalezene.join(', ')}) – instaluji bez ptaní.`
            + (chain.length > 1 ? ` Řetěz nese i ${chain.length - nalezene.length} běžných.` : ''));
          diagLog(`URGENTNÍ: ${nalezene.join(', ')} | celý řetěz: ${vRetezu.join(' → ')}`);
        }
      }
    } catch (_) {}

    // Pokud autoInstall=true (půlnoční scheduler) nebo je aktualizace urgentní,
    // dialog NEUKAZUJ a rovnou pokračuj k instalaci. Jinak se uživatel ptá.
    if (autoInstall || jeUrgentni) {
      log('INFO', 'updater',
        `${jeUrgentni ? 'URGENT-install' : 'Auto-install'}: ${chain.length} ZIP(ů), poslední ${lastVer} (bez dialogu)`);
      diagLog(`${jeUrgentni ? 'URGENTNÍ' : 'AUTO'}-INSTALL spuštěno bez dialogu uživatele.`);
    } else {
      const { response } = await dialog.showMessageBox({
        type:      'info',
        title:     S.foundTitle,
        message,
        detail,
        buttons:   [S.btnInstall, S.btnDefer, S.btnCancel],
        defaultId: 0,
        cancelId:  2,
      });

      if (response === 2) { log('INFO', 'updater', 'Uživatel zrušil aktualizaci.');  return; }
      if (response === 1) { log('INFO', 'updater', 'Uživatel odložil aktualizaci.'); return; }
    }

    // ── Otevři progress okno a počkej než je renderer připravený ────────
    diagLog(`Uživatel potvrdil instalaci. Chain: ${chain.length} ZIP(ů), poslední: ${lastVer}`);
    diagLog(`Otvírám progress okno...`);
    await _openProgressWindow();
    diagLog(`Progress okno otevřeno.`);
    _sendProgress(0, 'Připravuji aktualizaci…', lastVer);

    // ── ZÁLOHA před aktualizací ───────────────────────────────────────────
    _sendProgress(5, 'Zálohuji aplikaci…');
    diagLog(`Spouštím zálohu (v${APP_VERSION})...`);
    try {
      const backup = require('./backup');
      const backupResult = await backup.createBackupAsync(APP_VERSION);
      if (!backupResult.ok) {
        diagLog(`WARN: Záloha se nepodařila: ${backupResult.error}`);
        log('WARN', 'updater', `Záloha se nepodařila: ${backupResult.error} – pokračuji v aktualizaci`);
      } else {
        diagLog(`Záloha OK: ${JSON.stringify(backupResult)}`);
      }
    } catch (e) {
      diagLog(`WARN: Zálohovací modul selhal: ${e.message}`);
      log('WARN', 'updater', `Zálohovací modul nedostupný: ${e.message}`);
    }

    // ── 6. Sekvenčně rozbal celý řetěz do temp složky ────────────────────
    const tmpExtract = path.join(os.tmpdir(), `${APP_SLUG}_pending_update`);
    diagLog(`Spouštím _applyChain. tmpExtract=${tmpExtract}`);
    diagLog(`Chain ZIPy: ${chain.map(c => c.basename).join(', ')}`);
    const collectedChangelogs = await _applyChain(chain, tmpExtract, pat, (pct, main, sub) => _sendProgress(pct, main, sub));
    diagLog(`_applyChain dokončen.`);

    // ── 7. Zkopíruj soubory přes Node.js (async, PŘED app.quit()) ──────────
    // fs.promises.cp je async – neblokuje main thread → progress okno zůstane
    // responzivní a Windows shell nespadne do "not responding" stavu.
    _sendProgress(78, 'Kopíruji soubory…');
    const targetDir    = app.isPackaged
      ? path.join(path.dirname(app.getPath('exe')), 'resources', 'app')
      : path.resolve(__dirname, '..', '..');
    const resourcesDir = app.isPackaged ? process.resourcesPath : targetDir;

    log('INFO', 'updater', `Kopíruji soubory Node.js (async): ${tmpExtract} → ${targetDir}`);
    diagLog(`Kopíruji soubory: ${tmpExtract} → ${targetDir}`);
    diagLog(`app.isPackaged=${app.isPackaged}, exe=${app.isPackaged ? app.getPath('exe') : 'DEV'}`);
    try {
      await fs.promises.cp(tmpExtract, targetDir, { recursive: true, force: true });

      // ── Úklid po vadném balíčku v3.1.47 ─────────────────────────
      // Ten měl chybnou strukturu (resources/app/… místo obsahu v kořeni),
      // takže do instalace vložil vnořenou složku resources/ a README.
      // Odstraní se tiše; když tam nic není, nic se neděje.
      try {
        const junk = [
          path.join(targetDir, 'resources'),          // vnořená kopie
          path.join(targetDir, 'CTI_ME_NEJDRIV.txt'), // README z balíčku
          path.join(targetDir, 'build_v2.3.0'),       // starý balast z 3.1.46
        ];
        for (const j of junk) {
          if (fs.existsSync(j)) {
            fs.rmSync(j, { recursive: true, force: true });
            log('INFO', 'updater', `Úklid: odstraněno ${path.basename(j)}`);
            diagLog(`Úklid po v3.1.47: smazáno ${j}`);
          }
        }
        // Stará kopie návodu s diakritikou – aplikace používá jen navod.html
        const oldGuide = path.join(targetDir, 'templates', 'n\u00e1vod.html');
        if (fs.existsSync(oldGuide)) {
          fs.rmSync(oldGuide, { force: true });
          log('INFO', 'updater', 'Úklid: odstraněn duplicitní návod.html');
        }
      } catch (e) {
        log('WARN', 'updater', `Úklid po v3.1.47 selhal: ${e.message}`);
      }
      log('INFO', 'updater', 'Kopírování Node.js OK');
      diagLog(`Kopírování OK.`);

      // Zrcadlení index.html přímo do resources/ pro rychlejší načítání
      const htmlSrc = path.join(targetDir, 'src', 'renderer', 'index.html');
      if (fs.existsSync(htmlSrc)) {
        try {
          await fs.promises.copyFile(htmlSrc, path.join(resourcesDir, 'index.html'));
          log('INFO', 'updater', 'index.html zkopírován do resources/');
          diagLog(`index.html zkopírován do resources/.`);
        } catch (_) {}
      }

      // Úklid temp složky (soubory jsou už zkopírované)
      try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch (_) {}
      try { fs.mkdirSync(tmpExtract, { recursive: true }); } catch (_) {}
    } catch (copyErr) {
      diagLog(`CHYBA kopírování: ${copyErr.message}\n${copyErr.stack || ''}`);
      _closeProgressWindow();
      log('ERROR', 'updater', `Node.js kopírování selhalo: ${copyErr.message}`);
      throw copyErr;
    }

    // ── 8. Spusť restart – PhotoBridgeUpdater.exe nebo záložní BAT soubor ──
    // Soubory jsou JIŽ zkopírovány výše přes Node.js fs.promises.cp().
    // Helper/BAT jen čeká na exit PID a restartuje EXE.
    const exeDir    = app.isPackaged ? path.dirname(app.getPath('exe')) : null;
    const helperExe = exeDir ? path.join(exeDir, 'PhotoBridgeUpdater.exe') : null;
    const mainExe   = app.isPackaged ? app.getPath('exe') : process.execPath;
    const restartLog = path.join(os.tmpdir(), `${APP_SLUG}_update.log`);

    // Pomocná funkce: čeká na smrt procesu a spustí EXE přes BAT soubor.
    // BAT soubory jsou nejspolehlivější pro cesty s diakritikou a mezerami na Windows.
    const _spawnBatRestart = () => {
      const batPath = path.join(os.tmpdir(), `${APP_SLUG}_restart.bat`);
      const pid     = process.pid;
      // Uvozovky kolem cest zajistí správné zpracování mezer a diakritiky.
      // POZOR: timeout /NOBREAK zamrzne v detached cmd bez konzole - ping misto toho.
      // Skryti okna: windowsHide nekdy nezafunguje -> BAT se re-spusti pres START /MIN.
      const batLines = [
        '@echo off',
        'if "%1"=="hidden" goto main',
        `start /MIN "" cmd.exe /C "%~f0" hidden`,
        'exit',
        ':main',
        `set LOG=${restartLog}`,
        `set /A CNT=0`,
        `echo %TIME% bat restart start (PID=${pid}) >> "%LOG%"`,
        ':waitloop',
        `set /A CNT=CNT+1`,
        `if %CNT% GTR 60 goto launch`,
        `tasklist /FI "PID eq ${pid}" 2>NUL | find /I "${pid}" >NUL`,
        `if not errorlevel 1 (`,
        `  ping -n 2 127.0.0.1 >NUL`,
        `  goto waitloop`,
        `)`,
        ':launch',
        `echo %TIME% PID ${pid} skoncil (iter=%CNT%), spoustim EXE >> "%LOG%"`,
        `start "" "${mainExe}"`,
        `echo %TIME% HOTOVO >> "%LOG%"`,
        `del "%~f0" 2>NUL`,
      ];
      fs.writeFileSync(batPath, batLines.join('\r\n'), 'utf8');
      diagLog(`BAT restart zapsán: ${batPath}  (čeká na PID ${pid})`);

      const batProc = spawn('cmd.exe', ['/C', batPath], {
        detached:    true,
        stdio:       'ignore',
        windowsHide: true,
        shell:       false,
      });
      batProc.on('error', (e) => {
        log('ERROR', 'updater', `BAT restart spawn chyba: ${e.message}`);
        diagLog(`CHYBA spawn BAT: ${e.message}`);
      });
      batProc.unref();
      log('INFO', 'updater', `BAT restart spuštěn (PID ${batProc.pid || '?'}): ${batPath}`);
      diagLog(`BAT restart PID=${batProc.pid || '?'}`);
    };

    // ── Restart na Linuxu/macOS: shell skript místo BAT ───────────────────
    // Windows větev níž zůstává beze změny. Tady jen čekáme na zánik procesu
    // a spustíme aplikaci znovu – kill -0 vrací nenulový kód, když PID zmizí.
    const _spawnShRestart = () => {
      const shPath = path.join(os.tmpdir(), `${APP_SLUG}_restart.sh`);
      const pid    = process.pid;
      const lines = [
        '#!/bin/sh',
        `LOG="${restartLog}"`,
        `echo "$(date +%T) sh restart start (PID=${pid})" >> "$LOG"`,
        'CNT=0',
        `while kill -0 ${pid} 2>/dev/null; do`,
        '  CNT=$((CNT+1))',
        '  [ "$CNT" -gt 60 ] && break',
        '  sleep 1',
        'done',
        `echo "$(date +%T) PID ${pid} skoncil (iter=$CNT), spoustim aplikaci" >> "$LOG"`,
        `"${mainExe}" >/dev/null 2>&1 &`,
        'echo "$(date +%T) HOTOVO" >> "$LOG"',
        'rm -- "$0"',
      ];
      fs.writeFileSync(shPath, lines.join('\n'), { encoding: 'utf8', mode: 0o755 });
      diagLog(`SH restart zapsán: ${shPath}  (čeká na PID ${pid})`);

      const shProc = spawn('/bin/sh', [shPath], {
        detached: true, stdio: 'ignore',
      });
      shProc.on('error', (e) => {
        log('ERROR', 'updater', `SH restart spawn chyba: ${e.message}`);
        diagLog(`CHYBA spawn SH: ${e.message}`);
      });
      shProc.unref();
      log('INFO', 'updater', `SH restart spuštěn (PID ${shProc.pid || '?'}): ${shPath}`);
    };

    if (process.platform !== 'win32') {
      // ── Cesta C: Linux/macOS ──────────────────────────────────────────
      // PhotoBridgeUpdater.exe je windowsový program, tady neexistuje.
      // Soubory jsou už zkopírované, stačí restart.
      diagLog(`Cesta C: SH restart (${process.platform})  exe=${mainExe}  pid=${process.pid}`);
      _spawnShRestart();
    } else if (helperExe && fs.existsSync(helperExe)) {
      // ── Cesta A: PhotoBridgeUpdater.exe + záložní BAT vždy ────────────
      // PhotoBridgeUpdater.exe se spustí ale někdy selže tiše (bez error eventu).
      // Proto spouštíme BAT restart VŽDY jako zálohu – BAT čeká na zánik PID,
      // takže pokud exe restartuje první, BAT jen znovu otevře okno (neškodné).
      log('INFO', 'updater', `Spouštím pb_updater: ${helperExe}`);
      diagLog(`Cesta A: PhotoBridgeUpdater.exe  exe=${mainExe}  pid=${process.pid}`);
      const helperArgs = [
        `--src=${tmpExtract}`,
        `--dst=${targetDir}`,
        `--exe=${mainExe}`,
        `--res=${resourcesDir}`,
        `--pid=${process.pid}`,
        `--ver=${lastVer}`,
        `--log=${restartLog}`,
      ];
      const helperProc = spawn(helperExe, helperArgs, {
        detached:    true,
        stdio:       'ignore',
        windowsHide: true,
      });
      helperProc.on('error', (e) => {
        log('WARN', 'updater', `pb_updater.exe spawn chyba: ${e.message}`);
        diagLog(`WARN pb_updater.exe spawn chyba: ${e.message}`);
      });
      helperProc.unref();
      diagLog(`PhotoBridgeUpdater.exe spuštěn, PID=${helperProc.pid || '?'}`);
      // Vždy spustit BAT jako garantovanou zálohu
      diagLog(`Spouštím BAT zálohu paralelně (garantovaný restart)`);
      _spawnBatRestart();
    } else {
      // ── Cesta B: záložní BAT restart ───────────────────────────────────
      if (helperExe) {
        log('WARN', 'updater', `pb_updater.exe nenalezen (${helperExe}) – záložní BAT restart`);
        diagLog(`WARN: pb_updater.exe nenalezen – záložní BAT restart`);
      } else {
        diagLog(`Cesta B: BAT restart (dev mode nebo helperExe=null)`);
      }
      _spawnBatRestart();
    }

    // ── 9. Ulož název nejnovějšího ZIPu – po restartu se přeskočí ────────
    try { _saveLastZip(last.basename); } catch (_) {}

    // Self-heal: poznač verzi opravy a smaž crash flag (řízený restart není pád)
    try { _recordRecoveryFix(last.version || last.date); } catch (_) {}
    try { _clearCrashFlagForControlledRestart(); } catch (_) {}
    try { disarmSelfHeal(); } catch (_) {}

    try {
      const backup = require('./backup');
      // Použij changelogy sesbírané z každého ZIPu v chainu (každý PC má jiný chain)
      const changelog = collectedChangelogs.length > 0 ? collectedChangelogs : null;
      backup.markUpdatePending(last.version || last.date, changelog);
    } catch (_) {}

    diagLog(`Odesílám 100% progress (real done), čekám na animaci v rendereru...`);
    _sendProgress(100, 'Hotovo! Restartuji aplikaci…', lastVer);
    // Čekáme na signál 'update-progress:animation-done' z rendereru.
    // Renderer běží vlastní animaci (0→100% za ~10s) a pošle signál až skončí.
    // Tak má uživatel čas vidět průběh i na velmi rychlém PC.
    // Záchrana: pokud signál nepřijde do 15s, restartujeme stejně.
    await new Promise(r => {
      const timeout = setTimeout(r, 15000);
      ipcMain.once('update-progress:animation-done', () => {
        clearTimeout(timeout);
        r();
      });
    });
    diagLog(`Volám app.quit() – instalace chain update dokončena.`);

    _updateQuitPending = true;  // Říká before-quit: nemaž update_pending.json
    log('INFO', 'updater', `Ukončuji aplikaci pro instalaci chain update (${chain.length} ZIPů)...`);

    // Před quitem explicitně ulož aktuální refresh token do state.json
    // Bez toho by session token zůstal jen v paměti a po restartu by se ztratil
    try {
      require('./supabase').persistSession();
      log('INFO', 'updater', 'Session token uložen před restartem');
    } catch (_) {}

    // ZÁSADNÍ: naplánuj restart aplikace PŘED app.quit(). Bez relaunch()
    // by se aplikace po noční aktualizaci jen vypnula a už nezapnula
    // (uživatel ráno našel zhasnutý PhotoBridge). relaunch() zaregistruje
    // nový start procesu, který proběhne po skončení toho současného.
    try {
      app.relaunch();
      log('INFO', 'updater', 'app.relaunch() naplánován – aplikace se po instalaci znovu spustí');
      diagLog('app.relaunch() naplánován.');
    } catch (e) {
      log('ERROR', 'updater', `app.relaunch() selhal: ${e.message}`);
      diagLog(`CHYBA app.relaunch(): ${e.message}`);
    }

    app.quit();

  } catch (err) {
    diagLog(`CHYBA checkForUpdates: ${err.message}\n${err.stack || ''}`);
    _closeProgressWindow();
    log('ERROR', 'updater', `Chyba aktualizace: ${err.message}`);
    if (manual) {
      await dialog.showMessageBox({
        type: 'error', title: 'Chyba aktualizace',
        message: 'Aktualizace se nezdařila:\n' + err.message,
        buttons: [STRINGS.ok],
      });
    }
  }
}

// ── Midnight scheduler ────────────────────────────────────────────────────────
let _resumeDebounce = null;

/**
 * Tiché „dohnání" aktualizace (catch-up). Použije se po startu a po probuzení,
 * aby se nainstalovala i verze, kterou PC zaspal přes půlnoc.
 * Když je tichý režim vypnutý (AUTO_SILENT_UPDATE=false), spadne na dialog jako dřív.
 */
function _silentCatchUp(tag) {
  let silent = true;
  try { silent = String(getConfig().readConfig().AUTO_SILENT_UPDATE) !== 'false'; } catch (_) {}
  if (!silent) {
    log('INFO', 'updater', `${tag}: tichý režim vypnut → kontrola s dialogem`);
    checkForUpdates(false).catch(e => log('ERROR', 'updater', `${tag} check selhal: ${e.message}`));
    return;
  }
  log('INFO', 'updater', `${tag}: tiché dohnání aktualizace (catch-up)`);
  checkForUpdates(false, true).catch(e => log('ERROR', 'updater', `${tag} catch-up selhal: ${e.message}`));
}

/**
 * Pravidelná kontrola URGENTNÍCH aktualizací.
 *
 * PROČ ZVLÁŠŤ A NE JEN O PŮLNOCI
 * Urgentní verze řeší vážnou chybu – fotky neodcházejí, aplikace padá.
 * Čekat s tím do půlnoci nedává smysl, technik by celý den pracoval
 * s rozbitou aplikací.
 *
 * Stahuje se jen malý soubor urgent.json (pár set bajtů). Plná kontrola
 * aktualizací se spustí jen tehdy, když v něm je verze novější než ta
 * nainstalovaná. Běžné aktualizace se tímhle NEUSPÍŠÍ – ty čekají dál
 * na půlnoc nebo na ruční kontrolu.
 */
// Záložní kontrola pro případ, že websocket neběží (technik nepřihlášen,
// výpadek sítě). Hlavní cesta je push signál přes Realtime – ten dorazí
// během vteřin. Proto stačí zřídka.
const URGENT_CHECK_MS = 30 * 60 * 1000;   // á 30 minut
let _urgentTimer = null;

function _jeVerzeNovejsi(a, b) {
  const rozlozit = (v) => String(v).split('.').map(x => parseInt(x, 10) || 0);
  const x = rozlozit(a), y = rozlozit(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0;
  }
  return false;
}

async function _urgentCheck() {
  try {
    const seznam = await _fetchUrgentList();
    if (!seznam.length) return;

    const novejsi = seznam.filter(v => _jeVerzeNovejsi(v, APP_VERSION));
    if (!novejsi.length) return;

    log('INFO', 'updater',
      `URGENTNÍ verze k dispozici: ${novejsi.join(', ')} (mám ${APP_VERSION}) – instaluji hned`);
    await checkForUpdates(false, true);
  } catch (e) {
    // Nedostupný GitHub není důvod k panice, zkusí se za 10 minut znovu
    log('WARN', 'updater', `Kontrola urgentních aktualizací selhala: ${e.message}`);
  }
}

/**
 * Spustí aktualizaci na základě push signálu z Supabase.
 *
 * Správce změní pb_settings.urgent_version a všem běžícím aplikacím to
 * dorazí websocketem během vteřin. Žádné dotazování, žádné čekání.
 *
 * @param {string} chtenaVerze  verze ze signálu
 */
let _urgentBeziOd = 0;
async function urgentniSignal(chtenaVerze) {
    // Ochrana proti smyčce: když správce klíč přepíše víckrát za sebou,
    // nespouštěj instalaci pokaždé znovu.
    if (Date.now() - _urgentBeziOd < 5 * 60 * 1000) {
        log('INFO', 'updater', 'Signál k aktualizaci ignorován – před chvílí už jeden přišel');
        return;
    }

    if (!_jeVerzeNovejsi(chtenaVerze, APP_VERSION)) {
        log('INFO', 'updater',
            `Signál na ${chtenaVerze}, ale mám už ${APP_VERSION} – neinstaluji`);
        return;
    }

    _urgentBeziOd = Date.now();
    log('INFO', 'updater', `SIGNÁL: aktualizace na ${chtenaVerze} (mám ${APP_VERSION}) – instaluji hned`);
    try {
        await checkForUpdates(false, true);
    } catch (e) {
        log('ERROR', 'updater', `Aktualizace ze signálu selhala: ${e.message}`);
    }
}

function scheduleUpdateCheck() {
  // Po startu: dožeň případně zmeškanou aktualizaci (např. PC v noci spal) – tiše, bez ptaní
  setTimeout(() => _silentCatchUp('Startup'), 8000);

  // Urgentní kontrola: první za minutu po startu, pak á 10 minut
  if (_urgentTimer) clearInterval(_urgentTimer);
  setTimeout(() => { _urgentCheck().catch(() => {}); }, 60_000);
  _urgentTimer = setInterval(() => { _urgentCheck().catch(() => {}); }, URGENT_CHECK_MS);
  log('INFO', 'updater', 'Kontrola urgentních aktualizací aktivní (á 10 min)');

  _scheduleNextMidnight();

  // Po probuzení z spánku/hibernace nebo odemčení obrazovky taky dožeň (debounce 60 s,
  // ať to neskočí uživateli hned do práce v momentě probuzení)
  try {
    const { powerMonitor } = require('electron');
    const onWake = (ev) => {
      if (_resumeDebounce) clearTimeout(_resumeDebounce);
      _resumeDebounce = setTimeout(() => _silentCatchUp('Resume:' + ev), 60000);
      if (_resumeDebounce.unref) _resumeDebounce.unref();
      _scheduleNextMidnight();   // čas se mohl posunout, přeplánuj půlnoc
    };
    powerMonitor.on('resume',        () => onWake('resume'));
    powerMonitor.on('unlock-screen', () => onWake('unlock'));
    log('INFO', 'updater', 'Catch-up po probuzení aktivní (powerMonitor)');
  } catch (e) {
    log('WARN', 'updater', `powerMonitor nedostupný: ${e.message}`);
  }

  log('INFO', 'updater', 'Update scheduler spuštěn (start + půlnoc + probuzení)');
}

function _scheduleNextMidnight() {
  if (_midnightTimer) {
    clearTimeout(_midnightTimer);
    _midnightTimer = null;
  }

  const now  = new Date();
  const next = new Date(now);
  next.setDate(next.getDate() + 1);
  next.setHours(0, 0, 30, 0);

  const msUntil = next - now;
  log('INFO', 'updater', `Příští midnight check za ${Math.round(msUntil / 60000)} minut`);

  _midnightTimer = setTimeout(() => {
    const cfg = getConfig().readConfig();
    if (cfg.AUTO_MIDNIGHT_UPDATE !== 'false') {
      log('INFO', 'updater', 'Midnight AUTO-INSTALL aktualizací...');
      // manual=false, autoInstall=TRUE → žádný dialog, rovnou nainstaluje.
      // Sfajruje jen pokud PC běží přes půlnoc. Když PC v noci spí/hibernuje,
      // aktualizaci tiše dožene catch-up po startu nebo po probuzení (powerMonitor).
      checkForUpdates(false, true)
        .catch(e => log('ERROR', 'updater', `Midnight auto-install selhal: ${e.message}`))
        .finally(() => _scheduleNextMidnight());
    } else {
      log('INFO', 'updater', 'Půlnoc – AUTO_MIDNIGHT_UPDATE vypnuto, přeskakuji.');
      _scheduleNextMidnight();
    }
  }, msUntil);

  if (_midnightTimer.unref) _midnightTimer.unref();
}

function stopScheduler() {
  if (_midnightTimer) {
    clearTimeout(_midnightTimer);
    _midnightTimer = null;
  }
}

// ── IPC kanál ─────────────────────────────────────────────────────────────────
try {
  if (ipcMain) {
    ipcMain.handle('ipc:update:check-silent', () => checkForUpdates(false));
  }
} catch (_) {}

// ── Export ────────────────────────────────────────────────────────────────────
// ── Scan bez dialogu – vrací strukturovaná data pro UI ────────────────────────
/**
 * Prohledá oba zdroje a vrátí seznam všech aktualizací novějších než aktuální verze.
 * Nezobrazuje žádný dialog – slouží pro zobrazení tabulky v nastavení.
 *
 * @param {string} [overrideDir] – přepíše UPD_SERVER_PATH z konfigurace
 * @returns {Promise<{currentVersion, chain: Array}>}
 */
async function scanForUpdates(overrideDir) {
  const cfg       = getConfig().readConfig();
  const updateDir = overrideDir !== undefined ? overrideDir : (cfg.UPD_SERVER_PATH || '').trim();
  const pat       = (cfg.GITHUB_PAT || '').trim();

  const [githubAll, localAll] = await Promise.all([
    _findAllInGitHub(pat),
    updateDir && fs.existsSync(updateDir)
      ? Promise.resolve(_findAllInLocal(updateDir))
      : Promise.resolve([]),
  ]);

  const allCandidates = _mergeAndDedup(githubAll, localAll);
  const newer         = _filterNewer(allCandidates, APP_VERSION);
  const chain         = _sortAscending(newer);

  log('INFO', 'updater', `scanForUpdates: nalezeno ${chain.length} novějších ZIPů (aktuální: v${APP_VERSION})`);

  return {
    currentVersion: APP_VERSION,
    chain: chain.map(c => ({
      basename: c.basename,
      version:  c.version || null,
      date:     c.date,
      source:   c.source,
    })),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
//  SELF-HEAL: po pádu hledat opravu na GitHubu (jen v režimu pádu, á UPDATE_POLL_MIN)
//  Jen spadlý PC poolluje častěji – běžný provoz zůstává jako dosud (start + půlnoc).
// ─────────────────────────────────────────────────────────────────────────────
let _selfHealTimer = null;

function _recoveryStatePath() {
  return path.join(app.getPath('userData'), 'recovery_state.json');
}

/** Po úspěšné instalaci zapíše do recovery_state.json verzi opravy. */
function _recordRecoveryFix(fixVersion) {
  try {
    const p = _recoveryStatePath();
    if (!fs.existsSync(p)) return;
    const st = JSON.parse(fs.readFileSync(p, 'utf8') || '{}');
    st.fixVersion = String(fixVersion || '');
    st.fixTs = new Date().toISOString();
    fs.writeFileSync(p, JSON.stringify(st, null, 2), 'utf8');
  } catch (_) {}
}

/** Řízený restart (relaunch) NENÍ pád → smaž crash flag, ať to start nebere jako další pád. */
function _clearCrashFlagForControlledRestart() {
  try { require('./crash').clearCrashFlag(); } catch (_) {}
}

/**
 * Aktivuje self-heal: zapíše stav pádu a začne á UPDATE_POLL_MIN minut hledat
 * na GitHubu NOVĚJŠÍ verzi (opravu). _filterNewer bere jen verze > APP_VERSION,
 * takže se nikdy nepřeinstaluje ta samá spadlá verze (pojistka proti zacyklení).
 * Po nalezení opravy se aplikace sama nainstaluje a restartuje.
 */
function armSelfHeal(reason) {
  try {
    const cfg = getConfig().readConfig();
    if (String(cfg.AUTO_SILENT_UPDATE) === 'false') {
      log('INFO', 'updater', 'Self-heal vypnut (AUTO_SILENT_UPDATE=false)');
      return;
    }
    const p = _recoveryStatePath();
    let st = {};
    try { if (fs.existsSync(p)) st = JSON.parse(fs.readFileSync(p, 'utf8') || '{}'); } catch (_) {}
    st.crashedVersion = APP_VERSION;
    st.ts       = new Date().toISOString();
    st.attempts = (st.attempts || 0) + 1;
    st.reason   = reason || st.reason || 'crash';
    try { fs.writeFileSync(p, JSON.stringify(st, null, 2), 'utf8'); } catch (_) {}

    let min = parseInt(cfg.UPDATE_POLL_MIN, 10);
    if (!Number.isFinite(min) || min < 2) min = 10;

    log('WARN', 'updater', `SELF-HEAL aktivní (pád ve v${APP_VERSION}) – hledám opravu na GitHubu každých ${min} min`);

    // okamžitý první pokus (malý odklad, ať doběhne crash UI)
    setTimeout(() => { checkForUpdates(false, true).catch(() => {}); }, 5000);

    if (_selfHealTimer) clearInterval(_selfHealTimer);
    _selfHealTimer = setInterval(() => { checkForUpdates(false, true).catch(() => {}); }, min * 60 * 1000);
    if (_selfHealTimer.unref) _selfHealTimer.unref();
  } catch (e) {
    log('WARN', 'updater', `armSelfHeal selhal: ${e.message}`);
  }
}

function disarmSelfHeal() {
  if (_selfHealTimer) { clearInterval(_selfHealTimer); _selfHealTimer = null; }
}

module.exports = {
  urgentniSignal,
  checkForUpdates,
  scanForUpdates,
  scheduleUpdateCheck,
  stopScheduler,
  resolveIcon,
  resolveIconImage,
  compareVersions,
  armSelfHeal,
  disarmSelfHeal,
  isUpdateQuitPending: () => _updateQuitPending,  // pro before-quit v main.js
};
