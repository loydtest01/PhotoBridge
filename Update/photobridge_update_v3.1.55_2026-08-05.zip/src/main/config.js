'use strict';
// ============================================================
// PhotoBridge – src/main/config.js
// Správa konfigurace aplikace (čtení, zápis, zálohy, výchozí hodnoty)
// Odpovídá: Python photobridge.py řádky 347–730
// ============================================================

const { app } = require('electron');
const path    = require('path');
const fs      = require('fs');

// ── Cesty ─────────────────────────────────────────────────────────────────────
const USER_DATA_DIR     = app.getPath('userData');   // %APPDATA%/PhotoBridge
const CONFIG_PATH       = path.join(USER_DATA_DIR, 'config.json');
const BACKUP_DIR        = path.join(USER_DATA_DIR, 'backups');
const ENGINE_BACKUP_DIR = path.join(BACKUP_DIR, 'engine_backup');
const LOG_DIR           = path.join(USER_DATA_DIR, 'logs');
const PAINT_TEMP_DIR    = path.join(app.getAppPath(), 'paint_temp');  // kořen projektu
const INSTALLED_FILE    = path.join(USER_DATA_DIR, 'installed.txt');

// ── DEFAULT_CONFIG ────────────────────────────────────────────────────────────
// Odpovídá DEFAULT_CONFIG dict z Python originálu.
// Všechny hodnoty jsou stringy (kompatibilita s Python verzí).
const DEFAULT_CONFIG = {
  // Ukládání souborů
  SAVE_DIR:                      'M:\\UploadScan', // Cílová složka pro stažené fotky (po Malování i přímé)
  SAW_DIR:                       'M:\\UploadScan', // (legacy – nepoužívá se pro stahování fotek)
  USE_BUILTIN_EDITOR:            'false',           // v3.1.0: 'true' = vestavěný editor místo mspaint

  // Server
  PORT:                          '5000',         // Aktuálně používaný port
  PORT_FROM:                     '5000',         // Spodní hranice rozsahu portů
  PORT_TO:                       '65000',        // Horní hranice rozsahu portů

  // Vzhled
  THEME_MODE:                    'auto_timer',   // auto_windows / auto_timer / dark / light
  DAY_START:                     '08:00',        // Začátek denního (světlého) režimu (HH:MM)
  DAY_END:                       '18:00',        // Konec denního (světlého) režimu (HH:MM)

  // Limity souborů
  MAX_IMG_MB:                    '3',            // Max velikost obrázku v MB
  MAX_VIDEO_MB:                  '30',           // Max velikost videa v MB

  // Okno aplikace
  WIN_W:                         '520',          // Šířka okna v px
  WIN_H:                         '420',          // Výška okna v px
  WIN_X:                         '',             // Pozice X (prázdné = auto-centrování)
  WIN_Y:                         '',             // Pozice Y (prázdné = auto-centrování)

  // Floating okno (DevTools)
  FLOAT_X:                       '',             // Pozice X floating okna
  FLOAT_Y:                       '',             // Pozice Y floating okna

  // Token (platnost session)
  TOKEN_HOURS:                   '0',            // Platnost tokenu – hodiny
  TOKEN_MINUTES:                 '20',           // Platnost tokenu – minuty

  // QR kód
  QR_TIMEOUT_MINUTES:            '10',           // Timeout QR kódu v minutách (0 = bez timeoutu)
  AUTO_MINIMIZE_ON_TIMEOUT:      'false',        // Automatická minimalizace po QR timeoutu
  AUTO_MINIMIZE_MANUAL_DISABLED: 'false',        // Záznam ručního vypnutí auto-minimize
  AUTO_REFRESH_QR:               'true',         // Automatická obnova QR kódu

  // QR – vzhled
  QR_BG_COLOR:                   '255,255,255', // Pozadí QR kódu (R,G,B) – bílé
  QR_FILL_COLOR:                 '0,0,0',       // Barva modulů QR (R,G,B)
  QR_BORDER:                     '2',           // Quiet zone modulů (1–4)
  QR_BLACK_FRAME:                'true',        // Černý rámeček kolem QR kódu
  QR_EC_LEVEL:                   'H',           // Opravný stupeň: L / M / Q / H
  GITHUB_PAGES_URL:              'https://loydtest01.github.io/PhotoBridge/',  // Mobilní webapp (Supabase režim)
  QR_INVERT:                     'false',       // Invertovaný QR (světlé moduly na tmavém)

  // Tray a minimalizace
  USE_TRAY:                      'false',       // Použít systémovou tray ikonu
  MINIMIZE_TO:                   'panel',       // panel / tray
  MINIMIZE_ON_START:             'true',        // Minimalizovat při startu

  // Tapety
  WALLPAPER_MODE:                'system',      // system / custom / none
  ROTATE_WALLPAPER_ON_HOME:      'false',       // Rotace tapet na home screenu

  // Síťové IP adresy
  KNOWN_IPS:                     '',            // Čárkou oddělený seznam dříve použitých IP
  QR_IP_SELECTED:                '',            // Naposledy vybraná IP pro QR kód

  // Systém
  START_WITH_WINDOWS:            'true',        // Spouštět se systémem Windows
  DESKTOP_SHORTCUT:              'false',       // Zástupce na ploše už vytvořen (příznak)

  // Logging
  LOG_LEVEL:                     'warn',        // debug / info / warn / error

  // Aktualizace
  UPD_SERVER_PATH:               'I:\\Osobní složky\\Papež Ondřej\\INST\\PhotoBridgeE\\UpdateEL', // Síťová složka updates/ (výchozí, lze změnit v nastavení)
  GITHUB_PAT:                    '',            // GitHub Personal Access Token pro soukromé repo (Fine-grained, Contents: Read)
  ADMIN_PIN:                     '1234',        // PIN pro odemčení administrátorských polí (GitHub PAT apod.)
  AUTO_MIDNIGHT_UPDATE:          'true',        // Automatická tichá aktualizace o půlnoci
  AUTO_SILENT_UPDATE:            'true',        // Tichý 10min poll + self-heal po pádu (bez odsouhlasení). 'false' = vypnuto
  UPDATE_POLL_MIN:               '10',          // Interval tichého pollu na GitHub v minutách (min 2)

  // Externí editor obrázků (Linux/macOS; na Windows se vždy použije Malování)
  // Prázdné = automaticky (gimp → pinta → krita → kolourpaint → xdg-open)
  EXTERNAL_EDITOR: '',

  // RTS API (Britex) – cíl pro ukládání fotek do zakázek
  API_TARGET:        'rts',                       // rts = RTS API | generic = obecné API (multipart)
  RTS_URL:           'https://rts.britex.cz',     // dev: https://rts-dev.britex.cz
  RTS_CLIENT_ID:     '',                          // OAuth2 client_id od IT
  RTS_CLIENT_SECRET: '',                          // OAuth2 client_secret od IT
  RTS_REDIRECT_URI:  'https://vfxurqshbibaibqssjyz.supabase.co/auth/v1/callback',
  RTS_TOKEN:         '',                          // ruční token (jen pro testování, jinak prázdné)
  RTS_ID_MODE:       'job',                       // job = "id" je číslo zakázky | internal = interní ID
  RTS_DATA_FIELD:    'data',                      // kam patří base64: data | content

  // API servisu (náhrada za UploadScan – aktivuje se až bude endpoint od IT)
  API_MODE:     'disk',   // disk = jen M:\\UploadScan (výchozí) | both = disk+API | api = jen API
  API_URL:      '',       // endpoint servisu pro upload dokumentu (dodá IT/RTS)
  API_KEY:      '',       // autentizace (Bearer token / API klíč)
  API_TYPE_MAP: 'SD=DD_DOC,SDX=DD_DOC,SP=DD_DOC,SN=DD_DOC,VT=DD_DOC,FA=DD_DOC',  // zkratka=typ v servisu

  // Supabase
  SB_URL:    'https://vfxurqshbibaibqssjyz.supabase.co',
  SB_ANON:   'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZmeHVycXNoYmliYWlicXNzanl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA1NTgxNDQsImV4cCI6MjA5NjEzNDE0NH0._oexaz0fE_asoRPHBsUJcz0vz_6tShrUWHHNMPzMCXI',
  SB_BUCKET: 'pb-uploads',
  SB_EMAIL:  '',             // Plný email pro přihlášení do Supabase
  SB_PASS:   '',             // Heslo (ukládáno lokálně)

  // Supabase – auto-smazání
  RETENTION_DAYS: '7',           // Počet dní po kterých se smažou nevyzvednuté soubory

  // Vercel
  VERCEL_URL: 'https://photobridge-two.vercel.app',

  // Onboarding
  ONBOARDING_DONE: 'false',          // 'true' po dokončení první prohlídky

  // Windows toast notifikace o stažených souborech
  NOTIFY_ENABLED:  'true',           // 'true' = notifikace zapnuté
};

// ── Whitelist klíčů pro zápis na disk ────────────────────────────────────────
const CONFIG_KEYS = Object.keys(DEFAULT_CONFIG);

// ── Validační pravidla ────────────────────────────────────────────────────────
const VALIDATORS = {
  RETENTION_DAYS:     { type: 'int',  min: 1,     max: 365 },
  PORT:               { type: 'int',  min: 1024,  max: 65535 },
  PORT_FROM:          { type: 'int',  min: 1024,  max: 65535 },
  PORT_TO:            { type: 'int',  min: 1024,  max: 65535 },
  MAX_IMG_MB:         { type: 'int',  min: 1,     max: 500   },
  MAX_VIDEO_MB:       { type: 'int',  min: 1,     max: 2000  },
  WIN_W:              { type: 'int',  min: 300,   max: 9999  },
  WIN_H:              { type: 'int',  min: 200,   max: 9999  },
  TOKEN_HOURS:        { type: 'int',  min: 0,     max: 720   },
  TOKEN_MINUTES:      { type: 'int',  min: 0,     max: 59    },
  QR_TIMEOUT_MINUTES: { type: 'int',  min: 0,     max: 1440  },
  QR_BORDER:          { type: 'int',  min: 1,     max: 4     },
  QR_EC_LEVEL:        { type: 'enum', options: ['L', 'M', 'Q', 'H'] },
  THEME_MODE:         { type: 'enum', options: ['auto_windows', 'auto_timer', 'dark', 'light'] },
  MINIMIZE_TO:        { type: 'enum', options: ['panel', 'tray', 'float'] },
  API_MODE:           { type: 'enum', options: ['disk', 'both', 'api'] },
  API_TARGET:         { type: 'enum', options: ['rts', 'generic'] },
  RTS_ID_MODE:        { type: 'enum', options: ['job', 'internal'] },
  RTS_DATA_FIELD:     { type: 'enum', options: ['data', 'content'] },
  LOG_LEVEL:          { type: 'enum', options: ['debug', 'info', 'warn', 'error'] },
  WALLPAPER_MODE:     { type: 'enum', options: ['system', 'custom', 'none'] },
};

// ══════════════════════════════════════════════════════════════
// INICIALIZACE
// ══════════════════════════════════════════════════════════════

/**
 * Zajistí existenci všech runtime složek.
 * Voláno při startu aplikace (z main.js).
 */
function ensureRuntimeDirs() {
  for (const dir of [USER_DATA_DIR, BACKUP_DIR, LOG_DIR, PAINT_TEMP_DIR]) {
    try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
  }
}

/**
 * Inicializace konfigurace při startu.
 * Vytvoří výchozí config pokud neexistuje, doplní chybějící klíče.
 */
function initConfig() {
  ensureRuntimeDirs();
  if (!fs.existsSync(CONFIG_PATH)) {
    _writeRaw({ ...DEFAULT_CONFIG });
    _log('INFO', 'initConfig: vytvořen výchozí config', CONFIG_PATH);
  } else {
    readConfig(); // automaticky doplní a uloží chybějící klíče
  }
}

// ══════════════════════════════════════════════════════════════
// ČTENÍ KONFIGURACE
// ══════════════════════════════════════════════════════════════

/**
 * Načte konfiguraci z disku a sloučí ji s výchozími hodnotami.
 * Automaticky doplní chybějící klíče (schema upgrade) a uloží.
 * Provede migraci starých klíčů (MANUAL_IP, QR_IP_MANUAL) z Python formátu.
 * @returns {object} Kompletní konfigurační objekt
 */
// ── CUTOVER na nový samostatný Supabase projekt (PhotoBridge) ──────────────
// Jednorázově přepne STÁVAJÍCÍ instalace ze starého (sdíleného) projektu na
// nový. Podmínka = config.json má ještě STAROU SB_URL. Po přepnutí už SB_URL
// != stará → migrace se víc nespustí (idempotentní). SB_PASS se vymaže, aby se
// uživatel jednou přihlásil novým heslem (SB_EMAIL zůstává předvyplněný).
const SB_CUTOVER_OLD_URL  = 'https://fplegasiabuqfxwdggct.supabase.co';
const SB_CUTOVER_NEW_URL  = 'https://vfxurqshbibaibqssjyz.supabase.co';
const SB_CUTOVER_NEW_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZmeHVycXNoYmliYWlicXNzanl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA1NTgxNDQsImV4cCI6MjA5NjEzNDE0NH0._oexaz0fE_asoRPHBsUJcz0vz_6tShrUWHHNMPzMCXI';

function readConfig() {
  const cfg = { ...DEFAULT_CONFIG };

  // Které klíče reálně existovaly v uloženém config.json uživatele.
  // Slouží migraci: cokoliv co tu uživatel už má (jakákoliv hodnota)
  // je jeho volba a NESMÍ se přepsat na tovární.
  let _diskHadKey = {};
  let _schemaUpgradeNeeded = false;

  if (fs.existsSync(CONFIG_PATH)) {
    try {
      const raw  = fs.readFileSync(CONFIG_PATH, 'utf8');
      const disk = JSON.parse(raw);

      // Přepiš výchozí hodnoty tím, co je na disku (jen definované klíče)
      for (const key of CONFIG_KEYS) {
        if (Object.prototype.hasOwnProperty.call(disk, key)) {
          cfg[key] = disk[key];
          _diskHadKey[key] = true;
        }
      }

      // Migrace starých klíčů z Python config.txt formátu
      if (disk.MANUAL_IP)    cfg['_legacy_MANUAL_IP']    = disk.MANUAL_IP;
      if (disk.QR_IP_MANUAL) cfg['_legacy_QR_IP_MANUAL'] = disk.QR_IP_MANUAL;

      // Schema upgrade – zjisti zda chybí klíče. ZÁPIS ale provedeme
      // až NA KONCI (po nastavení nových voleb), jinak by se na disk
      // uložily tovární hodnoty a migrace by se příště neuplatnila.
      _schemaUpgradeNeeded = CONFIG_KEYS.some(
        k => !Object.prototype.hasOwnProperty.call(disk, k)
      );

    } catch (err) {
      _log('ERROR', 'readConfig: nelze parsovat config.json', err.message);
      _backupCorrupt();
      return { ...DEFAULT_CONFIG };
    }
  }

  // ── CUTOVER: jednorázové přepnutí na nový Supabase projekt ────────────────
  // Pokud má instalace ještě STAROU URL, přepni na novou + vymaž heslo.
  let _cutoverApplied = false;
  if (String(cfg.SB_URL || '').trim() === SB_CUTOVER_OLD_URL) {
    cfg.SB_URL  = SB_CUTOVER_NEW_URL;
    cfg.SB_ANON = SB_CUTOVER_NEW_ANON;
    cfg.SB_PASS = '';   // vynutí jednorázové přihlášení novým heslem
    _cutoverApplied = true;
    _log('INFO', 'readConfig: CUTOVER na nový Supabase projekt proveden');
  }

  // ── Normalizace KNOWN_IPS + QR_IP_SELECTED ────────────────────────────────
  let known = parseKnownIps(cfg.KNOWN_IPS);
  let sel   = (cfg.QR_IP_SELECTED || '').trim();

  // Migrace MANUAL_IP
  const oldManual = (cfg['_legacy_MANUAL_IP'] || '').trim();
  if (isValidIp(oldManual) && !known.includes(oldManual)) {
    known.push(oldManual);
    if (!sel) sel = oldManual;
  }
  delete cfg['_legacy_MANUAL_IP'];

  // Migrace QR_IP_MANUAL
  const oldQr = (cfg['_legacy_QR_IP_MANUAL'] || '').trim();
  if (isValidIp(oldQr) && !known.includes(oldQr)) {
    known.push(oldQr);
    if (!sel) sel = oldQr;
  }
  delete cfg['_legacy_QR_IP_MANUAL'];

  cfg.KNOWN_IPS      = knownIpsToStr(known);
  cfg.QR_IP_SELECTED = sel;

  // ── Jednorázové nastavení nových voleb (NEpřepisuje uživatele) ────────────
  // PRAVIDLO: cokoliv co si uživatel sám nastavil zůstává nezměněno.
  try {
    // SAVE_DIR: pokud je PRÁZDNÁ (uživatel ještě nevybral žádnou složku –
    // ať už klíč chybí nebo je ""), nastav M:\UploadScan. Když má uživatel
    // vyplněnou vlastní cestu (např. domácí PC s jinou složkou), NEsaháme
    // na ni – prázdná hodnota = "nevybráno", není to volba uživatele.
    if (!String(cfg.SAVE_DIR || '').trim()) {
      cfg.SAVE_DIR = 'M:\\UploadScan';
    }
    // Ostatní volby nastav JEN pokud klíč v uživatelově config.json úplně
    // chyběl (aplikace ho u něj nikdy neměla). Jakmile tam je – jakákoliv
    // hodnota, i vypnutá – je to jeho volba a nedotýkáme se jí.
    if (!_diskHadKey.THEME_MODE)         cfg.THEME_MODE         = 'auto_timer';
    if (!_diskHadKey.DAY_START)          cfg.DAY_START          = '08:00';
    if (!_diskHadKey.DAY_END)            cfg.DAY_END            = '18:00';
    if (!_diskHadKey.QR_BG_COLOR)        cfg.QR_BG_COLOR        = '255,255,255';
    if (!_diskHadKey.START_WITH_WINDOWS) cfg.START_WITH_WINDOWS = 'true';
    if (!_diskHadKey.MINIMIZE_ON_START)  cfg.MINIMIZE_ON_START  = 'true';
    if (!_diskHadKey.USE_TRAY)           cfg.USE_TRAY           = 'true';
    if (!_diskHadKey.MINIMIZE_TO)        cfg.MINIMIZE_TO        = 'tray';
  } catch (e) {
    _log('WARN', 'init nových voleb selhal', e.message);
  }

  // Schema upgrade zápis až TEĎ – cfg už obsahuje správné hodnoty
  // nových voleb (ne tovární). Tím se na disk uloží to, co uživatel
  // má vidět, a příští start už klíče respektuje jako jeho volbu.
  if (_schemaUpgradeNeeded || _cutoverApplied) {
    try {
      _writeRaw(cfg);
      _log('INFO', 'readConfig: schema upgrade / cutover zapsán na disk');
    } catch (_) {}
  }

  return cfg;
}

// ══════════════════════════════════════════════════════════════
// ZÁPIS KONFIGURACE
// ══════════════════════════════════════════════════════════════

/**
 * Zapíše konfiguraci na disk (atomicky: .tmp → rename).
 * Před zápisem provede zálohu, validuje hodnoty, filtruje jen povolené klíče.
 * @param {object} cfg – konfigurační objekt k uložení
 */
function writeConfig(cfg) {
  ensureRuntimeDirs();

  if (fs.existsSync(CONFIG_PATH)) {
    backupConfig();
  }

  const toSave = {};
  for (const k of CONFIG_KEYS) {
    const val = Object.prototype.hasOwnProperty.call(cfg, k) ? cfg[k] : (DEFAULT_CONFIG[k] ?? '');
    toSave[k] = validateValue(k, String(val));
  }

  _writeRaw(toSave);
  _log('INFO', 'writeConfig: konfigurace uložena', CONFIG_PATH);
}

/**
 * Resetuje konfiguraci na výchozí hodnoty.
 * @returns {object} Nová výchozí konfigurace
 */
function resetConfigToDefaults() {
  const cfg = { ...DEFAULT_CONFIG };
  writeConfig(cfg);
  _log('INFO', 'resetConfigToDefaults: konfigurace resetována');
  return cfg;
}

// ══════════════════════════════════════════════════════════════
// VALIDACE
// ══════════════════════════════════════════════════════════════

/**
 * Validuje hodnotu klíče dle VALIDATORS.
 * Pokud hodnota není platná, vrátí výchozí z DEFAULT_CONFIG.
 */
function validateValue(key, value) {
  const rule = VALIDATORS[key];
  if (!rule) return value;

  if (rule.type === 'int') {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < rule.min || num > rule.max) return DEFAULT_CONFIG[key] ?? value;
    return String(num);
  }

  if (rule.type === 'enum') {
    if (!rule.options.includes(value)) return DEFAULT_CONFIG[key] ?? value;
    return value;
  }

  return value;
}

// ══════════════════════════════════════════════════════════════
// ZÁLOHA KONFIGURACE
// ══════════════════════════════════════════════════════════════

/**
 * Vytvoří zálohu konfiguračního souboru do backups/ s timestampem.
 * Auto-prune: max 20 záloh.
 * @returns {string|null}
 */
function backupConfig() {
  if (!fs.existsSync(CONFIG_PATH)) return null;
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const dest = path.join(BACKUP_DIR, `config_backup_${_timestamp()}.json`);
    fs.copyFileSync(CONFIG_PATH, dest);
    _pruneOldBackups('config_backup', 20);
    _log('INFO', 'backupConfig: záloha vytvořena', dest);
    return dest;
  } catch (err) {
    _log('ERROR', 'backupConfig: selhání', err.message);
    return null;
  }
}

/**
 * Vrátí seznam záloh konfigurace seřazených od nejnovější.
 */
function listConfigBackups() {
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    return fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('config_backup'))
      .map(f => { const p = path.join(BACKUP_DIR, f); return { name: f, path: p, mtime: fs.statSync(p).mtime }; })
      .sort((a, b) => b.mtime - a.mtime);
  } catch { return []; }
}

// ══════════════════════════════════════════════════════════════
// ZÁLOHA ENGINE SOUBORŮ
// ══════════════════════════════════════════════════════════════

/**
 * Zazálohuje složky engine/ a resources/ do backups/engine_backup/.
 * Vždy jen jedna záloha (předchozí se odstraní).
 * Zapíše metadata + restore skripty (PB_restore.bat / PB_restore.sh).
 * @returns {string|null}
 */
function backupEngineFiles() {
  try {
    const appRoot = _getAppRoot();

    if (fs.existsSync(ENGINE_BACKUP_DIR)) {
      fs.rmSync(ENGINE_BACKUP_DIR, { recursive: true, force: true });
    }
    fs.mkdirSync(ENGINE_BACKUP_DIR, { recursive: true });

    const srcEngine = path.join(appRoot, 'engine');
    if (fs.existsSync(srcEngine)) {
      _copyDirSync(srcEngine, path.join(ENGINE_BACKUP_DIR, 'engine'));
    }

    const srcResources = path.join(appRoot, 'resources');
    if (fs.existsSync(srcResources)) {
      _copyDirSync(srcResources, path.join(ENGINE_BACKUP_DIR, 'resources'));
    }

    fs.writeFileSync(
      path.join(ENGINE_BACKUP_DIR, 'backup_meta.json'),
      JSON.stringify({ version: app.getVersion(), timestamp: new Date().toISOString() }, null, 2),
      'utf8'
    );

    _writeRestoreScripts(appRoot);
    _log('INFO', 'backupEngineFiles: záloha vytvořena', ENGINE_BACKUP_DIR);
    return ENGINE_BACKUP_DIR;
  } catch (err) {
    _log('ERROR', 'backupEngineFiles: selhání', err.message);
    return null;
  }
}

/**
 * Vrátí metadata zálohy engine nebo null pokud záloha neexistuje.
 */
function getEngineBackupMeta() {
  const metaPath = path.join(ENGINE_BACKUP_DIR, 'backup_meta.json');
  if (!fs.existsSync(metaPath)) return null;
  try { return JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch (_) { return null; }
}

// ══════════════════════════════════════════════════════════════
// OBNOVA ENGINE SOUBORŮ
// ══════════════════════════════════════════════════════════════

/**
 * Obnoví zálohu engine/ a resources/ zpět do aplikace.
 * @returns {{ ok: boolean, message: string }}
 */
function restoreEngineBackup() {
  try {
    if (!fs.existsSync(ENGINE_BACKUP_DIR)) {
      return { ok: false, message: 'Žádná záloha neexistuje.' };
    }

    const meta = getEngineBackupMeta();
    if (!meta) return { ok: false, message: 'Záloha je poškozená (chybí metadata).' };

    const appRoot  = _getAppRoot();
    const restored = [];

    const bakEngine = path.join(ENGINE_BACKUP_DIR, 'engine');
    const dstEngine = path.join(appRoot, 'engine');
    if (fs.existsSync(bakEngine)) {
      if (fs.existsSync(dstEngine)) fs.rmSync(dstEngine, { recursive: true, force: true });
      _copyDirSync(bakEngine, dstEngine);
      restored.push('engine/');
    }

    const bakRes = path.join(ENGINE_BACKUP_DIR, 'resources');
    const dstRes = path.join(appRoot, 'resources');
    if (fs.existsSync(bakRes)) {
      if (fs.existsSync(dstRes)) fs.rmSync(dstRes, { recursive: true, force: true });
      _copyDirSync(bakRes, dstRes);
      restored.push('resources/');
    }

    if (meta.version) {
      try { fs.appendFileSync(INSTALLED_FILE, `${meta.version} - restored\n`, 'utf8'); } catch (_) {}
    }

    _log('INFO', 'restoreEngineBackup: obnova dokončena', `v${meta.version} → ${restored.join(', ')}`);
    return {
      ok: true,
      message: `Záloha verze ${meta.version || '?'} ze dne ${meta.timestamp || '?'} byla obnovena.\nAplikace se nyní restartuje.`,
    };
  } catch (err) {
    _log('ERROR', 'restoreEngineBackup: selhání', err.message);
    return { ok: false, message: `Obnovení selhalo: ${err.message}` };
  }
}

// ══════════════════════════════════════════════════════════════
// IP HELPERY
// ══════════════════════════════════════════════════════════════

function isValidIp(ip) {
  if (!ip || typeof ip !== 'string') return false;
  const parts = ip.trim().split('.');
  if (parts.length !== 4) return false;
  return parts.every(p => { const n = Number(p); return Number.isInteger(n) && n >= 0 && n <= 255 && String(n) === p; });
}

function parseKnownIps(raw) {
  if (!raw) return [];
  return [...new Set(raw.split(',').map(s => s.trim()).filter(isValidIp))];
}

function knownIpsToStr(ips) {
  return (ips || []).filter(isValidIp).join(',');
}

// ══════════════════════════════════════════════════════════════
// QR BARVA HELPERY
// ══════════════════════════════════════════════════════════════

function parseRgbColor(raw, fallback) {
  try {
    const parts = (raw || '').split(',').map(s => parseInt(s.trim(), 10));
    if (parts.length === 3 && parts.every(n => !isNaN(n))) {
      return parts.map(n => Math.max(0, Math.min(255, n)));
    }
  } catch (_) {}
  return fallback;
}

function qrFillFromCfg(cfg) { return parseRgbColor(cfg.QR_FILL_COLOR, [0, 0, 0]); }
function qrBgFromCfg(cfg)   { return parseRgbColor(cfg.QR_BG_COLOR, [255, 255, 255]); }

// ══════════════════════════════════════════════════════════════
// PRIVÁTNÍ POMOCNÉ FUNKCE
// ══════════════════════════════════════════════════════════════

function _getAppRoot() {
  if (app.isPackaged) return path.dirname(app.getPath('exe'));
  return path.join(__dirname, '..', '..');
}

function _writeRaw(data) {
  const tmp = CONFIG_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, CONFIG_PATH);
}

function _backupCorrupt() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) return;
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    fs.copyFileSync(CONFIG_PATH, path.join(BACKUP_DIR, `config_CORRUPT_${_timestamp()}.json`));
  } catch (_) {}
}

function _pruneOldBackups(prefix, keep = 10) {
  try {
    const all = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith(prefix))
      .map(f => { const p = path.join(BACKUP_DIR, f); return { path: p, mtime: fs.statSync(p).mtime }; })
      .sort((a, b) => b.mtime - a.mtime);
    for (const item of all.slice(keep)) {
      try { fs.statSync(item.path).isDirectory() ? fs.rmSync(item.path, { recursive: true, force: true }) : fs.unlinkSync(item.path); } catch (_) {}
    }
  } catch (_) {}
}

function _copyDirSync(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    entry.isDirectory() ? _copyDirSync(s, d) : fs.copyFileSync(s, d);
  }
}

function _timestamp() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

function _writeRestoreScripts(appRoot) {
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });

    fs.writeFileSync(path.join(BACKUP_DIR, 'PB_restore.bat'), [
      '@echo off', 'chcp 65001 > nul',
      'set SCRIPT_DIR=%~dp0', 'set APP_ROOT=%SCRIPT_DIR%..',
      'set BACKUP=%SCRIPT_DIR%engine_backup', '',
      'set AUTO_ARG=',
      'if /i "%1"=="/auto"  set AUTO_ARG=--auto',
      'if /i "%1"=="--auto" set AUTO_ARG=--auto', '',
      'if not exist "%BACKUP%\\backup_meta.json" ( echo CHYBA: Zaloha neexistuje. & if not "%AUTO_ARG%"=="--auto" pause & exit /b 1 )',
      'if "%AUTO_ARG%"=="--auto" ( timeout /t 3 /nobreak > nul ) else ( pause )',
      'if exist "%APP_ROOT%\\engine"    rmdir /s /q "%APP_ROOT%\\engine"',
      'xcopy /e /i /y "%BACKUP%\\engine" "%APP_ROOT%\\engine" > nul',
      'if exist "%APP_ROOT%\\resources" rmdir /s /q "%APP_ROOT%\\resources"',
      'if exist "%BACKUP%\\resources"   xcopy /e /i /y "%BACKUP%\\resources" "%APP_ROOT%\\resources" > nul',
      'if "%AUTO_ARG%"=="--auto" ( timeout /t 2 /nobreak > nul & start "" "%APP_ROOT%\\PhotoBridge.exe" ) else ( start "" "%APP_ROOT%\\PhotoBridge.exe" )',
      'exit /b 0', '',
    ].join('\r\n'), { encoding: 'utf8' });

    fs.writeFileSync(path.join(BACKUP_DIR, 'PB_restore.sh'), [
      '#!/bin/bash',
      'SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"',
      'APP_ROOT="$(dirname "$SCRIPT_DIR")"',
      'BACKUP="$SCRIPT_DIR/engine_backup"', '',
      'if [ ! -f "$BACKUP/backup_meta.json" ]; then echo "CHYBA: Záloha neexistuje." && exit 1; fi', '',
      'rm -rf "$APP_ROOT/engine" && cp -r "$BACKUP/engine" "$APP_ROOT/engine"',
      'rm -rf "$APP_ROOT/resources"',
      '[ -d "$BACKUP/resources" ] && cp -r "$BACKUP/resources" "$APP_ROOT/resources"',
      'echo "Obnova dokončena."',
    ].join('\n'), { encoding: 'utf8', mode: 0o755 });

    const templatePath = path.join(BACKUP_DIR, 'RESTORE_REQUESTED_template.txt');
    if (!fs.existsSync(templatePath)) {
      fs.writeFileSync(templatePath, '# * = vsechna PC | PC01 = jen tento stroj\n*\n', 'utf8');
    }
  } catch (err) {
    _log('WARN', '_writeRestoreScripts: selhání', err.message);
  }
}

function _log(level, ...args) {
  console.log(`[${new Date().toISOString()}] [${level}] [config]`, ...args);
}

// ══════════════════════════════════════════════════════════════
// EXPORT
// ══════════════════════════════════════════════════════════════

module.exports = {
  // Cesty
  CONFIG_PATH, BACKUP_DIR, ENGINE_BACKUP_DIR, LOG_DIR, PAINT_TEMP_DIR, INSTALLED_FILE, USER_DATA_DIR,

  // Data
  DEFAULT_CONFIG,

  // Inicializace
  ensureRuntimeDirs, initConfig,

  // Config
  readConfig, writeConfig, resetConfigToDefaults, validateValue,

  // Zálohy
  backupConfig, listConfigBackups, backupEngineFiles, getEngineBackupMeta, restoreEngineBackup,

  // IP helpery
  isValidIp, parseKnownIps, knownIpsToStr,

  // QR helpery
  parseRgbColor, qrFillFromCfg, qrBgFromCfg,
};
