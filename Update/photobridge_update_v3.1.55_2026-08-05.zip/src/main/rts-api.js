'use strict';
// ============================================================
// PhotoBridge – src/main/rts-api.js
// Klient pro RTS API (Britex) – náhrada UploadScanu.
//
// CO UMÍ:
//   • drží OAuth2 přístupový token (obnova přes refresh_token)
//   • POST /api/SandBox/TempFile      – dočasné uložení souboru
//   • POST /api/SandBox/GetTempFile   – stažení dočasného souboru
//   • POST /api/Info21/SavePhotoFile  – ULOŽENÍ FOTKY DO ZAKÁZKY
//
// NEDOŘEŠENÉ BODY (čeká na potvrzení od IT – proto přepínače v configu):
//   1) RTS_ID_MODE     – je "id" u SavePhotoFile číslo zakázky, nebo interní ID?
//   2) RTS_DATA_FIELD  – patří base64 do "data", nebo "content"?
// Až se potvrdí, stačí přepnout v Nastavení; kód se nemění.
// ============================================================

const fs   = require('fs');
const path = require('path');

let _cfgMod = null;
function readCfg() {
    try {
        if (!_cfgMod) _cfgMod = require('./config');
        return _cfgMod.readConfig();
    } catch (_) { return {}; }
}
function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

// ── Základ ───────────────────────────────────────────────────────────────────

/** Kořenová adresa RTS (dev/produkce se přepíná v Nastavení). */
function baseUrl() {
    const u = String(readCfg().RTS_URL || 'https://rts.britex.cz').trim();
    return u.replace(/\/+$/, '');
}

/** Do kterého pole patří base64 obsah souboru ('data' | 'content'). */
function dataField() {
    const f = String(readCfg().RTS_DATA_FIELD || 'data').trim().toLowerCase();
    return (f === 'content') ? 'content' : 'data';
}

/** Jak se určuje "id" u SavePhotoFile ('job' = číslo zakázky | 'internal'). */
function idMode() {
    const m = String(readCfg().RTS_ID_MODE || 'job').trim().toLowerCase();
    return (m === 'internal') ? 'internal' : 'job';
}

// ── OAuth2 token ─────────────────────────────────────────────────────────────

let _token        = null;   // přístupový token
let _tokenExpires = 0;      // ms timestamp
let _refreshToken = null;

/**
 * Vrátí platný přístupový token.
 * Priorita: 1) ruční token z Nastavení (RTS_TOKEN – pro rychlé testování)
 *           2) v paměti, pokud ještě neexpiroval
 *           3) obnova přes refresh_token
 * Přihlašovací (authorization_code) flow řeší okno s přihlášením, ne tento modul.
 */
async function getToken() {
    const cfg = readCfg();

    // 1) Ruční token (vyplněný v Nastavení) – užitečné pro test bez přihlášení
    const manual = String(cfg.RTS_TOKEN || '').trim();
    if (manual) return manual;

    // 2) Platný token v paměti (30 s rezerva)
    if (_token && Date.now() < (_tokenExpires - 30_000)) return _token;

    // 3) Obnova přes refresh_token
    if (_refreshToken) {
        try {
            const t = await _requestToken({
                grant_type:    'refresh_token',
                refresh_token: _refreshToken,
                client_id:     String(cfg.RTS_CLIENT_ID || ''),
                client_secret: String(cfg.RTS_CLIENT_SECRET || ''),
            });
            if (t) return t;
        } catch (e) {
            log('WARN', 'RTS refresh', String(e.message || e));
        }
    }
    return null;
}

/** Zavolá POST /oauth/Token a uloží výsledek do paměti. */
async function _requestToken(params) {
    const url  = `${baseUrl()}/oauth/Token`;
    const body = new URLSearchParams(params).toString();

    const resp = await fetch(url, {
        method:  'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
        body,
    });
    if (!resp.ok) {
        const txt = await resp.text().catch(() => '');
        throw new Error(`Token HTTP ${resp.status}: ${txt.slice(0, 200)}`);
    }
    const j = await resp.json();
    _token        = j.access_token || j.token || null;
    _refreshToken = j.refresh_token || _refreshToken;
    const ttl     = Number(j.expires_in || 3600);
    _tokenExpires = Date.now() + ttl * 1000;
    log('INFO', 'RTS token', `Získán token, platnost ${ttl}s`);
    return _token;
}

/**
 * Vymění autorizační kód za token (dokončení přihlášení).
 * Volá se z okna, které provedlo /oauth/Authorize.
 */
async function exchangeCode(code, redirectUri, codeVerifier) {
    const cfg = readCfg();
    const p = {
        grant_type:    'authorization_code',
        code,
        redirect_uri:  redirectUri || String(cfg.RTS_REDIRECT_URI || ''),
        client_id:     String(cfg.RTS_CLIENT_ID || ''),
        client_secret: String(cfg.RTS_CLIENT_SECRET || ''),
    };
    if (codeVerifier) p.code_verifier = codeVerifier;
    return _requestToken(p);
}

/** Ruční nastavení tokenu (např. vytaženého z prohlížeče při testování). */
function setToken(token, expiresInSec) {
    _token        = token || null;
    _tokenExpires = Date.now() + (Number(expiresInSec || 3600) * 1000);
}

/** Hlavičky pro autorizované volání. */
async function authHeaders(extra) {
    const t = await getToken();
    const h = Object.assign({ 'Accept': 'application/json' }, extra || {});
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
}

// ── Volání API ───────────────────────────────────────────────────────────────

/**
 * Obecné POST volání na RTS s JSON tělem.
 * @returns {Promise<{ok:boolean, status:number, body:any, error?:string}>}
 */
async function postJson(endpoint, payload, timeoutMs = 60_000) {
    const url  = `${baseUrl()}${endpoint}`;
    const ctrl = new AbortController();
    const to   = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const resp = await fetch(url, {
            method:  'POST',
            headers: await authHeaders({ 'Content-Type': 'application/json' }),
            body:    JSON.stringify(payload),
            signal:  ctrl.signal,
        });
        clearTimeout(to);

        let body = null;
        const txt = await resp.text().catch(() => '');
        try { body = txt ? JSON.parse(txt) : null; } catch (_) { body = txt; }

        if (!resp.ok) {
            return { ok: false, status: resp.status, body,
                     error: (typeof body === 'string' ? body : JSON.stringify(body || '')).slice(0, 300) };
        }
        return { ok: true, status: resp.status, body };
    } catch (e) {
        clearTimeout(to);
        return { ok: false, status: 0, body: null, error: String(e.message || e) };
    }
}

/**
 * Uloží soubor do dočasného úložiště (redis) a vrátí jeho SHA256.
 * Používá se, když má fotku převzít PC (přes SignalR / poll).
 */
async function tempFileUpload(filePath) {
    const b64 = fs.readFileSync(filePath).toString('base64');
    const res = await postJson('/api/SandBox/TempFile', { content: b64 });
    if (!res.ok) {
        log('ERROR', 'RTS TempFile', `${path.basename(filePath)}: ${res.error}`);
        return null;
    }
    const sha = res.body?.sha256 || res.body?.Sha256 || res.body?.hash || null;
    log('INFO', 'RTS TempFile', `${path.basename(filePath)} → sha256=${sha || '(neznámý tvar odpovědi)'}`);
    return { sha256: sha, raw: res.body };
}

/** Stáhne dočasný soubor podle SHA256. */
async function tempFileDownload(sha256) {
    const res = await postJson('/api/SandBox/GetTempFile', { sha256 });
    if (!res.ok) {
        log('ERROR', 'RTS GetTempFile', `${sha256}: ${res.error}`);
        return null;
    }
    return res.body;
}

/**
 * ULOŽÍ FOTKU DO ZAKÁZKY – hlavní operace (náhrada UploadScanu).
 *
 * @param {string} filePath – cesta k hotovému souboru
 * @param {object} meta     – { job, typ, docType }
 */
async function savePhotoFile(filePath, meta) {
    if (!fs.existsSync(filePath)) {
        return { ok: false, error: 'Soubor neexistuje', permanent: true };
    }
    const b64  = fs.readFileSync(filePath).toString('base64');
    const name = path.basename(filePath);

    // Číslo zakázky → "id" (přepínatelné, dokud IT nepotvrdí význam pole)
    let id = parseInt(String(meta?.job || '').replace(/\D/g, ''), 10);
    if (idMode() === 'internal') {
        const resolved = await resolveOrderId(meta?.job);
        if (resolved) id = resolved;
    }
    if (!id || Number.isNaN(id)) {
        return { ok: false, error: `Neplatné číslo zakázky: ${meta?.job}`, permanent: true };
    }

    // Base64 do pole podle nastavení; druhé pole zůstává prázdné
    const file = { name, content: '', data: '' };
    file[dataField()] = b64;

    // Typ dokumentu (DD_DOC…) RTS zatím nepřijímá – až doplní pole, odkomentovat:
    // if (meta?.docType) file.doc_type = meta.docType;

    const res = await postJson('/api/Info21/SavePhotoFile', { files: [file], id });
    if (res.ok) {
        log('INFO', 'RTS SavePhotoFile', `OK: ${name} → zakázka ${id}`);
        return { ok: true, status: res.status, body: res.body };
    }

    // 4xx (kromě 408/429) = chyba požadavku → opakování nepomůže
    const permanent = res.status >= 400 && res.status < 500 &&
                      res.status !== 408 && res.status !== 429;
    log('ERROR', 'RTS SavePhotoFile', `${name} → zakázka ${id}: HTTP ${res.status} ${res.error}`);
    return { ok: false, status: res.status, error: res.error, permanent };
}

/**
 * Dohledá interní ID zakázky podle jejího čísla.
 * Použije se jen když RTS_ID_MODE = 'internal'.
 * POZN.: endpoint pro vyhledání zakázky zatím není potvrzen – doplní se
 * po odpovědi od IT. Do té doby vrací null (použije se číslo zakázky).
 */
async function resolveOrderId(job) {
    const n = String(job || '').replace(/\D/g, '');
    if (!n) return null;
    try {
        const url  = `${baseUrl()}/api/v4/ServiceOrder?doc=${encodeURIComponent(n)}`;
        const resp = await fetch(url, { headers: await authHeaders() });
        if (!resp.ok) return null;
        const j = await resp.json();
        const row = Array.isArray(j) ? j[0] : (j?.items?.[0] || j);
        return row?.id || row?.Id || null;
    } catch (_) { return null; }
}

/** Rychlý test spojení a autorizace (pro tlačítko v Nastavení). */
async function testConnection() {
    try {
        const resp = await fetch(`${baseUrl()}/api/v4/User`, { headers: await authHeaders() });
        if (resp.ok) {
            const u = await resp.json().catch(() => null);
            return { ok: true, user: u?.email || u?.username || u?.name || '(přihlášen)' };
        }
        if (resp.status === 401) return { ok: false, error: 'Neplatný nebo chybějící token (401)' };
        return { ok: false, error: `HTTP ${resp.status}` };
    } catch (e) {
        return { ok: false, error: String(e.message || e) };
    }
}

module.exports = {
    baseUrl, getToken, setToken, exchangeCode, authHeaders,
    postJson, tempFileUpload, tempFileDownload, savePhotoFile,
    resolveOrderId, testConnection, dataField, idMode,
};
