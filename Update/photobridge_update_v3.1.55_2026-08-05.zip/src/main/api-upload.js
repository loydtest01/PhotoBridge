'use strict';
// ============================================================
// PhotoBridge – src/main/api-upload.js
// Odesílání hotových fotek do API servisu (náhrada za M:\UploadScan).
//
// PROČ: UploadScan (info21) skončí s příchodem RTS. Fotky pak musí jít
// do zakázek přes HTTP API. Tento modul je JEDINÉ místo, kde se odesílá –
// používá ho poller (přímé fotky) i paint.js (fotky po editaci) i ruční vklad.
//
// REŽIMY (config API_MODE):
//   'disk'  – jen M:\UploadScan (výchozí, dnešní chování; API se nevolá)
//   'both'  – disk I API (přechodné období – bezpečné ověření, že API sedí)
//   'api'   – jen API (po vypnutí UploadScanu)
//
// ODOLNOST: každé odeslání jde nejdřív do fronty na disku (userData/api_queue).
// Když API neodpoví, položka ve frontě zůstane a zkusí se znovu (exponenciální
// backoff). Fotka se tedy nikdy neztratí kvůli výpadku sítě nebo serveru.
//
// POZNÁMKA: konkrétní endpoint/autentizaci/formát polí dodá IT (Luboš/RTS).
// Do té doby je modul připraven a NEAKTIVNÍ (API_MODE='disk').
// ============================================================

const fs   = require('fs');
const path = require('path');
const { app } = require('electron');

let _cfgMod = null;
function getConfig() { if (!_cfgMod) _cfgMod = require('./config'); return _cfgMod; }
let _utils = null;
function log(level, ctx, msg) {
    try {
        if (!_utils) _utils = require('./utils');
        _utils.log(level, ctx, msg);
    } catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

// ── Fronta na disku ──────────────────────────────────────────────────────────
// userData (ne složka aplikace!) – přežije aktualizaci i reinstalaci.
const QUEUE_DIR = path.join(app.getPath('userData'), 'api_queue');

const RETRY_DELAYS_MS = [0, 30e3, 2 * 60e3, 10 * 60e3, 30 * 60e3, 60 * 60e3];
const MAX_ATTEMPTS    = 8;
const TICK_MS         = 60e3;   // kontrola fronty jednou za minutu

let _timer      = null;
let _processing = false;

// ── Pomocné ──────────────────────────────────────────────────────────────────

function _cfg() {
    try { return getConfig().readConfig(); } catch (_) { return {}; }
}

/** Režim odesílání: 'disk' | 'both' | 'api' */
function getMode() {
    const m = String(_cfg().API_MODE || 'disk').trim().toLowerCase();
    return ['disk', 'both', 'api'].includes(m) ? m : 'disk';
}

/** Má se vůbec volat API? */
function isApiEnabled() {
    const m = getMode();
    if (m === 'disk') return false;
    // RTS má adresu ve vlastním nastavení (RTS_URL), obecné API potřebuje API_URL
    if (String(_cfg().API_TARGET || 'rts').toLowerCase() === 'rts') return true;
    return !!String(_cfg().API_URL || '').trim();
}

/** Má se ještě ukládat na disk (M:\UploadScan)? */
function isDiskEnabled() {
    return getMode() !== 'api';
}

/**
 * Přeloží interní zkratku typu (SD/SP/FA/…) na typ dokumentu v servisu.
 * Mapa je v configu API_TYPE_MAP jako "SD=DD_DOC,SP=DD_DOC,FA=DD_DOC".
 * Bez mapy se pošle původní zkratka.
 */
function mapDocType(typ) {
    const raw = String(_cfg().API_TYPE_MAP || '').trim();
    const key = String(typ || '').toUpperCase();
    if (!raw) return key;
    for (const pair of raw.split(',')) {
        const [from, to] = pair.split('=').map(s => (s || '').trim());
        if (from && to && from.toUpperCase() === key) return to;
    }
    return key;
}

/**
 * Z názvu souboru vytáhne metadata: zakázku, typ a pořadí.
 * Podporuje oba tvary: "SD_4529589A.jpg" i "SD_4529589_1785850772995_001.jpg".
 */
function parseMeta(filePath) {
    const base = path.basename(filePath, path.extname(filePath));
    const parts = base.split('_');
    const typ = (parts[0] || '').toUpperCase();

    let job = '', letter = '', sequence = '';
    const m2 = base.match(/^([A-Z]+)_(\d{6,})([A-Z]*)$/i);
    if (m2) {
        job = m2[2];
        letter = (m2[3] || '').toUpperCase();
        sequence = letter ? String(letter.charCodeAt(0) - 64) : '';
    } else {
        const jm = base.match(/(\d{6,})/);
        if (jm) job = jm[1];
        const sm = base.match(/_(\d{1,3})$/);
        if (sm) sequence = String(parseInt(sm[1], 10));
    }
    return { job, typ, letter, sequence };
}

function _ensureQueueDir() {
    try { fs.mkdirSync(QUEUE_DIR, { recursive: true }); } catch (_) {}
}

function _queueItems() {
    try {
        return fs.readdirSync(QUEUE_DIR)
            .filter(f => f.endsWith('.json'))
            .sort();
    } catch (_) { return []; }
}

/** Kolik položek čeká ve frontě (pro UI / diagnostiku). */
function queueLength() { return _queueItems().length; }

// ── Veřejné API modulu ───────────────────────────────────────────────────────

/**
 * Zařadí hotový soubor k odeslání do API servisu.
 * Volá se AŽ když je fotka finální (po uložení na disk / po zavření Malování).
 * Když je režim 'disk' nebo chybí URL, tiše neudělá nic.
 *
 * @param {string} filePath – absolutní cesta k hotovému souboru
 * @param {object} [meta]   – volitelně { job, typ, sequence } (jinak z názvu)
 */
function enqueueFile(filePath, meta) {
    try {
        if (!isApiEnabled()) return;
        if (!filePath || !fs.existsSync(filePath)) {
            log('WARN', 'API_UPLOAD', `Soubor neexistuje, nezařazuji: ${filePath}`);
            return;
        }
        _ensureQueueDir();

        const parsed = Object.assign(parseMeta(filePath), meta || {});
        const id = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const job = {
            id,
            filePath,
            job:      parsed.job || '',
            typ:      parsed.typ || '',
            docType:  mapDocType(parsed.typ),
            sequence: parsed.sequence || '',
            attempts: 0,
            nextTry:  Date.now(),
            created:  Date.now(),
        };
        fs.writeFileSync(path.join(QUEUE_DIR, `${id}.json`), JSON.stringify(job, null, 2), 'utf8');
        log('INFO', 'API_UPLOAD', `Zařazeno k odeslání: ${path.basename(filePath)} (zakázka ${job.job}, typ ${job.docType})`);
        // Zkus hned – ať se to neodkládá o minutu
        setTimeout(() => { processQueue().catch(() => {}); }, 500);
    } catch (e) {
        log('ERROR', 'API_UPLOAD enqueue', String(e));
    }
}

/**
 * Odešle jeden soubor na API servisu.
 *
 * ⚠️ FORMÁT REQUESTU JE PROZATÍMNÍ – upraví se podle specifikace od IT
 * (URL, autentizace, názvy polí). Změna se dělá JEN v této funkci.
 *
 * @returns {Promise<{ok:boolean, status?:number, error?:string, permanent?:boolean}>}
 */
async function sendOne(item) {
    if (!fs.existsSync(item.filePath)) {
        return { ok: false, error: 'Soubor už neexistuje', permanent: true };
    }

    // RTS (Britex) – výchozí cíl: POST /api/Info21/SavePhotoFile
    // Autorizace přes OAuth2 token, soubor jako base64 v JSON.
    if (String(_cfg().API_TARGET || 'rts').toLowerCase() === 'rts') {
        try {
            const rts = require('./rts-api');
            return await rts.savePhotoFile(item.filePath, {
                job:     item.job,
                typ:     item.typ,
                docType: item.docType,
            });
        } catch (e) {
            return { ok: false, error: `RTS modul: ${String(e.message || e)}` };
        }
    }

    // Obecné API (multipart) – záložní varianta pro jiný systém než RTS
    const cfg    = _cfg();
    const url    = String(cfg.API_URL || '').trim();
    const apiKey = String(cfg.API_KEY || '').trim();
    if (!url) return { ok: false, error: 'API_URL není nastavena', permanent: true };

    const buf  = fs.readFileSync(item.filePath);
    const name = path.basename(item.filePath);

    const form = new FormData();
    form.append('file', new Blob([buf]), name);
    form.append('order',    item.job || '');
    form.append('doc_type', item.docType || '');
    if (item.sequence) form.append('sequence', String(item.sequence));
    form.append('source', 'PhotoBridge');

    const headers = {};
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;

    const ctrl = new AbortController();
    const to   = setTimeout(() => ctrl.abort(), 60e3);
    try {
        const resp = await fetch(url, { method: 'POST', headers, body: form, signal: ctrl.signal });
        clearTimeout(to);
        if (resp.ok) return { ok: true, status: resp.status };

        const permanent = resp.status >= 400 && resp.status < 500 &&
                          resp.status !== 408 && resp.status !== 429;
        let detail = '';
        try { detail = (await resp.text() || '').slice(0, 200); } catch (_) {}
        return { ok: false, status: resp.status, error: detail || `HTTP ${resp.status}`, permanent };
    } catch (e) {
        clearTimeout(to);
        return { ok: false, error: String(e.message || e) };
    }
}

/** Projde frontu a zkusí odeslat, co je na řadě. */
async function processQueue() {
    if (_processing) return;
    if (!isApiEnabled()) return;
    _processing = true;
    try {
        const files = _queueItems();
        for (const f of files) {
            const p = path.join(QUEUE_DIR, f);
            let item;
            try { item = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (_) {
                try { fs.unlinkSync(p); } catch (_) {}
                continue;
            }
            if (Date.now() < (item.nextTry || 0)) continue;

            const res = await sendOne(item);
            if (res.ok) {
                try { fs.unlinkSync(p); } catch (_) {}
                log('INFO', 'API_UPLOAD', `Odesláno OK: ${path.basename(item.filePath)} (zakázka ${item.job})`);
                continue;
            }

            item.attempts = (item.attempts || 0) + 1;
            item.lastError = res.error || '';
            if (res.permanent || item.attempts >= MAX_ATTEMPTS) {
                // Neopakovatelná chyba / vyčerpané pokusy → odlož do failed/ a upozorni
                try {
                    const failedDir = path.join(QUEUE_DIR, 'failed');
                    fs.mkdirSync(failedDir, { recursive: true });
                    fs.writeFileSync(path.join(failedDir, f), JSON.stringify(item, null, 2), 'utf8');
                    fs.unlinkSync(p);
                } catch (_) {}
                log('ERROR', 'API_UPLOAD',
                    `NEODESLÁNO (${item.attempts}. pokus): ${path.basename(item.filePath)} – ${item.lastError}`);
                _notifyFailure(item);
            } else {
                const delay = RETRY_DELAYS_MS[Math.min(item.attempts, RETRY_DELAYS_MS.length - 1)];
                item.nextTry = Date.now() + delay;
                try { fs.writeFileSync(p, JSON.stringify(item, null, 2), 'utf8'); } catch (_) {}
                log('WARN', 'API_UPLOAD',
                    `Pokus ${item.attempts} selhal (${item.lastError}) – další za ${Math.round(delay / 1000)} s`);
            }
        }
    } finally {
        _processing = false;
    }
}

/** Upozorní uživatele, že se soubor nepodařilo odeslat (aby to neuniklo). */
function _notifyFailure(item) {
    try {
        const { Notification } = require('electron');
        if (Notification && Notification.isSupported()) {
            new Notification({
                title: 'PhotoBridge – odeslání selhalo',
                body:  `Fotku ${path.basename(item.filePath)} (zakázka ${item.job}) se nepodařilo odeslat do servisu. Zkontroluj nastavení API.`,
            }).show();
        }
    } catch (_) {}
}

/** Spustí periodické zpracování fronty. */
function start() {
    if (_timer) return;
    _ensureQueueDir();
    _timer = setInterval(() => { processQueue().catch(() => {}); }, TICK_MS);
    // Po startu zkus hned – doručí, co uvízlo při minulém běhu
    setTimeout(() => { processQueue().catch(() => {}); }, 5000);
    log('INFO', 'API_UPLOAD', `Fronta spuštěna (režim=${getMode()}, čeká ${queueLength()} položek)`);
}

function stop() {
    if (_timer) { clearInterval(_timer); _timer = null; }
}

module.exports = {
    enqueueFile, processQueue, start, stop,
    getMode, isApiEnabled, isDiskEnabled, mapDocType, parseMeta,
    queueLength, QUEUE_DIR,
};
