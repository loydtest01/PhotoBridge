'use strict';
// ============================================================================
//  PhotoBridge – src/main/sber-window.js
//
//  VYSKAKOVACÍ OKNO S NAČTENÝM SÉRIOVÝM ČÍSLEM
//
//  K ČEMU TO JE
//  Technik vkládá disky jeden po druhém a po každém potřebuje číslo hned
//  vložit do řádku v Excelu. Okno se objeví nad ostatními – i když je
//  PhotoBridge minimalizovaný – kliknutím se číslo zkopíruje do schránky
//  a okno zmizí. Zbývá Ctrl+V a další disk.
//
//  PROČ SE NEZAVÍRÁ SAMO
//  Kdyby zmizelo po čase, technik by o číslo přišel přesně ve chvíli, kdy
//  se otočí k dalšímu disku. Zavře se AŽ PO KLIKNUTÍ.
//
//  FRONTA
//  Když přijdou dvě čísla rychle za sebou, druhé počká. Po odkliknutí
//  prvního hned naskočí další – nic se neztratí.
// ============================================================================

const { BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const fs   = require('fs');

let _win   = null;
let _fronta = [];      // čísla čekající na odkliknutí
let _aktualni = '';

const SIROKE = 300;
const VYSOKE = 132;

function _cfg() { return require('./config'); }
function _log(u, z) { try { require('./utils').log(u, 'SBER', z); } catch (_) {} }

/** Vpravo dole nad hodinami – tam, kde uživatel čeká oznámení. */
function _poloha() {
    const b = screen.getPrimaryDisplay().workArea;
    return { x: b.x + b.width - SIROKE - 24, y: b.y + b.height - VYSOKE - 24 };
}

function _vytvorOkno() {
    if (_win && !_win.isDestroyed()) return _win;

    const { x, y } = _poloha();
    _win = new BrowserWindow({
        width: SIROKE, height: VYSOKE, x, y,
        frame: false, transparent: true, resizable: false,
        skipTaskbar: true, alwaysOnTop: true, hasShadow: false,
        roundedCorners: false, type: 'toolbar',
        // Okno se nesmí prát o zaměření s Excelem, ve kterém technik píše.
        focusable: false,
        webPreferences: {
            preload: path.join(__dirname, '..', '..', 'preload.js'),
            contextIsolation: true, nodeIntegration: false, sandbox: false,
        },
        show: false,
    });

    // 'screen-saver' drží okno nad běžnými aplikacemi i nad celoobrazovkovými.
    _win.setAlwaysOnTop(true, 'screen-saver');
    _win.setVisibleOnAllWorkspaces?.(true);

    const html = path.join(__dirname, '..', 'renderer', 'sber.html');
    if (!fs.existsSync(html)) { _log('ERROR', 'sber.html chybí'); return null; }
    _win.loadFile(html);

    _win.on('closed', () => { _win = null; });
    return _win;
}

/** Ukáže další číslo z fronty, nebo okno zavře, když už žádné není. */
function _dalsi() {
    if (!_fronta.length) {
        _aktualni = '';
        if (_win && !_win.isDestroyed()) _win.close();
        _win = null;
        return;
    }

    _aktualni = _fronta.shift();
    const w = _vytvorOkno();
    if (!w) return;

    const posli = () => {
        try { w.webContents.send('sber:cislo', { cislo: _aktualni, ceka: _fronta.length }); }
        catch (_) {}
    };

    if (w.webContents.isLoading()) w.webContents.once('did-finish-load', posli);
    else posli();

    // showInactive: okno se ukáže, ale NEPŘEVEZME zaměření – technik může
    // dál psát v Excelu, aniž by mu to skočilo pod ruce.
    if (!w.isVisible()) w.showInactive();
}

/** Volá modul sběru, když přijde nové číslo. */
function ukazCislo(cislo) {
    const c = String(cislo || '').trim();
    if (!c) return;

    _fronta.push(c);
    _log('INFO', `Nové číslo: ${c} (ve frontě ${_fronta.length})`);

    // Když se zrovna nic nezobrazuje, rovnou to vytáhneme.
    if (!_aktualni) _dalsi();
    else if (_win && !_win.isDestroyed()) {
        // Jen aktualizovat počet čekajících.
        try { _win.webContents.send('sber:cislo', { cislo: _aktualni, ceka: _fronta.length }); }
        catch (_) {}
    }
}

function zavri() {
    _fronta = [];
    _aktualni = '';
    if (_win && !_win.isDestroyed()) _win.close();
    _win = null;
}

function registerIpcHandlers() {
    // Okno se ptá na číslo, které má zobrazit.
    ipcMain.handle('sber:aktualni', () => ({ cislo: _aktualni, ceka: _fronta.length }));

    // Technik klikl → zkopírováno → další z fronty, nebo zavřít.
    ipcMain.handle('sber:hotovo', () => { _dalsi(); return { ok: true }; });

    // Otevře textový seznam všech nasbíraných čísel.
    ipcMain.handle('sber:otevrit-log', () => {
        try {
            const p = require('./sber-sn').souborLogu();
            // Když ještě nic nepřišlo, soubor neexistuje – ať se otevře
            // prázdný místo hlášky o chybějícím souboru.
            if (!fs.existsSync(p)) fs.writeFileSync(p, '', 'utf8');
            require('electron').shell.openPath(p);
            return { ok: true };
        } catch (e) { return { ok: false, error: String(e.message || e) }; }
    });

    _log('INFO', 'IPC handlery zaregistrovány');
}

module.exports = { ukazCislo, zavri, registerIpcHandlers };
