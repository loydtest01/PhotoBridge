'use strict';
// ============================================================
// PhotoBridge – src/main/tour-window.js
// Onboarding prohlídka jako SAMOSTATNÉ okno (nepřekrývá hlavní okno).
// v2.4.2: Opravy – tour:finish nesmí mazat config, openSettings přes modul
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let _utils = null;
function log(...a) { try { (_utils || (_utils = require('./utils'))).log(...a); } catch(_) {} }

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');
const ASSETS_DIR   = path.join(__dirname, '..', '..', 'assets');
const ICON_PATH    = path.join(ASSETS_DIR, 'icons', 'icon.ico');

let _win = null;
let _registered = false;

function openTourWindow(mainWindow) {
  if (_win && !_win.isDestroyed()) { _win.focus(); return; }

  const TOUR_W = 380;
  const TOUR_H = 540;
  let x, y;
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      const mb = mainWindow.getBounds();
      const { screen } = require('electron');
      const display = screen.getDisplayMatching(mb);
      const wa = display.workArea;
      x = mb.x + mb.width + 12;
      y = mb.y;
      if (x + TOUR_W > wa.x + wa.width) {
        x = mb.x - TOUR_W - 12;
        if (x < wa.x) {
          x = mb.x + Math.max(0, (mb.width - TOUR_W) / 2);
          y = mb.y + mb.height + 12;
          if (y + TOUR_H > wa.y + wa.height) {
            y = wa.y + Math.max(0, (wa.height - TOUR_H) / 2);
          }
        }
      }
      x = Math.max(wa.x + 4, Math.min(wa.x + wa.width - TOUR_W - 4, x));
      y = Math.max(wa.y + 4, Math.min(wa.y + wa.height - TOUR_H - 4, y));
    }
  } catch (_) {}

  _win = new BrowserWindow({
    width: TOUR_W, height: TOUR_H, minWidth: 320, minHeight: 420,
    x, y,
    title: 'PhotoBridge – Prohlídka',
    icon: ICON_PATH,
    parent: undefined, modal: false,
    resizable: true, frame: true, autoHideMenuBar: true, alwaysOnTop: false,
    webPreferences: {
      preload: PRELOAD_PATH, contextIsolation: true,
      nodeIntegration: false, sandbox: false, devTools: false,
    },
    show: false,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'tour.html'));
  _win.once('ready-to-show', () => { _win.show(); });
  _win.on('closed', () => { _win = null; });
}

/**
 * Vykoná akci krokem prohlídky.
 *
 * OPRAVA 1: openSettings používá přímé volání modulu.
 *   Původní kód: ipcMain.emit('settings:open') – nefunguje pro ipcMain.handle,
 *   okno se nikdy neotevřelo.
 *
 * OPRAVA 2: Akce otevírající nová okna mají 250 ms zpoždění,
 *   aby renderer stihl zpracovat předchozí akci (view switch apod.)
 */
function executeAction(action, mainWindow) {
  if (!action || !mainWindow || mainWindow.isDestroyed()) return;

  if (action.view) {
    try { mainWindow.webContents.send('tour:set-view', action.view); } catch (_) {}
  }

  if (action.highlight) {
    try { mainWindow.webContents.send('tour:highlight', action.highlight); } catch (_) {}
  }

  // OPRAVA: přímé volání modulu místo nefunkčního ipcMain.emit
  if (action.openSettings) {
    setTimeout(() => {
      try {
        require('./settings-window').openSettingsWindow(mainWindow);
      } catch (e) { log('WARN', 'tour openSettings', e.message); }
    }, 300);
  }

  // Webapp QR – se zpožděním aby view stihl reagovat
  if (action.openWebappQr) {
    setTimeout(() => {
      try {
        const wq = require('./webapp-qr-window');
        if (wq && wq.openWebAppQrWindow) wq.openWebAppQrWindow(mainWindow, '');
      } catch (e) { log('WARN', 'tour openWebappQr', e.message); }
    }, 250);
  }

  if (action.demoQr) {
    try { mainWindow.webContents.send('tour:demo-qr'); } catch (_) {}
  }

  if (action.demoQrEnd) {
    try { mainWindow.webContents.send('tour:demo-qr-end'); } catch (_) {}
  }

  // Demo upload – se zpožděním
  if (action.demoUpload) {
    setTimeout(() => {
      try { mainWindow.webContents.send('tour:demo-upload'); } catch (_) {}
    }, 250);
  }

  // Mobile preview – se zpožděním
  if (action.openMobilePreview) {
    setTimeout(() => {
      try {
        const mp = require('./mobile-preview-window');
        if (mp && mp.openMobilePreview) mp.openMobilePreview(mainWindow);
      } catch (e) { log('WARN', 'tour openMobilePreview', e.message); }
    }, 250);
  }
}

function registerIpcHandlers(getMainWindow) {
  if (_registered) return;
  _registered = true;

  ipcMain.handle('tour:start', () => {
    const mw = getMainWindow ? getMainWindow() : null;
    openTourWindow(mw);
    return { ok: true };
  });

  ipcMain.handle('tour:action', (_evt, action) => {
    const mw = getMainWindow ? getMainWindow() : null;
    executeAction(action || {}, mw);
    return { ok: true };
  });

  // KRITICKÁ OPRAVA: původní kód volal writeConfig({ ONBOARDING_DONE: 'true' }),
  // což přepsalo CELÝ config výchozími hodnotami – všechna uživatelská nastavení
  // (SAVE_DIR, Supabase heslo, tray, složky…) se po dokončení prohlídky SMAZALA.
  // Správně: přečti aktuální config, změň jeden klíč, ulož zpět.
  ipcMain.handle('tour:finish', async () => {
    try {
      const cfgMod = require('./config');
      const current = cfgMod.readConfig();
      current.ONBOARDING_DONE = 'true';
      cfgMod.writeConfig(current);
      log('INFO', 'tour:finish', 'ONBOARDING_DONE uloženo (ostatní nastavení zachována)');
    } catch (e) {
      log('WARN', 'tour:finish', e.message);
    }
    return { ok: true };
  });
}

module.exports = { openTourWindow, registerIpcHandlers };
