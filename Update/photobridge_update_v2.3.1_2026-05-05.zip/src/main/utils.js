"use strict";

/**
 * utils.js – PhotoBridge Electron
 * Fáze 3: Utility funkce (log, IP, porty, stav aplikace, statistiky)
 * Odpovídá Python originálu photobridge.py, řádky 747–1415
 */

const fs   = require("fs");
const os   = require("os");
const path = require("path");
const net  = require("net");
const { execSync, spawn } = require("child_process");

// ─── Electron app – dynamický import (main process) ──────────────────────────
// Bezpečný přístup k app.getPath() – funguje i při require z testů
let _electronApp = null;
function _getApp() {
  if (!_electronApp) {
    try { _electronApp = require("electron").app; } catch {}
  }
  return _electronApp;
}

// ─── Konstanty ────────────────────────────────────────────────────────────────
const APP_NAME = "PhotoBridge";

/** Složka pro logy: %APPDATA%/PhotoBridge/logs  (nebo fallback vedle EXE) */
function getLogDir() {
  try {
    const app = _getApp();
    if (app) return path.join(app.getPath("userData"), "logs");
  } catch {}
  return path.join(process.cwd(), "logs");
}

/** Cesta ke state.json */
function getStatePath() {
  try {
    const app = _getApp();
    if (app) return path.join(app.getPath("userData"), "state.json");
  } catch {}
  return path.join(process.cwd(), "state.json");
}

/** Cesta ke config.json (pro čtení LOG_LEVEL) */
function getConfigPath() {
  try {
    const app = _getApp();
    if (app) return path.join(app.getPath("userData"), "config.json");
  } catch {}
  return path.join(process.cwd(), "config.json");
}

// ─── Povolené přípony obrázků ──────────────────────────────────────────────
const ALLOWED_IMG_EXTS = [".jpg", ".jpeg", ".png", ".bmp", ".webp", ".gif"];

// ─── Limity pro geometrii okna ────────────────────────────────────────────────
const WIN_GEOM_MIN_W = 320;
const WIN_GEOM_MIN_H = 240;
const WIN_GEOM_MAX_W = 16384;
const WIN_GEOM_MAX_H = 16384;
const WIN_GEOM_POS_MIN = -16384;
const WIN_GEOM_POS_MAX = 16384;

// ─── Max počet položek v historii zakázek ────────────────────────────────────
const JOB_HISTORY_MAX = 2;

// ─────────────────────────────────────────────────────────────────────────────
// LOGOVÁNÍ
// ─────────────────────────────────────────────────────────────────────────────


// ─── DevTools hook (nastavuje main.js po inicializaci devtools modulu) ────────
const _logHooks = [];
/**
 * Přidá hook volaný při každém log() volání.
 * Používá main.js pro přesměrování logů do DevTools okna.
 * @param {function(level: string, ...args: any[]): void} fn
 */
function addLogHook(fn) {
  if (typeof fn === 'function') _logHooks.push(fn);
}

/** Zajistí existenci složky pro logy. */
function _ensureLogDir() {
  const dir = getLogDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

/**
 * Smaže soubory starší než `days` dní ze složky logů.
 * @param {number} days
 */
function cleanupLogs(days = 7) {
  const dir = _ensureLogDir();
  const cutoff = Date.now() - days * 86400 * 1000;
  try {
    for (const name of fs.readdirSync(dir)) {
      const p = path.join(dir, name);
      try {
        const stat = fs.statSync(p);
        if (stat.isFile() && stat.mtimeMs < cutoff) {
          fs.unlinkSync(p);
        }
      } catch {}
    }
  } catch {}
}

/** Čte LOG_LEVEL z config.json (warn/info/debug/error). Výchozí: warn. */
function _getLogLevel() {
  try {
    const cfgPath = getConfigPath();
    if (fs.existsSync(cfgPath)) {
      const raw = fs.readFileSync(cfgPath, "utf-8");
      const cfg = JSON.parse(raw);
      const lvl = (cfg.LOG_LEVEL || "").toLowerCase().trim();
      if (lvl) return lvl;
    }
  } catch {}
  return "warn";
}

/** Číselná závažnost úrovně logování. */
const LEVEL_MAP = { DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3 };

/**
 * Zapíše log do souboru YYYY-MM-DD.log i do konzole.
 * Filtruje podle LOG_LEVEL z konfigurace.
 *
 * @param {"DEBUG"|"INFO"|"WARN"|"ERROR"} level - úroveň zprávy
 * @param {...any} args - cokoliv (automaticky stringify)
 */
function log(level, ...args) {
  const lvl = (level || "INFO").toUpperCase().replace("WARNING", "WARN");
  const minLevel = _getLogLevel();
  const msgSev = LEVEL_MAP[lvl] ?? 1;
  const cfgSev = LEVEL_MAP[minLevel.toUpperCase()] ?? 2;

  // Zprávy pod nastavenou úrovní přeskočíme
  if (msgSev < cfgSev) return;

  const dir = _ensureLogDir();
  const now = new Date();

  // Timestamp: YYYY-MM-DD HH:MM:SS.mmm
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  const ts =
    `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ` +
    `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}.${pad(now.getMilliseconds(), 3)}`;

  const day = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const filePath = path.join(dir, `${day}.log`);

  // Caller info pro DEBUG a ERROR (stack frame)
  let callerInfo = "";
  if (msgSev <= 0 || msgSev >= 3) {
    try {
      const err = new Error();
      const lines = (err.stack || "").split("\n");
      // Přeskočíme rámce patřící log() a utils.js
      const frame = lines.find((l) => l.includes(".js:") && !l.includes("utils.js"));
      if (frame) {
        const m = frame.match(/at (\S+).*?[(/]([^(/]+:\d+):\d+\)?/);
        if (m) callerInfo = ` [${m[1]}@${m[2]}]`;
      }
    } catch {}
  }

  // Sestavení řádku
  const msg = args
    .map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a)))
    .join(" ");
  let line = `${ts}\t${lvl}${callerInfo}\t${msg}`;

  // Výpis chyby na konzoli
  if (msgSev >= 3) {
    console.error(`[${lvl}]${callerInfo} ${msg}`);
  } else if (msgSev >= 1) {
    console.log(`[${lvl}]${callerInfo} ${msg}`);
  }


  // ── DevTools hook ──────────────────────────────────────────────────────────
  // Posíláme do bufferu PŘED zápisem do souboru, aby byly i early logy zachyceny
  for (const hook of _logHooks) {
    try { hook(lvl, msg); } catch (_) {}
  }

  line += "\n";

  try {
    fs.appendFileSync(filePath, line, "utf-8");
  } catch {}
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDACE A FORMÁTOVÁNÍ
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Očistí zakázku – odstraní pouze mezery (povoleny číslice, písmena i znaky).
 * @param {string} s
 * @returns {string}
 */
function safeJob(s) {
  return (s || "").trim().replace(/\s+/g, "");
}

/**
 * Vrátí true pokud je zakázka přesně 7 nebo 10 znaků (libovolné znaky).
 * @param {string} job
 * @returns {boolean}
 */
function isValidJob(job) {
  const len = (job || "").length;
  return len === 7 || len === 10;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMA PROFIL – helper funkce (port z photobridge.py)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vytáhne čisté username z emailové adresy (část před @).
 * Pokud není @, vrátí vstup beze změny.
 * @param {string} emailOrName
 * @returns {string}
 */
function extractUsernameFromEmail(emailOrName) {
  const s = (emailOrName || "").trim();
  return s.includes("@") ? s.split("@")[0] : s;
}

/**
 * Vrátí true pokud username (nebo email) patří _doma (osobnímu) profilu.
 * Primárně čte account_type z STATE (user_metadata), fallback na _doma suffix.
 * Case-insensitive. Extrahuje username z emailu automaticky.
 * @param {string} username
 * @returns {boolean}
 */
function isDomaProfil(username) {
  // Primárně zkontroluj account_type z Supabase user_metadata uloženého v STATE
  if (STATE && STATE.sbAccountType) {
    return STATE.sbAccountType === "personal";
  }
  // Fallback: starý _doma suffix systém
  const name = extractUsernameFromEmail((username || "").toLowerCase());
  return name === "doma" || name.endsWith("_doma");
}

/**
 * Vygeneruje automatickou zakázku pro _doma profil.
 * Formát: PREFIX + YYYYMMDD + _ + HHMM
 *   doma       → DOMA20250428_1516
 *   novak_doma → NOVAK20250428_1516
 * @param {string} username
 * @returns {string}
 */
function autoJobForDoma(username) {
  const name = extractUsernameFromEmail((username || "").toLowerCase());
  const prefix = (name.replace(/_doma$/, "") || "DOMA").toUpperCase();
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const datePart = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
  const timePart = `${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `${prefix}${datePart}_${timePart}`;
}

/**
 * Rozhodne zakázku podle profilu přihlášeného uživatele.
 *  - _doma profil → autoJobForDoma(username) (ignoruje pole zakázky)
 *  - standardní  → safeJob(jobFieldValue) musí mít 7 nebo 10 znaků
 * @param {string} usernameOrEmail
 * @param {string} jobFieldValue  – hodnota z UI pole zakázky
 * @returns {string}
 * @throws {Error} pokud standardní zakázka nemá 7 nebo 10 znaků
 */
function resolveJob(usernameOrEmail, jobFieldValue) {
  const username = extractUsernameFromEmail(usernameOrEmail || "");
  if (isDomaProfil(username)) {
    return autoJobForDoma(username);
  }
  const job = safeJob(jobFieldValue || "");
  if (!isValidJob(job)) throw new Error("Zakázka musí mít 7 nebo 10 znaků.");
  return job;
}

/**
 * Vrátí true pokud je IP adresa validní IPv4.
 * @param {string} ip
 * @returns {boolean}
 */
function isValidIp(ip) {
  if (!ip) return false;
  const parts = ip.split(".");
  if (parts.length !== 4) return false;
  return parts.every((p) => {
    const n = Number(p);
    return Number.isInteger(n) && n >= 0 && n <= 255;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// SÍŤOVÉ FUNKCE – IP ADRESY
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Detekuje lokální IPv4 adresu pomocí UDP socketu (stejná metoda jako Python).
 * Pokud selže, vrátí "127.0.0.1".
 * @returns {string}
 */
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  // Pokus o nalezení non-loopback IPv4 adresy
  for (const iface of Object.values(interfaces)) {
    for (const info of iface || []) {
      if (info.family === "IPv4" && !info.internal) {
        return info.address;
      }
    }
  }
  return "127.0.0.1";
}

/**
 * Vrátí seznam [ [ip, popis_adaptéru], ... ] ze systémových rozhraní.
 * Filtruje loopback a link-local adresy.
 * @returns {Array<[string, string]>}
 */
function getLocalIpv4CandidatesWithLabels() {
  const result = [];
  const seen = new Set();

  const interfaces = os.networkInterfaces();
  for (const [name, iface] of Object.entries(interfaces)) {
    for (const info of iface || []) {
      if (
        info.family === "IPv4" &&
        !info.internal &&
        !info.address.startsWith("127.") &&
        !info.address.startsWith("169.254.")
      ) {
        if (!seen.has(info.address)) {
          seen.add(info.address);
          result.push([info.address, name]);
        }
      }
    }
  }

  // Fallback: přidáme getLocalIP() pokud ještě není v seznamu
  const fallback = getLocalIP();
  if (isValidIp(fallback) && !seen.has(fallback)) {
    result.push([fallback, "LAN"]);
  }

  return result;
}

/**
 * Vrátí pouze seznam IP adres (bez popisků).
 * @returns {string[]}
 */
function getLocalIpv4Candidates() {
  return getLocalIpv4CandidatesWithLabels().map(([ip]) => ip);
}

/**
 * Zparsuje čárkami/středníky oddělené IP adresy.
 * @param {string} s
 * @returns {string[]}
 */
function _parseKnownIps(s) {
  return (s || "")
    .trim()
    .split(/[;,\s]+/)
    .map((ip) => ip.trim())
    .filter((ip) => ip && isValidIp(ip))
    .filter((ip, i, arr) => arr.indexOf(ip) === i); // deduplikace
}

/**
 * Převede pole IP adres na čárkami oddělený řetězec.
 * @param {string[]} ips
 * @returns {string}
 */
function knownIpsToStr(ips) {
  return ips.join(",");
}

/**
 * Vrátí IP adresu pro QR kód.
 * Respektuje QR_IP_SELECTED a KNOWN_IPS z konfigurace.
 * @param {object} cfg
 * @returns {string}
 */
function getIpForQr(cfg) {
  const known = _parseKnownIps(cfg.KNOWN_IPS || "");
  const selected = (cfg.QR_IP_SELECTED || "").trim();

  if (selected && isValidIp(selected)) {
    if (!known.includes(selected)) {
      known.push(selected);
      cfg.KNOWN_IPS = knownIpsToStr(known);
    }
    return selected;
  }

  if (known.length > 0) return known[0];

  return getLocalIP();
}

// ─────────────────────────────────────────────────────────────────────────────
// PORT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Asynchronně najde první volný TCP port v rozsahu [portFrom, portTo].
 * Pokud žádný volný port nenajde, vrátí portFrom (nebo 5000 jako fallback).
 *
 * @param {number} portFrom
 * @param {number} portTo
 * @returns {Promise<number>}
 */
function findFreePort(portFrom, portTo) {
  portFrom = Math.max(1, Math.min(portFrom || 5000, 65535));
  portTo   = Math.max(portFrom, Math.min(portTo || portFrom + 100, 65535));

  return new Promise((resolve) => {
    let current = portFrom;

    function tryPort() {
      if (current > portTo) {
        resolve(Math.max(5000, portFrom));
        return;
      }

      const server = net.createServer();
      server.unref();

      server.once("error", () => {
        current++;
        tryPort();
      });

      server.listen(current, "0.0.0.0", () => {
        const port = server.address().port;
        server.close(() => resolve(port));
      });
    }

    tryPort();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// DISK
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Ověří, zda je složka zapisovatelná.
 * @param {string} dirPath
 * @returns {{ ok: boolean, message: string }}
 */
function isDirWritable(dirPath) {
  if (!dirPath) return { ok: false, message: "Cesta je prázdná." };
  if (!fs.existsSync(dirPath)) return { ok: false, message: `Složka neexistuje: ${dirPath}` };
  if (!fs.statSync(dirPath).isDirectory()) return { ok: false, message: `Není složka: ${dirPath}` };

  const testPath = path.join(dirPath, `__pb_test_${Date.now()}.tmp`);
  try {
    fs.writeFileSync(testPath, "ok");
    fs.unlinkSync(testPath);
    return { ok: true, message: "OK" };
  } catch (e) {
    return { ok: false, message: `Nelze zapisovat do: ${dirPath}\n${e.message}` };
  }
}

/**
 * Vrátí volné místo na disku v GB, nebo null při chybě.
 * @param {string} dirPath
 * @returns {number|null}
 */
function freeSpaceGb(dirPath) {
  try {
    // Node.js nemá nativní disk_usage, použijeme statvfs přes child_process
    if (process.platform === "win32") {
      // PowerShell vrací volné bajty pro danou cestu
      const driveLetter = path.parse(dirPath).root;
      const out = execSync(
        `powershell -NoProfile -NonInteractive -Command "` +
        `(Get-PSDrive -Name '${driveLetter.replace(":\\", "")}').Free"`,
        { timeout: 5000, stdio: ["ignore", "pipe", "ignore"] }
      )
        .toString()
        .trim();
      const bytes = Number(out);
      if (!isNaN(bytes)) return bytes / 1024 ** 3;
    } else {
      // Linux / macOS – df -k
      const out = execSync(`df -k "${dirPath}"`, {
        timeout: 5000,
        stdio: ["ignore", "pipe", "ignore"],
      })
        .toString()
        .trim();
      const lines = out.split("\n");
      if (lines.length >= 2) {
        const cols = lines[1].split(/\s+/);
        const freeKb = Number(cols[3]);
        if (!isNaN(freeKb)) return (freeKb * 1024) / 1024 ** 3;
      }
    }
  } catch {}
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTOSTART (Windows)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Zapne nebo vypne autostart přes složku Startup (bez zápisu do registrů).
 * Stejná metoda jako Python originál.
 * @param {boolean} enabled
 * @param {string} exePath - cesta k EXE aplikace
 */
function setStartWithWindows(enabled, exePath) {
  if (process.platform !== "win32") return;

  let startupDir;
  try {
    // Přečteme cestu ze systémových proměnných (bezpečnější než registry)
    startupDir = path.join(
      process.env.APPDATA || "",
      "Microsoft",
      "Windows",
      "Start Menu",
      "Programs",
      "Startup"
    );
  } catch {
    return;
  }

  const shortcutPath = path.join(startupDir, `${APP_NAME}.lnk`);

  if (enabled && exePath) {
    try {
      const workDir = path.dirname(exePath);
      const psCmd =
        `$s=(New-Object -COM WScript.Shell).CreateShortcut('${shortcutPath}');` +
        `$s.TargetPath='${exePath}';` +
        `$s.WorkingDirectory='${workDir}';` +
        `$s.Save()`;

      const child = spawn("powershell", [
        "-NoProfile", "-NonInteractive", "-Command", psCmd,
      ], { detached: true, stdio: "ignore" });
      child.unref();

      log("INFO", "Autostart povolen (složka Startup)", shortcutPath);
    } catch (e) {
      log("WARN", "Autostart shortcut selhal", e.message);
    }
  } else {
    // Odstraň zkratku pokud existuje
    try {
      if (fs.existsSync(shortcutPath)) {
        fs.unlinkSync(shortcutPath);
        log("INFO", "Autostart zakázán (složka Startup)", shortcutPath);
      }
    } catch (e) {
      log("WARN", "Odebrání autostart zkratky selhalo", e.message);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GEOMETRIE OKNA
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Omezí rozměry a pozici okna na rozumné hodnoty (multi-monitor + TV).
 * @param {number} w
 * @param {number} h
 * @param {number} x
 * @param {number} y
 * @returns {{ w: number, h: number, x: number, y: number }}
 */
function sanitizeWindowGeometry(w, h, x, y) {
  return {
    w: Math.max(WIN_GEOM_MIN_W, Math.min(WIN_GEOM_MAX_W, Math.round(w))),
    h: Math.max(WIN_GEOM_MIN_H, Math.min(WIN_GEOM_MAX_H, Math.round(h))),
    x: Math.max(WIN_GEOM_POS_MIN, Math.min(WIN_GEOM_POS_MAX, Math.round(x))),
    y: Math.max(WIN_GEOM_POS_MIN, Math.min(WIN_GEOM_POS_MAX, Math.round(y))),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// TÉMA – ČASOVAČ A WINDOWS REGISTRY
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Zparsuje čas ve formátu "HH:MM".
 * @param {string} s
 * @returns {{ h: number, m: number }|null}
 */
function parseHhmm(s) {
  const m = /^(\d{1,2}):(\d{2})$/.exec((s || "").trim());
  if (!m) return null;
  const h = parseInt(m[1], 10);
  const min = parseInt(m[2], 10);
  if (h < 0 || h > 23 || min < 0 || min > 59) return null;
  return { h, m: min };
}

/**
 * Vrátí true pokud je aktuální čas v rozsahu [start, end) (podporuje přechod přes půlnoc).
 * @param {{ h: number, m: number }} nowHm
 * @param {{ h: number, m: number }} startHm
 * @param {{ h: number, m: number }} endHm
 * @returns {boolean}
 */
function timeInRange(nowHm, startHm, endHm) {
  const n = nowHm.h * 60 + nowHm.m;
  const s = startHm.h * 60 + startHm.m;
  const e = endHm.h * 60 + endHm.m;
  if (s <= e) return n >= s && n < e;
  return n >= s || n < e;
}

/**
 * Přečte aktuální téma Windows z registru.
 * Vrátí "light" nebo "dark".
 * @returns {"light"|"dark"}
 */
function getWindowsThemeMode() {
  if (process.platform !== "win32") return "light";
  try {
    // Čteme AppsUseLightTheme z registru přes reg.exe
    const out = execSync(
      'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" ' +
      '/v AppsUseLightTheme',
      { timeout: 3000, stdio: ["ignore", "pipe", "ignore"] }
    ).toString();
    const m = out.match(/AppsUseLightTheme\s+REG_DWORD\s+0x(\d+)/i);
    if (m) return parseInt(m[1], 16) === 1 ? "light" : "dark";
  } catch {}
  return "light";
}

/**
 * Vypočítá efektivní téma (dark/light) podle konfigurace.
 * @param {object} cfg
 * @returns {"dark"|"light"}
 */
function computeEffectiveTheme(cfg) {
  const mode = (cfg.THEME_MODE || "auto_windows").toLowerCase();

  if (mode === "light") return "light";
  if (mode === "dark")  return "dark";

  if (mode === "auto_windows") return getWindowsThemeMode();

  if (mode === "auto_timer") {
    const start = parseHhmm(cfg.DAY_START || "08:00") || { h: 8,  m: 0 };
    const end   = parseHhmm(cfg.DAY_END   || "18:00") || { h: 18, m: 0 };
    const now   = new Date();
    const nowHm = { h: now.getHours(), m: now.getMinutes() };
    return timeInRange(nowHm, start, end) ? "light" : "dark";
  }

  // fallback pro "system" a neznámé hodnoty
  return getWindowsThemeMode();
}

// ─────────────────────────────────────────────────────────────────────────────
// PERSISTENTNÍ STAV – state.json
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Načte state.json ze disku. Vrátí prázdný objekt při chybě nebo neexistenci.
 * @returns {object}
 */
function loadState() {
  const p = getStatePath();
  if (!fs.existsSync(p)) return {};
  try {
    return JSON.parse(fs.readFileSync(p, "utf-8")) || {};
  } catch {
    return {};
  }
}

/**
 * Uloží objekt stavu do state.json. Při chybě pouze loguje.
 * @param {object} st
 */
function saveState(st) {
  try {
    fs.writeFileSync(getStatePath(), JSON.stringify(st, null, 2), "utf-8");
  } catch (e) {
    // Neselhávat tichce – ale ani nepadnout
    try { console.error("[utils] saveState selhal:", e.message); } catch {}
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// STATISTIKY TYPŮ
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Načte statistiky použití typů ze state.json.
 * @returns {object} Mapa { typ: počet }
 */
function getTypeStats() {
  return loadState().type_stats || {};
}

/**
 * Inkrementuje počítadlo pro daný typ.
 * @param {string} typ
 */
function incrementTypeStat(typ) {
  const st = loadState();
  const stats = st.type_stats || {};
  stats[typ] = (stats[typ] || 0) + 1;
  st.type_stats = stats;
  saveState(st);
}

/**
 * Vrátí nejčastěji používaný typ, nebo výchozí "SP_ (Scan poškození)".
 * @returns {string}
 */
function getMostUsedType() {
  const stats = getTypeStats();
  const keys = Object.keys(stats);
  if (keys.length === 0) return "SP_ (Scan poškození)";

  return keys.reduce((best, typ) =>
    stats[typ] > (stats[best] || 0) ? typ : best,
    keys[0]
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HISTORIE ZAKÁZEK
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vrátí poslední zakázky (max JOB_HISTORY_MAX).
 * @returns {string[]}
 */
function getJobHistory() {
  const st = loadState();
  const hist = st.job_history;
  if (!Array.isArray(hist)) return [];
  return hist.filter(Boolean).map(String).slice(0, JOB_HISTORY_MAX);
}

/**
 * Přidá zakázku na začátek historie (max JOB_HISTORY_MAX položek).
 * @param {string} job
 */
function addToJobHistory(job) {
  if (!job || !isValidJob(job)) return;
  const st = loadState();
  let hist = Array.isArray(st.job_history)
    ? st.job_history.filter(Boolean).map(String)
    : [];
  hist = hist.filter((h) => h !== job);
  hist.unshift(job);
  st.job_history = hist.slice(0, JOB_HISTORY_MAX);
  saveState(st);
}

// ─────────────────────────────────────────────────────────────────────────────
// NAPOSLEDY POUŽITÝ TYP (Drag & Drop dialog)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vrátí naposledy použitý typ v D&D dialogu, nebo getMostUsedType() jako fallback.
 * @returns {string}
 */
function getLastUsedType() {
  return loadState().last_used_type || getMostUsedType();
}

/**
 * Uloží naposledy použitý typ pro D&D dialog.
 * @param {string} typ
 */
function saveLastUsedType(typ) {
  if (!typ) return;
  const st = loadState();
  st.last_used_type = typ;
  saveState(st);
}

// ─────────────────────────────────────────────────────────────────────────────
// PÍSMENO PRO SOUBOR (sekvence A–Z bez X)
// ─────────────────────────────────────────────────────────────────────────────

/** Abeceda bez X (stejně jako v Python originálu). */
const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWYZ".split(""); // všechna písmena ASCII mimo X

/**
 * Vrátí a uloží další písmeno sekvence pro kombinaci zakázka:typ.
 * @param {string} job
 * @param {string} typ
 * @returns {string}
 */
function nextLetterFor(job, typ) {
  const st = loadState();
  const key = `${job}:${typ}`;
  const last = (st[key] || "").toUpperCase().trim();

  let nxt;
  if (!last || !LETTERS.includes(last)) {
    nxt = "A";
  } else {
    nxt = LETTERS[(LETTERS.indexOf(last) + 1) % LETTERS.length];
  }

  st[key] = nxt;
  saveState(st);
  return nxt;
}

// ─────────────────────────────────────────────────────────────────────────────
// AppState – centrální stav aplikace (singleton)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Centrální in-memory stav aplikace.
 * Odpovídá dataclass AppState z Python originálu.
 *
 * Vlastnosti:
 *  - token, tokenTs, tokenJob     – aktivní jednorázový token (legacy single-session)
 *  - job, saveDir, port           – aktuální zakázka, cílová složka, port
 *  - maxImgMb, maxVideoMb         – limity velikosti souborů
 *  - tokenMinutes                 – platnost tokenu v minutách
 *  - running                      – je server spuštěn?
 *  - qrActive                     – je aktivní QR kód?
 *  - sbAccessToken                – Supabase access token
 *  - sbRefreshToken               – Supabase refresh token
 *  - sbUserId                     – Supabase user ID
 *  - sessions                     – mapa aktivních relací { token → { job, ts, saveDir, qrActive, minutes } }
 *  - MAX_SESSIONS                 – maximální počet souběžných relací
 */
const STATE = {
  // Základní single-session token (zachován pro zpětnou kompatibilitu)
  token:         "",
  tokenTs:       0,
  tokenJob:      "",

  // Aktuální zakázka a nastavení
  job:           "",
  saveDir:       "",
  port:          5000,
  maxImgMb:      3.0,
  maxVideoMb:    30.0,
  tokenMinutes:  20.0,
  retentionDays: 7,

  // Stav serveru a QR
  running:       false,
  qrActive:      false,

  // Supabase Auth
  sbAccessToken:  "",
  sbRefreshToken: "",
  sbUserId:       "",
  sbEmail:        "",   // přihlášený email / username (pro isDomaProfil)
  sbAccountType:  "",   // 'business' nebo 'personal' (z user_metadata.account_type)

  // Multi-token: slovník aktivních relací
  // Klíč = token (hex string), hodnota = { job, ts, saveDir, qrActive, minutes }
  MAX_SESSIONS:  10,
  sessions:      {},

  // Statistiky session
  sessionStart:    null,   // Date | null – kdy byla session zahájena
  uploadCount:     0,      // počet uploadů v aktuální session
  totalUploadCount: 0,     // celkový počet od spuštění aplikace

  /**
   * Resetuje session statistiky (zavolat při startu serveru).
   */
  resetSessionStats() {
    this.sessionStart = new Date();
    this.uploadCount = 0;
  },

  /**
   * Inkrementuje počet uploadů.
   */
  bumpUpload() {
    this.uploadCount++;
    this.totalUploadCount++;
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// IPC HANDLERY (pro main process)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Zaregistruje IPC handlery pro utils funkce.
 * Voláme z main.js po app.ready.
 */
function registerIpcHandlers() {
  let ipcMain;
  try { ipcMain = require("electron").ipcMain; } catch { return; }

  // Vrátí aktuální stav aplikace (bezpečná kopie bez citlivých tokenů)
  ipcMain.handle("utils:get-state", () => {
    return {
      job:          STATE.job,
      saveDir:      STATE.saveDir,
      port:         STATE.port,
      running:      STATE.running,
      qrActive:     STATE.qrActive,
      loggedIn:     !!STATE.sbAccessToken,
      uploadCount:  STATE.uploadCount,
      totalUploadCount: STATE.totalUploadCount,
      sessionStart: STATE.sessionStart?.toISOString() || null,
    };
  });

  // Vrátí lokální IP adresy pro Settings dialog
  ipcMain.handle("utils:get-ip-candidates", () => {
    return getLocalIpv4CandidatesWithLabels();
  });

  // Najde volný port
  ipcMain.handle("utils:find-free-port", async (_e, from, to) => {
    return findFreePort(from, to);
  });

  // Ověří zapisovatelnost složky
  ipcMain.handle("utils:check-dir-writable", (_e, dirPath) => {
    return isDirWritable(dirPath);
  });

  // Volné místo na disku
  ipcMain.handle("utils:free-space-gb", (_e, dirPath) => {
    return freeSpaceGb(dirPath);
  });

  // Autostart
  ipcMain.handle("utils:set-start-with-windows", (_e, enabled) => {
    const exePath = process.execPath;
    setStartWithWindows(enabled, exePath);
    return { ok: true };
  });

  // Historie zakázek
  ipcMain.handle("utils:get-job-history", () => getJobHistory());
  ipcMain.handle("utils:add-job-history", (_e, job) => { addToJobHistory(job); });

  // Naposledy použitý typ
  ipcMain.handle("utils:get-last-used-type", () => getLastUsedType());
  ipcMain.handle("utils:save-last-used-type", (_e, typ) => { saveLastUsedType(typ); });

  // Statistiky typů
  ipcMain.handle("utils:get-type-stats", () => getTypeStats());
  ipcMain.handle("utils:increment-type-stat", (_e, typ) => { incrementTypeStat(typ); });
  ipcMain.handle("utils:get-most-used-type", () => getMostUsedType());

  // Příští písmeno v sekvenci
  ipcMain.handle("utils:next-letter-for", (_e, job, typ) => nextLetterFor(job, typ));

  // Efektivní téma
  ipcMain.handle("utils:get-effective-theme", (_e, cfg) => computeEffectiveTheme(cfg || {}));

  // Doma profil helpers
  ipcMain.handle("utils:is-doma-profil", (_e, username) => isDomaProfil(username));
  ipcMain.handle("utils:auto-job-for-doma", (_e, username) => autoJobForDoma(username));
  ipcMain.handle("utils:extract-username", (_e, emailOrName) => extractUsernameFromEmail(emailOrName));
  ipcMain.handle("utils:resolve-job", (_e, usernameOrEmail, jobFieldValue) => {
    try {
      return { ok: true, job: resolveJob(usernameOrEmail, jobFieldValue) };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  log("INFO", "utils: IPC handlery zaregistrovány");
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  // Logování
  log,
  cleanupLogs,
  addLogHook,

  // Validace
  safeJob,
  isValidJob,
  isValidIp,

  // Doma profil
  extractUsernameFromEmail,
  isDomaProfil,
  autoJobForDoma,
  resolveJob,

  // Síťové funkce
  getLocalIP,
  getLocalIpv4Candidates,
  getLocalIpv4CandidatesWithLabels,
  getIpForQr,
  knownIpsToStr,

  // Port
  findFreePort,

  // Disk
  isDirWritable,
  freeSpaceGb,

  // Autostart
  setStartWithWindows,

  // Okno
  sanitizeWindowGeometry,

  // Téma
  getWindowsThemeMode,
  computeEffectiveTheme,
  parseHhmm,
  timeInRange,

  // State
  loadState,
  saveState,
  STATE,

  // Statistiky
  getTypeStats,
  incrementTypeStat,
  getMostUsedType,

  // Historie zakázek
  getJobHistory,
  addToJobHistory,

  // Typ D&D
  getLastUsedType,
  saveLastUsedType,

  // Sekvence písmen
  nextLetterFor,
  LETTERS,

  // Konstanty
  APP_NAME,
  JOB_HISTORY_MAX,
  ALLOWED_IMG_EXTS,
  WIN_GEOM_MIN_W,
  WIN_GEOM_MIN_H,
  WIN_GEOM_MAX_W,
  WIN_GEOM_MAX_H,
  WIN_GEOM_POS_MIN,
  WIN_GEOM_POS_MAX,

  // IPC
  registerIpcHandlers,
};
