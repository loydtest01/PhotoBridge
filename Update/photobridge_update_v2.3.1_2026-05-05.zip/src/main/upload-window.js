'use strict';
// ============================================================
// PhotoBridge – src/main/upload-window.js
// Samostatné okno pro drag & drop / manuální upload souborů.
// Vzor: settings-window.js – stejný styl, stejná architektura.
//
//  • openUploadWindow(mainWindow, files, job) – otevře / přidá soubory
//  • addFilesToUploadWindow(files)            – přidá soubory do otevřeného okna
//  • registerIpcHandlers(getMainWindow)       – IPC kanály upload:*
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

// ── Lazy importy ──────────────────────────────────────────────────────────────
let _utils = null;
function utils() { return _utils || (_utils = require('./utils')); }

// ── Singleton reference na okno ──────────────────────────────────────────────
let _win = null;

// ── Cesty ─────────────────────────────────────────────────────────────────────
const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

// ══════════════════════════════════════════════════════════════
// OTEVŘENÍ / PŘIDÁNÍ SOUBORŮ
// ══════════════════════════════════════════════════════════════

/**
 * Otevře upload okno. Pokud již existuje, přidá soubory do stávajícího.
 * @param {BrowserWindow|null} mainWindow  – hlavní okno (volitelný rodič)
 * @param {Array}              files       – pole { path, name, … } ze server.js
 * @param {string}             job         – číslo zakázky
 */
function openUploadWindow(mainWindow, files, job, opts = {}) {
  if (_win && !_win.isDestroyed()) {
    // Okno již existuje → přidáme soubory a přeneseme fokus
    addFilesToUploadWindow(files, job);
    _win.focus();
    if (opts.tourDemo) {
      try { _win.webContents.send('upload:tour-demo', { job }); } catch (_) {}
    }
    return _win;
  }

  _win = new BrowserWindow({
    width:     560,
    height:    460,
    minWidth:  460,
    minHeight: 360,
    title:     opts.tourDemo ? 'PhotoBridge – Demo (Prohlídka)' : 'PhotoBridge – Nahrát soubory',
    icon:      path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico'),
    parent:    mainWindow || undefined,
    modal:     false,          // neblokující – hlavní okno zůstane aktivní
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools: (process.argv.includes('--dev') || !require('electron').app.isPackaged),
    },
    show:            false,
    backgroundColor: '#cfddf0',
    autoHideMenuBar: true,
    resizable:       true,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'upload.html'));

  _win.once('ready-to-show', () => {
    _win.show();
    // Po načtení pošleme počáteční soubory
    if (files && files.length) {
      _win.webContents.send('upload:add-files', { files, job });
    }
    // Demo režim – pošleme signál, renderer si nainjektuje 3 ukázkové fotky
    if (opts.tourDemo) {
      _win.webContents.send('upload:tour-demo', { job });
    }
  });

  _win.on('closed', () => {
    _win = null;
  });

  return _win;
}

/**
 * Přidá soubory do již otevřeného upload okna.
 * Pokud okno není otevřeno, pouze vrátí false.
 */
function addFilesToUploadWindow(files, job) {
  if (!_win || _win.isDestroyed()) return false;
  if (files && files.length) {
    _win.webContents.send('upload:add-files', { files, job });
  }
  return true;
}

// ══════════════════════════════════════════════════════════════
// IPC HANDLERY
// ══════════════════════════════════════════════════════════════

let _handlersRegistered = false;

function registerIpcHandlers(getMainWindow) {
  if (_handlersRegistered) return;
  _handlersRegistered = true;

  // ── upload:open – hlavní okno žádá otevření upload dialogu ──────────────
  ipcMain.handle('upload:open', (_evt, { files, job, tourDemo }) => {
    const mw = getMainWindow ? getMainWindow() : null;
    openUploadWindow(mw, files || [], job || '', { tourDemo: !!tourDemo });
    return { ok: true };
  });

  // ── upload:close – zavření okna ─────────────────────────────────────────
  ipcMain.handle('upload:close', () => {
    if (_win && !_win.isDestroyed()) _win.close();
    return { ok: true };
  });

  // Poznámka: upload.html volá 'files:save' přímo, registrovaný v main-tray.js.
}

// ══════════════════════════════════════════════════════════════
// EXPORT
// ══════════════════════════════════════════════════════════════

module.exports = {
  openUploadWindow,
  addFilesToUploadWindow,
  registerIpcHandlers,
  getUploadWindow: () => _win,
};
