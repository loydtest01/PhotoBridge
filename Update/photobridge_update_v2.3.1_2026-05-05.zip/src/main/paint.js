/**
 * paint.js – Paint Temp Cache + Queue systém
 * Fáze 6: přepis Python logiky z photobridge.py (řádky 1416–1689)
 *
 * Logika:
 *  1. createPaintTempCopy(finalPath, pngBuffer) – uloží soubor do PAINT_TEMP_DIR
 *     a přidá ho do fronty.
 *  2. Fronta (PAINT_QUEUE) zpracovává soubory sériově:
 *     otevře mspaint.exe, čeká na zavření procesu,
 *     pak přesune soubor do finální destinace.
 *  3. IPC handlery: start/stop monitoringu, stav fronty.
 *
 * Exportuje:
 *   createPaintTempCopy(finalPath, buffer)  → Promise<string>  (temp cesta)
 *   registerIpcHandlers()                   → void
 */

"use strict";

const { ipcMain, app } = require("electron");
const fs               = require("fs");
const path             = require("path");
const { spawn }        = require("child_process");

const { log, STATE }   = require("./utils");

// ─── Konfigurace ─────────────────────────────────────────────────────────────

// Temp složka v userData – zde se ukládají soubory před předáním Paintu
// paint_temp je v kořeni projektu (vedle main.js), ne v userData
const PAINT_TEMP_DIR = path.join(__dirname, '..', '..', 'paint_temp');

const MOVE_RETRY_COUNT = 5;   // počet pokusů o přesun (soubor může být zamčený)
const MOVE_RETRY_DELAY = 2000; // ms mezi pokusy
const MAX_WAIT_MS      = 30 * 60 * 1000; // max 30 minut čekání na zavření Paintu

// ─── Stav modulu ─────────────────────────────────────────────────────────────

/** Mapa: tempPath → finalPath */
const PAINT_FILE_MAP = new Map();

/** Fronta temp cest čekajících na zpracování */
const PAINT_QUEUE = [];

/** Příznak zda fronta právě běží */
let _queueRunning = false;

/** PID aktuálně zpracovávaného Paint procesu */
let currentPaintPid  = null;

/** Temp cesta aktuálně zpracovávaného souboru */
let currentPaintFile = null;

// ─── Veřejné API ─────────────────────────────────────────────────────────────

/**
 * Vytvoří dočasný soubor v PAINT_TEMP_DIR a přidá ho do fronty.
 * Soubor se otevře v Malování až na něj přijde řada.
 *
 * @param {string} finalPath  – konečná cesta kam soubor patří po editaci
 * @param {Buffer} content    – PNG data
 * @returns {Promise<string>} – cesta k temp souboru
 */
async function createPaintTempCopy(finalPath, content) {
    try {
        fs.mkdirSync(PAINT_TEMP_DIR, { recursive: true });

        const baseName  = path.basename(finalPath);
        const { name, ext } = _splitExt(baseName);

        // Pokud soubor se stejným názvem existuje, přidej číslo
        let tempPath = path.join(PAINT_TEMP_DIR, baseName);
        let counter  = 1;
        while (fs.existsSync(tempPath)) {
            tempPath = path.join(PAINT_TEMP_DIR, `${name}_${counter}${ext}`);
            counter++;
        }

        fs.writeFileSync(tempPath, content);
        PAINT_FILE_MAP.set(tempPath, finalPath);

        log("INFO", "PAINT created temp", path.basename(tempPath));

        // Přidej do fronty
        _addToQueue(tempPath);

        return tempPath;

    } catch (err) {
        log("ERROR", "PAINT failed to create temp", String(err));
        // Fallback – ulož přímo do finální cesty
        try {
            fs.mkdirSync(path.dirname(finalPath), { recursive: true });
            fs.writeFileSync(finalPath, content);
        } catch { /* ignoruj */ }
        return finalPath;
    }
}

// ─── Fronta ──────────────────────────────────────────────────────────────────

/**
 * Přidá soubor do fronty a spustí zpracování pokud fronta byla prázdná.
 *
 * @param {string} tempPath
 */
function _addToQueue(tempPath) {
    PAINT_QUEUE.push(tempPath);
    const pos = PAINT_QUEUE.length;
    log("INFO", `PAINT queue add (${pos} waiting)`, path.basename(tempPath));

    // Pokud fronta nebyla aktivní, spusť zpracování
    if (!_queueRunning) {
        _processQueue();
    }
}

/**
 * Zpracovává frontu sériově.
 * Každý soubor se otevře v Malování, počká se na zavření,
 * pak se soubor přesune a zpracuje se další.
 */
async function _processQueue() {
    if (_queueRunning) return;
    _queueRunning = true;

    while (PAINT_QUEUE.length > 0) {
        const tempPath  = PAINT_QUEUE[0];
        const finalPath = PAINT_FILE_MAP.get(tempPath);
        const tempName  = path.basename(tempPath);

        currentPaintFile = tempPath;

        if (!finalPath || !fs.existsSync(tempPath)) {
            log("WARN", "PAINT queue item invalid", tempName);
            PAINT_QUEUE.shift();
            continue;
        }

        log("INFO", `PAINT queue processing (${PAINT_QUEUE.length} remaining)`, tempName);

        const success = await _openAndMonitorPaint(tempPath, finalPath);

        // Odeber zpracovaný soubor z fronty
        if (PAINT_QUEUE[0] === tempPath) {
            PAINT_QUEUE.shift();
        }

        if (success) {
            log("INFO", "PAINT queue completed", tempName);
        } else {
            log("WARN", "PAINT queue failed", tempName);
        }

        // Krátká pauza před dalším souborem
        await _sleep(1000);
    }

    currentPaintFile = null;
    currentPaintPid  = null;
    _queueRunning    = false;
    log("INFO", "PAINT queue empty, processor stopped", "");
}

// ─── Otevření a sledování Malování ───────────────────────────────────────────

/**
 * Otevře soubor v mspaint.exe, sleduje proces a po zavření přesune soubor.
 *
 * @param {string} tempPath
 * @param {string} finalPath
 * @returns {Promise<boolean>}  true pokud soubor byl úspěšně přesunut
 */
async function _openAndMonitorPaint(tempPath, finalPath) {
    const tempName = path.basename(tempPath);

    try {
        // Zjisti existující Paint PID před spuštěním
        const existingPids = await _getPaintPids();
        log("INFO", `PAINT open – existing pids: ${existingPids.size}`, tempName);

        // Spusť mspaint.exe s absolutní cestou
        const absTempPath = path.resolve(tempPath);
        spawn("mspaint.exe", [absTempPath], { detached: true, stdio: "ignore" });
        log("INFO", "PAINT launched mspaint.exe", tempName);

        // Počkej max 15 sekund na nový Paint proces (30 × 500 ms)
        let myPaintPid = null;
        for (let attempt = 0; attempt < 30; attempt++) {
            await _sleep(500);
            const currentPids = await _getPaintPids();
            for (const pid of currentPids) {
                if (!existingPids.has(pid)) {
                    myPaintPid       = pid;
                    currentPaintPid  = pid;
                    log("INFO", `PAINT process found`, `pid=${pid} attempt=${attempt + 1} file=${tempName}`);
                    break;
                }
            }
            if (myPaintPid !== null) break;
        }

        if (myPaintPid === null) {
            log("WARN", "PAINT process not found after 15s", `file=${tempName} – using fallback`);
            // Fallback: krátké čekání a přesuň
            await _sleep(3000);
            return _moveFileToFinal(tempPath, finalPath);
        }

        // Sleduj proces dokud nezmizí (nebo max 30 min)
        log("INFO", `PAINT monitoring started`, `pid=${myPaintPid} file=${tempName}`);
        const deadline = Date.now() + MAX_WAIT_MS;

        while (Date.now() < deadline) {
            await _sleep(1000);
            const alive = await _isPidAlive(myPaintPid);
            if (!alive) {
                const elapsed = Math.round((Date.now() - (deadline - MAX_WAIT_MS)) / 1000);
                log("INFO", `PAINT closed by user`, `pid=${myPaintPid} open_for=${elapsed}s file=${tempName}`);
                break;
            }
        }

        if (Date.now() >= deadline) {
            log("WARN", `PAINT monitor timeout (30min)`, `pid=${myPaintPid} file=${tempName}`);
        }

        // Paint se zavřel – počkej chvíli a přesuň
        await _sleep(2000);
        const result = await _moveFileToFinal(tempPath, finalPath);

        if (result) {
            log("INFO", "PAINT file moved to final", `dest=${path.basename(finalPath)}`);
            _notifyRenderer(finalPath);
        } else {
            log("ERROR", "PAINT file move FAILED", `temp=${tempName} dest=${path.basename(finalPath)}`);
        }
        return result;

    } catch (err) {
        log("ERROR", "PAINT monitor error", `${tempName}: ${err}`);
        return false;
    }
}

// ─── Přesun souboru ──────────────────────────────────────────────────────────

/**
 * Přesune temp soubor do finální lokace.
 * Opakuje pokus pokud je soubor zamčený (PermissionError).
 *
 * @param {string} tempPath
 * @param {string} finalPath
 * @returns {Promise<boolean>}
 */
async function _moveFileToFinal(tempPath, finalPath) {
    if (!fs.existsSync(tempPath)) {
        log("WARN", "PAINT temp file missing", path.basename(tempPath));
        return false;
    }

    fs.mkdirSync(path.dirname(finalPath), { recursive: true });

    for (let attempt = 1; attempt <= MOVE_RETRY_COUNT; attempt++) {
        try {
            fs.copyFileSync(tempPath, finalPath);
            log("INFO", "PAINT SUCCESS", path.basename(finalPath));

            // Smaž temp soubor
            try { fs.unlinkSync(tempPath); } catch { /* nevadí */ }
            PAINT_FILE_MAP.delete(tempPath);
            return true;

        } catch (err) {
            if (err.code === "EPERM" || err.code === "EBUSY") {
                log("WARN", `PAINT move retry ${attempt}/${MOVE_RETRY_COUNT}`, String(err));
                await _sleep(MOVE_RETRY_DELAY);
            } else {
                log("ERROR", "PAINT move failed", String(err));
                return false;
            }
        }
    }

    log("ERROR", `PAINT move failed after ${MOVE_RETRY_COUNT} retries`, path.basename(finalPath));
    return false;
}

// ─── Pomocné funkce (systémové) ───────────────────────────────────────────────

/**
 * Vrátí Set PID všech běžících procesů mspaint.exe.
 * Používá WMIC (Windows) nebo fallback přes tasklist.
 *
 * @returns {Promise<Set<number>>}
 */
async function _getPaintPids() {
    return new Promise((resolve) => {
        const pids = new Set();

        // Použij tasklist – dostupný na každém Windows
        const proc = spawn("tasklist", ["/FO", "CSV", "/NH", "/FI", "IMAGENAME eq mspaint.exe"], {
            stdio: ["ignore", "pipe", "ignore"],
        });

        let output = "";
        proc.stdout.on("data", (chunk) => { output += chunk.toString(); });
        proc.on("close", () => {
            // Každý řádek: "mspaint.exe","1234","Console","1","..." 
            for (const line of output.split("\n")) {
                const match = line.match(/"mspaint\.exe","(\d+)"/i);
                if (match) pids.add(Number(match[1]));
            }
            resolve(pids);
        });
        proc.on("error", () => resolve(pids)); // tasklist nedostupný – vrátí prázdný set
    });
}

/**
 * Zkontroluje zda proces s daným PID stále běží.
 * @param {number} pid
 * @returns {Promise<boolean>}
 */
async function _isPidAlive(pid) {
    return new Promise((resolve) => {
        // tasklist s filtrem na PID
        const proc = spawn("tasklist", ["/FO", "CSV", "/NH", "/FI", `PID eq ${pid}`], {
            stdio: ["ignore", "pipe", "ignore"],
        });
        let output = "";
        proc.stdout.on("data", (chunk) => { output += chunk.toString(); });
        proc.on("close", () => {
            // Pokud výstup obsahuje mspaint a daný PID → proces běží
            resolve(output.toLowerCase().includes("mspaint") && output.includes(String(pid)));
        });
        proc.on("error", () => resolve(false));
    });
}

/**
 * Odešle IPC event renderu že byl soubor zpracován Paintem a uložen.
 * @param {string} filePath
 */
function _notifyRenderer(filePath) {
    try {
        const { BrowserWindow } = require("electron");
        for (const win of BrowserWindow.getAllWindows()) {
            if (!win.isDestroyed()) {
                win.webContents.send("paint:file-saved", { path: filePath });
            }
        }
    } catch { /* nevadí */ }

    // Windows toast notifikace – delegujeme na supabase.notifyFileReceived
    // (sdílí debounce s ostatními soubory: když uživatel zavře 3 Maloványcká
    // okna v krátké době, dostane jednu souhrnnou notifikaci).
    try {
        const sb = require("./supabase");
        if (sb && typeof sb.notifyFileReceived === "function") {
            sb.notifyFileReceived(filePath);
        }
    } catch { /* supabase modul ještě neexistuje – ignoruj */ }
}

/**
 * Vyčistí sledování pro daný temp soubor (pokud je třeba ručně).
 * @param {string} tempPath
 */
function cleanupPaintMonitoring(tempPath) {
    PAINT_FILE_MAP.delete(tempPath);
}

/**
 * Rozdělí název souboru na { name, ext }.
 * @param {string} filename
 * @returns {{ name: string, ext: string }}
 */
function _splitExt(filename) {
    const dotIdx = filename.lastIndexOf(".");
    if (dotIdx < 0) return { name: filename, ext: "" };
    return { name: filename.slice(0, dotIdx), ext: filename.slice(dotIdx) };
}

/**
 * Promise-based sleep.
 * @param {number} ms
 */
function _sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

// ─── IPC HANDLERY ────────────────────────────────────────────────────────────

/**
 * Zaregistruje IPC kanály – volat z main.js po app.ready.
 *
 * Kanály:
 *   paint:queue-status   {}                          → { running, queueLength, currentFile, currentPid }
 *   paint:open-file      { finalPath, buffer (hex) } → { ok, tempPath }
 *   paint:clear-queue    {}                          → void
 */
function registerIpcHandlers() {
    // Stav fronty (pro DevTools / debug)
    ipcMain.handle("paint:queue-status", () => ({
        running:     _queueRunning,
        queueLength: PAINT_QUEUE.length,
        currentFile: currentPaintFile ? path.basename(currentPaintFile) : null,
        currentPid:  currentPaintPid,
    }));

    // Otevřít soubor v Paintu (volá se z main.js nebo supabase.js)
    ipcMain.handle("paint:open-file", async (_evt, { finalPath, bufferHex }) => {
        try {
            const buffer  = Buffer.from(bufferHex, "hex");
            const tempPath = await createPaintTempCopy(finalPath, buffer);
            return { ok: true, tempPath };
        } catch (err) {
            log("ERROR", "paint:open-file IPC", String(err));
            return { ok: false, error: String(err) };
        }
    });

    // Vyprázdni frontu (nouzové zastavení)
    ipcMain.handle("paint:clear-queue", () => {
        PAINT_QUEUE.length = 0;
        log("INFO", "PAINT queue cleared by IPC", "");
    });

    log("INFO", "paint.js", "IPC handlery zaregistrovány");
}

// ─── EXPORT ──────────────────────────────────────────────────────────────────

module.exports = {
    createPaintTempCopy,
    cleanupPaintMonitoring,
    registerIpcHandlers,
    PAINT_TEMP_DIR,

    // Gettery pro stav (používá main.js / DevTools)
    get queueLength()   { return PAINT_QUEUE.length; },
    get isRunning()     { return _queueRunning; },
    get currentFile()   { return currentPaintFile; },
    get currentPid()    { return currentPaintPid; },
};
