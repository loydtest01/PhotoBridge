// ============================================================
// src/main/devtools.js
// DevTools konzole – log buffer + IPC handlery
// Ekvivalent Python: _devtools_log_queue + DevToolsWindow (řádky 5184–5370)
// ============================================================

'use strict';

const { ipcMain, BrowserWindow, app } = require('electron');
const path = require('path');
const fs   = require('fs');

// ── Kruhový buffer pro logy (max 2000 záznamů, stejně jako Python originál) ──
const MAX_LOG_LINES = 2000;
const _logBuffer    = [];           // pole { raw: string, ts: string, level: string }
let   _devToolsWin  = null;         // reference na DevTools okno

// ── Interní funkce: přidání záznamu do bufferu ────────────────────────────────
function _pushLog(raw) {
  _logBuffer.push(raw);
  // Ořez na MAX_LOG_LINES
  if (_logBuffer.length > MAX_LOG_LINES) {
    _logBuffer.shift();
  }
  // Pokud je DevTools okno otevřeno, pošli záznam ihned (push místo polling)
  if (_devToolsWin && !_devToolsWin.isDestroyed()) {
    try {
      _devToolsWin.webContents.send('devtools:log-added', raw);
    } catch (_e) { /* tichý fail */ }
  }
}

// ── Veřejné API: přidání logu do bufferu ──────────────────────────────────────
// Volá se z utils.js log() funkce jako hook.
function addLog(level, ...args) {
  const ts  = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const msg = args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  const raw = `[${ts}] [${level}] ${msg}`;
  _pushLog(raw);
}

// ── Získej celý buffer (pro inicializaci DevTools okna) ───────────────────────
function getAllLogs() {
  return [..._logBuffer];
}

// ── Vymaž buffer ──────────────────────────────────────────────────────────────
function clearLogs() {
  _logBuffer.length = 0;
}

// ── Export logů do souboru ────────────────────────────────────────────────────
function exportLogsToFile(text) {
  try {
    const logsDir  = path.join(app.getPath('userData'), 'logs');
    if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
    const filename = `photobridge-logs-${new Date().toISOString().slice(0,10)}.txt`;
    const filePath = path.join(logsDir, filename);
    fs.writeFileSync(filePath, text, 'utf8');
    return filePath;
  } catch (e) {
    return null;
  }
}

// ── Otevření DevTools okna ────────────────────────────────────────────────────
// Volá se z main.js při stisku F12 nebo z menu.
function openDevToolsWindow(parentWin) {
  // Pokud je okno již otevřeno, jen ho vyforejgrunduj
  if (_devToolsWin && !_devToolsWin.isDestroyed()) {
    _devToolsWin.focus();
    return;
  }

  _devToolsWin = new BrowserWindow({
    width:  820,
    height: 500,
    minWidth:  500,
    minHeight: 300,
    title: 'DevTools – PhotoBridge',
    parent: parentWin || undefined,
    // Nezobrazovat v taskbaru (ekvivalent _taskbar_hide z Pythonu)
    skipTaskbar: true,
    webPreferences: {
      preload:          path.join(__dirname, '../../preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
    },
    backgroundColor: '#0b0d14',
    // Bez rámečku toolwindow – ale ponecháme titulek pro přehlednost
    frame: true,
    show:  false,
  });

  _devToolsWin.loadFile(path.join(__dirname, '../renderer/devtools.html'));

  _devToolsWin.once('ready-to-show', () => {
    _devToolsWin.show();
  });

  _devToolsWin.on('closed', () => {
    _devToolsWin = null;
  });
}

// ── Registrace IPC handlerů ────────────────────────────────────────────────────
function registerIpcHandlers() {

  // Renderer žádá o všechny buffered logy (inicializace)
  ipcMain.handle('devtools:get-all-logs', () => {
    return getAllLogs();
  });

  // Renderer žádá o vymazání logů
  ipcMain.on('devtools:clear-logs', () => {
    clearLogs();
  });

  // Renderer žádá o export logů do souboru
  ipcMain.handle('devtools:export-logs', async (_event, text) => {
    const filePath = exportLogsToFile(text);
    return filePath;
  });

  // Main process otvírá DevTools okno (z menu / F12)
  ipcMain.handle('devtools:open', (_event) => {
    // Najdi hlavní okno
    const wins = BrowserWindow.getAllWindows();
    const mainWin = wins.find(w => !w.isDestroyed() && w !== _devToolsWin);
    openDevToolsWindow(mainWin || null);
  });
}

module.exports = {
  addLog,
  getAllLogs,
  clearLogs,
  openDevToolsWindow,
  registerIpcHandlers,
};
