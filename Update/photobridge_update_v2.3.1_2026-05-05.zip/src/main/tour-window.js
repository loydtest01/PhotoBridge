'use strict';
// ============================================================
// PhotoBridge – src/main/tour-window.js
// Onboarding prohlídka jako SAMOSTATNÉ okno (nepřekrývá hlavní okno).
//
// Přepíná views v hlavním okně podle aktuálního kroku, zvýrazňuje prvky,
// otevírá Nastavení – uživatel vidí to o čem se mluví.
//
// Tour kroky se rozliší podle typu účtu (firemní vs. osobní) – viz tour.html.
//
// Spouští se z main.js handleru 'tour:start'. Po dokončení (tour:finish)
// uloží ONBOARDING_DONE: 'true' do configu.
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let _utils = null;
function log(...a) { try { (_utils || (_utils = require('./utils'))).log(...a); } catch(_) {} }

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');
const ASSETS_DIR   = path.join(__dirname, '..', '..', 'assets');
const ICON_PATH    = path.join(ASSETS_DIR, 'icons', 'icon.ico');

let _win = null;
let _registered = false;

/**
 * Otevře okno prohlídky. Singleton – pokud už okno existuje, jen ho zfokusuje.
 * @param {BrowserWindow} mainWindow - hlavní okno (parent, kvůli always-on-top chování)
 */
function openTourWindow(mainWindow) {
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return;
  }

  // Spočítej polohu – vedle hlavního okna, nebo doprostřed obrazovky
  const TOUR_W = 380;
  const TOUR_H = 540;
  let x, y;
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      const mb = mainWindow.getBounds();
      const { screen } = require('electron');
      const display = screen.getDisplayMatching(mb);
      const wa = display.workArea;
      // Umísti vpravo od hlavního okna; pokud se nevejde, vlevo; jinak dolů
      x = mb.x + mb.width + 12;
      y = mb.y;
      if (x + TOUR_W > wa.x + wa.width) {
        x = mb.x - TOUR_W - 12;  // vlevo
        if (x < wa.x) {
          x = mb.x + Math.max(0, (mb.width - TOUR_W) / 2);
          y = mb.y + mb.height + 12;
          if (y + TOUR_H > wa.y + wa.height) {
            y = wa.y + Math.max(0, (wa.height - TOUR_H) / 2);
          }
        }
      }
      // Zarovnej do display
      x = Math.max(wa.x + 4, Math.min(wa.x + wa.width - TOUR_W - 4, x));
      y = Math.max(wa.y + 4, Math.min(wa.y + wa.height - TOUR_H - 4, y));
    }
  } catch (_) { /* nevadí, použijeme default centrování */ }

  _win = new BrowserWindow({
    width:           TOUR_W,
    height:          TOUR_H,
    minWidth:        320,
    minHeight:       420,
    x, y,
    title:           'PhotoBridge – Prohlídka',
    icon:            ICON_PATH,
    parent:          undefined, // NE parent – ať uživatel může klikat do hlavního okna
    modal:           false,
    resizable:       true,
    frame:           true,
    autoHideMenuBar: true,
    alwaysOnTop:     false,    // ať uživatel může pracovat v hlavním okně
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools:         false,
    },
    show: false,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'tour.html'));

  _win.once('ready-to-show', () => {
    _win.show();
  });

  _win.on('closed', () => { _win = null; });
}

/**
 * Vykoná akci spojenou s krokem prohlídky:
 *   - přepne view v hlavním okně ('main' / 'qr')
 *   - zvýrazní DOM prvek (highlight)
 *   - otevře okno Nastavení
 *
 * @param {object} action - { view?, highlight?, openSettings?, openWebappQr?, openSettingsTab? }
 * @param {BrowserWindow} mainWindow
 */
function executeAction(action, mainWindow) {
  if (!action || !mainWindow || mainWindow.isDestroyed()) return;

  // Přepnutí view – pošle event, který renderer odchytí v Tour handleru
  if (action.view) {
    try {
      mainWindow.webContents.send('tour:set-view', action.view);
    } catch (_) {}
  }

  // Zvýraznit prvek (renderer si nechá animovat outline kolem #id)
  if (action.highlight) {
    try {
      mainWindow.webContents.send('tour:highlight', action.highlight);
    } catch (_) {}
  }

  // Otevřít Nastavení v samostatném okně
  if (action.openSettings) {
    try {
      ipcMain.emit('settings:open');
    } catch (_) {}
  }

  // Otevřít WebApp QR popup (samostatné okno s QR kódem pro mobil)
  if (action.openWebappQr) {
    try {
      const wq = require('./webapp-qr-window');
      if (wq && wq.openWebAppQrWindow) wq.openWebAppQrWindow(mainWindow, '');
    } catch (_) {}
  }

  // Demo: vyplň zakázku 1234567, vygeneruj QR a přepni na QR view
  if (action.demoQr) {
    try {
      mainWindow.webContents.send('tour:demo-qr');
    } catch (_) {}
  }

  // Konec demo QR – vrátí pole zakázky do původního stavu a přepne na main
  if (action.demoQrEnd) {
    try {
      mainWindow.webContents.send('tour:demo-qr-end');
    } catch (_) {}
  }

  // Demo: ukázat upload (drag-drop) dialog s 3 ukázkovými fotkami
  if (action.demoUpload) {
    try {
      mainWindow.webContents.send('tour:demo-upload');
    } catch (_) {}
  }

  // Otevřít okno s náhledem mobilní webapp (rám telefonu + iframe)
  if (action.openMobilePreview) {
    try {
      const mp = require('./mobile-preview-window');
      if (mp && mp.openMobilePreview) mp.openMobilePreview(mainWindow);
    } catch (_) {}
  }
}

/**
 * IPC registrace.
 * @param {() => BrowserWindow} getMainWindow
 */
function registerIpcHandlers(getMainWindow) {
  if (_registered) return;
  _registered = true;

  // Otevřít okno prohlídky (volá se z app.js Tour.start() i ze Settings)
  ipcMain.handle('tour:start', () => {
    const mw = getMainWindow ? getMainWindow() : null;
    openTourWindow(mw);
    return { ok: true };
  });

  // Vykonat akci spojenou s krokem
  ipcMain.handle('tour:action', (_evt, action) => {
    const mw = getMainWindow ? getMainWindow() : null;
    executeAction(action || {}, mw);
    return { ok: true };
  });

  // Dokončit prohlídku – ulož ONBOARDING_DONE
  ipcMain.handle('tour:finish', async () => {
    try {
      const cfg = require('./config');
      cfg.writeConfig({ ONBOARDING_DONE: 'true' });
      log('INFO', 'tour:finish', 'ONBOARDING_DONE uloženo');
    } catch (e) {
      log('WARN', 'tour:finish', e.message);
    }
    return { ok: true };
  });
}

module.exports = { openTourWindow, registerIpcHandlers };
