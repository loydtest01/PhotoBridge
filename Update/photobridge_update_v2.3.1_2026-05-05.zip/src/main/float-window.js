'use strict';
/**
 * float-window.js – PhotoBridge plovoucí ikona (Electron port z Python FloatingWindow)
 *
 * Chování:
 *  - Malé okno 70×70 px, vždy nahoře, bez rámečku, průhledné
 *  - Zobrazí se při minimalizaci hlavního okna (pokud MINIMIZE_TO=float)
 *  - Klik → obnoví hlavní okno
 *  - Táhnutí → přesune okno, pozice se uloží do configu
 *  - Pravý klik → kontextové menu (Otevřít / Ukončit)
 *  - Skryto z taskbaru
 *  - Keepalive: každé 2s se dá znovu do popředí (řeší překrývání jinými appkami)
 *  - Multi-monitor: výchozí pozice = pravý dolní roh monitoru hlavního okna
 */

const { BrowserWindow, ipcMain, screen, Menu, app } = require('electron');
const path   = require('path');
const fs     = require('fs');

const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

let _floatWin        = null;   // instance BrowserWindow
let _mainWinRef      = null;   // odkaz na hlavní okno
let _onRestoreCb     = null;   // callback volaný při obnově
let _keepaliveTimer  = null;   // setInterval pro topmost keepalive
let _registered      = false;

// ─────────────────────────────────────────────────────────────────────────────
// Veřejné API
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Zobrazí plovoucí ikonu. Pokud už existuje, jen ji zobrazí.
 * @param {BrowserWindow} mainWindow  Hlavní okno aplikace
 * @param {Function}      onRestore   Callback pro obnovení hlavního okna
 * @param {object}        cfg         Config objekt (STATE.config nebo podobné)
 */
function showFloat(mainWindow, onRestore, cfg) {
    _mainWinRef  = mainWindow;
    _onRestoreCb = onRestore;

    if (_floatWin && !_floatWin.isDestroyed()) {
        _floatWin.show();
        _floatWin.setAlwaysOnTop(true, 'screen-saver');
        _floatWin.focus();
        return;
    }

    _createFloatWindow(cfg);
}

/**
 * Skryje plovoucí ikonu (neničí ji – jen ji schová pro rychlé opětovné zobrazení).
 */
function hideFloat() {
    if (_floatWin && !_floatWin.isDestroyed()) {
        _floatWin.hide();
    }
    _stopKeepalive();
}

/**
 * Zničí plovoucí okno (volat při ukončení aplikace).
 */
function destroyFloat() {
    _stopKeepalive();
    if (_floatWin && !_floatWin.isDestroyed()) {
        _floatWin.destroy();
    }
    _floatWin = null;
}

/**
 * Vrátí aktuální pozici plovoucího okna { x, y } nebo null.
 */
function getFloatPosition() {
    if (_floatWin && !_floatWin.isDestroyed()) {
        const [x, y] = _floatWin.getPosition();
        return { x, y };
    }
    return null;
}

/**
 * Zaregistruje IPC handlery. Volat z main.js po app.ready.
 */
function registerIpcHandlers(getMainWindow, getCfg, saveCfg, quitApp) {
    if (_registered) return;
    _registered = true;

    // Renderer požádal o restore (klik na plovoucí ikonu)
    ipcMain.on('float:restore', () => {
        _doRestore();
    });

    // Renderer posílá novou pozici při tažení
    ipcMain.on('float:move', (_evt, { x, y }) => {
        if (_floatWin && !_floatWin.isDestroyed()) {
            _floatWin.setPosition(Math.round(x), Math.round(y));
        }
    });

    // Renderer uložil pozici po konci tažení
    ipcMain.on('float:save-pos', (_evt, { x, y }) => {
        const cfg = getCfg();
        cfg['FLOAT_X'] = String(x);
        cfg['FLOAT_Y'] = String(y);
        if (saveCfg) saveCfg(cfg);
    });

    // Pravý klik – zobraz nativní menu
    ipcMain.on('float:context-menu', () => {
        const menu = Menu.buildFromTemplate([
            {
                label: 'Otevřít PhotoBridge',
                click: () => _doRestore(),
            },
            { type: 'separator' },
            {
                label: 'Ukončit',
                click: () => {
                    if (quitApp) quitApp();
                    else app.quit();
                },
            },
        ]);
        if (_floatWin && !_floatWin.isDestroyed()) {
            menu.popup({ window: _floatWin });
        }
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// Interní
// ─────────────────────────────────────────────────────────────────────────────

function _createFloatWindow(cfg) {
    const SIZE = 35;
    const [x, y] = _getInitialPosition(cfg, SIZE);

    _floatWin = new BrowserWindow({
        width:           SIZE,
        height:          SIZE,
        x,
        y,
        frame:           false,
        transparent:     true,
        resizable:       false,
        skipTaskbar:     true,           // skryje z taskbaru
        alwaysOnTop:     true,
        focusable:       true,
        hasShadow:       false,
        roundedCorners:  false,
        type:            'toolbar',      // na Windows: nezobrazí se v Alt+Tab
        webPreferences: {
            preload:          PRELOAD_PATH,
            contextIsolation: true,
            nodeIntegration:  false,
            sandbox:          false,
            devTools:         false,
        },
        show: false,
    });

    // always-on-top na nejvyšší vrstvě (překoná i fullscreen aplikace)
    _floatWin.setAlwaysOnTop(true, 'screen-saver');

    // Načti HTML plovoucí ikony
    const floatHtml = path.join(RENDERER_DIR, 'float.html');
    if (fs.existsSync(floatHtml)) {
        _floatWin.loadFile(floatHtml);
    } else {
        // Fallback: inline HTML
        _floatWin.loadURL(`data:text/html,${encodeURIComponent(_fallbackHtml(SIZE))}`);
    }

    _floatWin.once('ready-to-show', () => {
        _floatWin.show();
        _startKeepalive();
    });

    _floatWin.on('closed', () => {
        _floatWin = null;
        _stopKeepalive();
    });

    // Zabrání minimalizaci plovoucího okna
    _floatWin.on('minimize', () => {
        _floatWin.restore();
    });
}

function _doRestore() {
    // Ulož pozici před skrytím
    const pos = getFloatPosition();
    if (pos && _onRestoreCb) {
        // pozice se uloží uvnitř callbacku přes float:save-pos nebo přímo
    }
    hideFloat();
    if (_onRestoreCb) {
        _onRestoreCb();
    } else if (_mainWinRef && !_mainWinRef.isDestroyed()) {
        _mainWinRef.show();
        _mainWinRef.restore();
        _mainWinRef.focus();
    }
}

function _getInitialPosition(cfg, SIZE) {
    // 1. Uložená pozice z configu
    try {
        const fx = cfg && cfg['FLOAT_X'];
        const fy = cfg && cfg['FLOAT_Y'];
        if (fx && fy) {
            const x = parseInt(fx, 10);
            const y = parseInt(fy, 10);
            // Ověř, že je na některém monitoru
            const displays = screen.getAllDisplays();
            const onScreen = displays.some(d => {
                const b = d.bounds;
                return x >= b.x && x < b.x + b.width && y >= b.y && y < b.y + b.height;
            });
            if (onScreen) return [x, y];
        }
    } catch (_) {}

    // 2. Výchozí: pravý dolní roh monitoru, na kterém je hlavní okno
    try {
        let display;
        if (_mainWinRef && !_mainWinRef.isDestroyed()) {
            const [wx, wy] = _mainWinRef.getPosition();
            const [ww, wh] = _mainWinRef.getSize();
            const cx = wx + ww / 2;
            const cy = wy + wh / 2;
            display = screen.getDisplayNearestPoint({ x: cx, y: cy });
        } else {
            display = screen.getPrimaryDisplay();
        }
        const b = display.workArea;
        return [b.x + b.width - SIZE - 20, b.y + b.height - SIZE - 20];
    } catch (_) {
        return [100, 100];
    }
}

function _startKeepalive() {
    _stopKeepalive();
    // Každé 2s znovu nastav alwaysOnTop – řeší překrývání jinými aplikacemi
    _keepaliveTimer = setInterval(() => {
        if (_floatWin && !_floatWin.isDestroyed() && _floatWin.isVisible()) {
            _floatWin.setAlwaysOnTop(true, 'screen-saver');
            _floatWin.moveTop();
        } else {
            _stopKeepalive();
        }
    }, 2000);
}

function _stopKeepalive() {
    if (_keepaliveTimer) {
        clearInterval(_keepaliveTimer);
        _keepaliveTimer = null;
    }
}

function _fallbackHtml(SIZE) {
    return `<!DOCTYPE html><html><head>
<style>
  * { margin:0;padding:0;box-sizing:border-box; }
  html,body { width:${SIZE}px;height:${SIZE}px;background:transparent;overflow:hidden; }
  #icon { width:${SIZE}px;height:${SIZE}px;border-radius:50%;background:#1976D2;
          display:flex;align-items:center;justify-content:center;cursor:pointer;
          font-family:Arial;font-weight:bold;font-size:18px;color:white;
          user-select:none; -webkit-app-region:no-drag; }
  #icon:hover { background:#1565C0; }
</style></head><body>
<div id="icon" title="PhotoBridge – klikni pro otevření">PB</div>
<script>
  const el = document.getElementById('icon');
  let sx,sy,mx,my,dragging=false;
  el.addEventListener('mousedown', e => { sx=e.screenX; sy=e.screenY; dragging=false;
    window.addEventListener('mousemove',onMove); window.addEventListener('mouseup',onUp); });
  function onMove(e){ const dx=Math.abs(e.screenX-sx),dy=Math.abs(e.screenY-sy);
    if(dx>4||dy>4){ dragging=true; require_ipc('float:move',{x:e.screenX-${SIZE/2},y:e.screenY-${SIZE/2}}); } }
  function onUp(e){ window.removeEventListener('mousemove',onMove); window.removeEventListener('mouseup',onUp);
    if(!dragging) window.electronAPI?.send('float:restore');
    else window.electronAPI?.send('float:save-pos',{x:window.screenX,y:window.screenY}); }
  el.addEventListener('contextmenu', () => window.electronAPI?.send('float:context-menu'));
</script></body></html>`;
}

// ─────────────────────────────────────────────────────────────────────────────
module.exports = {
    showFloat,
    hideFloat,
    destroyFloat,
    getFloatPosition,
    registerIpcHandlers,
};
