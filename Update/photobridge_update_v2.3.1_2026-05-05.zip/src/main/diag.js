'use strict';
// ============================================================
// src/main/diag.js – Diagnostické IPC handlery pro restore okno
//
// Neimplementuje vlastní logování – to dělá utils.js (logy v logs/YYYY-MM-DD.log).
// Tento modul pouze:
//   • čte logy z logs/ složky pro zobrazení v restore.html
//   • vrací systémové informace
//   • vytváří ZIP diagnostiky ke stažení
//
// IPC handlery (registrovat přes registerIpc()):
//   diag:get-logs   → pole { ts, level, context, msg }
//   diag:sysinfo    → systémové informace
//   diag:create-zip → uloží ZIP přes dialog
// ============================================================

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { app, ipcMain, dialog } = require('electron');
const { spawnSync }            = require('child_process');

const _utils = () => { try { return require('./utils'); } catch { return null; } };

// ── Cesta k log složce ────────────────────────────────────────────────────────
function _logDir() {
  try {
    const u = _utils();
    if (u?.getLogDir) return u.getLogDir();
    return path.join(app.getPath('userData'), 'logs');
  } catch { return path.join(app.getPath('userData'), 'logs'); }
}

// ── Čtení logů ────────────────────────────────────────────────────────────────
/**
 * Načte posledních maxLines řádků ze všech log souborů v logs/.
 * Formát utils.js: "YYYY-MM-DD HH:MM:SS.mmm [LEVEL] ..."
 */
function getLogs(maxLines = 500) {
  try {
    const dir = _logDir();
    if (!fs.existsSync(dir)) return [];

    // Seřaď soubory podle data (nejnovější poslední) – YYYY-MM-DD.log
    const files = fs.readdirSync(dir)
      .filter(f => /^\d{4}-\d{2}-\d{2}\.log$/.test(f))
      .sort()
      .slice(-3);  // max 3 soubory (dnes + 2 dny zpět)

    const lines = [];
    for (const file of files) {
      try {
        const raw = fs.readFileSync(path.join(dir, file), 'utf8');
        lines.push(...raw.trim().split('\n').filter(Boolean));
      } catch {}
    }

    return lines.slice(-maxLines).map(l => {
      // Formát: "2025-01-15 14:23:45.123 [INFO] [context] zpráva"
      const m = l.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}):\d{2}\.\d+ \[([A-Z]+)\s*\] \[([^\]]*)\] (.*)/);
      if (!m) return { ts: '', level: 'INFO', context: '', msg: l };
      return { ts: m[1].slice(11), level: m[2].trim(), context: m[3], msg: m[4] };
    });
  } catch { return []; }
}

// ── Sysinfo ───────────────────────────────────────────────────────────────────
function getSysinfo() {
  const gb = n => (n / 1024 / 1024 / 1024).toFixed(1) + ' GB';
  let freeDisk = '—';
  try {
    const r = spawnSync('wmic', ['logicaldisk', 'get', 'size,freespace,caption'],
      { encoding: 'utf8', timeout: 3000, windowsHide: true });
    if (r.status === 0) {
      const cLine = r.stdout.trim().split('\n').find(l => l.trim().startsWith('C:'));
      if (cLine) {
        const parts = cLine.trim().split(/\s+/);
        if (parts[1]) freeDisk = gb(parseInt(parts[1])) + ' volných';
      }
    }
  } catch {}

  return {
    os:          `${os.type()} ${os.release()}`,
    arch:        os.arch(),
    cpu:         (os.cpus()[0]?.model || '—').trim().slice(0, 52),
    totalRam:    gb(os.totalmem()),
    freeRam:     gb(os.freemem()),
    freeDisk,
    nodeVersion: process.versions.node,
    electronVer: process.versions.electron || '—',
    userData:    (() => { try { return app.getPath('userData'); } catch { return '—'; } })(),
    uptime:      Math.round(os.uptime() / 60) + ' min',
  };
}

// ── ZIP diagnostiky ──────────────────────────────────────────────────────────
async function createDiagZip(parentWindow = null) {
  try {
    const ts      = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const zipName = `pb_diagnostics_${ts}.zip`;
    const tmpZip  = path.join(os.tmpdir(), zipName);
    const psScript= path.join(os.tmpdir(), 'pb_diag_zip.ps1');
    const infoFile= path.join(os.tmpdir(), 'pb_sysinfo.json');

    fs.writeFileSync(infoFile, JSON.stringify(getSysinfo(), null, 2), 'utf8');

    const logDir   = _logDir();
    const userData = (() => { try { return app.getPath('userData'); } catch { return ''; } })();

    // Shromáždi soubory
    const files = [];
    if (fs.existsSync(logDir)) {
      for (const f of fs.readdirSync(logDir)) {
        files.push(path.join(logDir, f));
      }
    }
    for (const fname of ['update_pending.json', 'crash_flag.txt', 'config.json']) {
      const fp = path.join(userData, fname);
      if (fs.existsSync(fp)) files.push(fp);
    }
    const backupMeta = (() => {
      try {
        const backup = require('./backup');
        const meta = backup.getBackupMeta?.();
        if (meta) {
          const metaFile = path.join(os.tmpdir(), 'pb_backup_meta.json');
          fs.writeFileSync(metaFile, JSON.stringify(meta, null, 2));
          return metaFile;
        }
      } catch {}
      return null;
    })();
    if (backupMeta) files.push(backupMeta);
    files.push(infoFile);

    const esc = s => s.replace(/'/g, "''");
    const addLines = files.filter(f => fs.existsSync(f)).map(f =>
      `Compress-Archive -Path '${esc(f)}' -DestinationPath '${esc(tmpZip)}' -Update`
    ).join('\n');

    fs.writeFileSync(psScript, [
      `if(Test-Path '${esc(tmpZip)}'){Remove-Item '${esc(tmpZip)}' -Force}`,
      addLines,
    ].join('\n'), 'utf8');

    const r = spawnSync('powershell', [
      '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', psScript,
    ], { encoding: 'utf8', timeout: 15000, windowsHide: true });

    if (r.status !== 0) return { ok: false, error: r.stderr || 'PS chyba' };

    const { filePath, canceled } = await dialog.showSaveDialog(parentWindow, {
      title:       'Uložit diagnostiku',
      defaultPath: path.join(os.homedir(), 'Desktop', zipName),
      filters:     [{ name: 'ZIP archiv', extensions: ['zip'] }],
    });
    if (canceled || !filePath) return { ok: false, error: 'Zrušeno' };
    fs.copyFileSync(tmpZip, filePath);
    _utils()?.log?.('INFO', 'diag', 'ZIP diagnostiky uložen: ' + filePath);
    return { ok: true, path: filePath };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── IPC ────────────────────────────────────────────────────────────────────────
function registerIpc(getWindow = () => null) {
  ipcMain.handle('diag:get-logs',   ()  => getLogs());
  ipcMain.handle('diag:sysinfo',    ()  => getSysinfo());
  ipcMain.handle('diag:create-zip', ()  => createDiagZip(getWindow()));
}

module.exports = { getLogs, getSysinfo, createDiagZip, registerIpc };
