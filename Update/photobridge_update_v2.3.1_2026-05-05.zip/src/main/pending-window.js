'use strict';
// ============================================================
// PhotoBridge – src/main/pending-window.js
// Okno s přehledem nestažených zakázek ze Supabase (pb_queue).
//
//  • openPendingWindow(mainWindow)  – otevře / přenese fokus
//  • registerIpcHandlers()          – IPC kanály pending:*
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path = require('path');

// ── Lazy importy ──────────────────────────────────────────────────────────────
let _utils = null;
function utils() { return _utils || (_utils = require('./utils')); }

// ── Singleton reference ───────────────────────────────────────────────────────
let _win = null;

// ── Cesty ─────────────────────────────────────────────────────────────────────
const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

// ══════════════════════════════════════════════════════════════
// OTEVŘENÍ OKNA
// ══════════════════════════════════════════════════════════════

function openPendingWindow(mainWindow) {
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return _win;
  }

  _win = new BrowserWindow({
    width:     540,
    height:    520,
    minWidth:  420,
    minHeight: 340,
    title:     'PhotoBridge – Nestažené zakázky',
    parent:    mainWindow || undefined,
    modal:     false,
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools: (process.argv.includes('--dev') || !require('electron').app.isPackaged),
    },
    show:            false,
    backgroundColor: '#141414',
    autoHideMenuBar: true,
    resizable:       true,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'pending.html'));

  _win.once('ready-to-show', () => {
    _win.show();
  });

  _win.on('closed', () => { _win = null; });

  utils().log('INFO', 'pending-window', 'Okno otevřeno');
  return _win;
}

// ══════════════════════════════════════════════════════════════
// IPC HANDLERY
// ══════════════════════════════════════════════════════════════

function registerIpcHandlers(getMainWindow) {
  // Otevřít okno nestažených zakázek
  ipcMain.handle('pending:open', (_evt) => {
    openPendingWindow(getMainWindow ? getMainWindow() : null);
  });

  // Zavřít okno
  ipcMain.handle('pending:close', () => {
    if (_win && !_win.isDestroyed()) _win.close();
  });

  // Vyplnit zakázku v hlavním okně a zavřít toto okno
  ipcMain.handle('pending:use-job', (_evt, job) => {
    const mw = getMainWindow ? getMainWindow() : null;
    if (mw && !mw.isDestroyed()) {
      mw.webContents.send('pending:fill-job', job);
      mw.focus();
    }
    if (_win && !_win.isDestroyed()) _win.close();
  });

  utils().log('INFO', 'pending-window', 'IPC handlery zaregistrovány');
}

module.exports = { openPendingWindow, registerIpcHandlers };
