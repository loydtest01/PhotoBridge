'use strict';
// ============================================================
// PhotoBridge – src/main/webapp-qr-window.js
// Malé popup okno s QR kódem pro webovou aplikaci.
// Otevře se kliknutím na QR ikonku vedle "Připojeno k SupaBase".
// QR zakóduje https://loydtest01.github.io/PhotoBridge/QR
// ============================================================

const { BrowserWindow, ipcMain } = require('electron');
const path   = require('path');
const qrcode = require('qrcode');

let _utils = null;
function log(...a) { try { (_utils || (_utils = require('./utils'))).log(...a); } catch(_) {} }

const RENDERER_DIR  = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH  = path.join(__dirname, '..', '..', 'preload.js');
const ASSETS_DIR    = path.join(__dirname, '..', '..', 'assets');
const ICON_PATH     = path.join(ASSETS_DIR, 'icons', 'icon.ico');
const WEBAPP_URL    = 'https://loydtest01.github.io/PhotoBridge/';

let _win = null;

// ── Otevření okna ─────────────────────────────────────────────────────────────
async function openWebAppQrWindow(mainWindow, job) {
  // Singleton – pokud okno existuje, jen ho zobraz
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return;
  }

  // Vygeneruj QR jako data URL (PNG base64)
  let qrDataUrl = '';
  try {
    qrDataUrl = await qrcode.toDataURL(WEBAPP_URL, {
      errorCorrectionLevel: 'L',  // L = menší/jednodušší QR, čitelné i na starých telefonech
      margin: 2,
      width: 220,
      color: { dark: '#000000', light: '#ffffff' },
    });
  } catch (e) {
    log('WARN', 'webapp-qr-window: QR generování selhalo', String(e));
  }

  _win = new BrowserWindow({
    width:           300,
    height:          430,
    minWidth:        260,
    minHeight:       380,
    maxWidth:        400,
    maxHeight:       540,
    title:           'PhotoBridge – Web App',
    icon:            ICON_PATH,
    parent:          mainWindow || undefined,
    modal:           false,
    resizable:       true,
    autoHideMenuBar: true,
    webPreferences: {
      preload:          PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools:         false,
    },
    show:            false,
  });

  // Načti HTML s QR předaným jako query param (base64 v URLu by byl příliš dlouhý → pošleme přes IPC)
  _win.loadFile(path.join(RENDERER_DIR, 'webapp-qr.html'));

  _win.once('ready-to-show', () => {
    _win.show();
    // Pošli QR data do rendereru
    _win.webContents.send('webapp-qr:data', { qrDataUrl, url: WEBAPP_URL, job: job || '' });
  });

  _win.on('closed', () => { _win = null; });
}

// ── IPC registrace ─────────────────────────────────────────────────────────────
let _registered = false;

function registerIpcHandlers(getMainWindow) {
  if (_registered) return;
  _registered = true;

  ipcMain.handle('webapp-qr:open', (_evt, { job } = {}) => {
    const mw = getMainWindow ? getMainWindow() : null;
    openWebAppQrWindow(mw, job || '');
    return { ok: true };
  });
}

module.exports = { openWebAppQrWindow, registerIpcHandlers };
