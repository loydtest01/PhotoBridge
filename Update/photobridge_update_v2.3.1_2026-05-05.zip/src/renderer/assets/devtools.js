// ============================================================
// src/renderer/assets/devtools.js
//
// POZNÁMKA: Renderer-side DevTools logika je INLINE v devtools.html
// (ve <script> tagu). Tento soubor existuje pouze jako placeholder –
// NEPŘIDÁVAT sem main-process kód (ipcMain, BrowserWindow atd.)!
//
// Renderer komunikuje s main procesem přes:
//   window.electronAPI.getAllLogs()      – načte buffered logy
//   window.electronAPI.onLogAdded(cb)   – real-time push nových logů
//   window.electronAPI.clearDevLogs()   – vymaže buffer
//   window.electronAPI.exportLogs(text) – export do souboru
// ============================================================

'use strict';
// (renderer DevTools logika je inlinována v devtools.html)
