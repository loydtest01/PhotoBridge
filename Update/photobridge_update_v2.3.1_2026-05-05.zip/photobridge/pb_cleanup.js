/**
 * PhotoBridge – jednorázový cleanup uvízlých souborů v Supabase Storage
 *
 * Spuštění z kořene projektu PhotoBridge:
 *   node pb_cleanup.js
 *
 * Automaticky přečte SB_URL, SB_ANON a refresh token z PhotoBridge configu.
 * Pojistka: spustí se jen JEDNOU na každém PC – další spuštění hned skončí.
 */

"use strict";

const fetch = require("node-fetch");

const { readConfig }           = require("./src/main/config");
const { loadState, saveState } = require("./src/main/utils");

const cfg    = readConfig();
const SB_URL  = (cfg.SB_URL  || "").trim().replace(/\/$/, "");
const SB_ANON = (cfg.SB_ANON || "").trim();
const BUCKET  = (cfg.SB_BUCKET || "pb-uploads").trim();
const CLEANUP_VERSION = "2.1.2";  // změňte pokud budete cleanup opakovat

if (!SB_URL || !SB_ANON) {
    console.error("Chybi SB_URL nebo SB_ANON v configu PhotoBridge.");
    process.exit(1);
}

function headers(token) {
    return {
        "Content-Type":  "application/json",
        "apikey":        SB_ANON,
        "Authorization": `Bearer ${token || SB_ANON}`,
    };
}

async function getToken() {
    const st      = loadState();
    const refresh = st.sb_refresh || "";

    if (!refresh) {
        console.error("Nejste prihlaseni v PhotoBridge. Prihlaste se v aplikaci a pak skript spustte znovu.");
        process.exit(1);
    }

    const resp = await fetch(`${SB_URL}/auth/v1/token?grant_type=refresh_token`, {
        method:  "POST",
        headers: { "Content-Type": "application/json", "apikey": SB_ANON },
        body:    JSON.stringify({ refresh_token: refresh }),
        timeout: 15_000,
    });
    const data = await resp.json();

    if (!data.access_token) {
        console.error("Refresh token expiroval. Prihlaste se v aplikaci a zkuste znovu.");
        process.exit(1);
    }

    try {
        const s      = loadState();
        s.sb_refresh = data.refresh_token || refresh;
        saveState(s);
    } catch { /* nevadi */ }

    return data.access_token;
}

async function main() {
    // ── Pojistka: spustí se jen jednou na každém PC ──────────────────────────
    // Po dokončení se do state.json uloží pb_cleanup_done = "2.1.2".
    // Druhý a další PC najde příznak a hned skončí bez jakéhokoli požadavku.
    const st = loadState();
    if (st.pb_cleanup_done === CLEANUP_VERSION) {
        console.log("Cleanup uz probehlo na tomto PC – preskakuji.");
        return;
    }

    console.log("PhotoBridge cleanup v" + CLEANUP_VERSION + "\n");
    console.log("Supabase: " + SB_URL);
    console.log("Bucket:   " + BUCKET + "\n");

    process.stdout.write("Prihlasuji se... ");
    const token = await getToken();
    console.log("OK\n");

    process.stdout.write("Nacitam uvizle zaznamy z pb_queue... ");
    const qResp = await fetch(
        `${SB_URL}/rest/v1/pb_queue?done=eq.true&select=id,file_path,created_at&limit=1000`,
        { headers: { ...headers(token), Accept: "application/json" }, timeout: 15_000 }
    );
    if (!qResp.ok) { console.error("HTTP " + qResp.status); process.exit(1); }
    const rows     = await qResp.json();
    const withPath = (rows || []).filter(r => r.file_path);
    console.log("nalezeno " + withPath.length + " zaznamu.\n");

    if (withPath.length > 0) {
        const paths = withPath.map(r => r.file_path);
        let deleted = 0, failed = 0;

        for (let i = 0; i < paths.length; i += 100) {
            const batch = paths.slice(i, i + 100);
            const resp  = await fetch(`${SB_URL}/storage/v1/object/${BUCKET}`, {
                method:  "DELETE",
                headers: headers(token),
                body:    JSON.stringify({ prefixes: batch }),
                timeout: 20_000,
            });
            if (resp.ok) {
                console.log("  Smazano " + batch.length + " souboru");
                deleted += batch.length;
            } else {
                const body = await resp.text().catch(() => "");
                console.warn("  Batch selhal HTTP " + resp.status + ": " + body.slice(0, 100));
                failed += batch.length;
            }
        }

        const cutoff = new Date(Date.now() - 60 * 60 * 1000).toISOString();
        const dResp  = await fetch(
            `${SB_URL}/rest/v1/pb_queue?done=eq.true&created_at=lt.${encodeURIComponent(cutoff)}`,
            { method: "DELETE", headers: { ...headers(token), Prefer: "return=minimal" }, timeout: 10_000 }
        );
        if (dResp.ok) console.log("\nStare zaznamy z pb_queue smazany.");
        else          console.warn("\npb_queue DELETE selhal: " + dResp.status);

        console.log("\nSmazano: " + deleted + " souboru" + (failed ? ", selhalo: " + failed : ""));
    } else {
        console.log("Nic k mazani – vse ciste.");
    }

    // ── Uložit příznak – tento PC cleanup přeskočí napřesrok ─────────────────
    try {
        const s = loadState();
        s.pb_cleanup_done = CLEANUP_VERSION;
        saveState(s);
    } catch { /* nevadi */ }

    console.log("\nHotovo. Muzete smazat soubor pb_cleanup.js – uz neni potreba.");
}

main().catch(err => {
    console.error("Neocekavana chyba:", err.message || err);
    process.exit(1);
});
