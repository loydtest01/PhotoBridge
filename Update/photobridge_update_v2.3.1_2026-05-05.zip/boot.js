'use strict';
// ============================================================
// resources/boot.js  –  Bootstrap vrstva (NIKDY se neaktualizuje)
//
// Tento soubor leží MIMO resources/app/ → updater ho nepřepíše.
// package.json v resources/ musí mít: "main": "boot.js"
//
// Co dělá:
//   1. Zkontroluje zda je přítomen --restore flag
//   2. Zkontroluje zda crash_flag + update_pending → špatná aktualizace
//   3. Zkontroluje zda app/main.js vůbec jde načíst (syntax check)
//   → normální start: načte app/main.js
//   → záchranný start: načte restore/restore-main.js
// ============================================================

const fs   = require('fs');
const path = require('path');
const { app } = require('electron');

const ROOT        = __dirname;                          // resources/
const APP_MAIN    = path.join(ROOT, 'app', 'main.js');
const RESTORE_MAIN= path.join(ROOT, 'restore', 'restore-main.js');
const USER_DATA   = app.getPath('userData');
const CRASH_FLAG  = path.join(USER_DATA, 'crash_flag.txt');
const PENDING_FLAG= path.join(USER_DATA, 'update_pending.json');

function _exists(p) {
  try { return fs.existsSync(p); } catch { return false; }
}

function _canLoad(p) {
  // Pokusí se načíst soubor syntakticky — odhalí rozbité JS
  try {
    require.resolve(p);
    // Zkusí načíst jako modul (zachytí SyntaxError)
    require(p);
    return true;
  } catch (e) {
    // Pokud je to jen chybějící závislost, to nevadí
    if (e.code === 'MODULE_NOT_FOUND' && !e.message.includes(p)) return true;
    if (e instanceof SyntaxError) return false;
    return true; // ostatní chyby jsou runtime — to necháme projít
  }
}

// ── Rozhodnutí ─────────────────────────────────────────────────────────────────
const forceRestore   = process.argv.includes('--restore');
const hasCrash       = _exists(CRASH_FLAG);
const hasPending     = _exists(PENDING_FLAG);
const isBadUpdate    = hasCrash && hasPending;
const appMainMissing = !_exists(APP_MAIN);

const useRestore = forceRestore || isBadUpdate || appMainMissing;

if (useRestore) {
  console.log('[boot] Záchranný režim:', { forceRestore, isBadUpdate, appMainMissing });
  // Předej kontext do restore okna přes global
  global.__PB_RESTORE_CONTEXT = {
    isBadUpdate,
    forceRestore,
    appMainMissing,
  };
  require(RESTORE_MAIN);
} else {
  require(APP_MAIN);
}
