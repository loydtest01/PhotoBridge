/**
 * supabase.js – Supabase Auth + Storage poller
 * Fáze 5: přepis Python logiky z photobridge.py (řádky 1690–2110)
 *
 * Exportuje:
 *   sbLogin(cfg, emailOrName, password)  → { ok, error }
 *   sbRegister(cfg, username, password)  → { ok, error }
 *   sbEnsureToken(cfg)                   → access_token string nebo ""
 *   sbListObjects(cfg, bucket, job)      → pole objektů
 *   sbDownload(cfg, bucket, path)        → Buffer
 *   sbDelete(cfg, bucket, path)          → void
 *   startSbPoller(cfg, job, saveDir)     → void
 *   stopSbPoller()                       → void
 *   registerIpcHandlers()                → void  (volat z main.js)
 */

"use strict";

const { ipcMain }  = require("electron");
const fetch        = require("node-fetch");   // npm i node-fetch@2
const https        = require("https");
const fs           = require("fs");
const path         = require("path");
const sharp        = require("sharp");        // npm i sharp  (konverze do PNG + resize)

// Importy ze sesterských modulů
const { log, loadState, saveState, STATE } = require("./utils");

// ─── HTTP/HTTPS agenti ────────────────────────────────────────────────────────
// Vlastní Agent pro auth endpointy (login, refresh, signup) – nepoužívá
// globální connection pool, takže se nezasekne když poller drmolil requesty
// před logoutem a auth si nemůže půjčit socket.
// keepAlive: false → každý request má vlastní fresh TCP connection.
const _authAgent = new https.Agent({
    keepAlive:    false,
    maxSockets:   8,
    timeout:      30_000,
});

// Pro pollovací requesty (časté, krátké) zůstává keepAlive aby šetřil overhead
const _pollAgent = new https.Agent({
    keepAlive:    true,
    keepAliveMsecs: 5_000,
    maxSockets:   10,
    timeout:      15_000,
});

// ─── Interní stav polleru ────────────────────────────────────────────────────
let _pollerTimer  = null;       // setInterval handle
let _pollerSeen   = new Set();  // již zpracované file_path hodnoty
let _pollerActive = false;

// ─── Realtime websocket ───────────────────────────────────────────────────────
let _rtSocket           = null;       // WebSocket instance
let _rtRef              = 0;          // counter pro Realtime message refs
let _rtHeartbeat        = null;       // setInterval pro heartbeat
let _rtReconnect        = null;       // setTimeout pro reconnect
let _rtConnected        = false;
let _rtHeartbeatSent    = 0;          // počet odeslaných heartbeatů bez odpovědi
let _rtLastHeartbeatRef = "";         // ref poslední odeslané heartbeat zprávy

// ─── Sériová fronta zpracování ────────────────────────────────────────────────
// Když přijde batch fotek (Realtime nebo polling), zpracovávají se postupně –
// nikdy 2 souběžně. To zajišťuje že _nextLetter přiděluje písmena ve správném
// pořadí (A pro nejstarší, B pro další, …) a Malování se otevře sekvenčně,
// ne 5× najednou.
let _processQueue   = [];        // fronta { filePath, rowId }
let _processRunning = false;     // je právě nějaké zpracování v běhu?

// ─── Counter pro fallback Storage scan ────────────────────────────────────────
// Každých N ticků (závisí na intervalu) projdeme Storage přímo, ne jen pb_queue.
// Pokrývá scénář kdy mobil úspěšně nahrál soubor ale pb_queue insert selhal.
let _pollerTickCount = 0;



// ─── Pomocné funkce ──────────────────────────────────────────────────────────

/**
 * Sestaví hlavičky pro Supabase API volání.
 * @param {string} apikey   – anon klíč nebo access token
 * @param {string} [bearer] – Bearer token (pokud se liší od apikey)
 */
function _sbHeaders(apikey, bearer) {
    return {
        "Content-Type":  "application/json",
        "apikey":        apikey,
        "Authorization": `Bearer ${bearer || apikey}`,
    };
}

/**
 * Dekóduje `exp` claim z JWT bez ověření podpisu.
 * @param {string} token
 * @returns {number} Unix timestamp nebo 0 při chybě
 */
function _jwtExp(token) {
    try {
        const parts   = token.split(".");
        if (parts.length < 2) return 0;
        const payload = Buffer.from(parts[1], "base64url").toString("utf8");
        return Number(JSON.parse(payload).exp || 0);
    } catch {
        return 0;
    }
}

/**
 * Vrátí platnou sb_url bez koncového lomítka.
 * @param {object} cfg
 */
function _sbUrl(cfg) {
    return (cfg.SB_URL || "").trim().replace(/\/$/, "");
}

// ─── AUTH ────────────────────────────────────────────────────────────────────

/**
 * Přihlásí aplikaci do Supabase Auth.
 * Přijímá plnou emailovou adresu.
 * Uloží access_token, refresh_token a user_id do STATE.
 *
 * @param {object} cfg       – konfigurace s SB_URL, SB_ANON
 * @param {string} emailOrName  – plná emailová adresa
 * @param {string} password
 * @returns {Promise<{ok: boolean, error: string}>}
 */
async function sbLogin(cfg, emailOrName, password) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const email  = emailOrName.trim();

    // Pojistka: pokud je nějaký poller/websocket z předchozího uživatele
    // ještě naživu, zastav ho. Bez toho by starý poller mohl chvíli běžet
    // s tokenem předchozího účtu, mít _pollerSeen z předchozího účtu, atd.
    const hadPrevSession = Boolean(STATE.sbAccessToken || _pollerActive || _rtSocket);
    try {
        if (typeof stopSbPoller === "function") stopSbPoller();
    } catch (_) {}
    _pollerSeen   = new Set();
    _processQueue = [];

    // Když jsme zrovna teardownovali předchozí session, dej Node.js 250 ms
    // na uvolnění TCP socketů (jinak by nový login request mohl čekat ve
    // frontě za uzavírajícím se websocketem nebo zbylými fetch requesty
    // předchozího pollera). Tohle vysvětluje "první pokus po logoutu trvá
    // 30 s a spadne timeout, druhý pokus je hned hotov."
    if (hadPrevSession) {
        await new Promise(r => setTimeout(r, 250));
    }

    /**
     * Pošle login request s 25s timeoutem; při síťové chybě 1× zkusí znova
     * po 1 sekundě. Tím odpadne většina „network timeout" chyb na pomalých sítích.
     */
    const doLogin = async () => fetch(`${sbUrl}/auth/v1/token?grant_type=password`, {
        method:  "POST",
        headers: _sbHeaders(sbAnon),
        body:    JSON.stringify({ email, password }),
        timeout: 25_000,
        agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
    });

    try {
        let resp;
        try {
            resp = await doLogin();
        } catch (netErr) {
            // Síťová chyba (timeout, ECONNRESET, …) → 1× retry po 1s
            log("INFO", "SB_AUTH login retry", String(netErr).split("\n")[0]);
            await new Promise(r => setTimeout(r, 1000));
            resp = await doLogin();
        }
        const data = await resp.json();

        if (!data.access_token) {
            const msg = data.error_description || data.msg || data.message || "Přihlášení selhalo";
            log("WARN", "SB_AUTH login", msg);
            return { ok: false, error: msg };
        }

        // Uložit tokeny do STATE
        STATE.sbAccessToken  = data.access_token;
        STATE.sbRefreshToken = data.refresh_token || "";
        STATE.sbUserId       = (data.user || {}).id || "";
        STATE.sbEmail         = emailOrName;  // pro isDomaProfil + UI
        STATE.sbAccountType  = ((data.user || {}).user_metadata || {}).account_type || "";

        log("INFO", "SB_AUTH login OK", `user=${STATE.sbUserId.slice(0, 8)}...`);

        // Persistentně uložit refresh token + email (pro obnovu po restartu)
        try {
            const st         = loadState();
            st.sb_refresh    = STATE.sbRefreshToken;
            st.sb_email      = STATE.sbEmail;      // uložit email pro UI po restartu
            // Také uložit do seznamu nedávných emailů (auto-suggest při dalším loginu)
            const recents    = Array.isArray(st.sb_recent_emails) ? st.sb_recent_emails : [];
            const filtered   = recents.filter(e => e !== STATE.sbEmail);
            filtered.unshift(STATE.sbEmail);
            st.sb_recent_emails = filtered.slice(0, 5);  // max 5 nedávných
            saveState(st);
        } catch { /* nevadí */ }

        return { ok: true, error: "" };

    } catch (err) {
        log("WARN", "SB_AUTH login failed", String(err));
        return { ok: false, error: String(err) };
    }
}

/**
 * Zaregistruje nového uživatele v Supabase Auth.
 * Přijímá plnou emailovou adresu.
 *
 * @param {object} cfg
 * @param {string} email  – plná emailová adresa
 * @param {string} password
 * @returns {Promise<{ok: boolean, error: string}>}
 */
async function sbRegister(cfg, email, password, accountType = "business") {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    email        = email.trim();
    const username = email.split("@")[0];

    try {
        const resp = await fetch(`${sbUrl}/auth/v1/signup`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon),
            body:    JSON.stringify({
                email,
                password,
                data: { username, email_verified: true, account_type: accountType },
            }),
            timeout: 25_000,
            agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
        });
        const data = await resp.json();

        // ── A) Signup vrátil přímo access_token (Email Confirmations vypnuté) ──
        if (data.access_token) {
            STATE.sbAccessToken  = data.access_token;
            STATE.sbRefreshToken = data.refresh_token || "";
            STATE.sbUserId       = (data.user || {}).id || "";
            STATE.sbEmail        = email;
            STATE.sbAccountType  = accountType || "business";
            log("INFO", "SB_AUTH register OK (auto-login)", `user=${email}`);
            try {
                const st            = loadState();
                st.sb_refresh       = STATE.sbRefreshToken;
                st.sb_email         = STATE.sbEmail;
                st.sb_account_type  = STATE.sbAccountType;
                saveState(st);
            } catch { /* nevadí */ }
            return { ok: true, error: "", accountType: STATE.sbAccountType };
        }

        // ── B) Signup vrátil pouze user (běžné u některých Supabase nastavení) ──
        // Supabase může vrátit user buď jako data.user, NEBO jako samotný root
        // objekt (data.id + data.email) — závisí na verzi a konfiguraci.
        // Obě varianty znamenají, že účet vznikl správně.
        const signupUser = data.user || (data.id && data.email ? data : null);
        if (signupUser) {
            // Pokud Supabase poslal confirmation_sent_at nebo prázdné identities,
            // je vyžadováno potvrzení emailu - NEZKOUŠÍME auto-login (způsoboval
            // dlouhé čekání na timeout), rovnou vrátíme info hlášku.
            const needsConfirm = signupUser.confirmation_sent_at
                || (Array.isArray(signupUser.identities) && signupUser.identities.length === 0);
            if (needsConfirm) {
                log("INFO", "SB_AUTH register: email confirmation required, přeskakuji auto-login", email);
                return {
                    ok:                    false,
                    needsEmailConfirmation: true,
                    error:                 "Účet byl vytvořen. Zkontrolujte e-mail a potvrďte registraci kliknutím na odkaz.",
                };
            }

            // Email confirmation není vyžadováno - zkusime rovnou přihlásit.
            log("INFO", "SB_AUTH register: signup OK, zkouším auto-login", email);
            const loginResult = await sbLogin(cfg, email, password);
            if (loginResult.ok) {
                STATE.sbAccountType = accountType || "business";
                try {
                    const st           = loadState();
                    st.sb_account_type = STATE.sbAccountType;
                    saveState(st);
                } catch { /* nevadí */ }
                log("INFO", "SB_AUTH register OK (login po signup)", email);
                return { ok: true, error: "", accountType: STATE.sbAccountType };
            }

            // Auto-login selhal z neznámého důvodu - ucet ale vznikl spravne.
            log("INFO", "SB_AUTH register: auto-login selhal, ale ucet vznikl", loginResult.error);
            return {
                ok:                    false,
                needsEmailConfirmation: true,
                error:                 "Účet byl vytvořen. Zkontrolujte e-mail a potvrďte registraci kliknutím na odkaz.",
            };
        }

        // ── C) Signup selhal ──
        const msg = data.msg || data.message || data.error_description || "Registrace selhala";
        log("WARN", "SB_AUTH register failed", msg);
        return { ok: false, error: msg };

    } catch (err) {
        log("WARN", "SB_AUTH register failed", String(err));
        return { ok: false, error: String(err) };
    }
}

/**
 * Vrátí platný access_token.
 * Pokud STATE je prázdný nebo expirovaný, zkusí refresh nebo login.
 *
 * @param {object} cfg  – musí obsahovat SB_URL, SB_ANON, SB_EMAIL, SB_PASS
 * @returns {Promise<string>}  access_token nebo ""
 */
async function sbEnsureToken(cfg) {
    const sbUrl       = _sbUrl(cfg);
    const sbAnon      = (cfg.SB_ANON  || "").trim();
    const emailOrName = (cfg.SB_EMAIL || "").trim();
    const password    = (cfg.SB_PASS  || "").trim();

    // Máme platný token v paměti? (s 60 s rezervou)
    if (STATE.sbAccessToken) {
        const exp = _jwtExp(STATE.sbAccessToken);
        if (exp === 0 || exp > Date.now() / 1000 + 60) {
            return STATE.sbAccessToken;
        }
        // Token expiroval – vyčisti
        log("INFO", "SB_AUTH", "Access token expiroval, obnovuji...");
        STATE.sbAccessToken = "";
    }

    // Načti refresh token ze state.json pokud není v paměti
    if (!STATE.sbRefreshToken) {
        try {
            const st = loadState();
            STATE.sbRefreshToken = st.sb_refresh || "";
        } catch { /* nevadí */ }
    }

    // Zkus refresh
    if (STATE.sbRefreshToken && sbUrl && sbAnon) {
        try {
            const resp = await fetch(`${sbUrl}/auth/v1/token?grant_type=refresh_token`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon),
                body:    JSON.stringify({ refresh_token: STATE.sbRefreshToken }),
                timeout: 10_000,
                agent:   sbUrl.startsWith("https") ? _authAgent : undefined,
            });
            const data = await resp.json();

            if (data.access_token) {
                STATE.sbAccessToken  = data.access_token;
                STATE.sbRefreshToken = data.refresh_token || STATE.sbRefreshToken;
                log("INFO", "SB_AUTH token refreshed", "");

                // Uložit aktualizovaný refresh token
                try {
                    const st      = loadState();
                    st.sb_refresh = STATE.sbRefreshToken;
                    saveState(st);
                } catch { /* nevadí */ }

                return STATE.sbAccessToken;
            }
        } catch (err) {
            log("WARN", "SB_AUTH refresh failed", String(err));
            STATE.sbAccessToken  = "";
            STATE.sbRefreshToken = "";
        }
    }

    // Fallback: přihlásit znovu jménem + heslem
    if (emailOrName && password && sbUrl && sbAnon) {
        const { ok } = await sbLogin(cfg, emailOrName, password);
        if (ok) return STATE.sbAccessToken;
    }

    log("WARN", "SB_AUTH", "Nelze získat token – jméno/heslo není nastaveno nebo je chybné");
    return "";
}

// ─── STORAGE OPERACE ─────────────────────────────────────────────────────────

/**
 * Vrátí seznam objektů ve složce job/ v bucketu.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} job
 * @returns {Promise<Array>}
 */
async function sbListObjects(cfg, bucket, job) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();

    try {
        const resp = await fetch(`${sbUrl}/storage/v1/object/list/${bucket}`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon),
            body:    JSON.stringify({ prefix: `${job}/`, limit: 100, offset: 0 }),
            timeout: 8_000,
        });
        return await resp.json();
    } catch (err) {
        log("WARN", "SB list error", String(err));
        return [];
    }
}

/**
 * Stáhne soubor ze Supabase Storage jako Buffer.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} filePath  – cesta uvnitř bucketu
 * @returns {Promise<Buffer>}
 */
async function sbDownload(cfg, bucket, filePath) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const token  = STATE.sbAccessToken || sbAnon;
    const url    = `${sbUrl}/storage/v1/object/${bucket}/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`;

    const resp = await fetch(url, {
        headers: _sbHeaders(sbAnon, token),
        timeout: 30_000,
    });
    if (!resp.ok) throw new Error(`SB download HTTP ${resp.status}`);
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Smaže soubor ze Supabase Storage po zpracování.
 *
 * @param {object} cfg
 * @param {string} bucket
 * @param {string} filePath
 * @returns {Promise<void>}
 */
async function sbDelete(cfg, bucket, filePath) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    const token  = STATE.sbAccessToken || sbAnon;
    // Supabase Storage bulk-delete endpoint (single path wrapped in array)
    const url    = `${sbUrl}/storage/v1/object/${bucket}`;

    try {
        const resp = await fetch(url, {
            method:  "DELETE",
            headers: _sbHeaders(sbAnon, token),
            body:    JSON.stringify({ prefixes: [filePath] }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            log("WARN", "SB delete error", `HTTP ${resp.status}: ${filePath}`);
        }
    } catch (err) {
        log("WARN", "SB delete error", String(err));
    }
}

// ─── POLLER – pb_queue tabulka ───────────────────────────────────────────────

/**
 * Stáhne řádky z pb_queue kde done=false pro přihlášeného uživatele.
 * RLS politika zajišťuje izolaci – každý uživatel vidí jen svoje řádky.
 */
async function _getQueue(sbUrl, sbAnon, token) {
    // PostgREST: done=is.null  → done IS NULL
    //            done=eq.false → done = false
    //            done=or=(eq.false,is.null) → done = false OR done IS NULL
    //
    // Filtrujeme oba stavy aby řádky s default NULL nebyly přehlédnuté
    // (původní dotaz s pouze done=eq.false řádky s done IS NULL ignoroval).
    const url = `${sbUrl}/rest/v1/pb_queue`
        + `?or=(done.eq.false,done.is.null)`
        + `&order=id.asc`
        + `&limit=50`;

    const resp = await fetch(url, {
        headers: {
            ..._sbHeaders(sbAnon, token),
            Accept: "application/json",
        },
        timeout: 20_000,
    });
    if (!resp.ok) {
        const err = new Error(`HTTP ${resp.status}`);
        err.status = resp.status;
        throw err;
    }
    return resp.json();
}

/**
 * Označí řádek jako done=true.
 */
async function _markDone(sbUrl, sbAnon, token, rowId) {
    try {
        const resp = await fetch(`${sbUrl}/rest/v1/pb_queue?id=eq.${rowId}`, {
            method:  "PATCH",
            headers: {
                ..._sbHeaders(sbAnon, token),
                Prefer: "return=minimal",
            },
            body:    JSON.stringify({ done: true }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            log("WARN", "SB_POLLER mark_done", `HTTP ${resp.status} pro rowId=${rowId}`);
        }
    } catch (err) {
        log("WARN", "SB_POLLER mark_done", String(err));
    }
}

/**
 * Stáhne soubor ze Storage pomocí tokenu přihlášeného uživatele.
 */
async function _downloadWithToken(sbUrl, sbAnon, token, bucket, filePath) {
    const url = `${sbUrl}/storage/v1/object/${bucket}/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`;
    const resp = await fetch(url, {
        headers: _sbHeaders(sbAnon, token),
        timeout: 30_000,
    });
    if (!resp.ok) throw new Error(`Download HTTP ${resp.status}: ${filePath}`);
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Smaže soubor ze Storage pomocí tokenu přihlášeného uživatele.
 */
async function _deleteWithToken(sbUrl, sbAnon, token, bucket, filePath) {
    try {
        // Supabase Storage bulk-delete endpoint (single path wrapped in array)
        const url  = `${sbUrl}/storage/v1/object/${bucket}`;
        const resp = await fetch(url, {
            method:  "DELETE",
            headers: _sbHeaders(sbAnon, token),
            body:    JSON.stringify({ prefixes: [filePath] }),
            timeout: 8_000,
        });
        if (!resp.ok) {
            log("WARN", "SB_POLLER delete", `HTTP ${resp.status}: ${filePath}`);
        }
    } catch (err) {
        log("WARN", "SB_POLLER delete", String(err));
    }
}
        }
    } catch (err) {
        log("WARN", "SB_POLLER delete", String(err));
    }
}

/**
 * Vrátí unikátní cestu k výstupnímu souboru – přidá _2, _3 … pokud soubor existuje.
 *
 * @param {string} dir
 * @param {string} baseName   – bez přípony
 * @param {string} ext        – včetně tečky, např. ".png"
 */
function _uniquePath(dir, baseName, ext) {
    let out = path.join(dir, `${baseName}${ext}`);
    let n   = 2;
    while (fs.existsSync(out)) {
        out = path.join(dir, `${baseName}_${n}${ext}`);
        n++;
    }
    return out;
}

/**
 * Cesta k paint_temp složce – musí odpovídat paint.js PAINT_TEMP_DIR.
 * Skenuje se zde, aby se _nextLetter započítal i soubory čekající v Paintu.
 */
const _PAINT_TEMP_DIR_FOR_SCAN = path.join(__dirname, "..", "..", "paint_temp");

/**
 * Persistentní počítadlo písmen pro každou kombinaci (job, typ).
 * Klíč: `${typ}|${job}` → poslední použitý charCode.
 * Načítá se ze state.json a ukládá při každé změně, takže přežije restart.
 */
const _letterCounters = new Map();
let _letterCountersLoaded = false;

/**
 * Při prvním volání načte uložené čítače ze state.json (klíč pb_letter_counters).
 */
function _initLetterCountersFromState() {
    if (_letterCountersLoaded) return;
    _letterCountersLoaded = true;
    try {
        const st = loadState();
        const stored = st.pb_letter_counters || {};
        for (const [k, v] of Object.entries(stored)) {
            if (typeof v === "number") _letterCounters.set(k, v);
        }
    } catch { /* nevadí */ }
}

/**
 * Uloží aktuální stav čítačů zpět do state.json.
 */
function _saveLetterCounters() {
    try {
        const st = loadState();
        const out = {};
        for (const [k, v] of _letterCounters.entries()) out[k] = v;
        st.pb_letter_counters = out;
        saveState(st);
    } catch { /* nevadí */ }
}

/**
 * Naskenuje danou složku a vrátí nejvyšší charCode písmena pro daný (job, typ).
 * X (charCode 88) je rezervované pro SD_X (typ=SDX) a ignoruje se.
 * Vrací 64 ('A' - 1) pokud nic nenajde – další písmeno bude tedy A.
 */
function _scanDirForMaxLetter(dir, job, typ) {
    let maxCode = 64;
    try {
        const files = fs.readdirSync(dir);
        const prefix = `${typ}_${job}`;
        for (const f of files) {
            if (!f.startsWith(prefix)) continue;
            const rest = f.slice(prefix.length); // např. "A.png" nebo "B_2.png"
            if (rest.length > 0 && /^[A-Z]/.test(rest)) {
                const code = rest.charCodeAt(0);
                if (code === 88) continue; // přeskoč X (SD_X má vlastní typ)
                if (code > maxCode) maxCode = code;
            }
        }
    } catch { /* složka neexistuje nebo jiná chyba */ }
    return maxCode;
}

/**
 * Vrátí další volné písmeno (A–Z bez X) pro danou kombinaci (job, typ).
 *
 * Strategie:
 *   1. Pokud máme v paměti persistentní counter pro (job, typ), použij ho.
 *   2. Jinak ho inicializuj jako MAX z (saveDir, paint_temp) – tj. zahrnuje
 *      i soubory, které stále čekají v Paint frontě a ještě nejsou v saveDir.
 *   3. Inkrementuj, přeskoč X, při překročení Z se vrať na A
 *      (_uniquePath dál doplní _2, _3 pokud by reálně vznikla kolize).
 *   4. Ulož counter do state.json – přežije restart aplikace pro stejnou zakázku.
 *
 * Tím se opravuje bug, kdy několik fotek SP_/SD_/VT_ rychle za sebou
 * dostalo všechny stejné písmeno A a přepsaly se navzájem.
 */
function _nextLetter(saveDir, job, typ) {
    _initLetterCountersFromState();
    const key = `${typ}|${job}`;
    let last = _letterCounters.get(key);

    if (last == null) {
        // První soubor pro tento (job, typ) – inicializuj scanováním obou složek
        const codeSave  = _scanDirForMaxLetter(saveDir, job, typ);
        const codePaint = _scanDirForMaxLetter(_PAINT_TEMP_DIR_FOR_SCAN, job, typ);
        last = Math.max(codeSave, codePaint, 64); // 64 = 'A' - 1
    }

    // Inkrementuj na další písmeno, přeskoč X
    let next = last + 1;
    if (next === 88) next = 89; // X (88) → Y (89)
    if (next > 90)   next = 65; // za Z (90) zpět na A (65)

    _letterCounters.set(key, next);
    _saveLetterCounters();

    return String.fromCharCode(next);
}

/**
 * Převede buffer (libovolný obrázek) na PNG Buffer pomocí sharp.
 * @param {Buffer} raw
 * @returns {Promise<Buffer>}
 */
async function _toPng(raw) {
    return sharp(raw).png().toBuffer();
}

/**
 * Zmenší PNG pokud přesahuje maxMb megabajtů.
 * Iterativně snižuje kvalitu/rozlišení dokud soubor nepasuje.
 *
 * @param {Buffer} pngBuf
 * @param {number} maxMb
 * @returns {Promise<Buffer>}
 */
async function _shrinkPng(pngBuf, maxMb) {
    const maxBytes = maxMb * 1024 * 1024;
    if (pngBuf.length <= maxBytes) return pngBuf;

    let img    = sharp(pngBuf);
    const meta = await img.metadata();
    let w      = meta.width  || 4000;
    let h      = meta.height || 3000;

    // Postupně zmenšuj o 20 % dokud nepasuje nebo šířka < 800 px
    while (true) {
        w = Math.floor(w * 0.8);
        h = Math.floor(h * 0.8);
        const buf = await sharp(pngBuf).resize(w, h, { fit: "inside" }).png().toBuffer();
        if (buf.length <= maxBytes || w < 800) return buf;
        pngBuf = buf; // zkus menší
    }
}

/**
 * Extrahuje sortovací klíč z názvu souboru, aby fronta zpracování zachovala
 * pořadí cvaknutí spouště v mobilu i při paralelních uploadech.
 *
 * Mobil generuje názvy:
 *   firemní:  "SP_4567895_1777903239672_001.jpg"
 *               typ_zakázka_batchTs_seq.ext
 *   osobní:   "20260504_135938_001.jpg"
 *               YYYYMMDD_HHMMSS_seq.ext
 *
 * Sort key = batchTs * 1000 + seq pro firemní; YYYYMMDDHHMMSS * 1000 + seq pro osobní.
 * Pro starší soubory bez _seq vrací prostě timestamp.
 */
function _sortKeyFromFilePath(filePath) {
    const name = (filePath || "").split("/").pop();
    const dotIdx = name.lastIndexOf(".");
    const base = dotIdx >= 0 ? name.slice(0, dotIdx) : name;
    // Strip _PAINT suffix
    const cleanBase = base.replace(/_PAINT$/, "");
    const parts = cleanBase.split("_");
    if (parts.length === 0) return 0;

    // Poslední část by měla být _seq (3 číslice)
    const last = parts[parts.length - 1];
    let seq = 0;
    let tsPart = cleanBase;
    if (/^\d{1,3}$/.test(last)) {
        seq = parseInt(last, 10);
        tsPart = parts.slice(0, -1).join("_");
    }
    // Najdi numerickou složku (timestamp)
    const tsMatches = tsPart.match(/(\d{10,})/);
    if (tsMatches) {
        return parseInt(tsMatches[1], 10) * 1000 + seq;
    }
    // Fallback: osobní formát YYYYMMDD_HHMMSS
    const dateMatches = tsPart.match(/(\d{8})_(\d{6})/);
    if (dateMatches) {
        return parseInt(dateMatches[1] + dateMatches[2], 10) * 1000 + seq;
    }
    return 0;
}

/**
 * Přidá soubor do fronty zpracování. Spustí processor pokud neběží.
 * Cfg/saveDir/sbCtx/tok jsou potřeba, použijeme je až ve worker funkci.
 */
function _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId) {
    if (!filePath || _pollerSeen.has(filePath)) {
        // Už zpracováno nebo právě ve frontě – jen markDone
        if (rowId) {
            sbEnsureToken(cfg).then(tok => {
                if (tok) _markDone(sbUrl, sbAnon, tok, rowId).catch(() => {});
            }).catch(() => {});
        }
        return;
    }
    _pollerSeen.add(filePath);
    _processQueue.push({ cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId });
    // Seřaď podle sortKey – starší (menší) první. Tím SP_xxx_1234_001 dostane
    // písmeno A, SP_xxx_1234_002 písmeno B, atd. Funguje i pro mix batchů.
    _processQueue.sort((a, b) => _sortKeyFromFilePath(a.filePath) - _sortKeyFromFilePath(b.filePath));
    _runProcessQueue();
}

/**
 * Worker, který sériově zpracuje jeden soubor po druhém z _processQueue.
 * Zaručuje:
 *   - správné pořadí písmen (_nextLetter dostane volání postupně)
 *   - sériové otevírání Malování (paint-window otevírá max 1 instance)
 */
async function _runProcessQueue() {
    if (_processRunning) return;
    _processRunning = true;
    try {
        while (_processQueue.length > 0 && _pollerActive) {
            const job = _processQueue.shift();
            const tok = await sbEnsureToken(job.cfg);
            if (!tok) {
                // Token expirovaný – vrať položku zpět a počkej na další tick
                _processQueue.unshift(job);
                _pollerSeen.delete(job.filePath);
                break;
            }
            try {
                await _processFilePath(
                    job.cfg, job.saveDir, job.sbUrl, job.sbAnon, tok, job.sbBucket,
                    job.filePath, job.rowId,
                );
            } catch (err) {
                log("ERROR", "SB_QUEUE process", `${job.filePath}: ${err}`);
            }
        }
    } finally {
        _processRunning = false;
    }
}

/**
 * Hlavní smyčka polleru – volaná přes setInterval.
 * Stahuje VŠE pro přihlášený účet:
 *   1. Primárně z pb_queue tabulky (rychlé, přesné)
 *   2. Každých 10 ticků fallback scan Storage (řeší selhané pb_queue inserty)
 */
async function _pollerTick(cfg, saveDir) {
    if (!_pollerActive) return;

    const sbUrl    = _sbUrl(cfg);
    const sbAnon   = (cfg.SB_ANON    || "").trim();
    const sbBucket = (cfg.SB_BUCKET  || "pb-uploads").trim();

    try {
        // Obnov token pokud expiroval
        const tok = await sbEnsureToken(cfg);
        if (!tok) return;

        // ── 1) Primární cesta: pb_queue ─────────────────────────────────────
        let rows;
        try {
            rows = await _getQueue(sbUrl, sbAnon, tok);
        } catch (err) {
            if (err.status === 401 || err.status === 403) {
                log("WARN", "SB_POLLER", `HTTP ${err.status} z pb_queue – čistím token`);
                STATE.sbAccessToken = "";
            } else if (String(err).includes("timeout") || String(err).includes("network")) {
                log("DEBUG", "SB_POLLER", `queue timeout (${String(err).split("\n")[0]})`);
            } else {
                log("WARN", "SB_POLLER queue error", String(err));
            }
            // i když pb_queue selže, zkus alespoň fallback scan níže
            rows = [];
        }

        for (const row of rows) {
            if (!_pollerActive) break;
            const rowId    = row.id;
            const filePath = row.file_path || "";
            // Místo přímého _processFilePath dáme do fronty – worker zpracuje
            // sériově a v pořadí podle sortKey (zachová pořadí cvaknutí spouště).
            _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId);
        }

        // ── 2) Fallback Storage scan – každých ~10 ticků ───────────────────
        // Při 2s pollingu (Realtime aktivní) = 20 s; při 1s pollingu = 10 s.
        // Pokrývá scénář kdy Realtime tiše vypadl mezi heartbeaty, nebo když
        // mobil úspěšně nahrál ale pb_queue insert selhal.
        _pollerTickCount = (_pollerTickCount + 1) % 10;
        if (_pollerTickCount === 0) {
            await _fallbackStorageScan(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket);
        }

    } catch (err) {
        log("WARN", "SB_POLLER loop error", String(err));
    }
}

/**
 * Fallback: naskenuje Storage bucket a najde soubory které nejsou v _pollerSeen.
 * Volá se každých 10 ticků (≈5 s). Řeší scénář kdy pb_queue insert na mobilu
 * selhal a soubor zůstal v Storage osamocený.
 *
 * Skenuje:
 *   - personal/  složku (osobní fotky)
 *   - všechny {číslo zakázky}/  složky
 */
async function _fallbackStorageScan(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket) {
    try {
        const userId = STATE.sbUserId || "";

        // 1) Vylistuj kořen bucketu – dostaneme všechny složky (NOVÝ formát:
        //    pouze {user_id}, STARÝ formát: jobs + personal). Storage RLS nás
        //    omezí jen na naše soubory tak jako tak, ale listing kořene vrátí
        //    všechny vlastníkovy složky.
        //
        //    Když ale máme user_id, můžeme rovnou listovat {user_id}/ a získat
        //    seznam podsložek (personal, 1234567, …) – efektivnější.
        const folderNames = [];

        if (userId) {
            // NOVÝ formát: vylistuj {user_id}/ a získej podsložky
            const myResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon, tok),
                body:    JSON.stringify({ prefix: `${userId}/`, limit: 200, offset: 0 }),
                timeout: 8_000,
                agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
            });
            if (myResp.ok) {
                const items = await myResp.json();
                if (Array.isArray(items)) {
                    for (const it of items) {
                        if (it && it.name && (it.id === null || it.id === undefined)) {
                            folderNames.push(`${userId}/${it.name}`);
                        }
                    }
                }
            }
        }

        // 2) Také zkusíme STARÝ formát (kořen bucketu) – Storage RLS odfiltruje
        //    cizí soubory; vlastní staré soubory ještě nahnijí dokud RETENTION_DAYS
        //    je nesmažo.
        const rootListResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
            method:  "POST",
            headers: _sbHeaders(sbAnon, tok),
            body:    JSON.stringify({ prefix: "", limit: 200, offset: 0 }),
            timeout: 8_000,
            agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
        });
        if (rootListResp.ok) {
            const rootItems = await rootListResp.json();
            if (Array.isArray(rootItems)) {
                for (const it of rootItems) {
                    if (it && it.name && (it.id === null || it.id === undefined)) {
                        // Vyloučíme {user_id} (už jsme listovali výše) – aby
                        // se neopakovalo pod novým formátem
                        if (it.name !== userId) {
                            folderNames.push(it.name);
                        }
                    }
                }
            }
        }

        if (folderNames.length === 0) return;

        let foundCount = 0;
        for (const folder of folderNames) {
            if (!_pollerActive) break;

            // Vylistuj obsah složky
            const folderResp = await fetch(`${sbUrl}/storage/v1/object/list/${sbBucket}`, {
                method:  "POST",
                headers: _sbHeaders(sbAnon, tok),
                body:    JSON.stringify({ prefix: `${folder}/`, limit: 100, offset: 0 }),
                timeout: 8_000,
                agent:   sbUrl.startsWith("https") ? _pollAgent : undefined,
            });
            if (!folderResp.ok) continue;
            const items = await folderResp.json();
            if (!Array.isArray(items)) continue;

            for (const it of items) {
                if (!_pollerActive) break;
                // Jen reálné soubory (id !== null), s názvem
                if (!it || !it.name || it.id === null || it.id === undefined) continue;
                const filePath = `${folder}/${it.name}`;
                if (_pollerSeen.has(filePath)) continue;

                log("INFO", "SB_POLLER fallback found", `${filePath} (chybí v pb_queue)`);
                foundCount++;
                // Zpracuj přes frontu (rowId=null = nemažeme z queue, jen ze Storage)
                _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, null);
            }
        }

        if (foundCount > 0) {
            log("INFO", "SB_POLLER fallback scan", `zpracováno ${foundCount} souborů ze Storage`);
        }
    } catch (err) {
        log("DEBUG", "SB_POLLER fallback scan err", String(err));
    }
}

/**
 * Zpracuje jeden filePath ze Supabase Storage – stáhne, přejmenuje, uloží,
 * smaže ze Storage a (pokud byl z pb_queue) označí řádek jako done.
 *
 * @param {string|null} rowId  – id řádku v pb_queue, nebo null pokud přišlo z fallback scanu
 */
async function _processFilePath(cfg, saveDir, sbUrl, sbAnon, tok, sbBucket, filePath, rowId) {
    _pollerSeen.add(filePath);
    const maxImgMb = STATE.maxImgMb || 8;

    // ── Rozpoznání path schema ──────────────────────────────────────────
    // NOVÝ formát (Cesta 1):  {user_id}/personal/{name}        nebo  {user_id}/{job}/{name}
    // STARÝ formát (Cesta 2): personal/{name}                  nebo  {job}/{name}
    //
    // Detekce: pokud první segment vypadá jako UUID (36 znaků s pomlčkami),
    // jde o nový formát a první segment přeskočíme. Jinak starý formát.
    const segments = filePath.split("/");
    let workPath = filePath;
    const UUID_RE = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    if (segments.length >= 2 && UUID_RE.test(segments[0])) {
        // Odstraň user_id prefix – zbytek logiky pracuje s "logickou" cestou
        // (personal/... nebo {job}/...) a nezáleží na nové vrstvě bezpečnosti.
        workPath = segments.slice(1).join("/");
    }

    const isPersonal = workPath.startsWith("personal/");
    const name       = workPath.split("/").pop();
    const dotIdx     = name.lastIndexOf(".");
    const extOrig    = dotIdx >= 0 ? name.slice(dotIdx).toLowerCase() : ".jpg";
    const base       = dotIdx >= 0 ? name.slice(0, dotIdx) : name;

    log("INFO", "SB_POLLER process", `${filePath} personal=${isPersonal} src=${rowId ? "queue" : "storage-scan"}`);

    // Stáhni soubor
    let raw;
    try {
        raw = await _downloadWithToken(sbUrl, sbAnon, tok, sbBucket, filePath);
    } catch (err) {
        log("ERROR", "SB_POLLER download", String(err));
        _pollerSeen.delete(filePath);
        return;
    }

    // wentToPaint = soubor putuje do Malování (uživatel ho dotvoří) → notifikaci
    // pošleme až po zavření Malování (paint.js to udělá), NE teď.
    let outPath;
    let wentToPaint = false;

    try {
        fs.mkdirSync(saveDir, { recursive: true });

        if (isPersonal) {
            // ── Osobní účet: uložit přímo s původním názvem (datum_čas) ──
            const isVideo = [".mp4", ".mov", ".avi", ".mkv", ".webm"].includes(extOrig);
            const isPdf   = extOrig === ".pdf";

            if (isVideo || isPdf) {
                outPath = _uniquePath(saveDir, base, extOrig);
                fs.writeFileSync(outPath, raw);
            } else {
                outPath = _uniquePath(saveDir, base, ".png");
                let png = await _toPng(raw);
                png     = await _shrinkPng(png, maxImgMb);
                fs.writeFileSync(outPath, png);
            }
            log("INFO", "SB_POLLER saved (personal)", path.basename(outPath));

        } else {
            // ── Firemní účet: extrahuj job z cesty, přejmenuj, zpracuj paint ──
            const job   = workPath.split("/")[0] || "";
            const parts = base.split("_");
            const typ   = (parts[0] || "SP").toUpperCase();
            const openPaint = base.includes("_PAINT");

            const isVideo = [".mp4", ".mov", ".avi", ".mkv", ".webm"].includes(extOrig);
            const isPdf   = extOrig === ".pdf";

            if (isVideo || isPdf) {
                if (typ === "SN") {
                    outPath = _uniquePath(saveDir, `SN_${job}`, extOrig);
                } else if (typ === "SDX") {
                    outPath = _uniquePath(saveDir, `SD_${job}X`, extOrig);
                } else {
                    const letter = _nextLetter(saveDir, job, typ);
                    outPath = _uniquePath(saveDir, `${typ}_${job}${letter}`, extOrig);
                }
                fs.writeFileSync(outPath, raw);
                log("INFO", "SB_POLLER saved", path.basename(outPath));

            } else {
                if (typ === "SDX") {
                    outPath = _uniquePath(saveDir, `SD_${job}X`, ".png");
                } else if (typ === "SN") {
                    outPath = _uniquePath(saveDir, `SN_${job}`, ".png");
                } else {
                    const letter = _nextLetter(saveDir, job, typ);
                    outPath = _uniquePath(saveDir, `${typ}_${job}${letter}`, ".png");
                }

                let png = await _toPng(raw);
                png     = await _shrinkPng(png, maxImgMb);

                const willPaint = (typ === "SP") ||
                    (openPaint && ["SD", "SDX", "VT", "SN"].includes(typ));

                if (willPaint) {
                    await _savePaintTemp(outPath, png);
                    wentToPaint = true;
                } else {
                    fs.writeFileSync(outPath, png);
                }
                log("INFO", "SB_POLLER saved+paint",
                    `${path.basename(outPath)} paint=${willPaint}`);
            }
        }

        // Potvrdit zpracování a smazat ze Storage
        if (rowId) {
            await _markDone(sbUrl, sbAnon, tok, rowId);
        }
        await _deleteWithToken(sbUrl, sbAnon, tok, sbBucket, filePath);

        // Oznámit renderu nový soubor
        _notifyRenderer(outPath);

        // Windows notifikace – jen pro soubory, které NEJDOU do Malování.
        // Soubory v Malování dostanou notifikaci až po zavření paint.js.
        // Notifikace jsou batched: pokud přijde víc fotek během 1.5 s,
        // zobrazí se jedna souhrnná („Nahrány 3 soubory: ...").
        if (!wentToPaint && outPath) {
            _enqueueNotification(outPath);
        }

    } catch (err) {
        log("ERROR", "SB_POLLER process", `${filePath}: ${err}`);
    }
}

/**
 * Uloží PNG do dočasné Paint složky (sleduje ji paint.js).
 * Pokud paint.js není k dispozici, uloží soubor přímo.
 *
 * @param {string} finalPath  – konečná cesta (bez přípony _tmp)
 * @param {Buffer} png
 */
async function _savePaintTemp(finalPath, png) {
    try {
        // Zkus delegovat na paint.js pokud je načtený
        const paint = require("./paint");
        if (typeof paint.createPaintTempCopy === "function") {
            return paint.createPaintTempCopy(finalPath, png);
        }
    } catch { /* paint.js ještě neexistuje nebo chyba */ }
    // Fallback – ulož přímo
    fs.writeFileSync(finalPath, png);
}

/**
 * Odešle IPC event renderu že byl přijat/uložen nový soubor.
 * Pokud renderer okno není k dispozici, tiše ignoruje.
 *
 * @param {string} filePath
 */
function _notifyRenderer(filePath) {
    try {
        const { BrowserWindow } = require("electron");
        const wins = BrowserWindow.getAllWindows();
        for (const win of wins) {
            if (!win.isDestroyed()) {
                win.webContents.send("supabase:file-received", { path: filePath });
            }
        }
    } catch { /* nevadí */ }
}

// ─── Windows notifikace pro stažené soubory ───────────────────────────────────
// Když přijde najednou víc fotek, batchujeme je do jedné notifikace s celým
// seznamem. Přijde-li další fotka v krátké pauze (1.5 s), STARÁ notifikace
// se ZAVŘE a okamžitě se otevře NOVÁ s rozšířeným seznamem – vizuálně to
// vypadá jako že se „přidává řádek do otevřené notifikace".
//
// Reset notifikací po Windows „auto-hide" (~5 s) – další upload pak začne
// nový batch (nová notifikace).
let _notifyBatch     = [];           // názvy souborů v aktuálním batchi
let _notifyTimer     = null;         // debounce timer pro zobrazení
let _notifyResetTimer = null;        // po 6 s ticha vyresetuj batch (nový soubor = nová notifikace)
let _lastNotification = null;         // reference na poslední Notification instance (pro close)
const NOTIFY_DEBOUNCE_MS = 1500;
const NOTIFY_RESET_MS    = 6000;     // o trochu déle než výchozí Windows zobrazení (~5 s)

/**
 * Zařadí stažený soubor do fronty. Po 1.5 s ticha se zobrazí jedna souhrnná
 * Windows toast notifikace se seznamem všech přijatých souborů.
 *
 * Soubory které jdou do Malování (SP / *_PAINT) se NEvolají – jejich
 * notifikace přijde až po zavření Malování (řeší paint.js).
 */
function _enqueueNotification(filePath) {
    if (!filePath) return;

    // Respektuj NOTIFY_ENABLED v configu
    try {
        const cfg = require("./config").readConfig();
        if (String(cfg.NOTIFY_ENABLED || "true").toLowerCase() === "false") return;
    } catch { /* nevadí */ }

    const name = path.basename(filePath);
    _notifyBatch.push(name);

    if (_notifyTimer) clearTimeout(_notifyTimer);
    if (_notifyResetTimer) clearTimeout(_notifyResetTimer);

    _notifyTimer = setTimeout(() => {
        _notifyTimer = null;
        _showWindowsNotification(_notifyBatch.slice());

        // Po 6 s ticha vyresetuj batch – další upload startuje novou notifikaci
        _notifyResetTimer = setTimeout(() => {
            _notifyBatch = [];
            _notifyResetTimer = null;
            _lastNotification = null;
        }, NOTIFY_RESET_MS);
    }, NOTIFY_DEBOUNCE_MS);
}

/**
 * Zobrazí Windows toast s aktuálním seznamem souborů.
 * Pokud již nějaká notifikace visí na obrazovce, ZAVŘE ji a okamžitě
 * zobrazí novou s aktualizovaným obsahem.
 *
 * Délku zobrazení řídí Windows (System → Notifications), my ji neovlivníme.
 * Křížek pro zavření má notifikace nativně.
 */
function _showWindowsNotification(filenames) {
    if (!filenames || filenames.length === 0) return;
    try {
        const { Notification } = require("electron");
        if (!Notification.isSupported()) {
            log("DEBUG", "SB_NOTIFY", "Notification API není v této platformě podporováno");
            return;
        }

        // Zavři předchozí notifikaci aby se nová mohla okamžitě zobrazit
        // s aktualizovaným seznamem (vypadá to jako přidání řádku).
        if (_lastNotification) {
            try { _lastNotification.close(); } catch (_) {}
            _lastNotification = null;
        }

        const count = filenames.length;
        const title = count === 1
            ? "PhotoBridge – Nahrán soubor"
            : `PhotoBridge – Nahráno ${count} souborů`;

        // Body: max 5 řádků, zbytek shrnout jako „… +N dalších"
        let body;
        if (count <= 5) {
            body = filenames.join("\n");
        } else {
            body = filenames.slice(0, 4).join("\n") + `\n… +${count - 4} dalších`;
        }

        const notif = new Notification({
            title,
            body,
            silent: false,   // přehrát standardní Windows zvuk
        });
        notif.show();
        _lastNotification = notif;

        log("INFO", "SB_NOTIFY shown", `${count} files: ${filenames.slice(0, 3).join(", ")}${count > 3 ? "..." : ""}`);
    } catch (err) {
        log("WARN", "SB_NOTIFY error", String(err));
    }
}

/**
 * Veřejná funkce – paint.js ji volá po zavření Malování (po dokončení uživatelem).
 * Tím se notifikace zobrazí i pro SP fotky / _PAINT fotky.
 */
function notifyFileReceived(filePath) {
    _enqueueNotification(filePath);
}

/**
 * Veřejná funkce pro test tlačítko v Nastavení.
 * Zobrazí ukázkovou notifikaci s 3 fiktivními soubory.
 */
function showTestNotification() {
    _showWindowsNotification([
        "SP_4567895A.png",
        "SD_4567895A.png",
        "VT_4567895A.png",
    ]);
}

/**
 * Smaže záznamy starší N dní z pb_queue a Storage.
 * Volá se při každém startu polleru.
 */
async function _cleanupExpiredEntries(sbUrl, sbAnon, token, sbBucket, retentionDays = 7) {
    try {
        const days = Math.max(1, parseInt(retentionDays, 10) || 7);
        const weekAgo = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
        const url = `${sbUrl}/rest/v1/pb_queue`
            + `?done=eq.false`
            + `&created_at=lt.${encodeURIComponent(weekAgo)}`
            + `&select=id,file_path`;
        const resp = await fetch(url, {
            headers: { ..._sbHeaders(sbAnon, token), Accept: "application/json" },
            timeout: 8_000,
        });
        if (!resp.ok) return;
        const rows = await resp.json();
        if (!Array.isArray(rows) || !rows.length) return;
        for (const row of rows) {
            await _markDone(sbUrl, sbAnon, token, row.id);
            if (row.file_path) {
                await _deleteWithToken(sbUrl, sbAnon, token, sbBucket, row.file_path);
            }
        }
        log("INFO", "SB_POLLER cleanup", `Smazáno ${rows.length} expirovaných záznamů (>${days} dní)`);
    } catch (err) {
        log("WARN", "SB_POLLER cleanup", String(err));
    }
}

// ─── PUBLIC API POLLERU ──────────────────────────────────────────────────────

/**
 * Spustí Supabase poller. Zastaví předchozí pokud běžel.
 * Stahuje VŠE pro přihlášený účet (Varianta A) – RLS izoluje uživatele.
 *
 * @param {object} cfg       – konfigurace
 * @param {string} saveDir   – cílová složka pro ukládání fotek
 */
function startSbPoller(cfg, saveDir) {
    stopSbPoller(); // zastav předchozí běh

    _pollerSeen   = new Set();

    const sbUrl    = _sbUrl(cfg);
    const sbAnon   = (cfg.SB_ANON || "").trim();
    const sbBucket = (cfg.SB_BUCKET || "pb-uploads").trim();

    if (!sbUrl || !sbAnon) {
        log("WARN", "SB_POLLER", "Chybí SB_URL nebo SB_ANON v konfiguraci");
        _broadcastPollerStatus(false);
        return;
    }
    if (!saveDir) {
        log("WARN", "SB_POLLER", "Chybí SAVE_DIR – poller se nespustil");
        _broadcastPollerStatus(false);
        return;
    }

    // Načti uložené čítače písmen ze state.json
    _initLetterCountersFromState();

    // Označ jako "spouští se" – až po úspěšném získání tokenu pošleme true
    _pollerActive = true;

    // Úvodní přihlášení před startem smyčky
    sbEnsureToken(cfg).then(async (tok) => {
        if (!tok) {
            log("WARN", "SB_POLLER", "Nelze se přihlásit – přihlas se znovu");
            _pollerActive = false;
            _broadcastPollerStatus(false);
            return;
        }

        // Vyčisti expirované záznamy při každém startu (dle RETENTION_DAYS)
        await _cleanupExpiredEntries(sbUrl, sbAnon, tok, sbBucket, cfg.RETENTION_DAYS);

        log("INFO", "SB_POLLER started", `bucket=${sbBucket} saveDir=${saveDir}`);

        // Polling jako pojistka. Začínáme rychle (1 s), Realtime to po připojení
        // zpomalí na 5 s (zpomalení provede _startRealtime po úspěšném subscribe).
        _pollerTimer = setInterval(() => _pollerTick(cfg, saveDir), 1000);

        // Spusť Realtime websocket – pokud Supabase má zapnutou Realtime
        // publication na pb_queue, dostaneme INSERT eventy s <100 ms latencí.
        _startRealtime(cfg, saveDir);

        // Až teď oznam rendereru, že příjem skutečně běží
        _broadcastPollerStatus(true);
    });
}

/**
 * Připojí se na Supabase Realtime websocket a subscribuje INSERT eventy
 * z tabulky pb_queue. Když přijde event, soubor se okamžitě přidá do fronty
 * (žádné čekání na další polling tick).
 *
 * Pokud připojení selže nebo Realtime není zapnutý na pb_queue, polling
 * (1 s) zachytí všechno – jen pomaleji. Po úspěšném připojení se polling
 * zpomalí na 5 s aby šetřil traffic.
 */
function _startRealtime(cfg, saveDir) {
    _stopRealtime(); // zruš případné předchozí spojení

    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    if (!sbUrl || !sbAnon) return;

    // Standardní Node.js global WebSocket (Node 22+, Electron 32+).
    // Pokud není dostupný, polling zůstane primárním kanálem.
    const WS = (typeof globalThis.WebSocket === "function") ? globalThis.WebSocket : null;
    if (!WS) {
        log("INFO", "SB_REALTIME", "WebSocket není dostupný v této verzi Node – jen polling");
        return;
    }

    // Realtime URL (Supabase Phoenix websocket)
    const wsUrl = sbUrl.replace(/^http/, "ws") + `/realtime/v1/websocket?apikey=${encodeURIComponent(sbAnon)}&vsn=1.0.0`;

    let socket;
    try {
        socket = new WS(wsUrl);
    } catch (err) {
        log("WARN", "SB_REALTIME connect", String(err));
        _scheduleRealtimeReconnect(cfg, saveDir);
        return;
    }
    _rtSocket = socket;

    socket.onopen = async () => {
        log("INFO", "SB_REALTIME", "websocket otevřen, subscribuji pb_queue INSERT");
        // Subscribe message – Phoenix protocol
        const tok = await sbEnsureToken(cfg).catch(() => null);
        const subscribeMsg = {
            topic:   "realtime:public:pb_queue",
            event:   "phx_join",
            payload: {
                config: {
                    postgres_changes: [
                        { event: "INSERT", schema: "public", table: "pb_queue" }
                    ],
                },
                access_token: tok || sbAnon,
            },
            ref: String(++_rtRef),
        };
        try { socket.send(JSON.stringify(subscribeMsg)); } catch (_) {}

        // Heartbeat každých 25 s (Supabase má 30 s timeout)
        // Hlídáme že Supabase odpovídá – pokud 2× po sobě neodpoví, websocket
        // je mrtvý i když readyState ještě říká OPEN. Zavřeme a reconnect.
        _rtHeartbeatSent = 0;
        _rtHeartbeat = setInterval(() => {
            if (!_rtSocket || _rtSocket.readyState !== 1) return;

            // Pokud je _rtHeartbeatSent >= 2, znamená že 2 předchozí heartbeaty
            // nebyly potvrzeny serverem → websocket je tichý/mrtvý
            if (_rtHeartbeatSent >= 2) {
                log("WARN", "SB_REALTIME", "heartbeat timeout – nucený reconnect");
                try { _rtSocket.close(); } catch (_) {}
                // onclose handler nás restartuje
                return;
            }

            try {
                const ref = String(++_rtRef);
                _rtLastHeartbeatRef = ref;
                _rtSocket.send(JSON.stringify({
                    topic: "phoenix", event: "heartbeat", payload: {}, ref,
                }));
                _rtHeartbeatSent++;
            } catch (_) {}
        }, 25_000);
    };

    socket.onmessage = (evt) => {
        let msg;
        try { msg = JSON.parse(evt.data); } catch { return; }
        if (!msg) return;

        // Heartbeat reply – Supabase odpověděl, jsme živí
        if (msg.event === "phx_reply" && msg.ref === _rtLastHeartbeatRef) {
            _rtHeartbeatSent = 0;
        }

        // Subscribe potvrzeno → zpomal polling, šetří síť (ale ne příliš –
        // pokud Realtime tiše vypadne, polling musí brzo chytit)
        if (msg.event === "phx_reply" && msg.payload && msg.payload.status === "ok") {
            if (!_rtConnected) {
                _rtConnected = true;
                log("INFO", "SB_REALTIME", "subscribe OK – polling 2s");
                if (_pollerTimer) {
                    clearInterval(_pollerTimer);
                    _pollerTimer = setInterval(() => _pollerTick(cfg, saveDir), 2_000);
                }
            }
        }

        // INSERT event → okamžitě stáhni soubor
        if (msg.event === "postgres_changes" && msg.payload) {
            const data = msg.payload.data || msg.payload;
            const rec  = data.record || data.new || {};
            const filePath = rec.file_path;
            const rowId    = rec.id;
            if (filePath) {
                const sbBucket = (cfg.SB_BUCKET || "pb-uploads").trim();
                log("INFO", "SB_REALTIME insert", filePath);
                _enqueueFilePath(cfg, saveDir, sbUrl, sbAnon, sbBucket, filePath, rowId);
            }
        }
    };

    socket.onerror = (err) => {
        log("DEBUG", "SB_REALTIME error", String(err && err.message || err));
    };

    socket.onclose = () => {
        if (_rtConnected) log("INFO", "SB_REALTIME", "websocket zavřen");
        _rtConnected = false;
        _rtHeartbeatSent = 0;
        if (_rtHeartbeat) { clearInterval(_rtHeartbeat); _rtHeartbeat = null; }
        // Zrychli polling zpět na 1 s dokud websocket nebude zase připojen
        if (_pollerTimer && _pollerActive) {
            clearInterval(_pollerTimer);
            _pollerTimer = setInterval(() => _pollerTick(cfg, saveDir), 1000);
        }
        if (_pollerActive) _scheduleRealtimeReconnect(cfg, saveDir);
    };
}

/**
 * Naplánuje reconnect Realtime websocketu za 10 s (s jitterem).
 */
function _scheduleRealtimeReconnect(cfg, saveDir) {
    if (_rtReconnect) return;
    const delay = 10_000 + Math.floor(Math.random() * 5_000);
    _rtReconnect = setTimeout(() => {
        _rtReconnect = null;
        if (_pollerActive) _startRealtime(cfg, saveDir);
    }, delay);
}

/**
 * Zavře Realtime websocket a vyčistí timery.
 */
function _stopRealtime() {
    if (_rtHeartbeat) { clearInterval(_rtHeartbeat); _rtHeartbeat = null; }
    if (_rtReconnect) { clearTimeout(_rtReconnect);  _rtReconnect = null; }
    if (_rtSocket) {
        try { _rtSocket.close(); } catch (_) {}
        _rtSocket = null;
    }
    _rtConnected = false;
}

/**
 * Zastaví Supabase poller. Po dokončení by neměl zůstat žádný timer,
 * websocket ani neuvolněné TCP sockety – aby další login byl rychlý.
 */
function stopSbPoller() {
    const wasActive = _pollerActive;
    _pollerActive = false;
    _stopRealtime();
    if (_pollerTimer !== null) {
        clearInterval(_pollerTimer);
        _pollerTimer = null;
        log("INFO", "SB_POLLER stopped", "");
    }
    // Násilně uzavři všechny keepAlive sockety v poll/auth agentech.
    // Bez toho by Node.js držel TCP connection na Supabase ještě desítky
    // sekund a další fetch by čekal ve frontě (= „login trvá dlouho").
    try { _pollAgent.destroy(); } catch (_) {}
    try { _authAgent.destroy(); } catch (_) {}
    if (wasActive) _broadcastPollerStatus(false);
}

/**
 * Vrátí true pokud poller skutečně běží (timer aktivní + token načten).
 */
function isSbPollerRunning() {
    return _pollerActive && _pollerTimer !== null;
}

/**
 * Pošle všem oknům aktuální stav polleru.
 */
function _broadcastPollerStatus(running) {
    try {
        const { BrowserWindow } = require("electron");
        for (const win of BrowserWindow.getAllWindows()) {
            if (!win.isDestroyed()) {
                win.webContents.send("poller:status", { job: running ? "auto" : null, running });
            }
        }
    } catch { /* nevadí */ }
}


// ─── OBNOVENÍ SESSION PO RESTARTU ────────────────────────────────────────────

/**
 * Načte uloženou session (refresh token + email) ze state.json a obnoví ji.
 * Volat z main.js hned po app.ready – UI pak správně ukáže přihlášeného technika.
 *
 * Odhlášení propadne POUZE pokud:
 *  - Refresh token vypršel na serveru Supabase (výchozí: velmi dlouhá platnost)
 *  - Technik klikl Odhlásit
 *
 * NIKDY se odhlášení nedeje automaticky jinak.
 *
 * @param {object} cfg  – konfigurace z config.readConfig()
 * @returns {Promise<boolean>}  true = session obnovena, false = není co obnovit
 */
async function sbRestoreSession(cfg) {
    try {
        const st = loadState();
        if (!st.sb_refresh) {
            return false; // Žádná uložená session
        }

        // Obnov email pro UI (i před obnovením tokenu)
        if (st.sb_email && !STATE.sbEmail) {
            STATE.sbEmail = st.sb_email;
        }

        // Obnov account_type
        if (st.sb_account_type && !STATE.sbAccountType) {
            STATE.sbAccountType = st.sb_account_type;
        }

        // Načti refresh token do STATE pokud tam ještě není
        if (!STATE.sbRefreshToken) {
            STATE.sbRefreshToken = st.sb_refresh;
        }

        // Zkus obnovit access token
        const tok = await sbEnsureToken(cfg);
        if (tok) {
            log('INFO', 'SB_AUTH', `Session obnovena po restartu – user=${STATE.sbEmail || '?'}`);
            // Uprav sbEmail pokud sbEnsureToken provedl re-login
            if (!STATE.sbEmail && st.sb_email) STATE.sbEmail = st.sb_email;
            return true;
        }

        // Refresh token propadl – ale NEODHLAŠUJEME automaticky.
        // Zachováme sbEmail pro UI (ukáže "přihlášen jako X, token vypršel")
        // Technik musí zadat heslo znovu ručně.
        log('WARN', 'SB_AUTH', 'Refresh token propadl – je potřeba ruční přihlášení');
        STATE.sbEmail = st.sb_email || STATE.sbEmail; // zachovat email pro UI
        return false;

    } catch (err) {
        log('WARN', 'SB_AUTH sbRestoreSession', String(err));
        return false;
    }
}

// ─── PŘEHLED NESTAŽENÝCH ZAKÁZEK ─────────────────────────────────────────────

/**
 * Vrátí seznam zakázek, které mají v pb_queue řádky s done=false.
 * Výsledek je seřazený seznam { job, count, newestAt } bez duplicit.
 *
 * @param {object} cfg
 * @returns {Promise<Array<{job:string, count:number, newestAt:string|null}>>}
 */
async function sbGetPendingJobs(cfg) {
    const sbUrl  = _sbUrl(cfg);
    const sbAnon = (cfg.SB_ANON || "").trim();
    if (!sbUrl || !sbAnon) throw new Error("Chybí konfigurace Supabase (SB_URL / SB_ANON).");

    const token = await sbEnsureToken(cfg);
    if (!token) throw new Error("Nejste přihlášeni do Supabase.");

    // Načteme až 1000 nestažených řádků (pro reálné nasazení víc než dost)
    const url = `${sbUrl}/rest/v1/pb_queue`
        + `?done=eq.false`
        + `&order=job.asc,id.asc`
        + `&limit=1000`
        + `&select=id,job,file_path,created_at`;

    const resp = await fetch(url, {
        headers: { ..._sbHeaders(sbAnon, token), Accept: "application/json" },
        timeout: 12_000,
    });
    if (!resp.ok) {
        const text = await resp.text().catch(() => "");
        throw new Error(`Supabase HTTP ${resp.status}: ${text.slice(0, 120)}`);
    }
    const rows = await resp.json();
    if (!Array.isArray(rows)) throw new Error("Neočekávaná odpověď ze Supabase.");

    // Seskupení podle job
    const map = {};
    for (const row of rows) {
        const j = row.job || "(bez zakázky)";
        if (!map[j]) map[j] = { job: j, count: 0, newestAt: null };
        map[j].count++;
        if (row.created_at && (!map[j].newestAt || row.created_at > map[j].newestAt)) {
            map[j].newestAt = row.created_at;
        }
    }

    return Object.values(map).sort((a, b) => a.job.localeCompare(b.job));
}

// ─── IPC HANDLERY ────────────────────────────────────────────────────────────

/**
 * Zaregistruje IPC kanály – volat z main.js po app.ready.
 *
 * Kanály:
 *   supabase:login      { sbUrl, sbAnon, emailOrName, password }  → { ok, error }
 *   supabase:register   { sbUrl, sbAnon, username, password }      → { ok, error }
 *   supabase:logout     {}                                         → void
 *   supabase:status     {}                                         → { loggedIn, userId }
 *   supabase:start-poller  { cfg, job, saveDir }                   → void
 *   supabase:stop-poller   {}                                      → void
 */
function registerIpcHandlers() {
    // Přihlásit uživatele + automaticky spustit poller (pokud máme SAVE_DIR)
    ipcMain.handle("supabase:login", async (_evt, { cfg, emailOrName, username, password }) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const result = await sbLogin(resolvedCfg, emailOrName || username, password);
        if (result.ok) {
            // Uložit account_type pro persistenci
            try {
                const { loadState, saveState } = require("./utils");
                const st = loadState();
                st.sb_account_type = STATE.sbAccountType || "business";
                saveState(st);
            } catch { /* nevadí */ }
            // Auto-start polleru po přihlášení – ať uživatel nemusí klikat
            const saveDir = resolvedCfg.SAVE_DIR || "";
            if (saveDir && (resolvedCfg.SB_URL || "").trim()) {
                startSbPoller(resolvedCfg, saveDir);
            }
        }
        return { ...result, accountType: STATE.sbAccountType || "business" };
    });

    // Zaregistrovat nového uživatele + auto-start polleru
    ipcMain.handle("supabase:register", async (_evt, { cfg, email, emailOrName, username, password, accountType }) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const result = await sbRegister(resolvedCfg, email || emailOrName || username, password, accountType || "business");
        if (result.ok) {
            // Persistuj account_type
            try {
                const st = loadState();
                st.sb_account_type = STATE.sbAccountType || accountType || "business";
                saveState(st);
            } catch { /* nevadí */ }
            // Auto-start polleru po registraci
            const saveDir = resolvedCfg.SAVE_DIR || "";
            if (saveDir && (resolvedCfg.SB_URL || "").trim()) {
                startSbPoller(resolvedCfg, saveDir);
            }
        }
        return { ...result, accountType: STATE.sbAccountType || accountType || "business" };
    });

    // Odhlásit – vymaž tokeny ze STATE
    ipcMain.handle("supabase:logout", () => {
        // 1) Zastav poller + Realtime websocket (ZÁSADNÍ – jinak by starý
        //    poller chvíli běžel s prázdným tokenem nebo starým stavem)
        try { stopSbPoller(); } catch (_) {}

        // 2) Vyčisti _pollerSeen Set, aby další uživatel mohl stáhnout
        //    soubory s názvy které se náhodou shodují s předchozím uživatelem
        _pollerSeen = new Set();

        // 3) Vyčisti procesní frontu (nezpracované soubory předchozího účtu)
        _processQueue = [];

        // 4) Vymaž STATE proměnné spojené se Supabase identitou
        STATE.sbAccessToken  = "";
        STATE.sbRefreshToken = "";
        STATE.sbUserId       = "";
        STATE.sbEmail        = "";
        STATE.sbAccountType  = "";   // důležité – jinak nový login zdědí typ předchozího

        // 5) Persistentně vymaž ze state.json (refresh + email + account_type)
        try {
            const st = loadState();
            delete st.sb_refresh;
            delete st.sb_email;
            delete st.sb_account_type;
            saveState(st);
        } catch { /* nevadí */ }

        log("INFO", "SB_AUTH logout – technician initiated", "stav vyčištěn");
    });

    // Vrátit aktuální stav přihlášení
    ipcMain.handle("supabase:status", () => ({
        loggedIn:    Boolean(STATE.sbAccessToken),
        userId:      STATE.sbUserId      || "",
        email:       STATE.sbEmail       || "",
        accountType: STATE.sbAccountType || "business",
    }));

    // Alias – app.js volá supabase:state
    ipcMain.handle("supabase:state", () => ({
        loggedIn:    Boolean(STATE.sbAccessToken),
        userId:      STATE.sbUserId      || "",
        email:       STATE.sbEmail       || "",
        accountType: STATE.sbAccountType || "business",
    }));

    // Vrátit seznam nedávno použitých emailů (pro auto-suggest při loginu).
    // Uloženo v state.json jako pole sb_recent_emails (max 5 položek).
    ipcMain.handle("supabase:recent-emails", () => {
        try {
            const st = loadState();
            const recents = Array.isArray(st.sb_recent_emails) ? st.sb_recent_emails : [];
            // Pro zpětnou kompatibilitu zahrnout také sb_email pokud tam ještě není
            if (st.sb_email && !recents.includes(st.sb_email)) {
                recents.unshift(st.sb_email);
            }
            return recents.slice(0, 5);
        } catch {
            return [];
        }
    });

    // Spustit poller (bez job - Varianta A, stahuje vše pro účet)
    ipcMain.handle("supabase:start-poller", (_evt, { cfg, saveDir } = {}) => {
        const resolvedCfg = cfg || require("../main/config").readConfig();
        const resolvedDir = saveDir || resolvedCfg.SAVE_DIR || "";
        startSbPoller(resolvedCfg, resolvedDir);
    });

    // Zastavit poller
    ipcMain.handle("supabase:stop-poller", () => {
        stopSbPoller();
    });

    // Manuálně seznam objektů ze Storage (pro diagnostiku / settings)
    ipcMain.handle("supabase:list-objects", async (_evt, { cfg, bucket, job }) => {
        return sbListObjects(cfg, bucket, job);
    });

    // Přehled nestažených zakázek z pb_queue
    ipcMain.handle("supabase:pending-jobs", async (_evt, { cfg } = {}) => {
        try {
            const resolvedCfg = cfg || require("../main/config").readConfig();
            const jobs = await sbGetPendingJobs(resolvedCfg);
            return { ok: true, jobs };
        } catch (err) {
            log("WARN", "supabase:pending-jobs", String(err));
            return { ok: false, error: String(err), jobs: [] };
        }
    });

    log("INFO", "supabase.js", "IPC handlery zaregistrovány");
}

// ─── EXPORT ──────────────────────────────────────────────────────────────────

module.exports = {
    sbRestoreSession,
    sbLogin,
    sbRegister,
    sbEnsureToken,
    sbListObjects,
    sbGetPendingJobs,
    sbDownload,
    sbDelete,
    startSbPoller,
    stopSbPoller,
    isSbPollerRunning,
    notifyFileReceived,
    showTestNotification,
    registerIpcHandlers,
};
