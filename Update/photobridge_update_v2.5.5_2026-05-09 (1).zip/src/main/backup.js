'use strict';
// ============================================================
// src/main/backup.js – Záloha a obnova před aktualizací
//
// Záloha se vytvoří PŘED každou aktualizací.
// Uchovává se vždy jen JEDNA záloha (předchozí verze).
// Záloha leží MIMO resources/app/ → updater ji nikdy nepřepíše.
//
// Adresářová struktura (packaged):
//   PhotoBridge.exe
//   resources/app/    ← updater přepisuje
//   backup/           ← sestra resources/, nikdy se nepřepisuje
//     meta.json
//     app/
// ============================================================

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { app, BrowserWindow, ipcMain } = require('electron');
const { spawn } = require('child_process');

const _log = (level, msg, detail = '') => {
  try { require('./utils').log(level, 'backup', msg + (detail ? ' | ' + detail : '')); }
  catch { console.log(`[${level}] [backup] ${msg}`, detail || ''); }
};

// ── Cesty ──────────────────────────────────────────────────────────────────────
function _appDir() {
  return app.isPackaged
    ? path.join(path.dirname(app.getPath('exe')), 'resources', 'app')
    : path.resolve(__dirname, '..', '..');
}

function _backupDir() {
  // Sestra resources/ – vně dosahu updater copy operace
  return app.isPackaged
    ? path.join(path.dirname(app.getPath('exe')), 'backup')
    : path.join(path.resolve(__dirname, '..', '..', '..'), 'backup');
}

function _pendingPath() {
  return path.join(app.getPath('userData'), 'update_pending.json');
}

// ── Veřejné API ────────────────────────────────────────────────────────────────

function hasBackup() {
  return fs.existsSync(path.join(_backupDir(), 'meta.json')) &&
         fs.existsSync(path.join(_backupDir(), 'app'));
}

function getBackupMeta() {
  try {
    const p = path.join(_backupDir(), 'meta.json');
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return null; }
}

/**
 * Vytvoří zálohu resources/app/ před aktualizací.
 * Volat z updater.js PŘED spuštěním PS skriptu.
 * @param {string} currentVersion
 */
function createBackup(currentVersion) {
  const src  = _appDir();
  const back = _backupDir();
  const dst  = path.join(back, 'app');

  _log('INFO', `Vytváření zálohy v${currentVersion}…`);
  try {
    // Vždy jen jedna záloha – smaž starou
    if (fs.existsSync(back)) {
      fs.rmSync(back, { recursive: true, force: true });
      _log('INFO', 'Stará záloha smazána');
    }
    fs.mkdirSync(dst, { recursive: true });
    _copyDirSync(src, dst);
    fs.writeFileSync(path.join(back, 'meta.json'), JSON.stringify({
      version:    currentVersion,
      backupDate: new Date().toISOString(),
      appDir:     src,
    }, null, 2), 'utf8');
    _log('INFO', `Záloha OK → ${back}`);
    return { ok: true };
  } catch (e) {
    _log('ERROR', 'Záloha selhala', e.message);
    return { ok: false, error: e.message };
  }
}

/**
 * Zapíše update_pending.json těsně před app.quit() v updater.js.
 * Při příštím startu main.js detekuje crash_flag + pending → špatná aktualizace.
 */
function markUpdatePending(newVersion) {
  try {
    fs.writeFileSync(_pendingPath(), JSON.stringify({
      newVersion,
      startedAt: new Date().toISOString(),
    }, null, 2), 'utf8');
    _log('INFO', `update_pending zapsán (→ v${newVersion})`);
  } catch (e) { _log('ERROR', 'Nelze zapsat update_pending', e.message); }
}

/**
 * Smaže update_pending.json – aktualizace proběhla OK.
 * Volat v main.js po úspěšném startu.
 */
function clearUpdatePending() {
  try {
    const p = _pendingPath();
    if (fs.existsSync(p)) { fs.unlinkSync(p); _log('INFO', 'update_pending smazán (update OK)'); }
  } catch (e) { _log('ERROR', 'Nelze smazat update_pending', e.message); }
}

function getUpdatePending() {
  try {
    const p = _pendingPath();
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return null; }
}

/**
 * Spustí obnovu zálohy přes PowerShell s UAC.
 * Po skončení PS skript spustí PhotoBridge.exe a app se ukončí.
 */
function runRestore() {
  const meta = getBackupMeta();
  if (!meta) return { ok: false, error: 'Záloha neexistuje.' };
  const backupApp = path.join(_backupDir(), 'app');
  if (!fs.existsSync(backupApp)) return { ok: false, error: 'Záloha je neúplná.' };

  const esc      = s => s.replace(/'/g, "''");
  const psScript = path.join(os.tmpdir(), 'pb_restore.ps1');
  const vbsPath  = path.join(os.tmpdir(), 'pb_restore_uac.vbs');
  const psLog    = path.join(os.tmpdir(), 'pb_restore.log');

  const ps = [
    `$log='${esc(psLog)}'`,
    `$src='${esc(backupApp)}'`,
    `$dst='${esc(_appDir())}'`,
    `$exe='${esc(app.getPath('exe'))}'`,
    `$pend='${esc(_pendingPath())}'`,
    `function L($m){Add-Content $log "$(Get-Date -f 'HH:mm:ss') $m"}`,
    `L 'START restore v${meta.version}'`,
    `Start-Sleep -Seconds 2`,
    `try{`,
    `  if(Test-Path $dst){Remove-Item $dst -Recurse -Force -ErrorAction Stop}`,
    `  New-Item -ItemType Directory -Path $dst -Force|Out-Null`,
    `  Copy-Item -Path "$src\\*" -Destination $dst -Recurse -Force -ErrorAction Stop`,
    `  L 'Kopírování OK'`,
    `  if(Test-Path $pend){Remove-Item $pend -Force}`,
    `  L 'Spouštím aplikaci...'`,
    `  Start-Process $exe`,
    `  L 'HOTOVO'`,
    `}catch{`,
    `  L "CHYBA: $_"`,
    `  Add-Type -AssemblyName System.Windows.Forms`,
    `  [System.Windows.Forms.MessageBox]::Show("Obnova selhala: $_","PhotoBridge Restore")`,
    `}`,
  ].join('\r\n');

  try {
    fs.writeFileSync(psScript, ps, 'utf8');
    fs.writeFileSync(vbsPath, [
      'Set o=CreateObject("Shell.Application")',
      `o.ShellExecute "powershell.exe","-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & "${psScript}" & """","","runas",0`,
    ].join('\r\n'), 'utf8');

    spawn('wscript.exe', [vbsPath], {
      detached: true, stdio: 'ignore', windowsHide: true,
    }).unref();

    _log('INFO', 'Restore PS spuštěn, ukončuji app...');
    app.quit();
    return { ok: true };
  } catch (e) {
    _log('ERROR', 'Spuštění restore selhalo', e.message);
    return { ok: false, error: e.message };
  }
}

// ── Restore okno (z běžící app) ───────────────────────────────────────────────
let _restoreWin = null;

function showRestoreWindow(opts = {}) {
  if (_restoreWin && !_restoreWin.isDestroyed()) { _restoreWin.focus(); return; }

  _restoreWin = new BrowserWindow({
    width: 620, height: 520, minWidth: 540, minHeight: 440,
    resizable: true, maximizable: false, fullscreenable: false,
    title: 'PhotoBridge – Záchranný režim',
    show: false, backgroundColor: '#141414',
    webPreferences: {
      preload: path.join(__dirname, '../../preload.js'),
      contextIsolation: true, nodeIntegration: false,
    },
  });
  _restoreWin.loadFile(path.join(__dirname, '../renderer/restore.html'));
  _restoreWin.setMenuBarVisibility(false);
  _restoreWin.once('ready-to-show', () => {
    _restoreWin.show();
    _restoreWin.center();
    _restoreWin.webContents.send('restore:context', {
      isBadUpdate: !!opts.isBadUpdate,
      meta: getBackupMeta(),
    });
  });
  _restoreWin.on('closed', () => { _restoreWin = null; });
}

// ── IPC handlery ───────────────────────────────────────────────────────────────
function registerIpc() {
  ipcMain.handle('backup:get-meta',    () => getBackupMeta());
  ipcMain.handle('backup:has-backup',  () => hasBackup());
  ipcMain.handle('backup:run-restore', () => runRestore());
  ipcMain.handle('backup:get-pending', () => getUpdatePending());
}

// ── Interní helper ─────────────────────────────────────────────────────────────
function _copyDirSync(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? _copyDirSync(s, d) : fs.copyFileSync(s, d);
  }
}

/**
 * Async verze _copyDirSync – přeskočí node_modules aby neblokovala thread.
 */
async function _copyDirAsync(src, dst) {
  await fs.promises.mkdir(dst, { recursive: true });
  const entries = await fs.promises.readdir(src, { withFileTypes: true });
  for (const e of entries) {
    if (e.name === 'node_modules') continue; // tisíce souborů – přeskok
    const s = path.join(src, e.name);
    const d = path.join(dst, e.name);
    if (e.isDirectory()) {
      await _copyDirAsync(s, d);
    } else {
      await fs.promises.copyFile(s, d);
    }
  }
}

/**
 * Async verze createBackup – neblokuje main thread.
 * Přeskočí node_modules (zůstanou ze stávající instalace).
 * @param {string} currentVersion
 */
async function createBackupAsync(currentVersion) {
  const src  = _appDir();
  const back = _backupDir();
  const dst  = path.join(back, 'app');

  _log('INFO', `Vytváření zálohy v${currentVersion} (async)…`);
  try {
    if (fs.existsSync(back)) {
      await fs.promises.rm(back, { recursive: true, force: true });
      _log('INFO', 'Stará záloha smazána');
    }
    await fs.promises.mkdir(dst, { recursive: true });
    await _copyDirAsync(src, dst);
    await fs.promises.writeFile(path.join(back, 'meta.json'), JSON.stringify({
      version:    currentVersion,
      backupDate: new Date().toISOString(),
      appDir:     src,
    }, null, 2), 'utf8');
    _log('INFO', `Záloha OK → ${back}`);
    return { ok: true };
  } catch (e) {
    _log('ERROR', 'Záloha selhala', e.message);
    return { ok: false, error: e.message };
  }
}

module.exports = {
  hasBackup, getBackupMeta, createBackup, createBackupAsync,
  markUpdatePending, clearUpdatePending, getUpdatePending,
  runRestore, showRestoreWindow, registerIpc,
};
