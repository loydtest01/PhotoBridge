'use strict';
// ============================================================================
//  PhotoBridge – src/main/stanoviste-window.js
//
//  Plovoucí okno pro SDÍLENÁ STANOVIŠTĚ (mikroskop, měřicí pracoviště).
//
//  PROČ TO EXISTUJE
//  Na univerzálních počítačích se fotky ukládaly rovnou do sdílené složky.
//  Po přechodu na RTS to nepůjde – musí projít aplikací. Přihlašovat se tam
//  ale nikdo nebude, počítač jede pod společným účtem.
//
//  Okno je malé, drží se nad ostatními, dá se odtáhnout kamkoli a pamatuje
//  si, kde ho kdo nechal. Zadá se zakázka, přetáhnou soubory, hotovo.
//
//  Ukládání NEDĚLÁ SÁM – předává to existujícímu 'files:save' v main-tray.js,
//  které řeší pojmenování i odeslání do zakázky. Duplikovat tu logiku by
//  znamenalo dvě místa, která se rozejdou.
// ============================================================================

const { BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const fs   = require('fs');

let _win = null;

const SIROKE  = 330;
const NIZKE   = 108;   // jen řádek se zakázkou
const VYSOKE  = 210;   // i s plochou pro přetažení
// Proužek musí být dost široký na celý název stanoviště – při 132 px se
// „PhotoBridge – Mikroskop" ořízlo a nebylo poznat, o které pracoviště jde.
const MALE_S  = 230;
const MALE_V  = 38;

function _cfg()   { return require('./config'); }
function _utils() { return require('./utils'); }
function _log(u, z, t) { try { _utils().log(u, z, t); } catch (_) {} }

/** Je tenhle počítač sdílené stanoviště? */
function jeStanoviste() {
    try { return String(_cfg().readConfig().SDILENE_STANOVISTE) === 'true'; }
    catch (_) { return false; }
}

/** Poslední poloha okna – ať ho technik nemusí přesouvat po každém startu. */
function _poloha() {
    try {
        const c = _cfg().readConfig();
        const x = Number(c.STANOVISTE_X), y = Number(c.STANOVISTE_Y);
        if (Number.isFinite(x) && Number.isFinite(y)) {
            // Ověř, že souřadnice pořád leží na některé obrazovce – po odpojení
            // druhého monitoru by se okno otevřelo mimo viditelnou plochu.
            const naObrazovce = screen.getAllDisplays().some(d => {
                const b = d.workArea;
                return x >= b.x - 50 && x < b.x + b.width - 50
                    && y >= b.y - 50 && y < b.y + b.height - 50;
            });
            if (naObrazovce) return { x, y };
        }
    } catch (_) {}

    const b = screen.getPrimaryDisplay().workArea;
    return { x: b.x + b.width - SIROKE - 30, y: b.y + 60 };
}

function _ulozPolohu() {
    if (!_win || _win.isDestroyed()) return;
    try {
        const [x, y] = _win.getPosition();
        const cfgMod = _cfg();
        cfgMod.writeConfig(Object.assign({}, cfgMod.readConfig(),
            { STANOVISTE_X: String(x), STANOVISTE_Y: String(y) }));
    } catch (_) {}
}

function otevri() {
    if (_win && !_win.isDestroyed()) { _win.show(); _win.focus(); return _win; }

    const { x, y } = _poloha();

    _win = new BrowserWindow({
        width:          SIROKE,
        height:         NIZKE,
        x, y,
        frame:          false,
        transparent:    true,
        resizable:      false,
        skipTaskbar:    true,
        alwaysOnTop:    true,
        hasShadow:      false,
        roundedCorners: false,
        type:           'toolbar',
        webPreferences: {
            preload:          path.join(__dirname, '..', '..', 'preload.js'),
            contextIsolation: true,
            nodeIntegration:  false,
            sandbox:          false,
        },
        show: false,
    });

    _win.setAlwaysOnTop(true, 'screen-saver');

    const html = path.join(__dirname, '..', 'renderer', 'stanoviste.html');
    if (!fs.existsSync(html)) {
        _log('ERROR', 'STANOVISTE', 'stanoviste.html chybí');
        return null;
    }
    _win.loadFile(html);

    _win.once('ready-to-show', () => _win.show());
    _win.on('moved', _ulozPolohu);
    _win.on('closed', () => { _win = null; });

    _log('INFO', 'STANOVISTE', 'Okno stanoviště otevřeno');
    return _win;
}

function zavri() {
    if (_win && !_win.isDestroyed()) { _ulozPolohu(); _win.close(); }
    _win = null;
}

function registerIpcHandlers() {
    // Výška okna – bez zadané zakázky nemá plocha pro přetažení co dělat.
    ipcMain.handle('stanoviste:resize', (_e, { vysoke } = {}) => {
        if (!_win || _win.isDestroyed()) return;
        const [x, y] = _win.getPosition();
        _win.setBounds({ x, y, width: SIROKE, height: vysoke ? VYSOKE : NIZKE });
    });

    // Okno se ZÁMĚRNĚ NESKRÝVÁ, jen zmenší na proužek.
    //
    // Do v3.3.17 tohle okno schovávalo (_win.hide()) a nebyla cesta zpátky –
    // otevírá se jen při startu, takže po kliknutí zmizelo nadobro a musela
    // se restartovat celá aplikace. Zmenšené okno je pořád vidět a kliknutím
    // se vrátí.
    ipcMain.handle('stanoviste:zmensit', (_e, { male } = {}) => {
        if (!_win || _win.isDestroyed()) return;
        const [x, y] = _win.getPosition();
        _win.setBounds(male
            ? { x, y, width: MALE_S, height: MALE_V }
            : { x, y, width: SIROKE, height: NIZKE });
    });

    // Ponecháno kvůli starší verzi okna, která ho ještě volá – ale místo
    // skrytí se taky jen zmenší, ať okno nemůže zmizet.
    ipcMain.handle('stanoviste:hide', () => {
        if (!_win || _win.isDestroyed()) return;
        const [x, y] = _win.getPosition();
        _win.setBounds({ x, y, width: MALE_S, height: MALE_V });
    });

    // Ukládání ZÁMĚRNĚ NEDĚLÁME TADY.
    // Okno volá přímo existující 'files:save' z main-tray.js, které už umí
    // pojmenování podle typu, převod, hlídání velikosti i odeslání do
    // zakázky. Kdyby se to duplikovalo sem, jsou to dvě místa, která se
    // dřív nebo později rozejdou.

    _log('INFO', 'STANOVISTE', 'IPC handlery zaregistrovány');
}

module.exports = { otevri, zavri, jeStanoviste, registerIpcHandlers };
