'use strict';
// ============================================================================
// PhotoBridge – src/main/britex-login.js
// Přihlášení do PhotoBridge přes firemní účet BRITEX (OAuth2 přes RTS).
//
// PROČ TAKHLE
// RTS není OIDC poskytovatel, takže se v Supabase nastavil jako „Custom Auth
// Provider" (custom:britex) s ručně zadanými endpointy. Celou výměnu kódu za
// token dělá Supabase – aplikace jen otevře okno a počká na návrat.
//
// CO Z TOHO PLYNE
//   • client_secret v aplikaci vůbec není (dřív se stahoval z pb_settings)
//   • jedním přihlášením technik získá účet v PhotoBridge (Supabase session)
//     I token do RTS (provider_token) na ukládání fotek do zakázky
//   • funguje i na Linuxu a macOS – nic nativního, jen okno prohlížeče
//
// NÁVRATOVÁ ADRESA
// Používáme adresu mobilní stránky. Nikam se doopravdy nenačte – zachytíme
// přesměrování dřív. Musí být povolená v Supabase → Authentication →
// URL Configuration → Redirect URLs (stejně jako pro mobil).
// ============================================================================

const RETURN_URL   = 'https://loydtest01.github.io/PhotoBridge/';
const PROVIDER     = 'custom:britex';
const RTS_TTL_MS   = 23 * 60 * 60 * 1000;   // RTS drží přihlášení ~24 h

function log(level, ctx, msg) {
    try { require('./utils').log(level, ctx, msg); }
    catch (_) { console.log(`[${level}] [${ctx}]`, msg); }
}

/** Vytáhne tokeny z návratové adresy (Supabase je vrací za mřížkou). */
function _parseReturn(url) {
    try {
        const u = new URL(url);
        const p = new URLSearchParams(String(u.hash || '').replace(/^#/, ''));
        if (!p.get('access_token') && !p.get('error') && !p.get('error_description')) return null;
        return {
            accessToken:   p.get('access_token'),
            refreshToken:  p.get('refresh_token'),
            providerToken: p.get('provider_token'),
            expiresIn:     Number(p.get('expires_in') || 3600),
            error:         p.get('error_description') || p.get('error'),
        };
    } catch (_) { return null; }
}

/**
 * Otevře přihlašovací okno BRITEX a počká na výsledek.
 *
 * @param {object} cfg – konfigurace aplikace (potřebujeme SB_URL a SB_ANON)
 * @returns {Promise<{ok:boolean, error?:string,
 *                    session?:{accessToken:string, refreshToken:string, user:object},
 *                    rts?:{accessToken:string, expiresAt:number}}>}
 */
async function login(cfg) {
    const { BrowserWindow } = require('electron');

    const sbUrl  = String(cfg?.SB_URL  || '').replace(/\/+$/, '');
    const sbAnon = String(cfg?.SB_ANON || '');
    if (!sbUrl || !sbAnon) {
        return { ok: false, error: 'Chybí adresa Supabase v nastavení' };
    }

    const authUrl = `${sbUrl}/auth/v1/authorize`
        + `?provider=${encodeURIComponent(PROVIDER)}`
        + `&redirect_to=${encodeURIComponent(RETURN_URL)}`;

    return new Promise((resolve) => {
        const win = new BrowserWindow({
            width: 520, height: 700,
            title: 'Přihlášení přes BRITEX',
            autoHideMenuBar: true,
            webPreferences: {
                nodeIntegration:  false,
                contextIsolation: true,
                // Trvalá session – RTS si technika zapamatuje, příští přihlášení
                // je obvykle jedno kliknutí bez psaní hesla.
                partition: 'persist:rts',
            },
        });

        let settled = false;
        const finish = (result) => {
            if (settled) return;
            settled = true;
            try { win.destroy(); } catch (_) {}
            resolve(result);
        };

        const onUrl = async (url) => {
            if (!url || !url.startsWith(RETURN_URL)) return;
            const tok = _parseReturn(url);
            if (!tok) return;                       // ještě nemáme tokeny

            if (tok.error) {
                log('WARN', 'BRITEX', `Přihlášení odmítnuto: ${tok.error}`);
                return finish({ ok: false, error: decodeURIComponent(tok.error) });
            }
            if (!tok.accessToken) {
                return finish({ ok: false, error: 'Supabase nevrátil přihlašovací token' });
            }

            // Kdo se přihlásil
            let user = null;
            try {
                const r = await fetch(`${sbUrl}/auth/v1/user`, {
                    headers: { apikey: sbAnon, Authorization: `Bearer ${tok.accessToken}` },
                });
                if (r.ok) user = await r.json();
            } catch (e) {
                log('WARN', 'BRITEX', `Načtení profilu selhalo: ${e.message}`);
            }
            if (!user || !user.id) {
                return finish({ ok: false, error: 'Přihlášení se nepodařilo dokončit' });
            }

            // Token do RTS – Supabase si ho neukládá, uschováme si ho sami
            if (tok.providerToken) {
                try {
                    require('./rts-api').setToken(tok.providerToken, Math.floor(RTS_TTL_MS / 1000));
                    require('./rts-auth').saveSession({
                        accessToken:  tok.providerToken,
                        refreshToken: null,           // RTS refresh nevydává
                        expiresAt:    Date.now() + RTS_TTL_MS,
                        user:         user.email || '',
                    });
                } catch (e) {
                    log('WARN', 'BRITEX', `Uložení RTS tokenu selhalo: ${e.message}`);
                }
            } else {
                log('WARN', 'BRITEX', 'Supabase nevrátil provider_token – fotky do zakázky '
                    + 'zatím posílat nepůjde, zkontroluj nastavení poskytovatele.');
            }

            log('INFO', 'BRITEX', `Přihlášen ${user.email || user.id}`);
            finish({
                ok: true,
                session: {
                    accessToken:  tok.accessToken,
                    refreshToken: tok.refreshToken,
                    user,
                },
                rts: tok.providerToken
                    ? { accessToken: tok.providerToken, expiresAt: Date.now() + RTS_TTL_MS }
                    : null,
            });
        };

        win.webContents.on('will-redirect',        (_, url) => onUrl(url));
        win.webContents.on('will-navigate',        (_, url) => onUrl(url));
        win.webContents.on('did-navigate',         (_, url) => onUrl(url));
        // Mřížka se mění bez načtení stránky – tohle je ten případ, kdy tokeny dorazí
        win.webContents.on('did-navigate-in-page', (_, url) => onUrl(url));
        win.on('closed', () => finish({ ok: false, error: 'Přihlášení zrušeno' }));

        log('INFO', 'BRITEX', 'Otevírám firemní přihlášení');
        win.loadURL(authUrl).catch((e) => finish({ ok: false, error: String(e.message || e) }));
    });
}

module.exports = { login, RETURN_URL, PROVIDER };
