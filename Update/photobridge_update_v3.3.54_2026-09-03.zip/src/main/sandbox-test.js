'use strict';
// ============================================================================
//  PhotoBridge – src/main/sandbox-test.js
//
//  ZKUŠEBNA SANDBOX API (TempFile / SignalR)
//
//  K ČEMU TO JE
//  Luboš nabídl přenos fotek přes RTS místo Cloudflare R2 a Supabase.
//  Zbývá zjistit věci, na které se nedá odpovědět od stolu:
//
//    1. Jak dlouho vydrží soubor v TempFile?  (potřeba aspoň 24 h)
//    2. Kudy jde název souboru, když TempFile bere jen `content`?
//    3. Co SignalR udělá se zprávou pro vypnutý počítač?
//
//  Všechny tři se dají ZMĚŘIT. Tenhle modul to dělá a zapisuje CELOU
//  odpověď serveru – u neznámého API je hodnota v tom, co server vrátí,
//  ne v tom, co jsme čekali.
//
//  JE TO VYPNUTÉ. Zapíná se v Nastavení a nikdo jiný to neuvidí, takže
//  se ta verze může klidně dostat mezi ostatní.
// ============================================================================

const fs   = require('fs');
const path = require('path');

function _cfg() { return require('./config'); }
function _log(u, z) { try { require('./utils').log(u, 'SANDBOX', z); } catch (_) {} }

function zapnuto() {
    try { return String(_cfg().readConfig().SANDBOX_TEST) === 'true'; }
    catch (_) { return false; }
}

function souborZaznamu() {
    const { app } = require('electron');
    return path.join(app.getPath('userData'), 'sandbox-test.txt');
}

/** Zapíše pokus i odpověď. Tohle je vlastně celý smysl modulu. */
function zapis(nadpis, data) {
    const cas = new Date().toLocaleString('cs-CZ');
    const telo = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    const blok = `\r\n===== ${cas} \u2013 ${nadpis} =====\r\n${telo}\r\n`;
    try { fs.appendFileSync(souborZaznamu(), blok, 'utf8'); } catch (_) {}
    _log('INFO', `${nadpis}`);
}

/**
 * Volání jde přes rts-api.postJson – tedy stejnou cestou jako všechno
 * ostatní, co aplikace do RTS posílá.
 *
 * ZÁMĚRNĚ SE NEPÍŠE VLASTNÍ: rts-api už řeší token, jeho obnovu, adresu
 * serveru i chyby. Druhá cesta by se od té provozní časem rozešla a
 * měřili bychom něco jiného, než co aplikace doopravdy dělá.
 */
async function _volej(cesta, telo) {
    const zacatek = Date.now();
    try {
        const res = await require('./rts-api').postJson(cesta, telo);
        return {
            cesta,
            ok:      !!res.ok,
            status:  res.status ?? '?',
            trvani:  Date.now() - zacatek,
            odpoved: res.body !== undefined ? res.body : (res.error || '(prázdné)'),
        };
    } catch (e) {
        return { cesta, ok: false, status: 'chyba', trvani: Date.now() - zacatek,
                 odpoved: String(e.message || e) };
    }
}

// ── 1) Uložit soubor do TempFile ──────────────────────────────────────────
async function ulozTempFile(obsah) {
    const data = obsah || `PhotoBridge test ${new Date().toISOString()}`;
    const v = await _volej('/api/SandBox/TempFile', { content: Buffer.from(data).toString('base64') });
    zapis('TempFile – uložení', { poslano: { content: data.slice(0, 120) }, ...v });

    // Otisk si zapamatujeme – podle něj se pak zkouší, jak dlouho vydrží.
    // Tvar odpovědi neznáme – zkoušíme, co v ní může být.
    const b = v.odpoved;
    let sha = '';
    if (b && typeof b === 'object') sha = b.sha256 || b.Sha256 || b.hash || b.id || '';
    else if (typeof b === 'string') sha = b.replace(/["\s]/g, '');

    if (sha) {
        const cfgMod = _cfg();
        cfgMod.writeConfig(Object.assign({}, cfgMod.readConfig(), {
            SANDBOX_SHA: sha,
            SANDBOX_SHA_KDY: new Date().toISOString(),
        }));
        zapis('TempFile – otisk uložen k pozdějšímu ověření', sha);
    }
    return { ...v, sha };
}

// ── 2) Stáhnout podle otisku ──────────────────────────────────────────────
async function stahniTempFile(sha) {
    const cfg = _cfg().readConfig();
    const otisk = String(sha || cfg.SANDBOX_SHA || '').trim();
    if (!otisk) return { ok: false, error: 'Není co zkoušet – nejdřív ulož soubor.' };

    const stari = cfg.SANDBOX_SHA_KDY
        ? Math.round((Date.now() - new Date(cfg.SANDBOX_SHA_KDY).getTime()) / 60000)
        : null;

    const v = await _volej('/api/SandBox/GetTempFile', { sha256: otisk });
    zapis(`GetTempFile – po ${stari !== null ? stari + ' min' : '?'}`,
          { otisk, stariMinut: stari, ...v });
    return { ...v, stariMinut: stari };
}

// ── 3) Trvalé uložení i s názvem ──────────────────────────────────────────
async function ulozStoreFiles(nazev) {
    const jmeno = nazev || `SD_4535409_${Date.now()}_001.txt`;
    const obsah = Buffer.from(`PhotoBridge test ${new Date().toISOString()}`).toString('base64');
    const v = await _volej('/api/SandBox/StoreFiles', { files: [{ name: jmeno, data: obsah }] });
    zapis('StoreFiles – zkouška, kudy jde název', { poslanoJmeno: jmeno, ...v });
    return v;
}

// ── 4) Zpráva přes SignalR ────────────────────────────────────────────────
async function poslziZpravu(text) {
    const zprava = text || `PhotoBridge test ${new Date().toLocaleTimeString('cs-CZ')}`;
    const v = await _volej('/signalR/message', { message: zprava });
    zapis('SignalR – odeslání zprávy', { poslano: zprava, ...v });
    return v;
}

/**
 * Automatické zjištění, jak dlouho TempFile vydrží.
 *
 * DVA KROKY
 *   1. HRUBĚ: zkouší se každou hodinu, dokud soubor nezmizí. Tím se najde
 *      hodina, ve které životnost skončila – třeba „ještě ve 4 h byl,
 *      v 5 h už ne".
 *   2. PŘESNĚ: pak se nahraje NOVÝ soubor a zkouší se po 15 minutách
 *      od nalezené hranice. Výsledek je čas s přesností na čtvrthodinu.
 *
 * Proč dva kroky: kdyby se zkoušelo po 15 minutách od začátku, u životnosti
 * 24 hodin by to bylo 96 zbytečných dotazů. A kdyby jen po hodinách,
 * nevěděli bychom, jestli je to 4:05 nebo 4:55 – a u 24hodinového
 * požadavku na tom záleží.
 *
 * Až se hranice najde, zapíše se do záznamu VÝRAZNĚ, ať ji jde najít.
 */
let _hlidac = null;
let _faze   = 'hrube';       // hrube / presne / hotovo
let _posledniOk = null;      // minut, kdy byl soubor naposledy dostupný

const HODINA = 3600000;
const CTVRT  = 900000;

async function _krok() {
    if (!zapnuto() || _faze === 'hotovo') return;

    let v;
    try { v = await stahniTempFile(); }
    catch (e) { zapis('GetTempFile – chyba', String(e.message || e)); return; }

    if (!v || v.ok === undefined) return;

    // Soubor tam ještě je – jen si zapamatujeme, jak byl starý.
    if (v.ok) { _posledniOk = v.stariMinut; return; }

    // Nedostupný. 404 znamená propadl; jiný kód může být chyba spojení.
    const propadl = String(v.status) === '404';
    if (!propadl) {
        zapis('GetTempFile – nedostupné, ale ne 404 (nepočítám jako konec)', v);
        return;
    }

    if (_faze === 'hrube') {
        zapis('!!! TEMPFILE PROPADL – hrubá hranice !!!',
              `naposledy dostupný po ${_posledniOk} min, `
              + `nedostupný po ${v.stariMinut} min\r\n`
              + `\u2192 přecházím na zpřesňování po 15 minutách`);

        // Nový soubor a jemnější měření.
        _faze = 'presne';
        _posledniOk = null;
        try { await ulozTempFile(); } catch (_) {}
        _nastavInterval(CTVRT);
        return;
    }

    // Druhé kolo – tady je výsledek.
    zapis('===== VÝSLEDEK: ŽIVOTNOST TEMPFILE =====',
          `Naposledy dostupný po ${_posledniOk} min `
          + `(${(_posledniOk / 60).toFixed(1)} h)\r\n`
          + `Nedostupný po ${v.stariMinut} min `
          + `(${(v.stariMinut / 60).toFixed(1)} h)\r\n\r\n`
          + `\u2192 TempFile vydrží mezi ${_posledniOk} a ${v.stariMinut} minutami.\r\n`
          + `\u2192 Požadavek je 24 h = 1440 min – `
          + (v.stariMinut >= 1440 ? 'VYHOVUJE' : 'NEVYHOVUJE, fronta musí zůstat jinde'));

    _faze = 'hotovo';
    zastavHlidani();

    try {
        const { Notification } = require('electron');
        if (Notification.isSupported()) {
            new Notification({
                title: 'Zkušebna: životnost TempFile změřena',
                body: `Vydrží ${(_posledniOk / 60).toFixed(1)}–${(v.stariMinut / 60).toFixed(1)} h. `
                    + 'Podrobnosti v záznamu.',
            }).show();
        }
    } catch (_) {}
}

function _nastavInterval(ms) {
    if (_hlidac) clearInterval(_hlidac);
    _hlidac = setInterval(() => { _krok().catch(() => {}); }, ms);
    if (_hlidac.unref) _hlidac.unref();
}

function spustHlidani() {
    if (_hlidac) return;
    _faze = 'hrube';
    _posledniOk = null;
    _nastavInterval(HODINA);
    zapis('Měření životnosti TempFile spuštěno',
          'krok 1: po hodině, dokud soubor nezmizí\r\n'
          + 'krok 2: pak nový soubor a zpřesnění po 15 minutách');
}

function zastavHlidani() {
    if (_hlidac) { clearInterval(_hlidac); _hlidac = null; }
}

function otevriZaznam() {
    try {
        const p = souborZaznamu();
        if (!fs.existsSync(p)) fs.writeFileSync(p, '(zatím nic)\r\n', 'utf8');
        require('electron').shell.openPath(p);
        return { ok: true, cesta: p };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
}

module.exports = {
    zapnuto, ulozTempFile, stahniTempFile, ulozStoreFiles, poslziZpravu,
    spustHlidani, zastavHlidani, otevriZaznam, souborZaznamu,
};
