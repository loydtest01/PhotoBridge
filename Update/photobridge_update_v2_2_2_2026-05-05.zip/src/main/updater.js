'use strict';
// ============================================================
// PhotoBridge – src/main/updater.js
// Systém automatických aktualizací přes lokální / síťovou složku
// + pevně zakódovaný GitHub zdroj (loydtest01/PhotoBridge/Update).
//
// Princip (CHAIN UPDATE od v2.2.0):
//   1. Při startu (tiše) nebo na žádost (manuálně z UI) prohledá:
//        a) GitHub repo:   GITHUB_UPDATE_REPO / GITHUB_UPDATE_BRANCH / GITHUB_UPDATE_FOLDER
//        b) Lokální cestu: UPD_SERVER_PATH z konfigurace
//   2. Sbírá VŠECHNY ZIPy novější než aktuální verze (ne jen nejnovější)
//   3. Seřadí je vzestupně (nejstarší první) → např. 2.1.3, 2.1.5, 2.2.0, 2.3.1, 2.3.3
//   4. Stáhne všechny GitHub ZIPy do %TEMP%
//   5. Rozbaluje je jeden po druhém do STEJNÉ temp složky — novější přepíše starší
//      (pokud je settings.html v 2.1.5 i v 2.3.3, vyhraje 2.3.3)
//   6. PowerShell skript zkopíruje sloučenou složku s UAC
//   7. Aplikace se automaticky restartuje
//
// DŮLEŽITÉ: package.json musí mít "asar": false
// ============================================================

const fs       = require('fs');
const path     = require('path');
const os       = require('os');
const https    = require('https');
const { app, dialog, nativeImage, ipcMain } = require('electron');
const { spawnSync, spawn }                  = require('child_process');

// ── Lazy import – config a utils se načtou až po jejich inicializaci ──────────
const getConfig = () => require('./config');
const getUtils  = () => { try { return require('./utils'); } catch { return null; } };

// ── Logování (fallback na console pokud utils ještě není načten) ──────────────
function log(level, context, msg) {
  const u = getUtils();
  if (u && u.log) {
    u.log(level, context, msg);
  } else {
    console.log(`[${new Date().toISOString()}] [${level}] [${context}]`, msg);
  }
}

// ── Konstanty ─────────────────────────────────────────────────────────────────
const APP_SLUG    = 'photobridge';   // prefix názvů update ZIPů
const APP_VERSION = app.getVersion();

// ── GitHub zdroj – pevně zakódovaný (NEZAVISÍ na konfiguraci) ────────────────
const GITHUB_UPDATE_OWNER  = 'loydtest01';
const GITHUB_UPDATE_REPO   = 'PhotoBridge';
const GITHUB_UPDATE_BRANCH = 'main';
const GITHUB_UPDATE_FOLDER = 'Update';

// Klíč v state.json pro zapamatování posledně nainstalované verze
const STATE_KEY_LAST_ZIP = 'lastInstalledZip';

// Midnight scheduler handle
let _midnightTimer = null;

// ── Ukládání stavu (GET_LAST / SAVE_LAST) ────────────────────────────────────
function _getLastZip() {
  try {
    const u = getUtils();
    if (u && u.loadState) {
      const st = u.loadState();
      return st[STATE_KEY_LAST_ZIP] || '';
    }
  } catch (_) {}
  try {
    const p = path.join(app.getPath('userData'), 'updater_state.json');
    if (fs.existsSync(p)) {
      return JSON.parse(fs.readFileSync(p, 'utf8'))[STATE_KEY_LAST_ZIP] || '';
    }
  } catch (_) {}
  return '';
}

function _saveLastZip(basename) {
  try {
    const u = getUtils();
    if (u && u.loadState && u.saveState) {
      const st = u.loadState();
      st[STATE_KEY_LAST_ZIP] = basename;
      u.saveState(st);
      return;
    }
  } catch (_) {}
  try {
    const p = path.join(app.getPath('userData'), 'updater_state.json');
    const existing = fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : {};
    existing[STATE_KEY_LAST_ZIP] = basename;
    fs.writeFileSync(p, JSON.stringify(existing, null, 2), 'utf8');
  } catch (_) {}
}

// ── Texty dialogů (česky) ─────────────────────────────────────────────────────
const STRINGS = {
  noFolderTitle:  'Aktualizace',
  noFolderMsg:    'Složka pro aktualizace není nastavena nebo neexistuje.',
  noFolderDetail: 'Nastavte cestu ke složce s aktualizacemi v Nastavení → Systém.',
  noUpdateTitle:  'Aktualizace',
  noUpdateMsg:    'Žádná nová aktualizace nenalezena.',
  alreadyTitle:   'Aktualizace',
  alreadyMsg:     (versionLabel, currentVer, basename) =>
    `Verze ${versionLabel} je již nainstalována.\n\nAktuální verze: v${currentVer}\nSoubor: ${basename}`,
  foundTitle:     '🔄 Nalezena aktualizace',
  foundMsgSingle: (versionLabel, date, source) =>
    `Nalezena aktualizace ${versionLabel} (${date})\nZdroj: ${source}`,
  foundMsgChain:  (fromVer, toVer, count, source) =>
    `Nalezeno ${count} aktualizací: v${fromVer} → v${toVer}\nZdroj: ${source}`,
  foundDetail:    'Chcete nainstalovat aktualizaci nyní?\n\n• Nainstalovat hned — aplikace se aktualizuje a restartuje\n• Odložit — připomene se při příštím spuštění\n• Zrušit — aktualizace nebude nainstalována',
  foundDetailChain: (versions) =>
    `Budou nainstalovány v pořadí:\n${versions}\n\n• Nainstalovat hned — aplikace se aktualizuje a restartuje\n• Odložit — připomene se při příštím spuštění\n• Zrušit — aktualizace nebude nainstalována`,
  btnInstall:     'Nainstalovat hned',
  btnDefer:       'Odložit',
  btnCancel:      'Zrušit',
  extractError:   'Chyba při rozbalování ZIPu',
  ok:             'OK',
};

// ── Ikony ─────────────────────────────────────────────────────────────────────
const FALLBACK_ICON_B64 =
  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAbklEQVR42mNk' +
  'YGD4z8BAAAACAAHgAQABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQ' +
  'ABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYA' +
  'JwAoACkAKgArACwALQAuAC8AMAAAAElFTkSuQmCC';

function resolveIcon(filename) {
  const alt = filename.endsWith('.ico')
    ? filename.replace('.ico', '.png')
    : filename.replace('.png', '.ico');

  const candidates = [];
  for (const name of [filename, alt]) {
    candidates.push(
      path.join(__dirname, '../../assets/icons', name),
      path.join(__dirname, '../../../assets/icons', name),
      path.join(process.resourcesPath || '', 'app', 'assets', 'icons', name),
      path.join(process.resourcesPath || '', 'assets', 'icons', name),
      path.join(process.resourcesPath || '', 'assets', name),
      path.join(process.resourcesPath || '', name),
      path.join(path.dirname(app.getPath('exe')), 'assets', 'icons', name),
      path.join(path.dirname(app.getPath('exe')), 'assets', name),
      path.join(__dirname, 'assets', 'icons', name),
      path.join(__dirname, 'assets', name),
    );
  }

  for (const p of candidates) {
    try { if (fs.existsSync(p)) return p; } catch (_) {}
  }
  return null;
}

function resolveIconImage(filename) {
  const iconPath = resolveIcon(filename);
  if (iconPath) {
    const img = nativeImage.createFromPath(iconPath);
    if (!img.isEmpty()) return img;
  }
  return nativeImage.createFromDataURL('data:image/png;base64,' + FALLBACK_ICON_B64);
}

// ── Porovnání verzí (semver) ──────────────────────────────────────────────────
/**
 * @returns {number} 1 pokud a > b, -1 pokud a < b, 0 pokud stejné
 */
function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

// ── Řazení kandidátů vzestupně (nejstarší první) ──────────────────────────────
function _sortAscending(candidates) {
  return [...candidates].sort((a, b) => {
    if (a.version && b.version) {
      const cmp = compareVersions(a.version, b.version);
      if (cmp !== 0) return cmp;
    } else if (a.version && !b.version) return -1;
    else if (!a.version && b.version) return 1;
    if (a.date < b.date) return -1;
    if (a.date > b.date) return 1;
    return (a.build || -1) - (b.build || -1);
  });
}

// ── Regex pro názvy update ZIPů ───────────────────────────────────────────────
const slugEsc  = APP_SLUG.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ZIP_REGEX = new RegExp(
  `^${slugEsc}_update_(?:v([\\d.]+)_)?(\\d{4}-\\d{2}-\\d{2})(?:_(\\d+))?\\.zip$`
);

// ── Pomocník: HTTPS GET → string ─────────────────────────────────────────────
function httpsGet(url, timeoutMs = 10000, pat = '') {
  return new Promise((resolve, reject) => {
    const headers = { 'User-Agent': `PhotoBridge-Updater/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        return resolve(httpsGet(res.headers.location, timeoutMs, pat));
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} pro ${url}`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      res.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', reject);
  });
}

// ── Pomocník: HTTPS GET → Buffer (stahování souborů) ─────────────────────────
function httpsDownload(url, destPath, timeoutMs = 120000, pat = '') {
  return new Promise((resolve, reject) => {
    const file    = fs.createWriteStream(destPath);
    const headers = { 'User-Agent': `PhotoBridge-Updater/${APP_VERSION}` };
    if (pat) headers['Authorization'] = `Bearer ${pat}`;
    const req = https.get(url, { headers }, res => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        file.close();
        return resolve(httpsDownload(res.headers.location, destPath, timeoutMs, pat));
      }
      if (res.statusCode !== 200) {
        file.close();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(destPath); });
      file.on('error', reject);
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('Timeout stahování')); });
    req.on('error', reject);
  });
}

// ── Hledání VŠECH ZIPů v GitHub složce ───────────────────────────────────────
/**
 * Vrátí VŠECHNY update ZIPy z GitHub složky jako pole kandidátů.
 * @param {string} pat – GitHub Personal Access Token (může být prázdný pro public repo)
 * @returns {Promise<Array>}
 */
async function _findAllInGitHub(pat = '') {
  const apiUrl = `https://api.github.com/repos/${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/contents/${GITHUB_UPDATE_FOLDER}?ref=${GITHUB_UPDATE_BRANCH}`;
  log('INFO', 'updater', `GitHub check: ${apiUrl} ${pat ? '[auth]' : '[no-auth]'}`);

  let items;
  try {
    const body = await httpsGet(apiUrl, 10000, pat);
    items = JSON.parse(body);
  } catch (e) {
    log('WARN', 'updater', `GitHub API nedostupné: ${e.message}${!pat ? ' (tip: nastav GITHUB_PAT pro soukromé repo)' : ''}`);
    return [];
  }

  if (!Array.isArray(items)) {
    log('WARN', 'updater', 'GitHub API vrátilo neočekávaný formát');
    return [];
  }

  const results = [];
  for (const item of items) {
    if (item.type !== 'file') continue;
    const match = item.name.match(ZIP_REGEX);
    if (!match) continue;

    const [, ver, date, build] = match;
    results.push({
      file:     item.download_url,
      version:  ver  || '',
      date:     date,
      build:    build ? parseInt(build, 10) : -1,
      source:   'github',
      basename: item.name,
    });
  }

  log('INFO', 'updater', `GitHub – nalezeno ${results.length} update ZIPů`);
  return results;
}

// ── Hledání VŠECH ZIPů v lokální / síťové složce ─────────────────────────────
/**
 * @param {string} updateDir – absolutní cesta ke složce
 * @returns {Array<{file, version, date, build, source, basename}>}
 */
function _findAllInLocal(updateDir) {
  let entries;
  try { entries = fs.readdirSync(updateDir); } catch (e) {
    log('ERROR', 'updater', `Nelze číst složku aktualizací: ${e.message}`);
    return [];
  }

  const results = [];
  for (const file of entries) {
    const match = file.match(ZIP_REGEX);
    if (!match) continue;

    const [, ver, date, build] = match;
    results.push({
      file:     path.join(updateDir, file),
      version:  ver  || '',
      date:     date,
      build:    build ? parseInt(build, 10) : -1,
      source:   'local',
      basename: file,
    });
  }

  log('INFO', 'updater', `Lokální složka – nalezeno ${results.length} update ZIPů`);
  return results;
}

// ── Deduplikace kandidátů (stejná verze → preferuj github, pak local) ────────
/**
 * Sloučí GitHub a lokální kandidáty: stejná verze → jedna položka (github preferován).
 * @param {Array} github
 * @param {Array} local
 * @returns {Array}
 */
function _mergeAndDedup(github, local) {
  const map = new Map();

  // Nejdříve lokální
  for (const c of local) {
    const key = c.version || `${c.date}_${c.build}`;
    map.set(key, c);
  }
  // GitHub přepíše (preferujeme GitHub jako zdroj)
  for (const c of github) {
    const key = c.version || `${c.date}_${c.build}`;
    map.set(key, c);
  }

  return Array.from(map.values());
}

// ── Filtrování: jen ZIPy NOVĚJŠÍ než aktuální verze ──────────────────────────
/**
 * Z pole všech kandidátů vrátí jen ty novější než `currentVersion`.
 * @param {Array} all
 * @param {string} currentVersion – např. "2.1.2"
 * @returns {Array}
 */
function _filterNewer(all, currentVersion) {
  return all.filter(c => {
    if (c.version) {
      return compareVersions(c.version, currentVersion) > 0;
    }
    // Bez čísla verze: vezmeme vždy (nelze spolehlivě porovnat)
    return true;
  });
}

// ── Stažení GitHub ZIPu do %TEMP% ────────────────────────────────────────────
async function _downloadGitHubZip(downloadUrl, basename, pat = '') {
  const tmpDir  = path.join(os.tmpdir(), `${APP_SLUG}_github_zip`);
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const destPath = path.join(tmpDir, basename);

  if (fs.existsSync(destPath)) {
    log('INFO', 'updater', `GitHub ZIP již v cache: ${destPath}`);
    return destPath;
  }

  log('INFO', 'updater', `Stahuji GitHub ZIP: ${downloadUrl}`);
  await httpsDownload(downloadUrl, destPath, 120000, pat);
  log('INFO', 'updater', `GitHub ZIP stažen: ${destPath}`);
  return destPath;
}

// ── Sekvenční rozbalování chain update ───────────────────────────────────────
/**
 * @param {Array}  chain
 * @param {string} tmpExtract
 * @param {string} pat        – GitHub PAT pro stahování
 */
async function _applyChain(chain, tmpExtract, pat = '') {
  if (fs.existsSync(tmpExtract)) {
    try { fs.rmSync(tmpExtract, { recursive: true, force: true }); } catch (_) {}
  }
  fs.mkdirSync(tmpExtract, { recursive: true });

  for (const candidate of chain) {
    const label = candidate.version ? `v${candidate.version}` : candidate.date;
    log('INFO', 'updater', `Chain: rozbaluji ${candidate.basename} [${candidate.source}]`);

    // Získej lokální cestu k ZIPu
    let zipPath;
    if (candidate.source === 'github') {
      zipPath = await _downloadGitHubZip(candidate.file, candidate.basename, pat);
    } else {
      zipPath = candidate.file;
    }

    // Rozbal do tmpExtract (Force přepíše existující soubory)
    const extractCmd = `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${tmpExtract.replace(/'/g, "''")}' -Force`;
    const result = spawnSync(
      'powershell',
      ['-NoProfile', '-NonInteractive', '-Command', extractCmd],
      { stdio: 'pipe' }
    );

    if (result.status !== 0) {
      const errMsg = result.stderr?.toString() || `PowerShell exit code ${result.status}`;
      throw new Error(`${STRINGS.extractError} (${label}): ${errMsg}`);
    }

    log('INFO', 'updater', `Chain: ${label} rozbaleno OK`);
  }

  log('INFO', 'updater', `Chain: všech ${chain.length} ZIPů rozbaleno do ${tmpExtract}`);
}

// ── Hlavní funkce: checkForUpdates ───────────────────────────────────────────
/**
 * Zkontroluje oba zdroje, sestaví řetěz aktualizací a nabídne sekvenční instalaci.
 *
 * @param {boolean} manual – true = voláno z UI (zobrazí dialog i "nic nového")
 * @returns {Promise<void>}
 */
async function checkForUpdates(manual = false) {
  const S = STRINGS;

  try {
    const cfg       = getConfig().readConfig();
    const updateDir = (cfg.UPD_SERVER_PATH || '').trim();
    const pat       = (cfg.GITHUB_PAT || '').trim();

    // ── 1. Paralelně sesbírej VŠECHNY ZIPy z obou zdrojů ─────────────────
    const [githubAll, localAll] = await Promise.all([
      _findAllInGitHub(pat),
      updateDir && fs.existsSync(updateDir)
        ? Promise.resolve(_findAllInLocal(updateDir))
        : Promise.resolve([]),
    ]);

    if (localAll.length === 0 && updateDir) {
      log('WARN', 'updater', `Lokální složka nenalezena nebo prázdná: "${updateDir}"`);
    }

    // ── 2. Slouč (dedup) a vyfiltruj jen novější než aktuální verze ───────
    const allCandidates = _mergeAndDedup(githubAll, localAll);
    const newer         = _filterNewer(allCandidates, APP_VERSION);

    if (newer.length === 0) {
      log('INFO', 'updater', `Žádné nové aktualizace (aktuální: v${APP_VERSION}).`);
      if (manual) {
        const detail = updateDir
          ? `Zkontrolováno:\n• GitHub: ${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/${GITHUB_UPDATE_FOLDER}\n• Lokální složka: ${updateDir}`
          : `Zkontrolováno:\n• GitHub: ${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO}/${GITHUB_UPDATE_FOLDER}\n• Lokální složka: (nenastavena)`;
        await dialog.showMessageBox({
          type: 'info', title: S.noUpdateTitle,
          message: S.noUpdateMsg,
          detail,
          buttons: [S.ok],
        });
      }
      return;
    }

    // ── 3. Seřaď vzestupně (nejstarší → nejnovější) ───────────────────────
    const chain   = _sortAscending(newer);
    const first   = chain[0];
    const last    = chain[chain.length - 1];
    const lastVer = last.version ? `v${last.version}` : last.date;

    const sourceName = chain.every(c => c.source === 'github')
      ? `GitHub (${GITHUB_UPDATE_OWNER}/${GITHUB_UPDATE_REPO})`
      : chain.every(c => c.source === 'local')
        ? `Lokální složka`
        : `GitHub + Lokální složka`;

    log('INFO', 'updater', `Chain update: ${chain.length} ZIPů [${chain.map(c => c.basename).join(' → ')}]`);

    // ── 4. Zkontroluj jestli je poslední již nainstalovaná ────────────────
    const lastInstalled = _getLastZip();
    const alreadyByName = (lastInstalled === last.basename);
    const alreadyByVer  = last.version && (compareVersions(APP_VERSION, last.version) >= 0);

    if (alreadyByName || alreadyByVer) {
      log('INFO', 'updater', `Již aktuální: current=v${APP_VERSION}, newest=${lastVer}`);
      if (manual) {
        await dialog.showMessageBox({
          type: 'info', title: S.alreadyTitle,
          message: S.alreadyMsg(lastVer, APP_VERSION, last.basename),
          buttons: [S.ok],
        });
      }
      return;
    }

    // ── 5. Dialog pro uživatele ───────────────────────────────────────────
    let message, detail;

    if (chain.length === 1) {
      message = S.foundMsgSingle(lastVer, last.date, sourceName);
      detail  = S.foundDetail;
    } else {
      const fromVer = first.version || first.date;
      const toVer   = last.version  || last.date;
      message = S.foundMsgChain(fromVer, toVer, chain.length, sourceName);
      const versionList = chain
        .map((c, i) => `  ${i + 1}. ${c.basename}`)
        .join('\n');
      detail = S.foundDetailChain(versionList);
    }

    const { response } = await dialog.showMessageBox({
      type:      'info',
      title:     S.foundTitle,
      message,
      detail,
      buttons:   [S.btnInstall, S.btnDefer, S.btnCancel],
      defaultId: 0,
      cancelId:  2,
    });

    if (response === 2) { log('INFO', 'updater', 'Uživatel zrušil aktualizaci.');  return; }
    if (response === 1) { log('INFO', 'updater', 'Uživatel odložil aktualizaci.'); return; }

    // ── ZÁLOHA před aktualizací ───────────────────────────────────────────
    try {
      const backup = require('./backup');
      const backupResult = backup.createBackup(APP_VERSION);
      if (!backupResult.ok) {
        log('WARN', 'updater', `Záloha se nepodařila: ${backupResult.error} – pokračuji v aktualizaci`);
      }
    } catch (e) {
      log('WARN', 'updater', `Zálohovací modul nedostupný: ${e.message}`);
    }

    // ── 6. Sekvenčně rozbal celý řetěz do temp složky ────────────────────
    const tmpExtract = path.join(os.tmpdir(), `${APP_SLUG}_pending_update`);
    await _applyChain(chain, tmpExtract, pat);

    // ── 7. PowerShell skript (kopíruje soubory s admin právy) ────────────
    const targetDir    = app.isPackaged
      ? path.join(path.dirname(app.getPath('exe')), 'resources', 'app')
      : path.resolve(__dirname, '..', '..');
    const resourcesDir = app.isPackaged ? process.resourcesPath : targetDir;

    const restartCmd = app.isPackaged
      ? `Start-Process '${app.getPath('exe').replace(/'/g, "''")}'`
      : `Start-Process '${process.execPath.replace(/'/g, "''")}' -ArgumentList '${targetDir.replace(/'/g, "''")}'`;

    const psScript = path.join(os.tmpdir(), `${APP_SLUG}_apply_update.ps1`);
    const psLog    = path.join(os.tmpdir(), `${APP_SLUG}_update.log`);
    const esc      = s => s.replace(/'/g, "''");

    const chainLabel = chain.length > 1
      ? `chain ${chain.length}x (v${APP_VERSION} → ${lastVer})`
      : `${lastVer} [${last.source}]`;

    const psLines = [
      `$log = '${esc(psLog)}'`,
      `$src = '${esc(tmpExtract)}'`,
      `$dst = '${esc(targetDir)}'`,
      `$res = '${esc(resourcesDir)}'`,
      `function L($m) { Add-Content $log "$(Get-Date -f 'HH:mm:ss') $m" }`,
      `L 'START update: ${APP_SLUG} ${chainLabel}'`,
      ``,
      `# Počkej na uvolnění file locků (Electron se zavírá)`,
      `Start-Sleep -Seconds 3`,
      `L 'Kopíruji soubory (sloučený chain update)...'`,
      ``,
      `try {`,
      `  Copy-Item -Path "$src\\*" -Destination $dst -Recurse -Force -ErrorAction Stop`,
      `  L 'Kopírování OK'`,
      ``,
      `  # Zrcadlení index.html přímo do resources/ pro rychlejší načítání`,
      `  $html = Join-Path $dst 'src\\renderer\\index.html'`,
      `  if (Test-Path $html) {`,
      `    Copy-Item $html (Join-Path $res 'index.html') -Force`,
      `    L 'index.html zkopírován do resources/'`,
      `  }`,
      ``,
      `  # Úklid temp souborů`,
      `  Remove-Item $src -Recurse -Force -ErrorAction SilentlyContinue`,
      `  Remove-Item '${esc(psScript)}' -Force -ErrorAction SilentlyContinue`,
      `  L 'Úklid OK — spouštím aplikaci...'`,
      `  ${restartCmd}`,
      `  L 'HOTOVO'`,
      `} catch {`,
      `  L "CHYBA: $_"`,
      `  Add-Type -AssemblyName System.Windows.Forms`,
      `  [System.Windows.Forms.MessageBox]::Show("Chyba aktualizace: $_", '${APP_SLUG}')`,
      `}`,
    ];

    fs.writeFileSync(psScript, psLines.join('\r\n'), 'utf8');
    log('INFO', 'updater', `PS skript zapsán: ${psScript}`);

    // ── 8. VBScript – spustí PS s UAC elevací ────────────────────────────
    const vbsPath = path.join(os.tmpdir(), `${APP_SLUG}_elevate.vbs`);
    fs.writeFileSync(vbsPath, [
      'Set oApp = CreateObject("Shell.Application")',
      'Dim psArgs',
      `psArgs = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & "${psScript}" & """"`,
      'oApp.ShellExecute "powershell.exe", psArgs, "", "runas", 0',
    ].join('\r\n'), 'utf8');
    log('INFO', 'updater', `VBS elevate skript zapsán: ${vbsPath}`);

    // ── 9. Spusť VBS a zavři aplikaci ────────────────────────────────────
    const proc = spawn('wscript.exe', [vbsPath], {
      detached:    true,
      stdio:       'ignore',
      windowsHide: true,
    });
    proc.unref();

    // ── 10. Ulož název nejnovějšího ZIPu – po restartu se přeskočí ───────
    try { _saveLastZip(last.basename); } catch (_) {}

    try {
      const backup = require('./backup');
      backup.markUpdatePending(last.version || last.date);
    } catch (_) {}

    log('INFO', 'updater', `Ukončuji aplikaci pro instalaci chain update (${chain.length} ZIPů)...`);
    app.quit();

  } catch (err) {
    log('ERROR', 'updater', `Chyba aktualizace: ${err.message}`);
    if (manual) {
      await dialog.showMessageBox({
        type: 'error', title: 'Chyba aktualizace',
        message: 'Aktualizace se nezdařila:\n' + err.message,
        buttons: [STRINGS.ok],
      });
    }
  }
}

// ── Midnight scheduler ────────────────────────────────────────────────────────
function scheduleUpdateCheck() {
  setTimeout(() => {
    checkForUpdates(false).catch(e => log('ERROR', 'updater', `Startup check selhal: ${e.message}`));
  }, 3000);

  _scheduleNextMidnight();
  log('INFO', 'updater', 'Midnight update scheduler spuštěn');
}

function _scheduleNextMidnight() {
  if (_midnightTimer) {
    clearTimeout(_midnightTimer);
    _midnightTimer = null;
  }

  const now  = new Date();
  const next = new Date(now);
  next.setDate(next.getDate() + 1);
  next.setHours(0, 0, 30, 0);

  const msUntil = next - now;
  log('INFO', 'updater', `Příští midnight check za ${Math.round(msUntil / 60000)} minut`);

  _midnightTimer = setTimeout(() => {
    const cfg = getConfig().readConfig();
    if (cfg.AUTO_MIDNIGHT_UPDATE !== 'false') {
      log('INFO', 'updater', 'Midnight check aktualizací...');
      checkForUpdates(false)
        .catch(e => log('ERROR', 'updater', `Midnight check selhal: ${e.message}`))
        .finally(() => _scheduleNextMidnight());
    } else {
      _scheduleNextMidnight();
    }
  }, msUntil);

  if (_midnightTimer.unref) _midnightTimer.unref();
}

function stopScheduler() {
  if (_midnightTimer) {
    clearTimeout(_midnightTimer);
    _midnightTimer = null;
  }
}

// ── IPC kanál ─────────────────────────────────────────────────────────────────
try {
  if (ipcMain) {
    ipcMain.handle('ipc:update:check-silent', () => checkForUpdates(false));
  }
} catch (_) {}

// ── Export ────────────────────────────────────────────────────────────────────
module.exports = {
  checkForUpdates,
  scheduleUpdateCheck,
  stopScheduler,
  resolveIcon,
  resolveIconImage,
  compareVersions,
};
