/* ════════════════════════════════════════════════════════════
   PhotoBridge – app.js
   Renderer-side JS · Fáze 8 + 9
   Komunikace POUZE přes window.electronAPI (preload.js + contextBridge)
   ════════════════════════════════════════════════════════════ */

'use strict';

// ── Bezpečný přístup k Electron API (přes preload.js) ───────
const api = window.electronAPI || {};

/* ══════════════════════════════════════════════════════════
   STAV APLIKACE (renderer-side)
/* ══════════════════════════════════════════════════════════ */
const State = {
  // Aktuální zakázka
  job: '',
  // QR url
  qrUrl: '',
  // Platnost QR tokenu (ms timestamp)
  tokenExpiry: null,
  tokenMinutes: 480,
  // Odpočet timeout bar
  _timeoutInterval: null,
  // Drag & Drop dialog – otevřené soubory
  pendingFiles: [],
  // Aktivní pohled: 'main' | 'qr'
  view: 'main',
  // Statistiky
  stats: { total: 0, session: 0, jobCount: 0 },
  // Supabase přihlášení
  sbLoggedIn: false,
  sbEmail: '',
  sbAccountType: 'business',   // 'business' | 'personal'
  // Vercel mód
  vercelMode: false,
  // Aktuální poller job (null = neaktivní)
  pollerJob: null,
  // Server running
  serverRunning: false,
  // Session timer (20 min po spuštění příjmu)
  _sessionTimerId:  null,
  _sessionTimerEnd: 0,
};

/* ══════════════════════════════════════════════════════════
   UTILITY
/* ══════════════════════════════════════════════════════════ */

/** Bezpečné volání IPC bez havarisování pokud preload chybí */
function ipc(channel, ...args) {
  if (api.invoke) return api.invoke(channel, ...args);
  console.warn('[PhotoBridge] electronAPI.invoke nedostupné – preload.js nenačten?');
  return Promise.resolve(null);
}

/** Formátuje sekundy jako mm:ss */
function fmtSecs(s) {
  if (s <= 0) return '0:00';
  const m = Math.floor(s / 60);
  const ss = String(Math.floor(s % 60)).padStart(2, '0');
  return `${m}:${ss}`;
}

/* ══════════════════════════════════════════════════════════
   SESSION TIMER – 20 minut (spec sekce 4)
/* ══════════════════════════════════════════════════════════ */
const SESSION_TIMEOUT_SEC = 20 * 60;  // 1200 sekund

function updateStopButtonLabel(label) {
  if (Els && Els.btnStopPoller) Els.btnStopPoller.textContent = label;
}

function startSessionTimer() {
  cancelSessionTimer();
  State._sessionTimerEnd = Date.now() + SESSION_TIMEOUT_SEC * 1000;
  _tickSessionTimer();
}

function cancelSessionTimer() {
  if (State._sessionTimerId !== null) {
    clearTimeout(State._sessionTimerId);
    State._sessionTimerId = null;
  }
  State._sessionTimerEnd = 0;
  // Resetuj text tlačítka na výchozí
  if (Els && Els.btnStopPoller) Els.btnStopPoller.textContent = '⏹  Zastavit příjem';
}

function _tickSessionTimer() {
  const remaining = Math.floor((State._sessionTimerEnd - Date.now()) / 1000);
  if (remaining <= 0) {
    // Auto-stop po 20 minutách
    _autoStopPoller();
    return;
  }
  const mins = Math.floor(remaining / 60);
  const secs = remaining % 60;
  updateStopButtonLabel(`⏹  Zastavit příjem  ${mins}:${secs.toString().padStart(2, '0')}`);
  State._sessionTimerId = setTimeout(_tickSessionTimer, 1000);
}

function _autoStopPoller() {
  cancelSessionTimer();
  ipc('supabase:stop-poller');
  updatePollerStatus(null);
  ipc('window:setTitle', 'PhotoBridge');
  ipc('tray:updateMenu', { job: null, qrActive: false });
  // Po uplynutí 20 minut vrátit na hlavní pohled a zaměřit zakázku
  showView('main');
}

/** Zkrátí cestu na název souboru */
function basename(p) {
  return p.replace(/\\/g, '/').split('/').pop();
}

/* ══════════════════════════════════════════════════════════
   DOM REFERENCE
/* ══════════════════════════════════════════════════════════ */
const $ = id => document.getElementById(id);

const Els = {
  // Záhlaví
  btnHelp:       $('btn-help'),
  btnSettings:   $('btn-settings'),

  // Hlavní pohled
  viewMain:      $('view-main'),
  viewQr:        $('view-qr'),

  // Zakázka
  jobEntry:      $('job-entry'),
  btnGenerate:   $('btn-generate'),
  jobHistoryRow: $('job-history-row'),
  jobHistory:    $('job-history'),

  // Status panel
  statusPanel:   $('status-panel'),
  dotServer:     $('dot-server'),
  statusServer:  $('status-server'),
  statusIp:      $('status-ip'),
  statusPort:    $('status-port'),

  // Supabase – login/logout tlačítka jsou nyní v headeru
  sbStatusRow:   null,  // odstraněno (přesunuto do headeru)
  sbStatusIcon:  null,
  sbStatusText:  null,
  btnSbLogin:    $('btn-sb-login'),
  btnSbLogout:   $('btn-sb-logout'),

  // Poller
  pollerStatusRow: $('poller-status-row'),
  pollerStatusLbl: $('poller-status-lbl'),
  btnStopPoller:   $('btn-stop-poller'),

  // Statistiky
  statTotal:   $('stat-total'),
  statSession: $('stat-session'),
  statJobCount:$('stat-job-count'),

  // Vercel poller
  vercelPollerRow: $('vercel-poller-row'),
  btnStartPoller:  $('btn-start-poller'),

  // Drop zóna hlavní pohled
  dropZoneMain:        $('drop-zone-main'),

  // QR pohled
  qrCanvas:         $('qr-canvas'),
  qrContainer:      $('qr-container'),
  dropOverlay:      $('drop-overlay'),
  qrUrlText:        $('qr-url-text'),
  btnCopyUrl:       $('btn-copy-url'),
  qrTimeoutRow:     $('qr-timeout-row'),
  qrTimeoutBar:     $('qr-timeout-bar'),
  qrTimeoutText:    $('qr-timeout-text'),
  btnTimerQr:       document.querySelector('.qr-timer-btn'),
  qrPollerRow:      $('qr-poller-row'),
  qrPollerLbl:      $('qr-poller-lbl'),
  btnBackFromQr:    $('btn-back-from-qr'),
  btnManualSelectQr:$('btn-manual-select-qr'),

  // DragDrop dialog
  modalOverlay:    $('modal-overlay'),
  modalDialog:     $('modal-dialog'),
  modalJobBadge:   $('modal-job-badge'),
  btnModalClose:   $('btn-modal-close'),
  btnModalCancel:  $('btn-modal-cancel'),
  btnModalConfirm: $('btn-modal-confirm'),
  fileList:        $('file-list'),
  btnAddMoreFiles: $('btn-add-more-files'),

  // Toast
  toast:           $('toast'),
  toastTitle:      $('toast-title'),
  toastFiles:      $('toast-files'),
  btnToastDismiss: $('btn-toast-dismiss'),

  // Login dialog
  loginOverlay:    $('login-overlay'),
  btnLoginClose:   $('btn-login-close'),
  btnLoginCancel:  $('btn-login-cancel'),
  btnLoginConfirm: $('btn-login-confirm'),
  tabLogin:        $('tab-login'),
  tabRegister:     $('tab-register'),
  loginHint:       $('login-hint'),
  loginName:       $('login-name'),
  loginPass:       $('login-pass'),
  loginPass2:      $('login-pass2'),
  reg2Row:         $('reg2-row'),
  loginStatus:     $('login-status'),
};

/* ══════════════════════════════════════════════════════════
   PŘEPÍNÁNÍ POHLEDŮ
/* ══════════════════════════════════════════════════════════ */
function showView(name) {
  State.view = name;
  Els.viewMain.style.display = (name === 'main') ? 'flex' : 'none';
  Els.viewQr.style.display   = (name === 'qr')   ? 'flex' : 'none';
  // Vždy zaměř pole zakázky při návratu na hlavní pohled
  if (name === 'main') {
    setTimeout(() => {
      if (Els.jobEntry) {
        Els.jobEntry.focus();
        Els.jobEntry.select();
      }
    }, 80);
  }
  updateDropZoneVisibility();
}

/* ══════════════════════════════════════════════════════════
   STATUS PANEL
/* ══════════════════════════════════════════════════════════ */
function updateServerStatus(running, ip, port) {
  State.serverRunning = running;

  // V Supabase/cloud módu lokální server není relevantní – panel skryjeme
  if (State.vercelMode) {
    if (Els.statusPanel) Els.statusPanel.style.display = 'none';
    updateHeaderInfo();
    return;
  }

  if (Els.statusPanel) Els.statusPanel.style.display = '';
  Els.dotServer.className = 'status-dot ' + (running ? 'running' : 'stopped');
  Els.statusServer.textContent = running ? 'běží' : 'zastaven';
  Els.statusIp.textContent   = ip   || '–';
  Els.statusPort.textContent = port ? String(port) : '–';

  // Ulož IP pro header badge
  if (ip) State._lastIp = ip;
  updateHeaderInfo();
}

/** Aktualizuje header – přihlášený uživatel + stav připojení */
function updateHeaderInfo() {
  const userEl = document.getElementById('header-username');
  const dotEl  = document.getElementById('header-conn-dot');
  const txtEl  = document.getElementById('header-conn-text');
  const qrEl   = document.getElementById('header-conn-qr');
  if (!userEl || !dotEl || !txtEl) return;

  // Uživatel – zobraz jméno nebo "Nepřihlášen"
  if (State.sbLoggedIn && State.sbEmail) {
    const name = State.sbEmail.includes('@') ? State.sbEmail.split('@')[0] : State.sbEmail;
    userEl.textContent = name;
  } else {
    userEl.textContent = 'Nepřihlášen';
  }

  // Tečka + text + QR ikonka
  if (State.vercelMode) {
    if (State.sbLoggedIn) {
      dotEl.className   = 'conn-dot supabase';
      txtEl.textContent = 'Připojeno k SupaBase';
    } else {
      dotEl.className   = 'conn-dot not-logged-in';
      txtEl.textContent = 'SupaBase – nepřihlášen';
    }
    if (qrEl) qrEl.style.display = '';   // zobraz QR ikonu jen v SupaBase módu
  } else if (State.serverRunning) {
    dotEl.className   = 'conn-dot local';
    const ip = State._lastIp || '';
    txtEl.textContent = ip ? `Připojeno local · ${ip}` : 'Připojeno local';
    if (qrEl) qrEl.style.display = 'none';
  } else {
    dotEl.className   = 'conn-dot stopped';
    txtEl.textContent = 'Server zastaven';
    if (qrEl) qrEl.style.display = 'none';
  }
}

/* ══════════════════════════════════════════════════════════
   STATISTIKY (Phase 9)
/* ══════════════════════════════════════════════════════════ */
function updateStats(stats) {
  if (!stats) return;
  Object.assign(State.stats, stats);
  if (Els.statTotal)    Els.statTotal.textContent    = State.stats.total    ?? 0;
  if (Els.statSession)  Els.statSession.textContent  = State.stats.session  ?? 0;
  if (Els.statJobCount) Els.statJobCount.textContent = State.stats.jobCount ?? 0;
}

/* ══════════════════════════════════════════════════════════
   HISTORIE ZAKÁZEK (Phase 9)
/* ══════════════════════════════════════════════════════════ */
function renderJobHistory(history) {
  if (!history || !history.length) {
    Els.jobHistoryRow.style.display = 'none';
    return;
  }
  Els.jobHistoryRow.style.display = 'flex';
  Els.jobHistory.innerHTML = '';
  history.slice(0, 8).forEach(job => {
    const chip = document.createElement('button');
    chip.className = 'history-chip';
    chip.textContent = job;
    chip.addEventListener('click', () => {
      Els.jobEntry.value = job;
      Els.jobEntry.focus();
    });
    Els.jobHistory.appendChild(chip);
  });
}

/* ══════════════════════════════════════════════════════════
   QR KÓD – vykreslení na canvas
/* ══════════════════════════════════════════════════════════ */

/**
 * Vykreslí QR kód na canvas.
 * Renderer dostane hotová QR data jako 2D pole (0/1) z main procesu.
 * Alternativně main pošle base64 PNG nebo URL s QR kódem.
 */
function renderQrOnCanvas(data) {
  if (!data) return;
  const canvas = Els.qrCanvas;
  const ctx    = canvas.getContext('2d');

  if (data.type === 'png_base64') {
    const img = new Image();
    img.onload = () => {
      const container = Els.qrContainer;
      const maxSide = Math.min(container.clientWidth, container.clientHeight, 360);
      const mod = data.modules || img.naturalWidth;
      const scale = Math.max(1, Math.floor(maxSide / mod));
      const side = mod * scale;
      canvas.width  = side;
      canvas.height = side;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, 0, 0, side, side);
    };
    img.src = 'data:image/png;base64,' + data.base64;
    return;
  }

  if (data.type === 'matrix') {
    const matrix = data.matrix;
    const mod    = matrix.length;
    const container = Els.qrContainer;
    const maxSide   = Math.min(container.clientWidth, container.clientHeight, 360);
    const scale = Math.max(1, Math.floor(maxSide / mod));
    const side  = mod * scale;
    canvas.width  = side;
    canvas.height = side;
    const fill = data.fillColor || '#000000';
    const bg   = data.bgColor   || '#ffffff';
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, side, side);
    ctx.fillStyle = fill;
    for (let r = 0; r < mod; r++) {
      for (let c = 0; c < mod; c++) {
        if (matrix[r][c]) ctx.fillRect(c * scale, r * scale, scale, scale);
      }
    }
    return;
  }

  if (data.type === 'url' && data.url) {
    _renderQrFromUrl(data.url, canvas, ctx);
  }
}

/** Fallback QR renderer pro případ že main nepošle matici */
function _renderQrFromUrl(url, canvas, ctx) {
  _generateQrMatrix(url).then(matrix => {
    if (!matrix) return;
    const mod = matrix.length;
    const container = Els.qrContainer;
    const maxSide = Math.min(container.clientWidth, container.clientHeight, 360);
    const scale = Math.max(1, Math.floor(maxSide / mod));
    const side = mod * scale;
    canvas.width = canvas.height = side;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, side, side);
    ctx.fillStyle = '#000';
    for (let r = 0; r < mod; r++) {
      for (let c = 0; c < mod; c++) {
        if (matrix[r][c]) ctx.fillRect(c * scale, r * scale, scale, scale);
      }
    }
  });
}

/** Minimální QR encoder – Reed-Solomon není potřeba pro typ 1-10 URL */
async function _generateQrMatrix(text) {
  try {
    // Pokud je nainstalován qrcode přes main IPC, použij ho
    const result = await ipc('qr:encode-matrix', { text });
    if (result && result.matrix) return result.matrix;
  } catch (_) {}
  return null;
}

/** Překreslí QR na aktuální velikost okna (volá se při resize) */
function rescaleQr() {
  if (State.view !== 'qr' || !Els.qrCanvas.width) return;
  // Main process pošle nová data znovu – nebo překreslíme z cache
  ipc('qr:rescale');
}

/* ══════════════════════════════════════════════════════════
   QR TIMEOUT / ODPOČET (Phase 9)
/* ══════════════════════════════════════════════════════════ */
function startQrTimeout(expiresAt, totalMinutes) {
  State.tokenExpiry  = expiresAt;
  State.tokenMinutes = totalMinutes || 480;
  _tickTimeout();
  State._timeoutInterval = setInterval(_tickTimeout, 1000);
}

function stopQrTimeout() {
  if (State._timeoutInterval) {
    clearInterval(State._timeoutInterval);
    State._timeoutInterval = null;
  }
  Els.qrTimeoutBar.style.width = '100%';
  Els.qrTimeoutBar.className   = 'timeout-bar';
  Els.qrTimeoutText.textContent = '–';
}

function _tickTimeout() {
  if (!State.tokenExpiry) return;
  const now      = Date.now();
  const remain   = Math.max(0, State.tokenExpiry - now);
  const total    = State.tokenMinutes * 60 * 1000;
  const fraction = remain / total;

  Els.qrTimeoutBar.style.width = (fraction * 100).toFixed(1) + '%';
  Els.qrTimeoutText.textContent = fmtSecs(remain / 1000);

  // Barva pruhu dle zbývajícího času
  Els.qrTimeoutBar.className = 'timeout-bar' +
    (fraction < 0.10 ? ' crit' : fraction < 0.25 ? ' warn' : '');

  if (remain <= 0) {
    stopQrTimeout();
    // Informuj renderer o vypršení QR
    onQrExpired();
  }
}

function onQrExpired() {
  // Pokud je dialog otevřen, necháme ho žít (token stále platný pro PC D&D)
  Els.qrTimeoutText.textContent = 'vypršel';
  // Upozornění Electron main procesu
  ipc('qr:expired');
}

/* ══════════════════════════════════════════════════════════
   VIDITELNOST DROP ZÓNY – závisí na platné zakázce (7 nebo 10 znaků)
/* ══════════════════════════════════════════════════════════ */
function updateDropZoneVisibility() {
  if (!Els.dropZoneMain) return;
  const job = Els.jobEntry ? Els.jobEntry.value.trim() : '';
  const valid = job.length === 7 || job.length === 10;
  Els.dropZoneMain.style.display = (valid && State.view === 'main') ? 'flex' : 'none';
}

/* ══════════════════════════════════════════════════════════
   POLLER STATUS (Phase 9)
/* ══════════════════════════════════════════════════════════ */
function updatePollerStatus(job) {
  const active = !!job;
  State.pollerJob = job || null;

  // Příjem nyní běží AUTOMATICKY na pozadí. Tlačítko Spustit/Zastavit
  // je v HTML skryté – uživatel ho nepotřebuje. Zobrazujeme jen indikátor.
  Els.pollerStatusRow.style.display = State.sbLoggedIn ? 'flex' : 'none';
  if (active) {
    Els.pollerStatusLbl.textContent = job === 'auto'
      ? '🟢  Příjem aktivní – běží automaticky'
      : `🟢  Příjem aktivní – zakázka ${job}`;
  } else if (State.sbLoggedIn) {
    // Přihlášen, ale poller dočasně neběží (síťová chyba apod.) – pojistka
    // v main procesu ho do 30 s znovu nastartuje.
    Els.pollerStatusLbl.textContent = '🟡  Připojuji k Supabase…';
  } else {
    Els.pollerStatusLbl.textContent = '🔴  Příjem neaktivní – přihlas se';
  }

  // Tlačítko schované (kompatibilita: event listener stále existuje)
  if (Els.btnStopPoller) Els.btnStopPoller.style.display = 'none';

  // Drop zóna v hlavním pohledu – zobrazí se když je zadána platná zakázka
  if (Els.dropZoneMain) {
    updateDropZoneVisibility();
  }

  // QR pohled – poller status nezobrazujeme
  Els.qrPollerRow.style.display = 'none';
}

/* ══════════════════════════════════════════════════════════
   SUPABASE STATUS
/* ══════════════════════════════════════════════════════════ */
function updateSbStatus(loggedIn, email, accountType) {
  State.sbLoggedIn = loggedIn;
  State.sbEmail    = email || '';
  // Tlačítka jsou nyní v headeru (user-info-row)
  if (Els.btnSbLogin)  Els.btnSbLogin.style.display  = loggedIn ? 'none' : '';
  if (Els.btnSbLogout) Els.btnSbLogout.style.display = loggedIn ? ''     : 'none';
  updateHeaderInfo();
  // Přizpůsob UI dle typu účtu
  if (accountType || State.sbAccountType) {
    updateAccountTypeUI(accountType || State.sbAccountType);
  }
  // Po přihlášení rovnou ukaž "Příjem aktivní – běží automaticky".
  // Hlavní proces poller automaticky spustí; pokud by selhal, pojistka
  // v _startPollerKeepalive() ho do 30 s znovu nastartuje.
  if (loggedIn) {
    updatePollerStatus('auto');
    // Po prvním přihlášení (i po session restore) zkontroluj SAVE_DIR.
    // Pokud je prázdná, hlavní proces zobrazí dialog s výběrem složky.
    // Krátká prodleva, aby se UI po loginu stihlo vyrenderovat.
    if (!State._saveDirCheckedAfterLogin) {
      State._saveDirCheckedAfterLogin = true;
      setTimeout(() => { ensureSaveDir().catch(() => {}); }, 1200);
    }
  } else {
    Els.pollerStatusRow.style.display = 'none';
    State._saveDirCheckedAfterLogin = false;  // při dalším loginu se znova zkontroluje
  }
}

/* ══════════════════════════════════════════════════════════
   TYP ÚČTU – UI přizpůsobení
/* ══════════════════════════════════════════════════════════ */
function updateAccountTypeUI(accountType) {
  State.sbAccountType = accountType || 'business';
  const isPersonal = State.sbAccountType === 'personal';

  // Pole zakázky – greyed out pro osobní účet
  if (Els.jobEntry) {
    Els.jobEntry.disabled    = isPersonal;
    Els.jobEntry.placeholder = isPersonal ? '(osobní účet – bez zakázky)' : '1234567';
    Els.jobEntry.style.opacity = isPersonal ? '0.4' : '';
  }

  // Tlačítko generovat QR – skryj pro osobní
  if (Els.btnGenerate) {
    Els.btnGenerate.style.display = isPersonal ? 'none' : '';
  }
}


/* ══════════════════════════════════════════════════════════ */
let _tempErrEl = null;
let _tempErrTimer = null;

function showTempError(msg) {
  if (!_tempErrEl) {
    _tempErrEl = document.getElementById('job-error-msg');
  }
  if (!_tempErrEl) {
    _tempErrEl = document.createElement('div');
    _tempErrEl.className = 'temp-error-msg';
    Els.btnGenerate.closest('.job-row').appendChild(_tempErrEl);
  }
  _tempErrEl.textContent = msg;
  _tempErrEl.style.display = 'block';
  if (_tempErrTimer) clearTimeout(_tempErrTimer);
  _tempErrTimer = setTimeout(() => {
    if (_tempErrEl) _tempErrEl.style.display = 'none';
  }, 3500);
}

/* ══════════════════════════════════════════════════════════
   DRAG & DROP – GLOBÁLNÍ (Phase 9)
/* ══════════════════════════════════════════════════════════ */

/** Zkontroluje zda má uživatel aktivní zakázku + platný token */
function hasActiveJob() {
  // Main process ví o platnosti tokenu – ptáme se přes IPC
  // Renderer si drží jen State.job jako hint
  return !!State.job;
}

/**
 * Zajistí platnou zakázku před akcí se soubory.
 * Pokud State.job není nastaven ale v poli je 7 nebo 10 znaků,
 * zakázku automaticky přijme a nastaví State.job – bez generování QR.
 * Vrátí job string nebo null pokud zakázka není platná.
 */
async function ensureJob() {
  if (State.job) return State.job;
  const raw = Els.jobEntry ? Els.jobEntry.value.trim() : '';
  if (raw.length !== 7 && raw.length !== 10) {
    showTempError('Zkontroluj zakázku (7 nebo 10 znaků).');
    Els.jobEntry && Els.jobEntry.classList.add('error');
    return null;
  }
  const sbState = await ipc('supabase:state');
  const usernameOrEmail = (sbState && sbState.email) || '';
  const resolveResult = await ipc('utils:resolve-job', usernameOrEmail, raw);
  if (!resolveResult || !resolveResult.ok) {
    showTempError((resolveResult && resolveResult.error) || 'Neplatná zakázka.');
    Els.jobEntry && Els.jobEntry.classList.add('error');
    return null;
  }
  State.job = resolveResult.job;
  Els.jobEntry && (Els.jobEntry.value = State.job);
  Els.jobEntry && Els.jobEntry.classList.remove('error');
  return State.job;
}

function setupGlobalDragDrop() {
  // Pomocná funkce: je zakázka platná (7 nebo 10 znaků)?
  function hasValidJob() {
    const job = Els.jobEntry ? Els.jobEntry.value.trim() : '';
    return job.length === 7 || job.length === 10;
  }

  // Zachytit dragover na celé stránce
  document.addEventListener('dragover', e => {
    e.preventDefault();

    if (State.view === 'qr' && hasActiveJob()) {
      e.dataTransfer.dropEffect = 'copy';
      Els.dropOverlay.classList.add('visible');
    } else if (State.view === 'main' && hasValidJob()) {
      e.dataTransfer.dropEffect = 'copy';
      document.body.classList.add('global-drag-over');
    } else {
      e.dataTransfer.dropEffect = 'none';
    }
  });

  document.addEventListener('dragleave', e => {
    // Opouštíme okno
    if (e.relatedTarget === null || e.relatedTarget === document.documentElement) {
      Els.dropOverlay.classList.remove('visible');
      document.body.classList.remove('global-drag-over');
    }
  });

  document.addEventListener('drop', e => {
    e.preventDefault();
    Els.dropOverlay.classList.remove('visible');
    document.body.classList.remove('global-drag-over');

    // Zpracovat drop jen pokud je platná zakázka (7 nebo 10 znaků)
    if (State.view === 'main' && !hasValidJob()) return;
    if (State.view !== 'main' && State.view !== 'qr') return;

    const files = Array.from(e.dataTransfer.files).map(f => f.path || f.name);
    if (files.length) {
      handleDroppedFiles(files);
    }
  });

  // Drag & Drop zóna v hlavním pohledu
  Els.dropZoneMain.addEventListener('dragover', e => {
    e.preventDefault();
    Els.dropZoneMain.classList.add('drag-over');
  });
  Els.dropZoneMain.addEventListener('dragleave', () => {
    Els.dropZoneMain.classList.remove('drag-over');
  });
  Els.dropZoneMain.addEventListener('drop', e => {
    e.preventDefault();
    Els.dropZoneMain.classList.remove('drag-over');
    const files = Array.from(e.dataTransfer.files).map(f => f.path || f.name);
    if (files.length) handleDroppedFiles(files);
  });

  // Kliknutí na drop zónu v QR pohledu = pravé tlačítko / manuální výběr
  Els.qrContainer.addEventListener('contextmenu', () => openManualSelect());
}

/** Zpracuje přetažené soubory (validace + otevření upload okna) */
async function handleDroppedFiles(paths) {
  const job = await ensureJob();
  if (!job) return;
  const result = await ipc('files:drop', { paths, job });
  if (!result) return;
  if (result.error) { showTempError(result.error); return; }
  if (result.files && result.files.length) {
    openDragDropDialog(result.files, result.job || State.job);
  }
}

/* ══════════════════════════════════════════════════════════
   DRAG & DROP DIALOG (Phase 9) – samostatné BrowserWindow
/* ══════════════════════════════════════════════════════════ */

const TYPE_CHOICES = ['SD', 'SDX', 'VT', 'SP', 'SN'];
const TYPE_LABELS  = { SD: 'SD', SDX: 'SDX', VT: 'VT', SP: 'SP (Paint)', SN: 'SN' };

// Video/PDF typy neumožňují Paint
const NO_PAINT_EXTS = ['.mp4', '.mov', '.m4v', '.avi', '.mkv', '.webm', '.pdf'];

/** Pole { path, type, openPaint } pro aktuálně otevřený dialog */
let _dialogFiles = [];

/** Otevře samostatné upload okno (nebo přidá soubory do existujícího) */
function openDragDropDialog(files, job) {
  State.job = job || State.job;
  ipc('upload:open', { files, job: State.job });
}

/** Přidá další soubory do již otevřeného upload okna */
function addFilesToDialog(files) {
  ipc('upload:open', { files, job: State.job });
}

/** Vrátí thumbnail element – obrázek nebo placeholder s emoji */
function makeThumb(filePath, ext) {
  const IMG_EXTS = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'];
  if (IMG_EXTS.includes(ext)) {
    const img = document.createElement('img');
    img.className = 'file-thumb';
    img.alt = '';
    // Electron umožňuje file:// pro lokální soubory
    try { img.src = 'file://' + filePath.replace(/\\/g, '/'); } catch (_) {}
    img.onerror = () => {
      const ph = document.createElement('div');
      ph.className = 'file-thumb-placeholder';
      ph.textContent = '🖼';
      img.replaceWith(ph);
    };
    return img;
  }
  const ph = document.createElement('div');
  ph.className = 'file-thumb-placeholder';
  const ICONS = { '.mp4': '🎬', '.mov': '🎬', '.m4v': '🎬', '.avi': '🎬',
                  '.mkv': '🎬', '.webm': '🎬', '.pdf': '📄' };
  ph.textContent = ICONS[ext] || '📎';
  return ph;
}

function renderFileList() {
  Els.fileList.innerHTML = '';
  _dialogFiles.forEach((item, idx) => {
    const ext = (item.path.match(/\.[^.]+$/) || [''])[0].toLowerCase();
    const name = basename(item.path);
    const noPaint = NO_PAINT_EXTS.includes(ext);
    const paintForced = item.type === 'SP';

    const row = document.createElement('div');
    row.className = 'file-row';

    // Thumbnail
    row.appendChild(makeThumb(item.path, ext));

    // Název
    const nameDiv = document.createElement('div');
    nameDiv.className = 'file-name';
    nameDiv.title = item.path;
    const badge = document.createElement('span');
    badge.className = 'file-ext-badge';
    badge.textContent = ext.replace('.', '') || '?';
    nameDiv.appendChild(badge);
    nameDiv.appendChild(document.createTextNode(name.replace(/\.[^.]+$/, '')));

    // Typ select
    const sel = document.createElement('select');
    sel.className = 'type-select';
    TYPE_CHOICES.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t;
      opt.textContent = TYPE_LABELS[t] || t;
      if (t === item.type) opt.selected = true;
      sel.appendChild(opt);
    });
    sel.addEventListener('change', () => {
      _dialogFiles[idx].type = sel.value;
      renderFileList();
    });

    // Paint checkbox
    const paintDiv = document.createElement('div');
    paintDiv.className = 'paint-checkbox' + (paintForced ? ' forced' : '');
    if (!paintForced) {
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = item.openPaint;
      cb.disabled = noPaint;
      cb.title = noPaint ? 'Nelze otevřít v Malování' : 'Otevřít v Malování';
      cb.addEventListener('change', () => { _dialogFiles[idx].openPaint = cb.checked; });
      paintDiv.appendChild(cb);
    }

    // Smazat řádek
    const delBtn = document.createElement('button');
    delBtn.className = 'btn-row-delete';
    delBtn.title = 'Odebrat soubor';
    delBtn.textContent = '✕';
    delBtn.addEventListener('click', () => {
      _dialogFiles.splice(idx, 1);
      if (!_dialogFiles.length) { closeDragDropDialog(); return; }
      renderFileList();
    });

    row.appendChild(nameDiv);
    row.appendChild(sel);
    row.appendChild(paintDiv);
    row.appendChild(delBtn);
    Els.fileList.appendChild(row);
  });
}

function closeDragDropDialog() {
  Els.modalOverlay.style.display = 'none';
  _dialogFiles = [];
  const bulkSel = $('bulk-type-select');
  if (bulkSel) bulkSel.value = '';
}

async function confirmDragDropDialog() {
  if (!_dialogFiles.length) { closeDragDropDialog(); return; }

  const payload = _dialogFiles.map(f => ({
    path:      f.path,
    type:      f.type,
    openPaint: f.type === 'SP' || f.openPaint,
  }));

  closeDragDropDialog();

  // Předáme do main procesu – ten provede ukládání souborů
  const result = await ipc('files:save', { files: payload, job: State.job });

  if (result && result.saved) {
    showToast(result.saved);
    // Obnovit stats
    if (result.stats) updateStats(result.stats);
  } else if (result && result.error) {
    showTempError('Chyba ukládání: ' + result.error);
  }
}

/* ══════════════════════════════════════════════════════════
   MANUÁLNÍ VÝBĚR SOUBORŮ (Phase 9)
/* ══════════════════════════════════════════════════════════ */
async function openManualSelect() {
  const job = await ensureJob();
  if (!job) return;
  const result = await ipc('files:manual-select', { job });
  if (!result) return;
  if (result.error) { showTempError(result.error); return; }
  if (result.files && result.files.length) {
    // Pokud je dialog otevřen, přidáme do něj
    if (Els.modalOverlay.style.display !== 'none') {
      addFilesToDialog(result.files);
    } else {
      openDragDropDialog(result.files, result.job || State.job);
    }
  }
}

/* ── Vložení obrázku ze schránky (PrintScreen / Ctrl+V) ── */
async function pasteFromClipboard() {
  const job = await ensureJob();
  if (!job) return;
  const result = await ipc('files:clipboard-paste', { job });
  if (!result) return;
  if (result.error) { showTempError(result.error); return; }
  if (result.files && result.files.length) {
    if (Els.modalOverlay.style.display !== 'none') {
      addFilesToDialog(result.files);
    } else {
      openDragDropDialog(result.files, result.job || State.job);
    }
  }
}


/* ══════════════════════════════════════════════════════════
   TOAST NOTIFIKACE (Phase 9)
/* ══════════════════════════════════════════════════════════ */
let _toastTimer = null;

function showToast(savedFiles) {
  if (!savedFiles || !savedFiles.length) return;

  Els.toastTitle.textContent = `✅  Uloženo ${savedFiles.length} ${
    savedFiles.length === 1 ? 'soubor' : 'souborů'
  }`;

  Els.toastFiles.innerHTML = '';
  const display = savedFiles.slice(0, 10);
  display.forEach(name => {
    const line = document.createElement('div');
    line.textContent = basename(name);
    Els.toastFiles.appendChild(line);
  });
  if (savedFiles.length > 10) {
    const more = document.createElement('div');
    more.style.color = 'var(--text-3)';
    more.textContent = `… a dalších ${savedFiles.length - 10}`;
    Els.toastFiles.appendChild(more);
  }

  Els.toast.style.display = 'flex';
  Els.toast.classList.remove('hiding');
  void Els.toast.offsetWidth; // reflow pro re-trigger animace

  if (_toastTimer) clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => hideToast(), 7000);
}

function hideToast() {
  Els.toast.classList.add('hiding');
  setTimeout(() => {
    Els.toast.style.display = 'none';
    Els.toast.classList.remove('hiding');
  }, 200);
}

/* ══════════════════════════════════════════════════════════
   SUPABASE LOGIN DIALOG (Phase 9)
/* ══════════════════════════════════════════════════════════ */
let _loginMode    = 'login';    // 'login' | 'register'
let _loginResolve = null;       // Promise resolve pro čekání na výsledek z login okna

// Přijmi výsledek přihlášení z login okna (posílá login-window.js přes ipcRenderer)
window.electronAPI && window.electronAPI.on && window.electronAPI.on('login:result', (result) => {
  if (!_loginResolve) return;
  if (result && result.ok) {
    const at = result.accountType || 'business';
    State.sbAccountType = at;
    updateAccountTypeUI(at);
    _loginResolve(true);
  } else {
    _loginResolve(false);
  }
  _loginResolve = null;
});

function openLoginDialog() {
  return new Promise(resolve => {
    if (_loginResolve) _loginResolve(false); // zruš případný čekající
    _loginResolve = resolve;
    ipc('login:open', { parentId: null });
  });
}

function closeLoginDialog(ok) {
  // Prázdná stub — zavírání řeší login-window.js
  if (_loginResolve) { _loginResolve(ok); _loginResolve = null; }
}

/* ══════════════════════════════════════════════════════════
   GENEROVÁNÍ QR KÓDU (Fáze 8 + 9)
/* ══════════════════════════════════════════════════════════ */
async function generateQr() {
  // Zjistit username přihlášeného uživatele
  const sbState = await ipc('supabase:state');
  const usernameOrEmail = (sbState && sbState.email) || '';

  // resolveJob – doma profil dostane auto-zakázku, standardní vyžaduje 7 nebo 10 znaků
  const resolveResult = await ipc('utils:resolve-job', usernameOrEmail, Els.jobEntry.value.trim());
  if (!resolveResult || !resolveResult.ok) {
    showTempError((resolveResult && resolveResult.error) || 'Zkontroluj zakázku (7 nebo 10 znaků).');
    Els.jobEntry.classList.add('error');
    return;
  }
  const resolvedJob = resolveResult.job;

  // Pro _doma profil auto-doplníme pole zakázky
  if (resolvedJob !== Els.jobEntry.value.trim()) {
    Els.jobEntry.value = resolvedJob;
  }
  Els.jobEntry.classList.remove('error');

  // Supabase / Vercel mód → zkontroluj přihlášení
  const cfg = await ipc('config:get');
  const vercelUrl = (cfg && cfg.VERCEL_URL || '').trim();
  if (vercelUrl) {
    if (sbState && !sbState.loggedIn) {
      const ok = await openLoginDialog();
      if (!ok) return;
    }
  }

  Els.btnGenerate.disabled = true;

  const result = await ipc('qr:generate', { job: resolvedJob });

  Els.btnGenerate.disabled = false;

  if (!result) { showTempError('Generování selhalo.'); return; }
  if (result.error) { showTempError(result.error); return; }

  // Přepneme na QR pohled
  State.job = resolvedJob;
  showView('qr');

  // Vykreslíme QR – requestAnimationFrame zajistí, že layout je vypočítaný
  // (container.clientHeight by byl 0 kdybychom volali synchronně)
  if (result.qrData) {
    const _qrDataToRender = result.qrData;
    requestAnimationFrame(() => renderQrOnCanvas(_qrDataToRender));
  }

  // URL pod QR
  Els.qrUrlText.textContent = result.url || '';
  State.qrUrl = result.url || '';

  // Spustíme QR timeout odpočet
  if (result.expiresAt) {
    startQrTimeout(result.expiresAt, result.tokenMinutes);
  }

  // Spustíme session timer (20 min)
  startSessionTimer();

  // Titulek okna
  ipc('window:setTitle', `PhotoBridge – ${resolvedJob}`);

  // Notify main pro tray menu
  ipc('tray:updateMenu', { job: resolvedJob, qrActive: true });
}

/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – ZÁHLAVÍ
/* ══════════════════════════════════════════════════════════ */
Els.btnHelp.addEventListener('click',     () => ipc('help:open'));
Els.btnSettings.addEventListener('click', () => ipc('settings:open'));

// Vyplnit zakázku z okna nestažených zakázek
if (api.on) {
  api.on('pending:fill-job', (job) => {
    if (Els.jobEntry) {
      Els.jobEntry.value = job;
      Els.jobEntry.focus();
      Els.jobEntry.classList.remove('error');
    }
  });
}

/* ══════════════════════════════════════════════════════════
   NASTAVENÍ DIALOG
/* ══════════════════════════════════════════════════════════ */
let _settingsMode = 'local'; // 'local' | 'supabase'

function _settingsEl(id) { return document.getElementById(id); }

function _updateSettingsModeUI(mode) {
  _settingsMode = mode;
  _settingsEl('cfg-mode-local').classList.toggle('active', mode === 'local');
  _settingsEl('cfg-mode-supabase').classList.toggle('active', mode === 'supabase');
  const localOnly = ['row-qr-ip', 'row-port'];
  localOnly.forEach(id => {
    const el = _settingsEl(id);
    if (el) el.style.display = mode === 'local' ? '' : 'none';
  });
}

async function openSettingsDialog() {
  const cfg = await ipc('config:get');
  if (!cfg) return;

  // Detekuj aktuální mode: supabase pokud je VERCEL_URL nastavena
  const mode = (cfg.VERCEL_URL || '').trim() ? 'supabase' : 'local';
  _updateSettingsModeUI(mode);

  _settingsEl('cfg-save-dir').value  = cfg.SAVE_DIR     || '';
  _settingsEl('cfg-port').value      = cfg.PORT         || '5000';
  _settingsEl('cfg-theme').value     = cfg.THEME_MODE   || 'auto_windows';
  _settingsEl('cfg-max-img').value   = cfg.MAX_IMG_MB   || '3';
  _settingsEl('cfg-max-video').value = cfg.MAX_VIDEO_MB || '30';
  _settingsEl('cfg-qr-ip').value     = cfg.QR_IP_SELECTED || '';

  // Načti seznam dostupných IP adres
  const ips = await ipc('utils:get-local-ips') || [];
  const sel = _settingsEl('cfg-qr-ip-select');
  if (sel) {
    sel.innerHTML = '<option value="">— vybrat ze seznamu —</option>';
    ips.forEach(ipLabel => {
      const ip = ipLabel.split('  ')[0].trim();
      const opt = document.createElement('option');
      opt.value = ip;
      opt.textContent = ipLabel;
      if (ip === cfg.QR_IP_SELECTED) opt.selected = true;
      sel.appendChild(opt);
    });
    sel.onchange = () => {
      if (sel.value) _settingsEl('cfg-qr-ip').value = sel.value;
    };
  }

  _settingsEl('settings-status').textContent = '';
  _settingsEl('settings-overlay').style.display = 'flex';
}

function closeSettingsDialog() {
  _settingsEl('settings-overlay').style.display = 'none';
}

_settingsEl('cfg-mode-local')?.addEventListener('click', () => _updateSettingsModeUI('local'));
_settingsEl('cfg-mode-supabase')?.addEventListener('click', () => _updateSettingsModeUI('supabase'));

_settingsEl('btn-settings-close')?.addEventListener('click', closeSettingsDialog);
_settingsEl('btn-settings-cancel')?.addEventListener('click', closeSettingsDialog);

_settingsEl('btn-pick-save-dir')?.addEventListener('click', async () => {
  const dir = await ipc('ipc:dialog:select-folder');
  if (dir) _settingsEl('cfg-save-dir').value = dir;
});

_settingsEl('btn-settings-save')?.addEventListener('click', async () => {
  const qrIp = _settingsEl('cfg-qr-ip').value.trim();
  const partial = {
    SAVE_DIR:        _settingsEl('cfg-save-dir').value.trim(),
    PORT:            _settingsEl('cfg-port').value.trim(),
    THEME_MODE:      _settingsEl('cfg-theme').value,
    MAX_IMG_MB:      _settingsEl('cfg-max-img').value.trim(),
    MAX_VIDEO_MB:    _settingsEl('cfg-max-video').value.trim(),
    QR_IP_SELECTED:  qrIp,
    // Přepínač mode: pokud supabase, nastav VERCEL_URL; pokud local, vymaz ho
    VERCEL_URL: _settingsMode === 'supabase'
      ? 'https://photobridge-two.vercel.app'
      : '',
  };
  await ipc('ipc:config:set', partial);
  _settingsEl('settings-status').textContent = '✅ Uloženo';
  _settingsEl('settings-status').style.color = 'var(--pb-ok)';
  setTimeout(closeSettingsDialog, 700);
});

// Nastavení se nyní otvírají jako samostatné BrowserWindow přes settings-window.js
// onMain('settings:open', ...) již není potřeba – okno otevírá main proces sám




/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – ZAKÁZKA
/* ══════════════════════════════════════════════════════════ */
Els.jobEntry.addEventListener('keydown', e => {
  if (e.key === 'Enter') generateQr();
});
// Povolíme libovolné znaky (číslice, písmena, speciální), max 10 znaků
Els.jobEntry.addEventListener('input', () => {
  Els.jobEntry.value = Els.jobEntry.value.slice(0, 10);
  Els.jobEntry.classList.remove('error');
  updateDropZoneVisibility();
});

Els.btnGenerate.addEventListener('click', generateQr);

/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – SUPABASE / POLLER
/* ══════════════════════════════════════════════════════════ */
Els.btnSbLogin.addEventListener('click', async () => {
  await openLoginDialog();
  const st = await ipc('supabase:state');
  if (st) updateSbStatus(st.loggedIn, st.email);
});

Els.btnSbLogout.addEventListener('click', async () => {
  cancelSessionTimer();
  await ipc('supabase:logout');
  updateSbStatus(false);
});

Els.btnStopPoller.addEventListener('click', async () => {
  if (State.pollerJob) {
    // ── Zastavit příjem ──────────────────────────────────────
    cancelSessionTimer();
    await ipc('supabase:stop-poller');
    updatePollerStatus(null);
    ipc('window:setTitle', 'PhotoBridge');
    ipc('tray:updateMenu', { job: null, qrActive: false });
  } else {
    // ── Spustit příjem ───────────────────────────────────────
    const sbState = await ipc('supabase:state');
    const usernameOrEmail = (sbState && sbState.email) || '';
    const jobVal = Els.jobEntry ? Els.jobEntry.value.trim() : '';

    if (State.sbAccountType === 'personal' || !jobVal) {
      // Osobní účet nebo prázdná zakázka → auto mód
      await ipc('supabase:start-poller', {});
      updatePollerStatus('auto');
      startSessionTimer();
      ipc('window:setTitle', 'PhotoBridge  [příjem]');
    } else {
      const resolveResult = await ipc('utils:resolve-job', usernameOrEmail, jobVal);
      if (!resolveResult || !resolveResult.ok) {
        showTempError((resolveResult && resolveResult.error) || 'Zkontroluj zakázku (7 nebo 10 znaků).');
        return;
      }
      const job = resolveResult.job;
      await ipc('supabase:start-poller', { job });
      updatePollerStatus(job);
      startSessionTimer();
      ipc('window:setTitle', `PhotoBridge – ${job}  [příjem]`);
      ipc('tray:updateMenu', { job, qrActive: false });
    }
  }
});

Els.btnStartPoller && Els.btnStartPoller.addEventListener('click', async () => {
  // Zjistit username přihlášeného uživatele
  const sbState = await ipc('supabase:state');
  const usernameOrEmail = (sbState && sbState.email) || '';

  const resolveResult = await ipc('utils:resolve-job', usernameOrEmail, Els.jobEntry.value.trim());
  if (!resolveResult || !resolveResult.ok) {
    showTempError((resolveResult && resolveResult.error) || 'Zkontroluj zakázku (7 nebo 10 znaků).');
    return;
  }
  const job = resolveResult.job;

  await ipc('supabase:start-poller', { job });
  updatePollerStatus(job);
  startSessionTimer();
  ipc('window:setTitle', `PhotoBridge – ${job}  [příjem]`);
});

/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – QR POHLED
/* ══════════════════════════════════════════════════════════ */
Els.btnBackFromQr.addEventListener('click', () => {
  stopQrTimeout();
  cancelSessionTimer();
  showView('main');
  ipc('window:setTitle', 'PhotoBridge');
  ipc('tray:updateMenu', { job: null, qrActive: false });
});

// Dvojklik na QR kód = zpět
Els.qrContainer.addEventListener('dblclick', () => {
  Els.btnBackFromQr.click();
});

// Tlačítko zpět na myši (button 3) = zpět
document.addEventListener('mousedown', e => {
  if (e.button === 3 && State.view === 'qr') {
    e.preventDefault();
    Els.btnBackFromQr.click();
  }
});

// Klik na hodiny = prodloužení tokenu o 20 minut
if (Els.btnTimerQr) {
  Els.btnTimerQr.addEventListener('click', async () => {
    const result = await ipc('server:extend-token', { minutes: 20 });
    if (result && result.ok) {
      startQrTimeout(result.expiresAt, result.tokenMinutes);
      startSessionTimer();
    }
  });
}

Els.btnCopyUrl.addEventListener('click', () => {
  if (State.qrUrl) {
    // Otevři URL v externím prohlížeči (stejné jako QR kód)
    ipc('shell:openExternal', State.qrUrl).catch(() => {});
    // Zkopíruj také do schránky
    navigator.clipboard.writeText(State.qrUrl).catch(() => {
      ipc('clipboard:write', State.qrUrl);
    });
  }
});

// qr-url-text je teď uvnitř btn-copy-url, klik otevře URL (propagace na btn zajistí i kopírování)
Els.qrUrlText.addEventListener('click', (e) => {
  e.stopPropagation(); // nezapnout copy, jen otevřít
  if (State.qrUrl) ipc('shell:openExternal', State.qrUrl);
});

Els.btnManualSelectQr.addEventListener('click', () => openManualSelect());
// Klik kamkoliv do drop zóny QR pohledu otevře výběr souborů
$('drop-zone-qr') && $('drop-zone-qr').addEventListener('click', (e) => {
  if (e.target.closest('#btn-clipboard-paste-qr')) return;
  openManualSelect();
});
// Klik kamkoliv do drop zóny otevře výběr souborů (kromě PrintScreen tlačítka)
$('drop-zone-main') && $('drop-zone-main').addEventListener('click', (e) => {
  if (e.target.closest('#btn-clipboard-paste-main')) return; // PrintScreen má vlastní handler
  openManualSelect();
});

// PrintScreen tlačítka
$('btn-clipboard-paste-qr')  && $('btn-clipboard-paste-qr').addEventListener('click', () => pasteFromClipboard());
$('btn-clipboard-paste-main') && $('btn-clipboard-paste-main').addEventListener('click', () => pasteFromClipboard());

// Ctrl+V (nebo Ctrl+Shift+V) – vložení ze schránky globálně
document.addEventListener('keydown', e => {
  if (e.key === 'v' && (e.ctrlKey || e.metaKey) && !e.shiftKey) {
    // Nepřepisujeme paste v textových polích
    const tag = document.activeElement && document.activeElement.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    e.preventDefault();
    pasteFromClipboard();
  }
});


/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – DRAG & DROP DIALOG
/* ══════════════════════════════════════════════════════════ */
Els.btnModalClose.addEventListener('click',   closeDragDropDialog);
Els.btnModalCancel.addEventListener('click',  closeDragDropDialog);
Els.btnModalConfirm.addEventListener('click', confirmDragDropDialog);

Els.modalOverlay.addEventListener('click', e => {
  if (e.target === Els.modalOverlay) closeDragDropDialog();
});

Els.btnAddMoreFiles.addEventListener('click', openManualSelect);

// Hromadný výběr typu pro všechny soubory
const bulkTypeSel = $('bulk-type-select');
if (bulkTypeSel) {
  bulkTypeSel.addEventListener('change', () => {
    const val = bulkTypeSel.value;
    if (!val) return;
    _dialogFiles.forEach(f => {
      f.type = val;
      // SP vždy otvírá Paint
      if (val === 'SP') f.openPaint = true;
    });
    renderFileList();
    // neresetujeme výběr – uživatel vidí co vybral
  });
}

/* ══════════════════════════════════════════════════════════
   EVENT LISTENERY – TOAST
/* ══════════════════════════════════════════════════════════ */
Els.btnToastDismiss.addEventListener('click', hideToast);

/* ══════════════════════════════════════════════════════════
   KLÁVESOVÉ ZKRATKY
/* ══════════════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  // Escape = zavřít modál nebo QR pohled
  if (e.key === 'Escape') {
    if (Els.loginOverlay.style.display !== 'none') { closeLoginDialog(false); return; }
    if (Els.modalOverlay.style.display !== 'none') { closeDragDropDialog();  return; }
    if (State.view === 'qr') {
      Els.btnBackFromQr.click();
    }
  }
});

/* ══════════════════════════════════════════════════════════
   IPC EVENTS Z MAIN PROCESU → RENDERER (Phase 9)
/* ══════════════════════════════════════════════════════════ */

/** Zaregistruje event listener přes preload.js */
function onMain(channel, handler) {
  if (api.on) api.on(channel, handler);
}

// Stav serveru se změnil
onMain('server:status', (data) => {
  updateServerStatus(data.running, data.ip, data.port);
});

// Nová QR data (např. po rescale nebo refresh)
onMain('qr:data', (data) => {
  renderQrOnCanvas(data);
});

// Token vypršel v main procesu
onMain('qr:tokenExpired', () => {
  stopQrTimeout();
  Els.qrTimeoutText.textContent = 'vypršel';
});

// Soubor přijat přes mobil nebo Supabase
onMain('file:received', (data) => {
  State.stats.session = (State.stats.session || 0) + 1;
  State.stats.total   = (State.stats.total   || 0) + 1;
  Els.statSession.textContent = State.stats.session;
  Els.statTotal.textContent   = State.stats.total;
  // Toast pro každý nový soubor
  showToast([data.name || data.path]);
});

// Příjem fotek z mobilního telefonu přes QR server → otevře upload okno
onMain('server:upload-received', (data) => {
  if (!data || !data.files || !data.files.length) return;
  openDragDropDialog(data.files, data.job || State.job);
});

// Hromadná aktualizace statistik
onMain('stats:update', updateStats);

// Aktualizace poller status (job se vyplní jen pokud poller skutečně běží)
onMain('poller:status', (data) => {
  if (data && data.running === false) {
    updatePollerStatus(null);
  } else {
    updatePollerStatus(data ? data.job : null);
  }
});

// Supabase stav se změnil
onMain('supabase:status', (data) => {
  updateSbStatus(data.loggedIn, data.email, data.accountType);
});

// Main požaduje otevření login dialogu
onMain('supabase:requestLogin', async () => {
  const ok = await openLoginDialog();
  ipc('supabase:loginResult', { ok });
});

// Historie zakázek
onMain('jobHistory:update', (data) => {
  renderJobHistory(data.history);
});

// Tray – "Zobrazit QR" (z tray menu)
onMain('tray:showQr', () => {
  if (State.view !== 'qr') showView('qr');
});

// Okno obnoveno ze tray nebo plovoucího okna – zaměři pole zakázky
onMain('window:restored', () => {
  if (State.view === 'main') {
    setTimeout(() => {
      if (Els.jobEntry) {
        Els.jobEntry.focus();
        Els.jobEntry.select();
      }
    }, 150);
  }
});

// Minimalizace do tray → skryjeme okno přes IPC
onMain('window:minimize', () => {
  ipc('window:hideToTray');
});

// Vercel mód přepínání
onMain('config:vercelMode', (data) => {
  State.vercelMode = !!data.vercelMode;
  // Skryj/ukáž server status panel podle módu
  updateServerStatus(State.serverRunning, null, null);
  // vercelPollerRow odstraněn – btn-start-poller-main je vždy viditelný
  // sbStatusRow odstraněn – login/logout jsou v headeru
});

// Soubory přetaženy přes Electron (windnd / native DnD mimo prohlížeč)
onMain('files:nativeDrop', async (data) => {
  if (data.files && data.files.length) {
    handleDroppedFiles(data.files);
  }
});

/* ══════════════════════════════════════════════════════════
   ONBOARDING PRŮVODCE (Tour) – nyní v SAMOSTATNÉM OKNĚ
/* ══════════════════════════════════════════════════════════ */
// Tour je realizována jako samostatné BrowserWindow (src/renderer/tour.html),
// které řídí hlavní okno přes IPC eventy 'tour:set-view' a 'tour:highlight'.
// Renderer hlavního okna pouze poslouchá tyto eventy.
const Tour = {
  start() { ipc('tour:start').catch(() => {}); },
  finish() { ipc('tour:finish').catch(() => {}); },
  init()  { /* nic – staré DOM listenery už nejsou potřeba */ },
  goTo()  { /* obsluhuje samostatné okno */ },
};

// Hlavní okno reaguje na pokyny z Tour okna:
//  - tour:set-view  → přepni zobrazení (main / qr)
//  - tour:highlight → zvýrazni DOM prvek pulzujícím outline
let _tourHighlightEl = null;
let _tourHighlightTimer = null;

function _clearTourHighlight() {
  if (_tourHighlightEl) {
    _tourHighlightEl.classList.remove('tour-pulse-highlight');
    _tourHighlightEl = null;
  }
  if (_tourHighlightTimer) {
    clearTimeout(_tourHighlightTimer);
    _tourHighlightTimer = null;
  }
}

onMain('tour:set-view', (view) => {
  _clearTourHighlight();
  if (view === 'qr' || view === 'main') {
    try { showView(view); } catch (_) {}
  }
});

onMain('tour:highlight', (elementId) => {
  _clearTourHighlight();
  if (!elementId) return;
  const target = document.getElementById(elementId);
  if (!target) return;
  // Scroll do pohledu, pak přidej pulzující třídu (CSS níže)
  try { target.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
  target.classList.add('tour-pulse-highlight');
  _tourHighlightEl = target;
  // Po 8s pulz vypneme (nebo dřív při dalším kroku)
  _tourHighlightTimer = setTimeout(() => _clearTourHighlight(), 8000);
});

// Hlavní proces vyzve renderer aby zobrazil dialog pro výběr SAVE_DIR
// (typicky po startu, když SAVE_DIR není v configu nastavena).
onMain('app:request-ensure-save-dir', () => {
  ensureSaveDir().catch(() => {});
});

// Helper: vyvolá kontrolu SAVE_DIR. Hlavní proces vrátí buď ok (cesta je
// nastavena nebo uživatel vybral novou), nebo canceled (nechce teď nastavovat).
async function ensureSaveDir() {
  try {
    const result = await ipc('app:ensure-save-dir');
    if (result && result.ok && !result.alreadySet) {
      // Uživatel zrovna vybral novou cestu – krátká vizuální zpětná vazba
      try {
        if (typeof showTempError === 'function') {
          showTempError('✅ Složka pro fotky uložena: ' + (result.path || ''));
        }
      } catch (_) {}
    }
    return result;
  } catch (e) {
    console.warn('ensureSaveDir failed', e);
    return { ok: false, error: String(e) };
  }
}

// Demo QR view – vyplní pole zakázky demo číslem, vygeneruje QR, přepne view
let _tourSavedJob = null;
onMain('tour:demo-qr', async () => {
  _clearTourHighlight();
  try {
    if (Els.jobEntry) {
      _tourSavedJob = Els.jobEntry.value || '';
      Els.jobEntry.value = '1234567';   // demo zakázka
    }
    // Spusť generování QR – přepne na QR view a vyrenderuje QR kód
    if (typeof generateQr === 'function') {
      await generateQr();
    }
  } catch (e) { console.warn('tour:demo-qr selhalo', e); }
});

// Návrat z QR view zpět na hlavní + obnovit původní zakázku
onMain('tour:demo-qr-end', () => {
  try {
    showView('main');
    if (Els.jobEntry && _tourSavedJob !== null) {
      Els.jobEntry.value = _tourSavedJob;
      _tourSavedJob = null;
    }
  } catch (_) {}
});

// Demo upload dialog – otevře dialog s prázdnou tabulkou (žádné soubory)
// Uživatel uvidí jak okno vypadá, ale nic nenahraje.
onMain('tour:demo-upload', () => {
  _clearTourHighlight();
  try {
    // upload:open IPC otevře okno – pošleme prázdné pole souborů s "demo" jobem
    ipc('upload:open', {
      files: [],
      job:   State.job || '1234567',
      tourDemo: true,   // flag pro upload-window aby věděl že nic nemá ukládat
    });
  } catch (e) { console.warn('tour:demo-upload selhalo', e); }
});

/* ── Naslouchej příkazu z main procesu (Settings → Znovu spustit) ─ */
onMain('tour:start', () => Tour.start());

// Demo přihlášení – tour ukáže přihlašovací okno jako součást prohlídky
onMain('tour:demo-login', () => {
  try {
    ipc('login:open', { parentId: null });
  } catch (_) {}
});

// Konec prohlídky – vymaž zvýraznění a vrať se na hlavní view
onMain('tour:ended', () => {
  _clearTourHighlight();
  try { showView('main'); } catch (_) {}
});

async function init() {
  // Načti aktuální stav z main procesu
  const appState = await ipc('app:getState');
  if (!appState) return;

  // Motiv (dark/light) – aplikuj z configu
  const cfg = await ipc('config:get');
  if (cfg && cfg.THEME_MODE && window.PBTheme) {
    PBTheme.applyFromConfig(cfg);
  } else {
    const theme = appState.theme || 'light';
    document.documentElement.setAttribute('data-theme', theme);
  }

  // Vercel/Supabase mód – musí být nastaveno PŘED updateServerStatus
  State.vercelMode = !!appState.vercelMode;
  if (State.vercelMode) {
    // vercelPollerRow a sbStatusRow odstraněny – funkce jsou v headeru a btn-start-poller-main
  }

  // Stav serveru (používá State.vercelMode – proto až tady)
  updateServerStatus(appState.serverRunning, appState.ip, appState.port);

  // Statistiky
  updateStats(appState.stats);

  // Historie zakázek
  renderJobHistory(appState.jobHistory);

  // Supabase
  if (appState.sbLoggedIn !== undefined) {
    updateSbStatus(appState.sbLoggedIn, appState.sbEmail, appState.sbAccountType);
  }

  // Poller – zobraz reálný stav (pollerRunning přichází z hlavního procesu)
  if (appState.pollerRunning) {
    updatePollerStatus(appState.pollerJob || 'auto');
  } else if (appState.sbLoggedIn) {
    // Přihlášen, ale poller neběží → zobraz "Příjem neaktivní"
    updatePollerStatus(null);
  }

  // Zaregistruj globální drag & drop
  setupGlobalDragDrop();

  // Inicializuj tour event listenery
  Tour.init();

  // QR ikonka v headeru → otevři popup okno s QR kódem pro webovou aplikaci
  const _connQrBtn = document.getElementById('header-conn-qr');
  if (_connQrBtn) {
    _connQrBtn.addEventListener('click', (e) => {
      e.preventDefault();
      ipc('webapp-qr:open', { job: State.job || '' });
    });
  }

  // Fokus na pole zakázky
  function refocusJobEntry() {
    if (State.view === 'main' && Els.jobEntry && !Els.jobEntry.disabled) {
      Els.jobEntry.focus();
    }
  }
  // Opakovaně se pokoušej o fokus dokud se nepovede (async init může trvat déle)
  let _focusAttempts = 0;
  function tryFocus() {
    if (document.activeElement === Els.jobEntry) return;
    refocusJobEntry();
    _focusAttempts++;
    if (_focusAttempts < 10) setTimeout(tryFocus, 200);
  }
  setTimeout(tryFocus, 200);

  // Znovu fokus při přepnutí zpět do okna
  window.addEventListener('focus', refocusJobEntry);

  // Znovu fokus při kliknutí kamkoliv mimo interaktivní prvek
  document.addEventListener('mousedown', e => {
    const interactive = e.target.closest('button, input, select, a, [tabindex]');
    if (!interactive) {
      setTimeout(refocusJobEntry, 0);
    }
  });

  // Nastav resize handler pro QR překreslení
  window.addEventListener('resize', () => {
    if (State.view === 'qr') rescaleQr();
  });

  // Spusť onboarding při prvním spuštění
  try {
    const cfg = await ipc('config:get');
    if (!cfg || cfg.ONBOARDING_DONE !== 'true') {
      setTimeout(() => Tour.start(), 400);
    }
  } catch (_) {}

  // ── Auto-otevření přihlašovacího okna ─────────────────────
  // app:getState vrátí sbLoggedIn=false i když session právě probíhá obnova
  // (sbRestoreSession běží paralelně v main procesu po did-finish-load).
  // Proto čekáme na supabase:status event – pokud přijde s loggedIn=true,
  // login dialog vůbec neotevřeme. Pokud nepřijde do 3s, otevřeme ho.
  if (!appState.sbLoggedIn) {
    let _loginPending = true;
    const _cancelLogin = onMain('supabase:status', (data) => {
      if (data.loggedIn && _loginPending) {
        _loginPending = false; // session obnovena – login dialog nepotřeba
      }
    });
    setTimeout(() => {
      if (!_loginPending) return; // session se mezitím obnovila
      _loginPending = false;
      try { openLoginDialog(); } catch (e) { console.warn('openLoginDialog failed', e); }
    }, 3000); // 3s = dost času pro sbRestoreSession
  }
}

/* ══════════════════════════════════════════════════════════
   RYCHLÝ PŘEPÍNAČ MÓDU (lokální ↔ supabase) v headeru
/* ══════════════════════════════════════════════════════════ */
// Mode toggle (lokální / Supabase) ODSTRANĚNO – aplikace běží pouze přes Supabase.
// Tlačítko #btn-mode-toggle je vyřazeno z HTML; kdyby ho někdo přidal zpět,
// existence tohoto IIFE jen potichu nic neudělá.

// Spusť inicializaci po načtení DOMu
document.addEventListener('DOMContentLoaded', init);
