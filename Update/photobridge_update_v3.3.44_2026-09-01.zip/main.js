'use strict';
// ============================================================
// PhotoBridge – Electron main process
// main.js – vstupní bod aplikace
// Odpovídá: Python photobridge.py řádky 1–345 (bootstrap, konstanty, shutdown)
// ============================================================

const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, shell, dialog, Notification } = require('electron');
const path  = require('path');
const fs    = require('fs');
const { spawn } = require('child_process');
const os    = require('os');

// ── Záchyt pádů PŘED spuštěním logování ──────────────────────────────────────
// Když aplikace spadne při startu (než se rozjede log), zůstal by uživatel
// s prázdnou obrazovkou a bez jediné stopy. Na Windows se aspoň ukázalo okno
// s chybou, na Linuxu spuštěném kliknutím se neukáže nic.
//
// Přesně tohle se stalo u chyby s paint_temp na AppImage: aplikace spadla
// při zakládání složek, tedy dřív, než existoval log.
//
// Zapisuje se do userData, protože ta složka je zapisovatelná vždycky –
// na rozdíl od místa vedle aplikace.
(function nastavZachytPadu() {
  const zapis = (nadpis, chyba) => {
    try {
      const dir = app.getPath('userData');
      fs.mkdirSync(dir, { recursive: true });
      const soubor = path.join(dir, 'start-crash.log');
      const text =
        `\n${'='.repeat(70)}\n` +
        `${new Date().toISOString()}  ${nadpis}\n` +
        `verze: ${app.getVersion()}  platforma: ${process.platform}  ` +
        `zabaleno: ${app.isPackaged}\n` +
        `cesta aplikace: ${app.getAppPath()}\n` +
        `${'='.repeat(70)}\n` +
        `${(chyba && chyba.stack) || String(chyba)}\n`;
      fs.appendFileSync(soubor, text, 'utf8');

      // Ať to uživatel vidí i bez hledání v souborech
      try {
        const { dialog: dlg } = require('electron');
        dlg.showErrorBox('PhotoBridge – chyba při spuštění',
          `${(chyba && chyba.message) || chyba}\n\n`
          + `Podrobnosti jsou v souboru:\n${soubor}\n\n`
          + `Pošli ho prosím správci.`);
      } catch (_) {}
    } catch (_) {
      // Když selže i tohle, aspoň do terminálu
      console.error(nadpis, chyba);
    }
  };

  process.on('uncaughtException',  (e) => zapis('NEZACHYCENÁ VÝJIMKA', e));
  process.on('unhandledRejection', (e) => zapis('NEOŠETŘENÉ ODMÍTNUTÍ', e));
})();

// ── Vývojový mód ─────────────────────────────────────────────────────────────
const IS_DEV = process.argv.includes('--dev') || !app.isPackaged;

// ── Konstanty aplikace ────────────────────────────────────────────────────────
// Odpovídá: APP_NAME, APP_VERSION, CONFIG_NAME, STATE_NAME atd. v Python kódu
const APP_NAME    = 'PhotoBridge';
const APP_VERSION = app.getVersion(); // čte z package.json – vždy aktuální

// Složky pro data uživatele (ekvivalent CWD v Python verzi)
const USER_DATA_DIR  = app.getPath('userData');          // %APPDATA%/PhotoBridge
const LOGS_DIR       = path.join(USER_DATA_DIR, 'logs');
const BACKUP_DIR     = path.join(USER_DATA_DIR, 'backups');
// Bere se z config.js, ať mají všechny části aplikace STEJNOU složku.
// Vedle aplikace to jde jen tam, kde se dá zapisovat – AppImage na Linuxu
// je jen pro čtení, tam se použije složka uživatele.
const PAINT_TEMP_DIR = require('./src/main/config').resolvePaintTempDir();

// Soubory
const CONFIG_FILE     = path.join(USER_DATA_DIR, 'config.json');
const STATE_FILE      = path.join(USER_DATA_DIR, 'state.json');
const CRASH_FLAG_FILE = path.join(USER_DATA_DIR, 'crash_flag.txt');

// Složky assets (ikony, HTML stránky) – relativní k main.js
const ASSETS_DIR   = path.join(__dirname, 'assets');
const RENDERER_DIR = path.join(__dirname, 'src', 'renderer');

// ── Složky: vytvoř pokud neexistují ──────────────────────────────────────────
// Každou složku zvlášť – když jedna selže (třeba na úložišti jen pro čtení),
// nesmí to shodit celou aplikaci. Dřív stačila jedna a nespustilo se nic.
for (const dir of [USER_DATA_DIR, LOGS_DIR, BACKUP_DIR, PAINT_TEMP_DIR]) {
  try {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  } catch (e) {
    console.error(`Složku ${dir} se nepodařilo vytvořit: ${e.message}`);
  }
}

// ── Úklid po aktualizaci AppImage ─────────────────────────────────────────────
// Poznamená, že nová verze naběhla, a po 24 hodinách smaže zálohu.
// Záměrně ne hned – kdyby nová verze padala až po chvíli běhu, byla by
// záloha to jediné, čím se dá vrátit zpět.
if (process.platform === 'linux') {
  try { require('./src/main/appimage-update').uklidPoStartu(); } catch (_) {}
}

// ── Crash detection ───────────────────────────────────────────────────────────
// Pokud crash_flag.txt existuje při startu → předchozí spuštění skončilo pádem
const hadCrash = fs.existsSync(CRASH_FLAG_FILE);

// Zapíše příznak (smazán při čistém ukončení nebo systémovém shutdown)
function writeCrashFlag() {
  try {
    fs.writeFileSync(CRASH_FLAG_FILE, new Date().toISOString(), 'utf8');
  } catch (e) {
    console.error('Nelze zapsat crash_flag:', e.message);
  }
}

function removeCrashFlag() {
  try {
    if (fs.existsSync(CRASH_FLAG_FILE)) {
      fs.unlinkSync(CRASH_FLAG_FILE);
    }
  } catch (e) {
    console.error('Nelze smazat crash_flag:', e.message);
  }
}

/**
 * Jde do složky aplikace zapisovat? Když ne, aktualizace nikdy neproběhnou.
 *
 * PROČ TO TU JE
 * Instalátor do v3.3.11 nabízel volbu "pro každého", která znamená
 * C:\Program Files. Aplikace běží pod asInvoker, takže tam nezapíše –
 * aktualizace selže na EPERM a nikde se to neohlásí. Technik zůstane navždy
 * na staré verzi a myslí si, že žádná nevyšla.
 *
 * Od v3.3.12 instalátor tu volbu nenabízí, ale počítače, kam se takhle
 * nainstalovalo dřív, existují dál. Tohle je najde a řekne to nahlas.
 *
 * Kontroluje se zápisem skutečného souboru, ne přes fs.accessSync –
 * ten na Windows u složek hlásí přístup i tam, kde zápis stejně selže.
 */
function zkontrolujZapisDoAplikace() {
  // AppImage je jen pro čtení schválně a aktualizuje se přebalením,
  // takže tahle kontrola pro něj neplatí.
  if (process.platform === 'linux' && process.env.APPIMAGE) return;

  const dir = app.getAppPath();
  const zkusebni = path.join(dir, '.zapis_test.tmp');

  try {
    fs.writeFileSync(zkusebni, 'x');
    fs.unlinkSync(zkusebni);
    return;
  } catch (e) {
    try { getUtils().log('ERROR', 'startup',
      `Do složky aplikace nelze zapisovat (${dir}): ${e.code || e.message} – aktualizace nebudou fungovat`); } catch (_) {}
  }

  // Hlášku ukazujeme jednou za spuštění a až po startu, ať nebrzdí okno.
  setTimeout(() => {
    try {
      dialog.showMessageBox({
        type:    'warning',
        title:   'PhotoBridge – aktualizace nebudou fungovat',
        message: 'Aplikace je nainstalovaná do složky, kam nemá právo zapisovat.',
        detail:  `Složka: ${dir}\n\n`
               + 'Nové verze se proto nenainstalují a zůstaneš na téhle. '
               + 'Nejde o chybu aplikace – při instalaci byla zvolena složka '
               + 'pro všechny uživatele (obvykle C:\\Program Files).\n\n'
               + 'Řešení: aplikaci odinstaluj a nainstaluj znovu. Novější '
               + 'instalátor se už na umístění neptá a nainstaluje ji tam, '
               + 'kde aktualizace fungují.\n\n'
               + 'Nastavení, přihlášení ani fotky se odinstalací neztratí.',
        buttons: ['Rozumím'],
      });
    } catch (_) {}
  }, 8000).unref?.();
}

// ── Ukončení systémem (jen mimo Windows) ─────────────────────────────────────
// PROČ TO TU JE
// Když se vypne virtuál nebo se restartuje systém, dostane proces SIGTERM.
// Electron při něm nevyvolá 'before-quit' ani 'will-quit', takže crash_flag.txt
// zůstane ležet a příští start ho vyhodnotí jako pád. Aplikace pak zbytečně
// zapne self-heal, který se každých 10 minut ptá GitHubu na opravu, která
// neexistuje – a do logu přitom napíše, že předchozí běh spadl, i když
// start-crash.log je prázdný. Přesně to se stalo 11. i 12. 8. 2026.
//
// Windowsová větev zůstává nedotčená: tam se signály takhle neposílají
// a ukončení řeší 'before-quit'.
if (process.platform !== 'win32') {
  for (const signal of ['SIGTERM', 'SIGINT', 'SIGHUP']) {
    process.on(signal, () => {
      try { getUtils().log('INFO', 'shutdown', `Systém poslal ${signal} – ukončuji čistě`); } catch (_) {}
      removeCrashFlag();
      try { app.quit(); } catch (_) {}
      // Pojistka: kdyby se quit zasekl, systém proces stejně za chvíli zabije.
      setTimeout(() => { try { process.exit(0); } catch (_) {} }, 3000).unref?.();
    });
  }
}

// ── Globální reference (prevence GC) ─────────────────────────────────────────
let mainWindow   = null;   // Hlavní okno aplikace
let tray         = null;   // Systémová tray ikona
let isQuitting   = false;  // true = uživatel zvolil ukončení (ne jen zavření okna)

// ── Lazy import modulů backendu ───────────────────────────────────────────────
// Moduly se načtou až při potřebě (rychlejší start)
let configModule  = null;
let utilsModule   = null;
let serverModule  = null;
let supabaseModule = null;
let paintModule   = null;
let updaterModule = null;

function getConfig()   { return configModule  || (configModule  = require('./src/main/config'));   }
function getUtils()    { return utilsModule   || (utilsModule   = require('./src/main/utils'));    }
function getServer()   { return serverModule  || (serverModule  = require('./src/main/server'));   }
function getSupabase() { return supabaseModule || (supabaseModule = require('./src/main/supabase')); }
function getPaint()    { return paintModule   || (paintModule   = require('./src/main/paint'));    }
function getUpdater()  { return updaterModule || (updaterModule = require('./src/main/updater'));  }
// ── Fáze 9: Tray menu + Phase 9 IPC handlery ─────────────────────────────────
let mainTrayModule = null;
function getMainTray() { return mainTrayModule || (mainTrayModule = require('./src/main/main-tray')); }

// ── Fáze 11: Crash detection + DevTools ──────────────────────────────────────
let crashModule   = null;
let devtoolsModule = null;
function getCrash()    { return crashModule    || (crashModule    = require('./src/main/crash'));    }
function getDevtools() { return devtoolsModule || (devtoolsModule = require('./src/main/devtools')); }

// ── Nastavení: samostatné okno ────────────────────────────────────────────────
let settingsWindowModule = null;
function getSettingsWindow() {
  return settingsWindowModule || (settingsWindowModule = require('./src/main/settings-window'));
}

// ── Upload: samostatné okno ───────────────────────────────────────────────────
let uploadWindowModule = null;
function getUploadWindow() {
  return uploadWindowModule || (uploadWindowModule = require('./src/main/upload-window'));
}

// ── Nestažené zakázky: samostatné okno ───────────────────────────────────────
let pendingWindowModule = null;
function getPendingWindow() {
  return pendingWindowModule || (pendingWindowModule = require('./src/main/pending-window'));
}

let webAppQrModule = null;
function getWebAppQr() {
  return webAppQrModule || (webAppQrModule = require('./src/main/webapp-qr-window'));
}

let tourWindowModule = null;
function getTourWindow() {
  return tourWindowModule || (tourWindowModule = require('./src/main/tour-window'));
}

let mobilePreviewModule = null;
function getMobilePreview() {
  return mobilePreviewModule || (mobilePreviewModule = require('./src/main/mobile-preview-window'));
}

let loginWindowModule = null;
function getLoginWindow() {
  return loginWindowModule || (loginWindowModule = require('./src/main/login-window'));
}

// ── Záloha / obnova + diagnostika ─────────────────────────────────────────────
let backupModule = null;
let diagModule   = null;
function getBackup() { return backupModule || (backupModule = require('./src/main/backup')); }
function getDiag()   { return diagModule   || (diagModule   = require('./src/main/diag'));   }


// ── Jediná instance aplikace ──────────────────────────────────────────────────
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  // Jiná instance již běží → zobraz ji a ukonči tuto
  app.quit();
  process.exit(0);
}

app.on('second-instance', () => {
  // Někdo se pokusil spustit druhou instanci → obnov hlavní okno
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  }
});

// ── Popup "Aktualizace dokončena" ─────────────────────────────────────────────
let _updateDoneWin = null;

function showUpdateDoneWindow(newVersion, changelog = null) {
  if (_updateDoneWin && !_updateDoneWin.isDestroyed()) return;

  const { screen } = require('electron');
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  _updateDoneWin = new BrowserWindow({
    width:           400,
    height:          340,
    x:               width  - 416,
    y:               height - 360,
    resizable:       true,
    maximizable:     false,
    minimizable:     false,
    fullscreenable:  false,
    alwaysOnTop:     true,
    frame:           true,
    autoHideMenuBar: true,
    title:           'PhotoBridge – Aktualizace dokončena',
    icon:            path.join(ASSETS_DIR, 'icons', 'icon.ico'),
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools:         false,
    },
    show: false,
  });

  // IPC – vrátí data pro popup
  const { ipcMain } = require('electron');
  const _handleGetInfo = () => {
    const cfg     = getConfig().readConfig();
    const inTray  = cfg.MINIMIZE_ON_START === 'true' || cfg.MINIMIZE_TO === 'tray';
    return {
      version:   newVersion || APP_VERSION,
      inTray,
      sawDir:    cfg.SAW_DIR || '',
      changelog: changelog || null,
    };
  };
  const _handleClose = () => {
    if (_updateDoneWin && !_updateDoneWin.isDestroyed()) _updateDoneWin.close();
    return { ok: true };
  };

  // Použij once aby se handlery neregistrovaly vícekrát
  ipcMain.handleOnce('update-done:get-info', _handleGetInfo);
  ipcMain.handleOnce('update-done:close',    _handleClose);

  _updateDoneWin.loadFile(path.join(RENDERER_DIR, 'update-done.html'));
  _updateDoneWin.once('ready-to-show', () => {
    if (_updateDoneWin && !_updateDoneWin.isDestroyed()) _updateDoneWin.show();
  });
  _updateDoneWin.on('closed', () => { _updateDoneWin = null; });
}

// ── Vytvoření hlavního okna ───────────────────────────────────────────────────
// Minimalizace okna PŘI STARTU dle nastaveného cíle (tray / float / panel).
// Volá se z ready-to-show, když je MINIMIZE_ON_START = true.
function applyStartupMinimize(cfg) {
  const target = String(cfg.MINIMIZE_TO || 'tray').toLowerCase();
  try {
    if (target === 'tray') {
      // Tray ikona je vytvořená v whenReady (createTray). Okno necháme skryté
      // → je „v tray". Pojistka: kdyby tray ikona nevznikla, nenech aplikaci
      // zmizet úplně – minimalizuj ji na taskbar.
      if (tray) {
        try { mainWindow.hide(); } catch (_) {}
        return;
      }
      // jinak propadni na 'panel'
    } else if (target === 'float') {
      try {
        const floatMod = require('./src/main/float-window');
        mainWindow.hide();
        floatMod.showFloat(mainWindow, () => {
          try { floatMod.hideFloat(); } catch (_) {}
          try { mainWindow.show(); mainWindow.focus(); } catch (_) {}
        }, cfg);
        return;
      } catch (_) { /* propadni na 'panel' */ }
    }
    // PANEL (a fallback): zobraz MINIMALIZOVANÉ na taskbaru, ne neviditelné
    try { mainWindow.showInactive(); } catch (_) {}
    try { mainWindow.minimize(); } catch (_) {}
  } catch (e) {
    try { getUtils().log('WARN', 'applyStartupMinimize selhal', e.message); } catch (_) {}
    try { mainWindow.show(); } catch (_) {}   // krajní pojistka – ať není okno ztracené
  }
}

function createMainWindow() {
  // Načti uložené rozměry/pozici z konfigurace
  const cfg = getConfig().readConfig();
  const winW = parseInt(cfg.WIN_W, 10) || 520;
  const winH = parseInt(cfg.WIN_H, 10) || 420;
  const winX = cfg.WIN_X ? parseInt(cfg.WIN_X, 10) : undefined;
  const winY = cfg.WIN_Y ? parseInt(cfg.WIN_Y, 10) : undefined;

  const windowOptions = {
    width:  winW,
    height: winH,
    minWidth:  400,
    minHeight: 320,
    title: APP_NAME,
    icon: path.join(ASSETS_DIR, 'icons', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,    // bezpečnostní sandbox
      nodeIntegration: false,    // renderer NESMÍ mít přímý přístup k Node.js
      sandbox: false,            // preload.js potřebuje require()
      devTools: IS_DEV,
    },
    show: false,                 // zobrazíme až po 'ready-to-show' (bez bliknutí)
    backgroundColor: '#1a1a2e',
    autoHideMenuBar: true,       // skrýt menu lištu (Alt ji zobrazí)
  };

  // Obnov pozici okna
  if (winX !== undefined && winY !== undefined) {
    windowOptions.x = winX;
    windowOptions.y = winY;
  }

  mainWindow = new BrowserWindow(windowOptions);

  // Drž v tray modulu referenci na AKTUÁLNÍ okno (okno se může znovuvytvořit)
  try { getMainTray().setMainWindow(mainWindow); } catch (_) {}

  // Načti hlavní HTML stránku
  mainWindow.loadFile(path.join(RENDERER_DIR, 'index.html'));

  // DEBUG: zachyť JS chyby z rendereru a vypiš do PowerShell konzole
  mainWindow.webContents.on('console-message', (_evt, level, message, line, sourceId) => {
    if (level >= 2) { // 2=warning, 3=error
      console.error(`[RENDERER ${level === 3 ? 'ERROR' : 'WARN'}] ${message}  (${sourceId}:${line})`);
    }
  });
  mainWindow.webContents.on('render-process-gone', (_evt, details) => {
    console.error('[RENDERER CRASHED]', JSON.stringify(details));
  });
  mainWindow.webContents.on('did-fail-load', (_evt, code, desc, url) => {
    console.error(`[LOAD FAILED] ${code} ${desc} – ${url}`);
  });

  // Zobraz okno až je připraveno (bez bílého bliknutí)
  mainWindow.once('ready-to-show', () => {
    if (String(cfg.MINIMIZE_ON_START) !== 'true') {
      mainWindow.show();
      bringWindowToFront(mainWindow);   // vyzvedni nad ostatní programy
    } else {
      // Minimalizovat při startu → pošli okno do cíle dle MINIMIZE_TO.
      // (Dříve se okno jen NEzobrazilo → u 'panel'/'float' zmizelo nadobro
      //  a nešlo ho najít. Teď to respektuje nastavený cíl.)
      applyStartupMinimize(cfg);
    }
    // Pokud předchozí spuštění skončilo pádem → zobraz crash dialog
    if (hadCrash) {
      mainWindow.webContents.send('ipc:crash-detected', {
        flagFile: CRASH_FLAG_FILE,
        message:  'Předchozí spuštění aplikace skončilo neočekávaně.',
      });
    }
  });

  // Uloži pozici/rozměr okna při pohybu/resize
  mainWindow.on('resized', saveWindowBounds);
  mainWindow.on('moved',   saveWindowBounds);

  // Zachycení pokusu o zavření okna
  // Logika tray/float/panel je v main-tray.js setupMinimizeToTray()
  // Zde jen synchronizujeme isQuitting flag pro skutečný quit
  mainWindow.on('close', () => {
    // Pokud close handler v main-tray.js neprovedl preventDefault(),
    // znamená to skutečný quit → zajisti čistý shutdown
    if (!isQuitting) {
      isQuitting = true;
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    try { getMainTray().setMainWindow(null); } catch (_) {}
  });

  // DevTools v debug módu
  if (IS_DEV) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  return mainWindow;
}

// ── Uložení rozměrů a pozice okna ────────────────────────────────────────────
function saveWindowBounds() {
  if (!mainWindow || mainWindow.isMinimized()) return;
  try {
    const bounds = mainWindow.getBounds();
    const cfg = getConfig().readConfig();
    cfg.WIN_W = String(bounds.width);
    cfg.WIN_H = String(bounds.height);
    cfg.WIN_X = String(bounds.x);
    cfg.WIN_Y = String(bounds.y);
    getConfig().writeConfig(cfg);
  } catch (e) {
    console.error('saveWindowBounds chyba:', e.message);
  }
}

// ── Tray ikona ────────────────────────────────────────────────────────────────
function createTray() {
  // POZOR: .ico je windowsový formát a Linux ho NEPŘEČTE.
  //     Failed to load image from path '.../assets/icons/tray.ico'
  // Zkoušíme proto nejdřív PNG a teprve pak .ico. Na Windows se nic nemění,
  // .ico tam funguje dál a je v seznamu hned za PNG.
  const kandidati = [
    path.join(__dirname, 'templates', 'icon_192.png'),
    path.join(__dirname, 'templates', 'icon_512.png'),
    path.join(ASSETS_DIR, 'icons', 'tray.png'),
    path.join(ASSETS_DIR, 'icons', 'tray.ico'),
    path.join(ASSETS_DIR, 'icons', 'icon.ico'),
  ];
  const iconFile = kandidati.find(p => { try { return fs.existsSync(p); } catch { return false; } })
                   || kandidati[kandidati.length - 1];

  try {
    tray = new Tray(iconFile);
    tray.setToolTip(APP_NAME);
    updateTrayMenu();

    // Klik na tray ikonu (levé tlačítko) → zobraz/skryj okno
    tray.on('click', () => toggleMainWindow());
  } catch (e) {
    console.error(`Nelze vytvořit tray ikonu (${iconFile}):`, e.message);
    tray = null;
  }
}

// Sestaví a nastaví kontextové menu tray ikony
// (Plné menu implementuje Fáze 9 – zatím základní kostra)
function updateTrayMenu(extraItems = []) {
  if (!tray) return;

  const menuTemplate = [
    {
      label: `${APP_NAME} ${APP_VERSION}`,
      enabled: false,
    },
    { type: 'separator' },
    {
      label: 'Zobrazit',
      click: () => showMainWindow(),
    },
    ...extraItems,
    { type: 'separator' },
    {
      label: 'Ukončit',
      click: () => quitApp(),
    },
  ];

  const contextMenu = Menu.buildFromTemplate(menuTemplate);
  tray.setContextMenu(contextMenu);
}

// ── Pomocné funkce pro okno ───────────────────────────────────────────────────
function showMainWindow() {
  if (!mainWindow) {
    createMainWindow();
    return;
  }
  mainWindow.show();
  if (mainWindow.isMinimized()) mainWindow.restore();
  bringWindowToFront(mainWindow);
}

// Vyzvedne okno nad ostatní programy – krátký puls alwaysOnTop.
// Trvalý alwaysOnTop by překážel (okno by bylo pořád navrchu i když
// uživatel přepne jinam), proto ho hned zase vypneme.
function bringWindowToFront(win) {
  if (!win || win.isDestroyed()) return;
  try {
    win.setAlwaysOnTop(true);
    win.show();
    win.focus();
    win.moveTop();
    // Po krátké chvíli vypneme alwaysOnTop – okno zůstane navrchu,
    // ale uživatel může normálně přepnout na jiný program
    setTimeout(() => {
      try {
        if (win && !win.isDestroyed()) win.setAlwaysOnTop(false);
      } catch (_) {}
    }, 400);
  } catch (e) {
    try { win.focus(); } catch (_) {}
  }
}

function toggleMainWindow() {
  if (!mainWindow) {
    createMainWindow();
    return;
  }
  if (mainWindow.isVisible() && !mainWindow.isMinimized()) {
    mainWindow.hide();
  } else {
    showMainWindow();
  }
}

// ── Čisté ukončení aplikace ───────────────────────────────────────────────────
// Ekvivalent _on_closing() + čistého ukončení v Python verzi
async function quitApp() {
  isQuitting = true;
  app.isQuitting = true;  // flag pro main-tray.js close handler
  getUtils().log('INFO', 'Ukončení aplikace', 'quitApp() zavoláno');

  // Zruš plovoucí okno
  try { require('./src/main/float-window').destroyFloat(); } catch (_) {}
  try { require('./src/main/stanoviste-window').zavri(); } catch (_) {}
  try { require('./src/main/sber-sn').stop(); } catch (_) {}
  try { require('./src/main/sber-window').zavri(); } catch (_) {}

  // Zastav backend služby
  try { await getServer().stopServer();   } catch (_) {}
  try { getSupabase().stopSbPoller();     } catch (_) {}
  try { getPaint().stopMonitoring();      } catch (_) {}

  // Smaž crash flag → čisté ukončení, není pád
  removeCrashFlag();

  // Zruš tray ikonu
  if (tray) {
    tray.destroy();
    tray = null;
  }

  app.quit();
}

// ── Zpracování nekritických výjimek ──────────────────────────────────────────
process.on('uncaughtException', (error) => {
  console.error('uncaughtException:', error);
  getUtils().log('ERROR', 'uncaughtException', error.stack || error.message);
  // crash_flag.txt zůstane → příští spuštění ukáže crash dialog
});

process.on('unhandledRejection', (reason) => {
  console.error('unhandledRejection:', reason);
  getUtils().log('ERROR', 'unhandledRejection', String(reason));
});

// ── Životní cyklus Electron app ───────────────────────────────────────────────
app.whenReady().then(async () => {
  // Fronta odesílání do API servisu (neaktivní dokud je API_MODE='disk')
  try { require('./src/main/api-upload').start(); } catch (_) {}
  // Hlídání platnosti RTS tokenu (upozornění + výzva k přihlášení)
  try { require('./src/main/rts-auth').startWatchdog(); } catch (_) {}
  // Zapiš crash flag hned po startu (smazán při čistém ukončení)
  writeCrashFlag();

  // Denní záloha se ZÁMĚRNĚ NEDĚLÁ PŘI STARTU.
  //
  // Dělá se až ve chvíli, kdy se opravdu chystá aktualizace – viz
  // updater.js. Při startu by vznikala každý den stejná kopie i v době,
  // kdy se měsíc nic nevydává. Zbytečné místo a šum.
  //
  // Úklid starých záloh se ale hodí i tak, ať se nehromadí, když se
  // dlouho neaktualizuje.
  try { require('./src/main/denni-zaloha').uklid(); } catch (_) {}

  // Do složky aplikace se musí dát zapisovat, jinak aktualizace tiše selhávají
  try { zkontrolujZapisDoAplikace(); } catch (_) {}

  // ── Detekce špatné aktualizace ─────────────────────────────────────────────
  // crash_flag + update_pending zároveň = app nenastartovala po aktualizaci
  const _backup       = getBackup();
  const updatePending = _backup.getUpdatePending();
  const hadBadUpdate  = hadCrash && !!updatePending;

  // Detekce úspěšné self-heal opravy: minule spadlo, teď čistý start na NOVĚJŠÍ verzi
  let _selfHealRepaired = null;
  try {
    const _recPath = path.join(USER_DATA_DIR, 'recovery_state.json');
    if (fs.existsSync(_recPath)) {
      const _rec = JSON.parse(fs.readFileSync(_recPath, 'utf8') || '{}');
      if (!hadCrash && getUpdater().compareVersions(APP_VERSION, _rec.crashedVersion || '0.0.0') > 0) {
        _selfHealRepaired = { from: _rec.crashedVersion, to: APP_VERSION };
      }
      if (!hadCrash) { try { fs.unlinkSync(_recPath); } catch (_) {} }  // čistý start → režim ukončit
    }
  } catch (_) {}

  const _notifyRepaired = (r) => {
    setTimeout(() => {
      try {
        if (Notification.isSupported()) {
          new Notification({
            title: 'PhotoBridge byla opravena',
            body:  `Chyba byla automaticky vyřešena aktualizací z v${r.from} na v${r.to}.`,
          }).show();
        }
      } catch (_) {}
    }, 2000);
  };

  if (hadBadUpdate) {
    getUtils().log('WARN', 'startup', `Špatná aktualizace detekována (pending: ${updatePending?.newVersion})`);
  } else if (updatePending && !hadCrash) {
    // Aktualizace proběhla OK → smaž příznak
    _backup.clearUpdatePending();
    if (_selfHealRepaired) {
      getUtils().log('INFO', 'startup', `SELF-HEAL OK: v${_selfHealRepaired.from} → v${_selfHealRepaired.to}`);
      _notifyRepaired(_selfHealRepaired);
    } else {
      getUtils().log('INFO', 'startup', `Aktualizace na v${updatePending.newVersion} proběhla OK`);
      // Zobraz popup "Aktualizace dokončena" po načtení okna
      setTimeout(() => showUpdateDoneWindow(updatePending.newVersion, updatePending.changelog || null), 1200);
    }
  } else if (_selfHealRepaired) {
    getUtils().log('INFO', 'startup', `SELF-HEAL OK: v${_selfHealRepaired.from} → v${_selfHealRepaired.to}`);
    _notifyRepaired(_selfHealRepaired);
  }

  // Pád BEZ čekající aktualizace → aktivuj self-heal (hledá opravu na GitHubu á UPDATE_POLL_MIN)
  if (hadCrash && !hadBadUpdate) {
    getUtils().log('WARN', 'startup', `Předchozí běh spadl (v${APP_VERSION}) – aktivuji self-heal`);
    setTimeout(() => { try { getUpdater().armSelfHeal('startup'); } catch (_) {} }, 6000);
  }

  getUtils().log('INFO', 'App start', `${APP_NAME} v${APP_VERSION} – pid=${process.pid}`);

  // Inicializuj konfiguraci (vytvoří výchozí pokud neexistuje)
  getConfig().initConfig();

  // ── Autostart se systémem + zástupce na ploše ────────────────────────────
  // Podle configu (default zapnuto): zajisti autostart v registru a
  // vytvoř zástupce na ploše, pokud tam ještě není. Bezpečné – chyba
  // jen zaloguje a nijak nebrání startu aplikace.
  try {
    const _cfg  = getConfig().readConfig();
    const _u    = getUtils();
    const _exe  = process.execPath;

    if (String(_cfg.START_WITH_WINDOWS) === 'true') {
      _u.setStartWithWindows(true, _exe);
    } else {
      _u.setStartWithWindows(false, _exe);
    }

    // Zástupce na ploše – vytvoř jen jednou (pak si to pamatuje v configu)
    if (String(_cfg.DESKTOP_SHORTCUT) !== 'true') {
      const made = _u.ensureDesktopShortcut(_exe);
      if (made) {
        try {
          const c2 = getConfig().readConfig();
          c2.DESKTOP_SHORTCUT = 'true';
          getConfig().writeConfig(c2);
        } catch (_) {}
      }
    }
  } catch (e) {
    getUtils().log('WARN', 'autostart/shortcut init selhal', e.message);
  }

  // Vytvoř hlavní okno
  createMainWindow();

  // Vytvoř tray ikonu – vždy, aby bylo možné přepínat MINIMIZE_TO bez restartu
  // (main-tray.js si sám řídí viditelnost dle konfigurace)
  createTray();

  // Spusť auto-updater check (tichý, na pozadí)
  try {
    getUpdater().scheduleUpdateCheck();
  } catch (e) {
    getUtils().log('WARN', 'Updater init selhal', e.message);
  }

  // ── Spusť samostatný updater démon (detached Node.js proces) ─────────────
  // Démon přežije pád hlavní app, hlídá update_pending.json a v případě
  // crash-after-update automaticky spustí PB_restore.bat. Navíc samostatně
  // kontroluje GitHub / lokální složku pro nové aktualizace.
  try {
    const _daemonScript = path.join(__dirname, 'src', 'main', 'updater-daemon.js');
    if (fs.existsSync(_daemonScript)) {
      const _cfg     = getConfig().readConfig();
      const _pollMin = _cfg.AUTO_MIDNIGHT_UPDATE === 'false' ? '120' : '60';
      const _daemon  = spawn(process.execPath, [
        _daemonScript,
        `--userData=${app.getPath('userData')}`,
        `--pid=${process.pid}`,
        `--exe=${app.getPath('exe')}`,
        `--appDir=${path.dirname(app.getPath('exe'))}`,
        `--version=${APP_VERSION}`,
        `--poll=${_pollMin}`,
      ], {
        detached:    true,
        stdio:       'ignore',
        windowsHide: true,
      });
      _daemon.unref();
      getUtils().log('INFO', 'daemon', `Updater démon spuštěn (PID: ${_daemon.pid || '?'})`);
    } else {
      getUtils().log('WARN', 'daemon', `updater-daemon.js nenalezen: ${_daemonScript}`);
    }
  } catch (_daemonErr) {
    getUtils().log('WARN', 'daemon', `Démon start selhal: ${_daemonErr.message}`);
  }

  // ── Sledování update_ready.json (démon ho zapíše, my zobrazíme dialog) ────
  try {
    const _readyPath = path.join(app.getPath('userData'), 'update_ready.json');
    setInterval(() => {
      try {
        if (!fs.existsSync(_readyPath)) return;
        const _ready = JSON.parse(fs.readFileSync(_readyPath, 'utf8'));
        const _readySeen = _readyPath + '.seen';
        fs.renameSync(_readyPath, _readySeen);
        getUtils().log('INFO', 'daemon', `update_ready.json detekován → v${_ready.latestVersion || '?'}`);
        getUpdater().checkForUpdates(true, false).catch(() => {});
      } catch (_) {}
    }, 5 * 60 * 1000);
  } catch (_) {}

  // ── Registrace IPC handlerů všech modulů ─────────────────────────────────
  try { getUtils().registerIpcHandlers();    } catch (e) { console.error('utils IPC selhal:', e.message); }
  try { getServer().registerIpcHandlers();   } catch (e) { console.error('server IPC selhal:', e.message); }
  try { getSupabase().registerIpcHandlers(); } catch (e) { console.error('supabase IPC selhal:', e.message); }
  // v3.1.0: Vestavěný editor (alternativa k mspaintu)
  try {
    const editorWin = require('./src/main/editor-window');
    editorWin.setLogger((lvl, ctx, msg) => getUtils().log(lvl, ctx, msg));
    editorWin.registerIpcHandlers();
    getUtils().log('INFO', 'init', 'editor-window IPC handlery zaregistrovány');
  } catch (e) {
    getUtils().log('WARN', 'init', `editor-window selhal: ${e.message}`);
  }

  // v3.1.3: Diagnostika uvízlých souborů v paint_temp/ (z dřívějšího bugu)
  try {
    const paintMod = require('./src/main/paint');
    if (paintMod.logStuckPaintTempOnStartup) {
      paintMod.logStuckPaintTempOnStartup();
    }
  } catch (e) {
    getUtils().log('WARN', 'init', `paint stuck check selhal: ${e.message}`);
  }

  // ── Obnova Supabase session po restartu (refresh token ze state.json) ────
  // Technik zůstane přihlášen i po restartu. Odhlášení POUZE manuálním klikem.
  // Po obnovení session se POLLER AUTOMATICKY SPUSTÍ a běží trvale na pozadí.
  // Tím odpadá potřeba klikat na "Spustit příjem" – fotky se stahují samy.
  // Pokud při startu selže (síť, token), pojistka v _ensurePollerRunning()
  // se ho pokusí znovu spustit každých 30 sekund.
  //
  // DŮLEŽITÉ: čekáme na did-finish-load aby renderer stihl zaregistrovat
  // IPC listenery. Bez toho by supabase:status event přišel příliš brzy
  // (renderer ještě neběží) a ztratil by se → "Připojuji k Supabase" natrvalo.
  mainWindow.webContents.once('did-finish-load', () => {
  try {
    const cfg = getConfig().readConfig();
    getSupabase().sbRestoreSession(cfg).then(async (restored) => {
      if (restored && mainWindow && !mainWindow.isDestroyed()) {
        // Informuj renderer že session byla obnovena
        mainWindow.webContents.send('supabase:status', {
          loggedIn:    true,
          email:       getUtils().STATE.sbEmail || '',
          userId:      getUtils().STATE.sbUserId || '',
          accountType: getUtils().STATE.sbAccountType || 'business',
        });
        getUtils().log('INFO', 'startup', `Supabase session obnovena: ${getUtils().STATE.sbEmail}`);

        // Pokud SAVE_DIR není nastavena, zeptej se uživatele
        // (krátká prodleva, aby se hlavní okno stihlo zobrazit a renderer
        // navázat onMain('app:request-ensure-save-dir') listener)
        const saveDir = cfg.SAVE_DIR || '';
        if (!saveDir) {
          setTimeout(() => {
            try {
              if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.webContents.send('app:request-ensure-save-dir');
              }
            } catch (_) {}
          }, 1500);
        } else {
          // Auto-start polleru po obnovení session (jen když máme SAVE_DIR)
          if ((cfg.SB_URL || '').trim()) {
            getSupabase().startSbPoller(cfg, saveDir);
          }
        }
      }
      // Když se obnova nepovedla, zkusíme to ještě dvakrát.
      //
      // Po aktualizaci se aplikace restartuje ve chvíli, kdy síť často
      // ještě nenaběhla – obnova selže a technik dostane přihlašovací okno,
      // přestože je jeho token v pořádku. Za minutu už spojení bývá.
      if (!restored) {
        let pokus = 0;
        const znovu = () => {
          pokus++;
          getSupabase().sbRestoreSession(cfg).then((ok) => {
            if (ok) {
              getUtils().log('INFO', 'startup', `Session obnovena na ${pokus}. pokus`);
              if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.webContents.send('supabase:status', {
                  loggedIn: true,
                  email:    getUtils().STATE.sbEmail  || '',
                  userId:   getUtils().STATE.sbUserId || '',
                });
              }
              if ((cfg.SB_URL || '').trim()) getSupabase().startSbPoller(cfg, saveDir);
            } else if (pokus < 2) {
              const t = setTimeout(znovu, 120000);
              if (t.unref) t.unref();
            }
          }).catch(() => {});
        };
        const t = setTimeout(znovu, 45000);
        if (t.unref) t.unref();
      }

      // Aktivuj pojistku, která drží poller permanentně živý
      _startPollerKeepalive();
    }).catch(() => { _startPollerKeepalive(); });
  } catch (e) {
    getUtils().log('WARN', 'startup sbRestoreSession', e.message);
    _startPollerKeepalive();
  }
  }); // end did-finish-load

  // ── Pojistka: každých 30 s zkontroluj, zda poller běží. Pokud ne ──
  //    a uživatel je přihlášen + má SAVE_DIR, znovu spusť. Tím má aplikace
  //    "trvalý příjem" – uživatel nemusí nikdy klikat na Spustit. ─────
  function _startPollerKeepalive() {
    setInterval(() => {
      try {
        const sb = getSupabase();
        if (!sb || typeof sb.isSbPollerRunning !== 'function') return;
        if (sb.isSbPollerRunning()) return; // všechno OK
        const utils = getUtils();
        if (!utils.STATE.sbAccessToken && !utils.STATE.sbRefreshToken) return; // nepřihlášen
        const cfg2 = getConfig().readConfig();
        const saveDir2 = cfg2.SAVE_DIR || '';
        if (!saveDir2 || !(cfg2.SB_URL || '').trim()) return;
        utils.log('INFO', 'POLLER_KEEPALIVE', 'Poller neběží – znovu spouštím');
        sb.startSbPoller(cfg2, saveDir2);
      } catch (_) { /* nevadí */ }
    }, 30_000);
  }

  // ── Fáze 9: Registrace plného tray menu + Phase 9 IPC handlerů ──────────
  try {
    const trayMod = getMainTray();
    if (tray) trayMod.setupTray(mainWindow, tray);
    trayMod.registerPhase9IpcHandlers(mainWindow);
    // Nastaví minimize handler (tray / float / panel) – musí být PO setupTray
    trayMod.setupMinimizeToTray(mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'Phase9 init selhal', e.message);
  }

  // ── Float window IPC handlery ─────────────────────────────────────────
  try {
    const floatMod = require('./src/main/float-window');
    floatMod.registerIpcHandlers(
      () => mainWindow,
      () => getConfig().readConfig(),
      (cfg) => getConfig().writeConfig(cfg),
      () => quitApp()
    );
  } catch (e) {
    getUtils().log('WARN', 'float-window IPC init selhal', e.message);
  }

  // ── Sběr sériových čísel ───────────────────────────────────────────────
  // Poslouchá na pozadí. Dokud se nesbírá, ptá se jednou za minutu –
  // jakmile čísla začnou chodit, zrychlí na 3 sekundy.
  //
  // Okno se otevírá SAMO, když přijde číslo. Nikde se nezapíná: technik
  // zapne sběr v telefonu a na počítači to prostě funguje.
  try {
    require('./src/main/sber-window').registerIpcHandlers();
    require('./src/main/sber-sn').start();
  } catch (e) {
    getUtils().log('WARN', 'sber init selhal', e.message);
  }

  // ── Sdílené stanoviště ─────────────────────────────────────────────────
  // Jen na počítačích označených jako stanoviště (mikroskop, měřicí
  // pracoviště). Jinde se okno neotevře a nic se nezaregistruje.
  try {
    const stanMod = require('./src/main/stanoviste-window');
    if (stanMod.jeStanoviste()) {
      stanMod.registerIpcHandlers();
      setTimeout(() => { try { stanMod.otevri(); } catch (_) {} }, 2500);
    }
  } catch (e) {
    getUtils().log('WARN', 'stanoviste init selhal', e.message);
  }

  // ── SP_ post-processing: soubory z local serveru s typem SP → Paint fronta ─
  // server.js posílá 'server:upload-received' do rendereru; my ho zde zachytíme
  // přes ipcMain a zkontrolujeme zda soubor je SP_ → zařadíme do paint fronty
  try {
    const { ipcMain: _ipc } = require('electron');
    // Listener na interní event z server.js (poslaný přes BrowserWindow.send)
    // Hookujeme se na webContents message který server.js pošle renderu
    mainWindow.webContents.on('ipc-message', () => {}); // no-op (placeholder)

    // Skutečný hook: server.js volá BrowserWindow.send('server:upload-received', data)
    // Zachytíme to tak, že zaregistrujeme listener na mainWindow webContents
    const _origSend = mainWindow.webContents.send.bind(mainWindow.webContents);
    mainWindow.webContents.send = function(channel, ...args) {
      // Zavolej původní send
      _origSend(channel, ...args);

      // Post-process SP_ soubory z local server uploadu
      if (channel === 'server:upload-received') {
        const data = args[0];

        // ── Float fix: když je hlavní okno skryté (float mód), renderer je
        //    throttlován Chromiem a neodešle ipc('upload:open').
        //    Otevřeme upload okno přímo z main procesu. ──────────────────────
        if (!mainWindow.isVisible() && data && Array.isArray(data.files) && data.files.length) {
          try {
            const srv = (() => { try { return require('./src/main/server'); } catch(_) { return null; } })();
            const job = data.job || (srv && srv.getState && srv.getState().tokenJob) || '';
            getUploadWindow().openUploadWindow(null, data.files, job);
            getUtils().log('INFO', 'Float: upload okno otevřeno přímo (renderer throttlován)', `job=${job}`);
          } catch (floatErr) {
            getUtils().log('WARN', 'Float: upload:open selhal', String(floatErr.message));
          }
        }

        if (data && Array.isArray(data.files)) {
          const paint = (() => { try { return require('./src/main/paint'); } catch(_) { return null; } })();
          if (paint && paint.createPaintTempCopy) {
            for (const f of data.files) {
              const fname = (f.name || f.path || '').toUpperCase();
              const isSP  = fname.startsWith('SP_') || /^SP[_\-]/i.test(path.basename(f.path || f.name || ''));
              if (isSP && f.path && fs.existsSync(f.path)) {
                const finalPath = f.path; // soubor je už v saveDir
                const content   = fs.readFileSync(finalPath);
                // Smaž původní soubor a nechej paint.js vytvořit temp kopii
                try { fs.unlinkSync(finalPath); } catch(_) {}
                paint.createPaintTempCopy(finalPath, content).catch(() => {});
                getUtils().log('INFO', 'SP_ → paint queue (local)', path.basename(finalPath));
              }
            }
          }
        }
      }
    };
  } catch (e) {
    getUtils().log('WARN', 'SP_ paint hook selhal', e.message);
  }

  // ── Fáze 11: Crash detection + DevTools ──────────────────────────────────
  try {
    getCrash().registerIpcHandlers(mainWindow);
    getDevtools().registerIpcHandlers(mainWindow);
    getCrash().registerCrashHandler();   // ← aktivuje crash dialog při uncaughtException
  } catch (e) {
    getUtils().log('WARN', 'Phase11 init selhal', e.message);
  }

  // ── Nastavení: samostatné okno – registrace IPC handlerů ─────────────────
  try {
    getSettingsWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'settings-window IPC init selhal', e.message);
  }

  // ── Záloha / obnova + diagnostika – registrace IPC handlerů ──────────────
  try {
    getBackup().registerIpc();
    getDiag().registerIpc(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'backup/diag IPC init selhal', e.message);
  }

  // Pokud špatná aktualizace + záloha existuje → zobraz restore okno
  if (hadBadUpdate && getBackup().hasBackup()) {
    setTimeout(() => {
      try { getBackup().showRestoreWindow({ isBadUpdate: true }); } catch (e) {
        getUtils().log('ERROR', 'showRestoreWindow selhal', e.message);
      }
    }, 1000);
  }

  // ── Upload: samostatné okno – registrace IPC handlerů ────────────────────
  try {
    getUploadWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'upload-window IPC init selhal', e.message);
  }

  // ── Nestažené zakázky: okno – registrace IPC handlerů ────────────────────
  try {
    getPendingWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'pending-window IPC init selhal', e.message);
  }

  // ── Web App QR okno – registrace IPC handlerů ─────────────────────────────
  try {
    getWebAppQr().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'webapp-qr-window IPC init selhal', e.message);
  }

  // ── Tour okno – registrace IPC handlerů ───────────────────────────────────
  try {
    getTourWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'tour-window IPC init selhal', e.message);
  }

  // ── Mobile Preview okno – registrace IPC handlerů ─────────────────────────
  try {
    getMobilePreview().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'mobile-preview-window IPC init selhal', e.message);
  }

  // ── Login okno – registrace IPC handlerů ──────────────────────────────────
  try {
    getLoginWindow().registerIpcHandlers();
  } catch (e) {
    getUtils().log('WARN', 'login-window IPC init selhal', e.message);
  }

  // ── DevTools log hook: přesměruj utils.log() → devtools buffer ──────────
  // Musí být PO registraci IPC handlerů, ale PŘED dalším logováním
  try {
    const devtools = getDevtools();
    getUtils().addLogHook((level, msg) => {
      try { devtools.addLog(level, msg); } catch (_) {}
    });
    getUtils().log('INFO', 'DevTools', 'Log hook aktivní – všechny logy jdou do DevTools bufferu');
  } catch (e) {
    console.error('DevTools hook registrace selhala:', e.message);
  }

  // ── F12 globální zkratka → otevři DevTools konzoli ─────────────────────
  try {
    const { globalShortcut } = require('electron');
    globalShortcut.register('F12', () => {
      try { getDevtools().openDevToolsWindow(mainWindow); } catch (_) {}
    });
  } catch (_) {}

  // ── Aliasy kanálů – app.js používá kratší názvy ──────────────────────────
  // config:get (app.js) → ipc:config:get (main.js)
  ipcMain.handle('config:get', () => getConfig().readConfig());

  // app:getState – init() rendereru potřebuje kompletní stav aplikace
  ipcMain.handle('app:getState', () => {
    const cfg   = getConfig().readConfig();
    const utils = getUtils();
    const sb    = getSupabase ? getSupabase() : null;
    const srv   = getServer   ? getServer()   : null;
    return {
      theme:         utils.computeEffectiveTheme(cfg),
      serverRunning: srv?.isRunning?.() ?? false,
      ip:            utils.getLocalIP(),
      port:          parseInt(cfg.PORT, 10) || 5000,
      stats:         {
        total:    utils.STATE.totalUploadCount || 0,
        session:  utils.STATE.uploadCount      || 0,
        jobCount: 0,
      },
      jobHistory:   utils.getJobHistory(),
      sbLoggedIn:   Boolean(utils.STATE.sbAccessToken),
      sbEmail:      utils.STATE.sbEmail       || '',
      sbAccountType: utils.STATE.sbAccountType || 'business',
      pollerJob:    utils.STATE.pollerJob || null,
      pollerRunning: sb?.isSbPollerRunning?.() ?? false,
      vercelMode:   Boolean((cfg.VERCEL_URL || '').trim()),
    };
  });

  // qr:generate – vygeneruje QR odkazující na mobilní webapp s předvyplněnou zakázkou.
  // URL formát: https://loydtest01.github.io/PhotoBridge/?job=ZAKAZKA
  // Mobil otevře webapp, sám rozpozná `?job=` parametr a předvyplní ho.
  // Fotky chodí přímo na Supabase (pod účtem mobilu), poller v PC je stáhne.
  ipcMain.handle('qr:generate', async (_e, { job }) => {
    try {
      const cfg     = getConfig().readConfig();
      const ghPages = (cfg.GITHUB_PAGES_URL || 'https://loydtest01.github.io/PhotoBridge/').trim().replace(/\/$/, '');
      // URL = mobilní webapp + zakázka jako query parametr
      const url     = `${ghPages}/?job=${encodeURIComponent(job || '')}`;

      // Vygeneruj QR matici
      let qrData;
      try {
        const QRCode = require('qrcode');
        const qr     = QRCode.create(url, { errorCorrectionLevel: cfg.QR_EC_LEVEL || 'H' });
        const size   = qr.modules.size;
        const data   = qr.modules.data;
        const matrix = [];
        for (let r = 0; r < size; r++) {
          const row = [];
          for (let c = 0; c < size; c++) {
            row.push(data[r * size + c] ? 1 : 0);
          }
          matrix.push(row);
        }
        // Barvy z konfigurace
        const fillRgb = (cfg.QR_FILL_COLOR || '0,0,0').split(',').map(n => parseInt(n, 10));
        const bgRgb   = (cfg.QR_BG_COLOR   || '255,255,255').split(',').map(n => parseInt(n, 10));
        const toHex   = ([r, g, b]) => '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
        qrData = {
          type:      'matrix',
          matrix,
          fillColor: toHex(fillRgb),
          bgColor:   toHex(bgRgb),
        };
      } catch (qrErr) {
        getUtils().log('WARN', 'qr:generate – qrcode lib selhala, posílám URL', qrErr.message);
        qrData = { type: 'url', url };
      }

      // Odpočet timeru: QR_TIMEOUT_MINUTES (0 = vypnuto), fallback TOKEN_MINUTES
      const qrTimeoutMin = parseInt(cfg.QR_TIMEOUT_MINUTES || '0', 10);
      const tokenMin     = parseInt(cfg.TOKEN_MINUTES       || '480', 10);
      const timerMins    = qrTimeoutMin > 0 ? qrTimeoutMin : tokenMin;
      const expiresAt    = Date.now() + timerMins * 60 * 1000;

      return { url, qrData, token: null /* legacy field, supabase mode netoken */, expiresAt, tokenMinutes: timerMins };
    } catch (e) {
      getUtils().log('ERROR', 'qr:generate', e.message);
      return { error: e.message };
    }
  });

  // settings:open – otvírá nastavení jako samostatné BrowserWindow
  // (registrace je v getSettingsWindow().registerIpcHandlers() výše;
  //  tento fallback zůstává pro zpětnou kompatibilitu s old app.js inline modálem)
  ipcMain.handle('help:open', () => {
    require('electron').shell.openPath(path.join(__dirname, 'templates', 'navod.html'));
  });

  // help:open-doc – otevře konkrétní návod ze složky templates/navody.
  // Návody jsou součástí instalace, takže fungují i bez internetu a vždycky
  // odpovídají nainstalované verzi (na GitHubu může být novější).
  ipcMain.handle('help:open-doc', (_evt, jmeno) => {
    try {
      const povolene = [
        'NAVOD_britex_prihlaseni.md',
        'NAVOD_LINUX.md',
        'NAVOD_AKTUALIZACE.md',
        'NAVOD_RELEASES.md',
        'NAVOD_SESTAVENI_LINUX.md',
        'POSTUP_NASAZENI.md',
      ];
      // Bílá listina – bez ní by šlo přes ../ otevřít cokoli na disku
      if (!povolene.includes(String(jmeno))) return { ok: false, error: 'Neznámý návod' };

      const cesta = path.join(__dirname, 'templates', 'navody', String(jmeno));
      if (!require('fs').existsSync(cesta)) {
        return { ok: false, error: 'Návod nebyl nalezen – nainstaluj novější verzi.' };
      }
      require('electron').shell.openPath(cesta);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // help:open-logs – otevře složku s logy.
  // Cesta je na každém systému jiná (%APPDATA% vs ~/.config), takže je lepší
  // otevřít ji tlačítkem, než po technikovi chtít, aby ji hledal.
  ipcMain.handle('help:open-logs', () => {
    try {
      const dir = path.join(app.getPath('userData'), 'logs');
      require('fs').mkdirSync(dir, { recursive: true });
      require('electron').shell.openPath(dir);
      return { ok: true, cesta: dir };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // help:open-docs-folder – otevře složku s návody
  ipcMain.handle('help:open-docs-folder', () => {
    try {
      require('electron').shell.openPath(path.join(__dirname, 'templates', 'navody'));
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // Vrátí seznam lokálních IPv4 adres (pro settings dialog)
  ipcMain.handle('utils:get-local-ips', () => {
    try {
      return getUtils().getLocalIpv4CandidatesWithLabels().map(([ip, label]) => `${ip}  (${label})`);
    } catch (_) {
      return [];
    }
  });

  // Záložní QR encoder – pokud main v qr:generate neposlal matici
  ipcMain.handle('qr:encode-matrix', (_e, { text }) => {
    try {
      const QRCode = require('qrcode');
      const qr = QRCode.create(text, { errorCorrectionLevel: 'H' });
      const size = qr.modules.size;
      const data = qr.modules.data;
      const matrix = [];
      for (let r = 0; r < size; r++) {
        const row = [];
        for (let c = 0; c < size; c++) row.push(data[r * size + c] ? 1 : 0);
        matrix.push(row);
      }
      return { matrix };
    } catch (e) {
      return { error: e.message };
    }
  });

  // devtools:open → handled via ipcMain.on in src/main/devtools.js registerIpcHandlers()
});

// macOS: znovu vytvoř okno při kliknutí na ikonu v Docku
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createMainWindow();
  }
});

// Windows/Linux: ukončí se když jsou všechna okna zavřená
// (pokud IS_TRAY, okna se skrývají místo zavírání → event se nezpracuje)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Pokud MINIMIZE_TO=tray, okno se jen schovává → aplikace pokračuje v tray
    // Pokud MINIMIZE_TO=float nebo panel, ukončíme
    const cfg2       = getConfig ? getConfig().readConfig() : {};
    const minimizeTo = (cfg2.MINIMIZE_TO || 'panel').toLowerCase();
    if (minimizeTo !== 'tray') {
      quitApp();
    }
  }
});

// Před ukončením: čistý shutdown
app.on('before-quit', () => {
  isQuitting = true;
  app.isQuitting = true;
  removeCrashFlag();
  try { require('./src/main/float-window').destroyFloat(); } catch (_) {}
  // OPRAVA: nemaž update_pending.json pokud quit = restart po aktualizaci.
  // updater.js nastaví _updateQuitPending = true těsně před app.quit().
  // update_pending.json se smaže při dalším startu pokud app nastartuje OK.
  try {
    if (!getUpdater().isUpdateQuitPending()) {
      getBackup().clearUpdatePending();
    }
  } catch (_) {}
});

app.on('will-quit', () => {
  removeCrashFlag();
});

// ── IPC kanály – hlavní (kostra, implementace v dalších fázích) ───────────────
// Každý kanál odpovídá určité funkci aplikace.
// Konvence pojmenování: 'ipc:akce' nebo 'ipc:modul:akce'

// ── APP INFO ──────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:app-info', () => ({
  name:     APP_NAME,
  version:  APP_VERSION,
  isDev:    IS_DEV,
  userData: USER_DATA_DIR,
  platform: process.platform,
}));

// ── OKNO ──────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:window:minimize', () => mainWindow?.minimize());
ipcMain.handle('ipc:window:close',    () => { isQuitting = true; mainWindow?.close(); });
ipcMain.handle('ipc:window:quit',     () => quitApp());
ipcMain.handle('ipc:window:show',     () => showMainWindow());

// ── KONFIGURACE ───────────────────────────────────────────────────────────────
ipcMain.handle('ipc:config:get', () => getConfig().readConfig());

ipcMain.handle('ipc:config:set', (_event, partial) => {
  const cfgBefore = getConfig().readConfig();
  const oldSaveDir = (cfgBefore.SAVE_DIR || '').trim();

  const cfg = { ...cfgBefore };
  Object.assign(cfg, partial);
  getConfig().writeConfig(cfg);

  // Rozešli změnu VŠEM oknům, ať hned přepnou motiv a další nastavení.
  // Bez toho hlavní okno (běží pořád) zůstane ve starém tématu, zatímco
  // čerstvě otevřená okna už mají nové → nekonzistentní vzhled.
  try {
    const { BrowserWindow } = require('electron');
    for (const w of BrowserWindow.getAllWindows()) {
      if (!w.isDestroyed()) {
        w.webContents.send('config:changed', cfg);
      }
    }
  } catch (_) {}

  // Pokud se změnila SAVE_DIR, okamžitě aktualizuj STATE.saveDir, aktivní sessions a restartuj poller.
  // BUG FIX: dříve se aktualizoval jen STATE.saveDir, ale aktivní sessions mají save_dir zachycené
  // při vydání tokenu (issueToken) → server.js je četl z session, nikoli ze STATE → stará složka.
  // Nyní přepisujeme save_dir ve VŠECH aktivních sessions, takže změna platí okamžitě bez restartu.
  const newSaveDir = (cfg.SAVE_DIR || '').trim();
  if (newSaveDir && newSaveDir !== oldSaveDir) {
    try {
      const utils = getUtils();
      if (utils && utils.STATE) {
        // 1) Aktualizuj STATE.saveDir – fallback pro nové tokeny bez session
        utils.STATE.saveDir = newSaveDir;

        // 2) KLÍČOVÁ OPRAVA: aktualizuj save_dir ve VŠECH živých sessions
        //    server.js v destination() preferuje session.save_dir nad STATE.saveDir,
        //    takže bez tohoto kroku aktivní session pokračují do staré složky.
        const sessions = utils.STATE.sessions;
        if (sessions && typeof sessions === 'object') {
          let updated = 0;
          for (const session of Object.values(sessions)) {
            if (session && typeof session === 'object') {
              session.save_dir = newSaveDir;
              updated++;
            }
          }
          utils.log('INFO', 'ipc:config:set', `SAVE_DIR → STATE + ${updated} session(s) aktualizováno: ${newSaveDir}`);
        } else {
          utils.log('INFO', 'ipc:config:set', `STATE.saveDir aktualizována (žádné sessions): ${newSaveDir}`);
        }
      }

      // 3) Restartuj Supabase poller s novou cestou (jen pokud je uživatel přihlášen)
      const sb = getSupabase();
      if (sb && utils && utils.STATE && utils.STATE.sbAccessToken) {
        sb.stopSbPoller();
        sb.startSbPoller(getConfig().readConfig(), newSaveDir);
        utils.log('INFO', 'ipc:config:set', `SAVE_DIR změněna → poller restartován: ${newSaveDir}`);
      }
    } catch (e) {
      getUtils().log('WARN', 'ipc:config:set', `Aktualizace SAVE_DIR selhal: ${e.message}`);
    }
  }

  return { ok: true };
});

// ── SERVER (LOCAL) – VYPNUTO ─────────────────────────────────────────────────
// Aplikace běží POUZE přes Supabase. Lokální HTTP server na LAN je vyřazen.
// IPC handlery vrací ok:true ale nic nedělají (zpětná kompatibilita s old UI).
ipcMain.handle('ipc:server:start', async () => {
  getUtils().log('INFO', 'ipc:server:start', 'IGNOROVÁNO – lokální server je vypnutý (Supabase-only mód)');
  mainWindow?.webContents.send('ipc:server:status', { running: false });
  return { ok: true, disabled: true };
});

ipcMain.handle('ipc:server:stop', async () => {
  // Pokud by server byl náhodou spuštěný, zastavme ho
  try { await getServer().stopServer?.(); } catch {}
  mainWindow?.webContents.send('ipc:server:status', { running: false });
  return { ok: true };
});

ipcMain.handle('ipc:server:status', () => ({ running: false }));

// ── SUPABASE ──────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:sb:login', async (_event, { email, password }) => {
  try {
    return await getSupabase().sbLogin(email, password);
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ipc:sb:logout', async () => {
  try {
    return await getSupabase().sbLogout();
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ipc:sb:poller:start', () => {
  const cfg     = getConfig().readConfig();
  const saveDir = cfg.SAVE_DIR || '';
  getSupabase().startSbPoller(cfg, saveDir);
});
ipcMain.handle('ipc:sb:poller:stop',  () => getSupabase().stopSbPoller());

// ── PAINT MONITORING ──────────────────────────────────────────────────────────
ipcMain.handle('ipc:paint:start', () => getPaint().startMonitoring());
ipcMain.handle('ipc:paint:stop',  () => getPaint().stopMonitoring());

// ── AKTUALIZACE ───────────────────────────────────────────────────────────────
ipcMain.handle('ipc:update:check', async () => {
  try {
    return await getUpdater().checkForUpdates();
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ── LOG ───────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:log', (_event, { level, context, message }) => {
  getUtils().log(level || 'INFO', context || 'renderer', message);
});

// ── CRASH ─────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:crash:info', () => ({
  hadCrash,
  flagFile: CRASH_FLAG_FILE,
}));

ipcMain.handle('ipc:crash:clear', () => {
  removeCrashFlag();
  return { ok: true };
});

// ── OTEVŘENÍ SLOŽKY ───────────────────────────────────────────────────────────
// ── WALLPAPER SLOŽKA ─────────────────────────────────────────────────────────
ipcMain.handle('ipc:wallpaper:open-user-folder', () => {
  // Složka wallpapers/user relativně ke __dirname (root projektu)
  const wallpaperUserDir = path.join(__dirname, 'wallpapers', 'user');
  // Vytvoř složky pokud neexistují (dark + light)
  for (const sub of ['dark', 'light']) {
    const d = path.join(wallpaperUserDir, sub);
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  }
  shell.openPath(wallpaperUserDir);
});

ipcMain.handle('ipc:shell:open-folder', (_event, folderPath) => {
  shell.openPath(folderPath);
});

ipcMain.handle('ipc:shell:open-url', (_event, url) => {
  shell.openExternal(url);
});

// ── VÝBĚR SLOŽKY (dialog) ─────────────────────────────────────────────────────
ipcMain.handle('ipc:dialog:select-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
    title: 'Vyberte složku',
  });
  if (result.canceled || !result.filePaths.length) return null;
  return result.filePaths[0];
});

// ── POKUD SAVE_DIR NENÍ NASTAVENA: PŘÁTELSKÝ DIALOG + FOLDER PICKER ──────────
// Renderer to volá ihned po přihlášení (a po obnovení session při startu).
// 1) Pokud cesta je v configu nastavena, vrátí { ok: true, alreadySet: true }.
// 2) Jinak zobrazí messageBox „kam ukládat fotky?" → uživatel klikne Vybrat.
// 3) Otevře nativní folder picker. Uživatel vybere složku → uloží se do configu.
// 4) Pokud uživatel zruší, vrátí { ok: false, canceled: true } – renderer
//    může zopakovat při dalším pokusu poslat fotku.
ipcMain.handle('app:ensure-save-dir', async () => {
  const cfgMod = getConfig();
  const cfg    = cfgMod.readConfig();
  const cur    = (cfg.SAVE_DIR || '').trim();

  // 1) Už je nastaveno – nic nedělej
  if (cur) {
    try {
      const fs = require('fs');
      // Drobná kontrola, že složka stále existuje – pokud byla smazána,
      // znovu se zeptáme.
      if (fs.existsSync(cur) && fs.statSync(cur).isDirectory()) {
        return { ok: true, alreadySet: true, path: cur };
      }
      getUtils().log('WARN', 'ensure-save-dir', `SAVE_DIR ${cur} neexistuje – ptám se znovu`);
    } catch (_) { /* pokračuj na výběr */ }
  }

  // 2) Zobraz vysvětlující messageBox
  const msgRes = await dialog.showMessageBox(mainWindow, {
    type:    'info',
    buttons: ['Vybrat složku', 'Později'],
    defaultId: 0,
    cancelId:  1,
    title:   'PhotoBridge – kam ukládat fotky?',
    message: 'Ještě nemáš zvolenou složku pro stažené fotky.',
    detail:  'Vyber prosím složku, kam se mají ukládat fotky stažené ze Supabase ' +
             'a ze schránky/PrintScreen. Můžeš to později změnit v Nastavení → ' +
             'Složka pro fotky.',
  });

  if (msgRes.response === 1) {
    // „Později" – nic neukládáme, vrátíme canceled
    return { ok: false, canceled: true };
  }

  // 3) Folder picker
  const pick = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory', 'createDirectory'],
    title: 'Vyberte složku pro ukládání fotek',
    buttonLabel: 'Použít tuto složku',
  });

  if (pick.canceled || !pick.filePaths.length) {
    return { ok: false, canceled: true };
  }

  const chosen = pick.filePaths[0];

  // 4) Uložit do configu
  try {
    cfg.SAVE_DIR = chosen;
    cfgMod.writeConfig(cfg);
    getUtils().log('INFO', 'ensure-save-dir', `SAVE_DIR nastavena: ${chosen}`);
  } catch (e) {
    getUtils().log('ERROR', 'ensure-save-dir', e.message);
    return { ok: false, error: e.message };
  }

  // Informuj všechna okna o změně configu
  try {
    BrowserWindow.getAllWindows().forEach(w => {
      if (!w.isDestroyed()) w.webContents.send('config:changed', { SAVE_DIR: chosen });
    });
  } catch (_) {}

  // Po nastavení složky restartuj poller, aby fotky ze fronty mohly začít stahovat
  try {
    const sb = getSupabase();
    if (sb && sb.startSbPoller && getUtils().STATE.sbAccessToken) {
      sb.startSbPoller(cfgMod.readConfig(), chosen);
    }
  } catch (_) {}

  return { ok: true, path: chosen };
});


// ── VÝBĚR SOUBORŮ (dialog) ────────────────────────────────────────────────────
ipcMain.handle('ipc:dialog:select-files', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    title: 'Vyberte soubory',
    filters: [
      { name: 'Obrázky a videa', extensions: ['png','jpg','jpeg','webp','mp4','mov','pdf'] },
      { name: 'Všechny soubory', extensions: ['*'] },
    ],
  });
  if (result.canceled || !result.filePaths.length) return [];
  return result.filePaths;
});

// ── TRAY MENU UPDATE ──────────────────────────────────────────────────────────
// Renderer může požádat o aktualizaci tray menu (např. po změně stavu serveru)
ipcMain.handle('ipc:tray:update', (_event, extraItems) => {
  updateTrayMenu(extraItems || []);
  return { ok: true };
});

// ── NOTIFIKACE ────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:notify', (_event, { title, body }) => {
  if (Notification.isSupported()) {
    new Notification({ title: title || APP_NAME, body }).show();
  }
});

// ── Onboarding tour – spustí průvodce v hlavním okně ─────────────────────────
ipcMain.handle('tour:request', () => {
  mainWindow?.webContents.send('tour:start');
});


// ── Export konstant pro ostatní main moduly ───────────────────────────────────
module.exports = {
  APP_NAME,
  APP_VERSION,
  USER_DATA_DIR,
  LOGS_DIR,
  BACKUP_DIR,
  PAINT_TEMP_DIR,
  CONFIG_FILE,
  STATE_FILE,
  CRASH_FLAG_FILE,
  ASSETS_DIR,
  RENDERER_DIR,
  IS_DEV,
  getMainWindow: () => mainWindow,
  getTray:       () => tray,
  updateTrayMenu,
  quitApp,
};
