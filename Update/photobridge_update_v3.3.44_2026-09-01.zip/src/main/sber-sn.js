'use strict';
// ============================================================================
//  PhotoBridge – src/main/sber-sn.js
//
//  SBĚR SÉRIOVÝCH ČÍSEL
//
//  Technik zapne v telefonu sběr, naskenuje kód z disku – a tady vyskočí
//  okno s číslem. Kliknutím se zkopíruje do schránky, technik ho vloží
//  do Excelu a jede dál.
//
//  BĚŽÍ NA POZADÍ, ale jen když je co dělat: dokud nepřijde první číslo,
//  ptáme se jednou za minutu. Jakmile sběr začne, zrychlíme na 3 sekundy
//  a po pěti minutách bez nového čísla se vrátíme zpátky.
//
//  PROČ VLASTNÍ TABULKA A NE FRONTA FOTEK
//  Čísla nejsou fotky. Nemají soubor v úložišti, nepatří do zakázky
//  a neprochází editorem. Ve frontě fotek by je poller chtěl stahovat
//  a hlídání uvízlých fotek by je hlásilo jako problém.
// ============================================================================

const fs   = require('fs');
const path = require('path');

const KLID_MS    = 60000;     // dokud se nesbírá
const AKTIVNI_MS = 3000;      // když čísla chodí
const UTLUM_MS   = 5 * 60000; // jak dlouho po posledním čísle zůstat aktivní

let _timer       = null;
let _rychle      = false;
let _posledniId  = 0;
let _posledniCas = 0;

function _cfg() { return require('./config'); }
function _log(u, z) { try { require('./utils').log(u, 'SBER', z); } catch (_) {} }

/** Soubor s historií – v datech aplikace, ne v její složce.
 *  Do složky aplikace rozbaluje aktualizace balíčky; log tam nepatří. */
function souborLogu() {
    const { app } = require('electron');
    return path.join(app.getPath('userData'), 'seriova_cisla.txt');
}

/**
 * Zapíše číslo do logu. Každý den má vlastní hlavičku, čísla pod sebou:
 *
 *   === 1. 9. 2026 ===
 *   493545208890353
 *   493545208890354
 */
function _zapis(cislo) {
    try {
        const p = souborLogu();
        const dnes = new Date().toLocaleDateString('cs-CZ',
            { day: 'numeric', month: 'numeric', year: 'numeric' });
        const hlavicka = `=== ${dnes} ===`;

        let obsah = '';
        try { obsah = fs.readFileSync(p, 'utf8'); } catch (_) {}

        // Hlavičku píšeme jen jednou denně, ne před každé číslo.
        const uvod = obsah.includes(hlavicka)
            ? ''
            : (obsah ? '\r\n' : '') + hlavicka + '\r\n';

        fs.appendFileSync(p, uvod + cislo + '\r\n', 'utf8');
    } catch (e) {
        _log('WARN', `Zápis do logu selhal: ${e.message}`);
    }
}

function _nastavTempo(rychle) {
    if (_rychle === rychle && _timer) return;
    _rychle = rychle;
    if (_timer) clearInterval(_timer);

    _timer = setInterval(() => {
        _zkontroluj().catch(e => _log('WARN', `Dotaz selhal: ${e.message}`));
    }, rychle ? AKTIVNI_MS : KLID_MS);
    if (_timer.unref) _timer.unref();

    _log('INFO', rychle
        ? 'Sběr aktivní – kontrola po 3 s'
        : 'Sběr v klidu – kontrola po minutě');
}

async function _zkontroluj() {
    const cfg  = _cfg().readConfig();
    const url  = String(cfg.SB_URL  || '').trim();
    const anon = String(cfg.SB_ANON || '').trim();
    if (!url || !anon) return;

    const token = await require('./supabase').sbEnsureToken(cfg);
    if (!token) return;

    // Poprvé jen zjistíme, kde seznam končí – ať po startu nevyskočí
    // všechno, co se nasbíralo dřív.
    const prvni = _posledniId === 0;

    // JEN VLASTNÍ ČÍSLA.
    // Do v3.3.36 se bralo všechno, takže když skenovali dva technici,
    // vyskakovala čísla na obou počítačích – a hrozilo, že si někdo vloží
    // do Excelu cizí. Každý má vidět jen to, co sám naskenoval.
    const mail = String(require('./utils').STATE?.sbEmail || '').trim();
    if (!mail) return;

    const dotaz = `${url}/rest/v1/pb_sber`
        + `?id=gt.${_posledniId}`
        + `&kdo=eq.${encodeURIComponent(mail)}`
        + `&select=id,cislo&order=id.asc&limit=200`;

    const resp = await fetch(dotaz, {
        headers: { apikey: anon, Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
    if (!resp.ok) return;

    const nove = await resp.json();
    if (!Array.isArray(nove) || !nove.length) {
        // Dlouho nic → zpomalit.
        if (_rychle && Date.now() - _posledniCas > UTLUM_MS) _nastavTempo(false);
        return;
    }

    for (const r of nove) _posledniId = Math.max(_posledniId, Number(r.id) || 0);

    if (prvni) {
        _log('INFO', `Navázáno na seznam (poslední id ${_posledniId})`);
        return;
    }

    _posledniCas = Date.now();
    if (!_rychle) _nastavTempo(true);

    const okno = require('./sber-window');
    for (const r of nove) {
        _zapis(String(r.cislo));
        okno.ukazCislo(String(r.cislo));
    }
}

function start() {
    if (_timer) return;
    _nastavTempo(false);
    _zkontroluj().catch(() => {});   // hned zjistit, kde seznam končí
}

function stop() {
    if (_timer) { clearInterval(_timer); _timer = null; }
    _rychle = false;
}

module.exports = { start, stop, souborLogu };
