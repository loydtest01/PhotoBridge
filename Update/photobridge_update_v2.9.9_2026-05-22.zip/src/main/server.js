"use strict";

/**
 * server.js – Express HTTP server (náhrada Flask serveru z photobridge.py)
 *
 * Fáze 4 – PhotoBridge Electron konverze
 *
 * Implementuje:
 *  - Token management (vydání, validace, invalidace, purge)
 *  - Multi-session slovník (max MAX_SESSIONS aktivních relací)
 *  - Express HTTP server s upload endpointem pro příjem fotek z mobilu
 *  - Statické soubory (upload UI pro mobilní prohlížeč)
 *  - CORS + bezpečnostní hlavičky
 *  - Firewall pravidlo (Windows netsh / PowerShell / ShellExecute UAC)
 *  - Start/stop serveru přes IPC
 *  - Automatické hledání volného portu (5000–5020)
 */

const express    = require("express");
const multer     = require("multer");
const path       = require("path");
const fs         = require("fs");
const net        = require("net");
const crypto     = require("crypto");
const { exec, execFile, spawn } = require("child_process");
const { ipcMain }               = require("electron");

// Importy ze zbytku projektu (Fáze 3)
const { log, STATE }            = require("./utils");
const { readConfig }              = require("./config");

// ─────────────────────────────────────────────────────────────────────────────
// Konstanty
// ─────────────────────────────────────────────────────────────────────────────

/** Maximální počet současně aktivních relací. */
const MAX_SESSIONS = 10;

/** Výchozí platnost tokenu v minutách (přepisuje se z STATE.tokenMinutes). */
const DEFAULT_TOKEN_MINUTES = 60;

// ─────────────────────────────────────────────────────────────────────────────
// Vnitřní stav serveru
// ─────────────────────────────────────────────────────────────────────────────

/** Odkaz na běžící HTTP server (instance http.Server), nebo null. */
let _httpServer = null;

/** Odkaz na Express aplikaci. */
let _app = null;

// ─────────────────────────────────────────────────────────────────────────────
// TOKEN MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vydá nový token pro zakázku a zaregistruje ji v multi-session slovníku.
 * Starý single-token STATE.token je zachován pro zpětnou kompatibilitu,
 * ale slouží pouze jako odkaz na naposledy vytvořený token.
 *
 * @param {string} job  Identifikátor zakázky (název složky / číslo jobu).
 * @returns {string}    Vygenerovaný hex token (22 znaků → QR vždy verze 3).
 */
function issueToken(job) {
    // 8 náhodných bajtů → 16 hex znaků (kratší = jednodušší QR, čitelný i na starých telefonech)
    const token = crypto.randomBytes(8).toString("hex");

    // Inicializuj sessions slovník pokud ještě neexistuje
    if (!STATE.sessions) {
        STATE.sessions = {};
    }

    const minutes = STATE.tokenMinutes || DEFAULT_TOKEN_MINUTES;

    // Zaregistruj novou relaci
    STATE.sessions[token] = {
        job,
        ts:        Date.now() / 1000,   // Unix timestamp v sekundách (shodné s Python time.time())
        save_dir:  STATE.saveDir || "",
        qr_active: true,
        minutes,
    };

    // Zpětná kompatibilita – ukazuje na aktuálně zobrazený token
    STATE.token     = token;
    STATE.tokenTs  = STATE.sessions[token].ts;
    STATE.tokenJob = job;
    STATE.job      = job;  // oprava: handlers kontrolují STATE.job

    // Čistíme vypršelé relace (max MAX_SESSIONS aktivních)
    _purgeExpiredSessions();

    log("INFO", `Token issued job=${job}`, `active_sessions=${Object.keys(STATE.sessions).length}`);
    return token;
}

/**
 * Odstraní relace jejichž token vypršel. Ponechá max MAX_SESSIONS.
 * (interní funkce)
 */
function _purgeExpiredSessions() {
    if (!STATE.sessions) return;

    const now = Date.now() / 1000;

    // Odstraň vypršelé
    for (const [t, s] of Object.entries(STATE.sessions)) {
        if ((now - s.ts) > (s.minutes * 60)) {
            log("INFO", "Session expired (purge)", `job=${s.job}`);
            delete STATE.sessions[t];
        }
    }

    // Pokud je stále příliš mnoho, odstraň nejstarší (FIFO eviction)
    while (Object.keys(STATE.sessions).length > MAX_SESSIONS) {
        const oldest = Object.entries(STATE.sessions)
            .reduce((a, b) => (a[1].ts < b[1].ts ? a : b));
        log("WARNING", "Session evicted (max sessions reached)", `job=${oldest[1].job}`);
        delete STATE.sessions[oldest[0]];
    }
}

/**
 * Zneplatní aktuální (právě zobrazenou) relaci – ostatní relace zůstávají.
 *
 * @param {string} [reason=""]  Volitelný důvod pro log.
 */
function invalidateSession(reason = "") {
    const t = STATE.token;
    if (t && STATE.sessions && STATE.sessions[t]) {
        const job = STATE.sessions[t].job || "?";
        delete STATE.sessions[t];
        log("WARNING", `Session invalidated job=${job}`, reason || "-");
    } else {
        log("WARNING", "Session invalidated (not in sessions)", reason || "-");
    }

    STATE.token     = "";
    STATE.tokenTs  = 0;
    STATE.tokenJob = "";
    STATE.job       = "";
}

/**
 * Zneplatní VŠECHNY relace (použít při ukončení nebo resetu).
 *
 * @param {string} [reason=""]  Volitelný důvod pro log.
 */
function invalidateAllSessions(reason = "") {
    const count = STATE.sessions ? Object.keys(STATE.sessions).length : 0;
    STATE.sessions  = {};
    STATE.token     = "";
    STATE.tokenTs  = 0;
    STATE.tokenJob = "";
    STATE.job       = "";
    log("WARNING", `All ${count} sessions invalidated`, reason || "-");
}

/**
 * Vrátí session objekt pro token nebo null.
 *
 * @param {string} t  Token.
 * @returns {object|null}
 */
function getSession(t) {
    _purgeExpiredSessions();
    return (STATE.sessions && STATE.sessions[t]) || null;
}

/**
 * Ověří platnost tokenu.
 *
 * Multi-session: každý token si nese vlastní metadata (job, ts, minutes, qr_active).
 * - requireQrActive=true  → telefon/web – token platí jen když je QR okno zobrazeno.
 * - requireQrActive=false → PC drag&drop – stačí nepřekročit čas TOKEN_MINUTES.
 *
 * @param {string}  t               Token k ověření.
 * @param {boolean} [requireQrActive=false]
 * @returns {boolean}
 */
function tokenValid(t, requireQrActive = false) {
    if (!t) return false;
    if (!STATE.sessions) return false;

    const session = STATE.sessions[t];
    if (!session) return false;

    // Zkontroluj vypršení
    if ((Date.now() / 1000 - session.ts) > (session.minutes * 60)) {
        // Vypršel – odstraň z cache
        delete STATE.sessions[t];
        return false;
    }

    // Pokud je vyžadováno aktivní QR okno
    if (requireQrActive && !session.qr_active) {
        return false;
    }

    return true;
}

/**
 * Nastaví příznak qr_active pro daný token.
 * Volá main.js při otevření / zavření QR okna.
 *
 * @param {string}  t      Token.
 * @param {boolean} active true = QR okno je zobrazeno.
 */
function setQrActive(t, active) {
    if (STATE.sessions && STATE.sessions[t]) {
        STATE.sessions[t].qr_active = active;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FIREWALL (Windows)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Přidá Windows Firewall pravidlo pro daný port.
 * 1. Zkontroluje jestli pravidlo už existuje → přeskočí
 * 2. Zkusí netsh přímo (funguje pokud má app admin práva)
 * 3. Fallback: zapíše dočasný .bat a spustí ho přes ShellExecute runas (UAC dialog)
 *
 * @param {number} port  TCP port.
 */
function ensureFirewallRule(port) {
    const ruleName = `PhotoBridge-${port}`;

    // Krok 1: zkontroluj jestli pravidlo už existuje
    execFile(
        'netsh',
        ['advfirewall', 'firewall', 'show', 'rule', `name=${ruleName}`],
        { windowsHide: true, timeout: 8000 },
        (err, stdout) => {
            if (!err && stdout && stdout.includes(ruleName)) {
                log('INFO', `Firewall rule already exists for port ${port}`, ruleName);
                return; // pravidlo existuje, nic nedělej
            }
            // Pravidlo chybí → přidej ho
            _addFirewallRule(port, ruleName);
        }
    );
}

function _addFirewallRule(port, ruleName) {
    const args = [
        'advfirewall', 'firewall', 'add', 'rule',
        `name=${ruleName}`,
        'dir=in', 'action=allow', 'protocol=TCP',
        `localport=${port}`,
        'profile=any',
        'enable=yes',
    ];

    // Krok 2: zkus netsh přímo (funguje s admin právy)
    execFile('netsh', args, { windowsHide: true, timeout: 10000 }, (err) => {
        if (!err) {
            log('INFO', `Firewall rule added for port ${port}`, ruleName);
            return;
        }

        // Krok 3: fallback – dočasný .bat + ShellExecute runas (UAC)
        log('INFO', `Firewall: zkouším UAC elevaci pro port ${port}`, ruleName);
        _addFirewallRuleElevated(port, ruleName);
    });
}

function _addFirewallRuleElevated(port, ruleName) {
    const os  = require('os');
    const batPath = path.join(os.tmpdir(), `pb_fw_${port}.bat`);
    const batContent = [
        '@echo off',
        `netsh advfirewall firewall delete rule name="${ruleName}" >nul 2>&1`,
        `netsh advfirewall firewall add rule name="${ruleName}" dir=in action=allow protocol=TCP localport=${port} profile=any enable=yes`,
    ].join('\r\n');

    try {
        fs.writeFileSync(batPath, batContent, 'utf8');
    } catch (e) {
        log('WARNING', 'Firewall: nelze zapsat dočasný .bat', String(e));
        return;
    }

    // Spusť .bat přes PowerShell Start-Process runas (zobrazí UAC dialog)
    const psCmd = `Start-Process cmd -ArgumentList '/c "${batPath}"' -Verb RunAs -Wait`;
    execFile(
        'powershell',
        ['-NoProfile', '-NonInteractive', '-Command', psCmd],
        { windowsHide: true, timeout: 30000 },
        (err) => {
            try { fs.unlinkSync(batPath); } catch {} // uklid dočasný soubor
            if (!err) {
                log('INFO', `Firewall rule added via UAC for port ${port}`, ruleName);
            } else {
                log('WARNING', `Firewall UAC selhal pro port ${port}`, err.message.slice(0, 200));
                log('WARNING', `Spusťte aplikaci jako správce nebo přidejte pravidlo ručně:`,
                    `netsh advfirewall firewall add rule name="${ruleName}" dir=in action=allow protocol=TCP localport=${port} profile=any enable=yes`
                );
            }
        }
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// PORT UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vrátí Promise<boolean> – true pokud je port volný.
 *
 * @param {number} port
 * @returns {Promise<boolean>}
 */
function portIsFree(port) {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.once("error", () => resolve(false));
        server.once("listening", () => {
            server.close(() => resolve(true));
        });
        server.listen(port, "0.0.0.0");
    });
}

/**
 * Najde první volný port v rozsahu [start, start+20].
 * Vrátí null pokud žádný volný port nebyl nalezen.
 *
 * @param {number} [start=5000]
 * @returns {Promise<number|null>}
 */
async function findFreePortInRange(start = 5000) {
    for (let p = start; p <= start + 20; p++) {
        if (await portIsFree(p)) return p;
    }
    return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// MULTER – konfigurace úložiště pro nahrané soubory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vytvoří multer storage engine, který ukládá soubory do správné složky
 * dle session tokenu.
 */
function _createMulterStorage() {
    return multer.diskStorage({
        destination(req, file, cb) {
            // Přečti token z query nebo hlavičky
            const token = req.query.t || req.query.token || req.headers["x-photobridge-token"] || "";
            const session = getSession(token);

            // Vždy čti aktuální STATE.saveDir (může být změněno v nastavení za běhu).
            // session.save_dir je zachycená hodnota z doby vytvoření tokenu – může být stará.
            const dest = STATE.saveDir || (session && session.save_dir) || ".";

            // Vytvoř složku pokud neexistuje
            try {
                fs.mkdirSync(dest, { recursive: true });
            } catch (e) {
                log("WARNING", "Could not create upload dir", String(e));
            }

            cb(null, dest);
        },
        filename(req, file, cb) {
            // Zachovej původní jméno souboru; pokud by kolidovalo, přidej timestamp
            const safeName = path.basename(file.originalname).replace(/[^\w.\-]/g, "_");
            const dest     = (req._multerDest || ".");
            const candidate = path.join(dest, safeName);

            if (fs.existsSync(candidate)) {
                const ext  = path.extname(safeName);
                const base = path.basename(safeName, ext);
                cb(null, `${base}_${Date.now()}${ext}`);
            } else {
                cb(null, safeName);
            }
        },
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPRESS APLIKACE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Sestaví a vrátí Express aplikaci s kompletním routingem.
 *
 * @returns {import("express").Application}
 */
function createExpressApp() {
    const app    = express();
    const upload = multer({
        storage: _createMulterStorage(),
        limits:  { fileSize: 50 * 1024 * 1024 },   // max 50 MB na soubor
        fileFilter(_req, file, cb) {
            // Přijímáme pouze obrázky a PDF (rozšiřitelné)
            const allowed = /\.(jpg|jpeg|png|gif|bmp|webp|tiff|heic|heif|pdf|raw|dng|cr2|nef|arw)$/i;
            if (allowed.test(file.originalname)) {
                cb(null, true);
            } else {
                cb(new Error(`Nepodporovaný typ souboru: ${file.originalname}`));
            }
        },
    });

    // ── Bezpečnostní hlavičky ───────────────────────────────────────────────
    app.use((_req, res, next) => {
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("X-Frame-Options", "DENY");
        res.setHeader("X-XSS-Protection", "1; mode=block");
        next();
    });

    // ── CORS ────────────────────────────────────────────────────────────────
    // Povolíme všechny origins – mobilní prohlížeč přistupuje z jiné IP
    app.use((req, res, next) => {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-PhotoBridge-Token");
        if (req.method === "OPTIONS") {
            res.sendStatus(204);
            return;
        }
        next();
    });

    // ── Statické soubory pro mobilní upload UI ──────────────────────────────
    // Adresář src/renderer/mobile/ obsahuje jednoduchý HTML upload formulář
    const mobileUiDir = path.join(__dirname, "..", "renderer", "mobile");
    if (fs.existsSync(mobileUiDir)) {
        app.use("/static", express.static(mobileUiDir));
    }

    // ── Statické soubory z templates/ (ikony, manifest, …) ─────────────────
    const templatesDir = path.join(__dirname, "..", "..", "templates");
    if (fs.existsSync(templatesDir)) {
        app.use(express.static(templatesDir));
    }

    // ── GET / – hlavní mobilní stránka ─────────────────────────────────────
    app.get("/", (req, res) => {
        // Akceptuj ?t= (QR kód) i ?token= (přímé volání)
        const token = req.query.t || req.query.token || "";

        // Ověř token (vyžaduje aktivní QR okno)
        if (!tokenValid(token, true)) {
            res.status(403).send(_buildErrorPage("Token je neplatný nebo vypršel. Naskenujte prosím QR kód znovu."));
            return;
        }

        // Servíruj templates/index.html – plná PhotoBridge web app
        // Injektuj PB_QR objekt → index.html přeskočí login a rovnou otevře LOCAL mód
        const indexPath = path.join(templatesDir, "index.html");
        if (fs.existsSync(indexPath)) {
            const host     = req.headers.host || `${req.hostname}:${STATE.port || 5000}`;
            const localUrl = `http://${host}`;
            const pbQR     = { token, job, localUrl, mode: "local" };
            const retentionDays = parseInt((readConfig().RETENTION_DAYS) || 7, 10);
            const injection = `<script>window.PB_QR=${JSON.stringify(pbQR)};window.PB_RETENTION_DAYS=${retentionDays};</script>`;
            const html      = fs.readFileSync(indexPath, "utf8");
            res.send(html.replace("</head>", injection + "\n</head>"));
        } else {
            // Fallback na inline stránku pokud soubor chybí
            const session = getSession(token);
            const job     = session ? session.job : "";
            const ip      = req.hostname || req.headers.host?.split(":")[0] || "";
            const port    = STATE.port || 5000;
            res.send(_buildUploadPage(token, job, ip, port));
        }
    });

    // ── GET /ping – healthcheck ─────────────────────────────────────────────
    app.get("/ping", (_req, res) => {
        res.json({ status: "ok", ts: Date.now() });
    });

    // ── GET /status – stav serveru (pro renderer) ───────────────────────────
    app.get("/status", (_req, res) => {
        res.json({
            running:         true,
            port:            STATE.port,
            active_sessions: STATE.sessions ? Object.keys(STATE.sessions).length : 0,
            current_job:     STATE.tokenJob || "",
        });
    });

    // ── POST /upload – příjem fotek z mobilu ────────────────────────────────
    app.post("/upload", (req, res) => {
        const token = req.query.t || req.query.token || req.headers["x-photobridge-token"] || "";

        // Ověř token – stačí platný token (qr_active se nevyžaduje)
        // Spojení zůstane aktivní po celou dobu platnosti tokenu (nastavení → Token PC)
        if (!tokenValid(token, false)) {
            log("WARNING", "Upload odmítnut – neplatný token", token);
            res.status(403).json({ ok: false, error: "Neplatný nebo vypršelý token" });
            return;
        }

        // Spusť multer upload
        upload.array("photos", 50)(req, res, (err) => {
            if (err) {
                log("WARNING", "Upload chyba", String(err));
                res.status(400).json({ ok: false, error: err.message });
                return;
            }

            if (!req.files || req.files.length === 0) {
                res.status(400).json({ ok: false, error: "Žádné soubory nebyly nahrány" });
                return;
            }

            const uploaded = req.files.map((f) => ({
                name: f.originalname,
                size: f.size,
                path: f.path,
            }));

            // Aktualizuj statistiky v STATE
            STATE.bumpUpload ? STATE.bumpUpload() : (STATE.uploadCount = (STATE.uploadCount || 0) + uploaded.length);

            log(
                "INFO",
                `Upload OK – ${uploaded.length} soubor(ů)`,
                `job=${STATE.sessions[token]?.job || "?"} token=${token.slice(0, 8)}…`
            );

            // Notifikuj renderer přes IPC (main process forwarduje)
            try {
                const { BrowserWindow } = require("electron");
                BrowserWindow.getAllWindows().forEach((win) => {
                    win.webContents.send("server:upload-received", {
                        count: uploaded.length,
                        files: uploaded,
                        job:   STATE.sessions[token]?.job || "",
                    });
                });
            } catch (e) {
                // Electron nemusí být dostupný v unit testech – ignoruj
            }

            res.json({ ok: true, uploaded: uploaded.length });
        });
    });

    // ── POST /upload-dragdrop – PC drag & drop ──────────────────────────────
    // Drag & drop z Průzkumníku nepotřebuje aktivní QR (require_qr_active=false)
    app.post("/upload-dragdrop", (req, res) => {
        const token = req.query.t || req.query.token || req.headers["x-photobridge-token"] || "";

        if (!tokenValid(token, false)) {
            log("WARNING", "DragDrop odmítnut – neplatný token", token);
            res.status(403).json({ ok: false, error: "Neplatný nebo vypršelý token" });
            return;
        }

        upload.array("photos", 200)(req, res, (err) => {
            if (err) {
                log("WARNING", "DragDrop upload chyba", String(err));
                res.status(400).json({ ok: false, error: err.message });
                return;
            }

            const count = req.files ? req.files.length : 0;
            STATE.bumpUpload ? STATE.bumpUpload() : (STATE.uploadCount = (STATE.uploadCount || 0) + count);

            log("INFO", `DragDrop upload OK – ${count} soubor(ů)`, `token=${token.slice(0, 8)}…`);
            res.json({ ok: true, uploaded: count });
        });
    });

    // ── 404 fallback ────────────────────────────────────────────────────────
    app.use((_req, res) => {
        res.status(404).send(_buildErrorPage("Stránka nenalezena."));
    });

    // ── Globální error handler ───────────────────────────────────────────────
    // eslint-disable-next-line no-unused-vars
    app.use((err, _req, res, _next) => {
        log("ERROR", "Express error handler", String(err));
        res.status(500).json({ ok: false, error: "Interní chyba serveru" });
    });

    return app;
}

// ─────────────────────────────────────────────────────────────────────────────
// MOBILNÍ UI – jednoduché HTML stránky (inline, bez závislosti na souborech)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Sestaví HTML stránku pro upload z mobilního prohlížeče.
 *
 * @param {string} token
 * @param {string} job
 * @returns {string}
 */
function _buildUploadPage(token, job, ip, port) {
    const _ip   = ip   || "";
    const _port = port || 5000;
    const deepLink = `photobridge://upload?t=${token}&host=${_ip}&port=${_port}`;

    return `<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>PhotoBridge</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background: #0d1b2e; color: #eee; min-height: 100vh;
         display: flex; flex-direction: column; align-items: center;
         justify-content: center; padding: 24px; }

  /* ── Deep link splash ────────────────────────── */
  #splash { display:flex; flex-direction:column; align-items:center; gap:18px; text-align:center; }
  #splash .logo { font-size: 4rem; }
  #splash h1 { font-size: 1.4rem; color: #7ec8e3; }
  #splash .sub { font-size: 0.9rem; color: #aaa; }
  .spinner { width:40px; height:40px; border:4px solid rgba(126,200,227,0.2);
             border-top-color:#7ec8e3; border-radius:50%;
             animation: spin 0.8s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .open-btn { margin-top:8px; background:#7ec8e3; color:#0d1b2e; border:none;
              padding:13px 32px; border-radius:30px; font-size:1rem;
              font-weight:700; cursor:pointer; text-decoration:none;
              display:inline-block; }
  .web-link { margin-top:4px; font-size:0.8rem; color:#7ec8e3;
              cursor:pointer; text-decoration:underline; }

  /* ── Upload UI ───────────────────────────────── */
  #upload-ui { display:none; width:100%; max-width:440px; flex-direction:column; align-items:center; gap:16px; }
  #upload-ui h1 { font-size:1.4rem; color:#7ec8e3; }
  .job-badge { font-size:0.85rem; color:#aaa; }
  .drop-zone { border:2px dashed rgba(126,200,227,0.5); border-radius:16px;
               padding:36px 20px; text-align:center; cursor:pointer;
               transition:background 0.2s, border-color 0.2s;
               width:100%; }
  .drop-zone:hover, .drop-zone.over { background:rgba(126,200,227,0.08); border-color:#7ec8e3; }
  .drop-zone input[type=file] { display:none; }
  .dz-icon { font-size:2.8rem; margin-bottom:8px; }
  .hint { font-size:0.82rem; color:#aaa; margin-top:6px; }
  .upload-btn { background:#7ec8e3; color:#0d1b2e; border:none;
                padding:13px 0; border-radius:30px; font-size:1rem;
                font-weight:700; cursor:pointer; width:100%;
                transition:opacity 0.2s; }
  .upload-btn:disabled { opacity:0.45; cursor:not-allowed; }
  #status { font-size:0.88rem; min-height:1.3em; text-align:center; }
  .ok  { color:#4ade80; }
  .err { color:#f87171; }
  #preview { display:flex; flex-wrap:wrap; gap:8px; justify-content:center; }
  #preview img { width:70px; height:70px; object-fit:cover; border-radius:8px; }
  .app-btn { margin-top:4px; font-size:0.78rem; color:#aaa;
             cursor:pointer; text-decoration:underline; }
</style>
</head>
<body>

<!-- Splash: pokus o deep link -->
<div id="splash">
  <div class="logo">📷</div>
  <h1>PhotoBridge</h1>
  <div class="sub">Otevírám aplikaci…</div>
  <div class="spinner"></div>
  <a class="open-btn" id="deepLinkBtn" href="${deepLink}">Otevřít aplikaci</a>
  <span class="web-link" id="webFallbackLink">Použít webový formulář</span>
</div>

<!-- Upload UI (fallback) -->
<div id="upload-ui">
  <h1>📷 PhotoBridge</h1>
  <div class="job-badge">${job ? `Zakázka: <strong>${_escHtml(job)}</strong>` : "Připraveno k příjmu"}</div>

  <div class="drop-zone" id="dropZone">
    <label for="fileInput">
      <div class="dz-icon">🖼️</div>
      <div>Klepněte pro výběr fotek</div>
      <div class="hint">JPG · PNG · WEBP · PDF · RAW</div>
    </label>
    <input type="file" id="fileInput" multiple accept="image/*,.pdf,.raw,.dng,.cr2,.nef,.arw">
  </div>

  <div id="preview"></div>
  <button class="upload-btn" id="uploadBtn" disabled>Nahrát fotky</button>
  <div id="status"></div>
  <span class="app-btn" id="tryAppBtn">Zkusit otevřít aplikaci znovu</span>
</div>

<script>
const TOKEN    = ${JSON.stringify(token)};
const DEEP     = ${JSON.stringify(deepLink)};
const BASE_URL = window.location.origin;

/* ── Deep link logika ───────────────────────────────────── */
let appOpened  = false;
let splashDone = false;

function showUploadUI() {
  if (splashDone) return;
  splashDone = true;
  document.getElementById("splash").style.display = "none";
  document.getElementById("upload-ui").style.display = "flex";
}

// Zkus otevřít app ihned
function tryDeepLink() {
  window.location.href = DEEP;
}
tryDeepLink();

// Pokud se stránka stala neviditelnou (app se otevřela), považuj to za úspěch
document.addEventListener("visibilitychange", () => {
  if (document.hidden) appOpened = true;
});

// Po 2.8 s: pokud app nebyla otevřena → zobraz web UI
setTimeout(() => {
  if (!appOpened) showUploadUI();
}, 2800);

document.getElementById("webFallbackLink").addEventListener("click", showUploadUI);
document.getElementById("deepLinkBtn").addEventListener("click", () => {
  appOpened = false; // reset – dá uživateli další šanci
  setTimeout(() => { if (!appOpened) showUploadUI(); }, 2800);
});
document.getElementById("tryAppBtn")?.addEventListener("click", () => {
  appOpened = false;
  window.location.href = DEEP;
  setTimeout(() => { if (!appOpened) showUploadUI(); }, 2800);
});

/* ── Upload logika ──────────────────────────────────────── */
const fileInput = document.getElementById("fileInput");
const dropZone  = document.getElementById("dropZone");
const uploadBtn = document.getElementById("uploadBtn");
const statusEl  = document.getElementById("status");
const previewEl = document.getElementById("preview");
let selectedFiles = [];

function setStatus(msg, cls) {
  statusEl.textContent = msg;
  statusEl.className = cls || "";
}

function showPreviews(files) {
  previewEl.innerHTML = "";
  Array.from(files).forEach(f => {
    if (!f.type.startsWith("image/")) return;
    const img = document.createElement("img");
    img.src = URL.createObjectURL(f);
    previewEl.appendChild(img);
  });
}

fileInput.addEventListener("change", () => {
  selectedFiles = Array.from(fileInput.files);
  uploadBtn.disabled = !selectedFiles.length;
  setStatus(selectedFiles.length ? \`Vybráno: \${selectedFiles.length} soubor(ů)\` : "");
  showPreviews(selectedFiles);
});

dropZone.addEventListener("dragover", e => { e.preventDefault(); dropZone.classList.add("over"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("over"));
dropZone.addEventListener("drop", e => {
  e.preventDefault();
  dropZone.classList.remove("over");
  selectedFiles = Array.from(e.dataTransfer.files);
  uploadBtn.disabled = !selectedFiles.length;
  setStatus(selectedFiles.length ? \`Vybráno: \${selectedFiles.length} soubor(ů)\` : "");
  showPreviews(selectedFiles);
});

uploadBtn.addEventListener("click", async () => {
  if (!selectedFiles.length) return;
  uploadBtn.disabled = true;
  setStatus("Nahrávám…");
  const fd = new FormData();
  selectedFiles.forEach(f => fd.append("photos", f));
  try {
    const res  = await fetch(\`\${BASE_URL}/upload?t=\${encodeURIComponent(TOKEN)}\`, { method:"POST", body:fd });
    const data = await res.json();
    if (data.ok) {
      setStatus(\`✅ Nahráno \${data.uploaded} soubor(ů). Díky!\`, "ok");
      fileInput.value = "";
      selectedFiles = [];
      previewEl.innerHTML = "";
    } else {
      setStatus(\`❌ Chyba: \${data.error}\`, "err");
      uploadBtn.disabled = false;
    }
  } catch (e) {
    setStatus(\`❌ Síťová chyba: \${e.message}\`, "err");
    uploadBtn.disabled = false;
  }
});
</script>
</body>
</html>`;
}

/**
 * Sestaví jednoduchou HTML chybovou stránku.
 *
 * @param {string} message
 * @returns {string}
 */
function _buildErrorPage(message) {
    return `<!DOCTYPE html>
<html lang="cs">
<head><meta charset="UTF-8"><title>PhotoBridge – Chyba</title>
<style>body{font-family:sans-serif;background:#1a1a2e;color:#eee;
display:flex;align-items:center;justify-content:center;min-height:100vh;}
.box{text-align:center;padding:40px;}.icon{font-size:3rem;}.msg{margin-top:16px;color:#ff6b6b;}</style>
</head>
<body><div class="box"><div class="icon">⚠️</div>
<div class="msg">${_escHtml(message)}</div></div></body></html>`;
}

/**
 * Escapuje HTML speciální znaky (ochrana před XSS v inline HTML).
 *
 * @param {string} str
 * @returns {string}
 */
function _escHtml(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

// ─────────────────────────────────────────────────────────────────────────────
// START / STOP SERVERU
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Spustí Express HTTP server.
 *
 * Analogie Python run_server():
 *  1. Zkontroluje obsazenost preferovaného portu.
 *  2. Najde alternativní port (5000–5020) pokud je hlavní obsazený.
 *  3. Přidá firewall pravidlo (na pozadí).
 *  4. Spustí Express listener.
 *
 * @returns {Promise<void>}
 */
async function startServer() {
    if (_httpServer && _httpServer.listening) {
        log("WARNING", "Server už běží", `port=${STATE.port}`);
        return;
    }

    let port = STATE.port || 5000;
    log("INFO", "Server starting", `port=${port} host=0.0.0.0`);

    // Zkontroluj jestli port není obsazený jiným procesem
    if (!(await portIsFree(port))) {
        log("ERROR", `Port ${port} je OBSAZEN jiným procesem!`, "Zkouším alternativní port…");

        const alt = await findFreePortInRange(5001);
        if (!alt) {
            log("ERROR", "Žádný volný port 5000-5020 nebyl nalezen!", "Server se nespustí");
            STATE.running = false;
            _notifyRenderer("server:stopped", { error: "Žádný volný port nebyl nalezen" });
            return;
        }

        log("WARNING", `Používám alternativní port ${alt}`, "");
        port      = alt;
        STATE.port = alt;
    }

    // Přidej firewall pravidlo na pozadí (neblokuje start)
    if (process.platform === "win32") {
        setImmediate(() => ensureFirewallRule(port));
    }

    try {
        // Vytvoř Express app pokud ještě neexistuje
        _app = createExpressApp();

        await new Promise((resolve, reject) => {
            _httpServer = _app.listen(port, "0.0.0.0", () => {
                log("INFO", "Server naslouchá", `port=${port}`);
                STATE.running = true;
                STATE.port    = port;
                resolve();
            });

            _httpServer.once("error", (err) => {
                log("ERROR", `Server start FAILED na portu ${port}`, err.message);
                STATE.running = false;
                reject(err);
            });
        });

        _notifyRenderer("server:started", { port });

    } catch (err) {
        log("ERROR", "Server crash při spuštění", err.stack || String(err));
        STATE.running = false;
        _notifyRenderer("server:stopped", { error: err.message });
    }
}

/**
 * Zastaví Express HTTP server.
 *
 * @returns {Promise<void>}
 */
function stopServer() {
    return new Promise((resolve) => {
        if (!_httpServer || !_httpServer.listening) {
            log("WARNING", "Server nebyl spuštěn (stopServer zavolán zbytečně)", "");
            resolve();
            return;
        }

        // Zneplatni všechny relace při zastavení serveru
        invalidateAllSessions("server stop");
        STATE.running = false;

        _httpServer.close((err) => {
            if (err) {
                log("WARNING", "Chyba při zastavování serveru", err.message);
            } else {
                log("INFO", "Server zastaven", "");
            }
            _httpServer = null;
            _notifyRenderer("server:stopped", {});
            resolve();
        });
    });
}

/**
 * Odešle IPC zprávu do všech BrowserWindow instancí.
 *
 * @param {string} channel
 * @param {object} data
 */
function _notifyRenderer(channel, data) {
    try {
        const { BrowserWindow } = require("electron");
        BrowserWindow.getAllWindows().forEach((win) => {
            if (!win.isDestroyed()) {
                win.webContents.send(channel, data);
            }
        });
    } catch (_) {
        // Electron nemusí být dostupný v testech
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// IPC HANDLERY (registrace v main procesu)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Zaregistruje všechny IPC handlery pro server modul.
 * Volat z main.js po electron app.ready.
 */

/**
 * Vrátí true pokud server aktuálně naslouchá.
 * @returns {boolean}
 */
function isRunning() {
    return Boolean(_httpServer && _httpServer.listening);
}

function registerIpcHandlers() {
    // Spuštění serveru – ZAKÁZÁNO (lokální server vypnut, používá se jen Supabase)
    ipcMain.handle("server:start", async () => {
        log("INFO", "server:start", "IGNOROVÁNO – aplikace běží v Supabase-only módu");
        return { port: 0, running: false, disabled: true };
    });

    // Zastavení serveru
    ipcMain.handle("server:stop", async () => {
        await stopServer();
        return { running: false };
    });

    // Vydání tokenu – ZAKÁZÁNO (lokální server nefunguje)
    ipcMain.handle("server:issue-token", () => {
        return { token: null, disabled: true };
    });

    // Prodloužení tokenu o N minut (výchozí 20)
    ipcMain.handle("server:extend-token", (_event, { minutes } = {}) => {
        if (!STATE.token || !STATE.sessions || !STATE.sessions[STATE.token]) {
            return { ok: false, error: "no active session" };
        }
        const extMins = minutes || 20;
        STATE.sessions[STATE.token].ts      = Date.now() / 1000;
        STATE.sessions[STATE.token].minutes = extMins;
        const expiresAt = Date.now() + extMins * 60 * 1000;
        log("INFO", "Token extended", `job=${STATE.tokenJob} minutes=${extMins}`);
        return { ok: true, expiresAt, tokenMinutes: extMins };
    });

    // Zneplatnění aktuálního tokenu
    ipcMain.handle("server:invalidate-session", (_event, reason) => {
        invalidateSession(reason || "ipc request");
        return { ok: true };
    });

    // Zneplatnění VŠECH tokenů
    ipcMain.handle("server:invalidate-all", (_event, reason) => {
        invalidateAllSessions(reason || "ipc request");
        return { ok: true };
    });

    // Přepnutí příznaku qr_active
    ipcMain.handle("server:set-qr-active", (_event, { token, active }) => {
        setQrActive(token, active);
        return { ok: true };
    });

    // Dotaz na stav serveru
    ipcMain.handle("server:get-status", () => ({
        running:         STATE.running || false,
        port:            STATE.port    || 0,
        active_sessions: STATE.sessions ? Object.keys(STATE.sessions).length : 0,
        current_job:     STATE.tokenJob || "",
    }));

    log("INFO", "Server IPC handlery zaregistrovány", "");
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
    // Token management
    issueToken,
    invalidateSession,
    invalidateAllSessions,
    getSession,
    tokenValid,
    setQrActive,

    // Server lifecycle
    startServer,
    stopServer,
    isRunning,

    // Firewall (exported pro testování / manuální volání)
    ensureFirewallRule,
    _addFirewallRule,
    _addFirewallRuleElevated,

    // Port utilities
    portIsFree,
    findFreePortInRange,

    // IPC registrace
    registerIpcHandlers,

    // Přístup ke STATE (pro float fix v main.js)
    getState: () => STATE,
};
