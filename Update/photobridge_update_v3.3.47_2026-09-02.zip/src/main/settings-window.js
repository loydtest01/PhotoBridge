'use strict';
// ============================================================
// PhotoBridge – src/main/settings-window.js
// Samostatné okno nastavení (BrowserWindow) + IPC handlery
//
// Fáze: Základ + IP pro QR + Mód přenosu
//   • openSettingsWindow()   – otevře / přenese fokus na okno
//   • registerIpcHandlers()  – registruje všechny settings:* kanály
// ============================================================

const { BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs   = require('fs');

// ── Lazy importy hlavních modulů ──────────────────────────────────────────────
let _config    = null;
let _utils     = null;
let _updater   = null;
let _supabase  = null;
let _server    = null;

function cfg()      { return _config   || (_config   = require('./config'));   }
function utils()    { return _utils    || (_utils    = require('./utils'));     }
function updater()  { return _updater  || (_updater  = require('./updater'));   }
function supabase() { return _supabase || (_supabase = require('./supabase')); }
function server()   { return _server   || (_server   = require('./server'));   }

// ── Singleton reference na okno ──────────────────────────────────────────────
let _win = null;

// ── Cesta k renderer adresáři ─────────────────────────────────────────────────
const RENDERER_DIR = path.join(__dirname, '..', 'renderer');
const PRELOAD_PATH = path.join(__dirname, '..', '..', 'preload.js');

// ══════════════════════════════════════════════════════════════
// OTEVŘENÍ / FOKUS OKNA
// ══════════════════════════════════════════════════════════════

/**
 * Otevře okno nastavení (nebo mu přenese fokus, pokud již existuje).
 * @param {BrowserWindow} mainWindow  – reference na hlavní okno (pro rodičovský vztah)
 */
function openSettingsWindow(mainWindow) {
  if (_win && !_win.isDestroyed()) {
    _win.focus();
    return _win;
  }

  const cfg2 = cfg().readConfig();

  _win = new BrowserWindow({
    width:  780,
    height: 720,
    minWidth:  640,
    minHeight: 500,
    title: 'PhotoBridge – Nastavení',
    icon: path.join(__dirname, '..', '..', 'assets', 'icons', 'icon.ico'),
    parent: mainWindow || undefined,   // rodičovské okno → settings je vždy nad ním
    modal: false,                      // neblokující; true by zmrazilo hlavní okno
    webPreferences: {
      preload: PRELOAD_PATH,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      devTools: (process.argv.includes('--dev') || !require('electron').app.isPackaged),
    },
    show: false,
    backgroundColor: '#cfddf0',
    autoHideMenuBar: true,
    resizable: true,
  });

  _win.loadFile(path.join(RENDERER_DIR, 'settings.html'));

  _win.once('ready-to-show', () => {
    _win.show();
  });

  _win.on('closed', () => {
    _win = null;
  });

  return _win;
}

// ══════════════════════════════════════════════════════════════
// IPC HANDLERY
// ══════════════════════════════════════════════════════════════

let _handlersRegistered = false;

/**
 * Registruje všechny settings:* IPC kanály.
 * Volat jednou po app.whenReady().
 * @param {function} getMainWindow  – getter pro hlavní okno
 */
function registerIpcHandlers(getMainWindow) {
  if (_handlersRegistered) return;
  _handlersRegistered = true;

  // ── settings:open – otevření okna (z hlavního okna nebo tray) ────────────
  ipcMain.handle('settings:open', () => {
    const mw = getMainWindow ? getMainWindow() : null;
    openSettingsWindow(mw);
    return { ok: true };
  });

  // ── settings:load – načtení konfigurace pro formulář ────────────────────
  ipcMain.handle('settings:load', () => {
    try {
      const c    = cfg().readConfig();
      const u    = utils();
      const srv  = server();
      const bm   = cfg().getEngineBackupMeta();

      // Sestavení seznamu dostupných IPv4 s popisky
      let ips = [];
      try {
        ips = u.getLocalIpv4CandidatesWithLabels().map(([ip, label]) => ({
          ip,
          label: `${ip}  (${label})`,
        }));
      } catch (_) {}

      return {
        ok:         true,
        cfg:        c,
        version:    (() => { try { return require('../../package.json').version; } catch { return require('electron').app.getVersion(); } })(),
        port:       u.STATE?.port || parseInt(c.PORT, 10) || 5000,
        ips,
        backupMeta: bm || null,
      };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:save – zápis konfigurace ────────────────────────────────────
  ipcMain.handle('settings:save', (_evt, partial) => {
    try {
      const current = cfg().readConfig();
      const merged  = Object.assign({}, current, partial);
      cfg().writeConfig(merged);

      // Informuj VŠECHNA okna o změně konfigurace (hlavní okno, QR popup, atd.)
      try {
        const { BrowserWindow } = require('electron');
        for (const w of BrowserWindow.getAllWindows()) {
          if (!w.isDestroyed()) {
            w.webContents.send('config:changed', merged);
          }
        }
      } catch (_) {}

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:back – zavře settings okno ──────────────────────────────────
  ipcMain.handle('settings:back', () => {
    if (_win && !_win.isDestroyed()) {
      _win.close();
    }
    return { ok: true };
  });

  // ── settings:send-feedback – ruční zpětná vazba do tabulky feedback ──────
  ipcMain.handle('settings:send-feedback', async (_evt, payload) => {
    try {
      const message = (payload && payload.message ? String(payload.message) : '').trim();
      const images  = Array.isArray(payload && payload.images) ? payload.images.slice(0, 4) : [];
      if (!message && !images.length) return { ok: false, reason: 'prázdná zpráva' };
      const conf = cfg().readConfig();

      // Nahraj obrázky (pokud jsou) do bucketu feedback-attachments
      const attachments = [];
      for (const img of images) {
        try {
          const m = /^data:(.+?);base64,(.*)$/s.exec(img.dataUrl || '');
          if (!m) continue;
          const contentType = m[1];
          const buffer      = Buffer.from(m[2], 'base64');
          if (buffer.length > 6 * 1024 * 1024) continue;   // max ~6 MB/obrázek
          const up = await supabase().sbUploadFeedbackImage(conf, {
            name: img.name || 'screenshot.png',
            contentType,
            buffer,
          });
          if (up && up.ok) attachments.push({ path: up.path, name: up.name });
        } catch (_) { /* přeskoč vadný obrázek */ }
      }

      const res = await supabase().sbInsertFeedback(conf, {
        kind:       'feedback',
        message:    message || '(bez textu)',
        appVersion: require('electron').app.getVersion(),
        attachments,
      });
      return res;   // { ok:true } | { ok:false, queued:true } | { ok:false, reason }
    } catch (e) {
      return { ok: false, reason: e.message };
    }
  });

  // ── settings:pick-folder – dialog pro výběr složky ───────────────────────
  ipcMain.handle('settings:pick-folder', async () => {
    const owner = (_win && !_win.isDestroyed()) ? _win : (getMainWindow ? getMainWindow() : null);
    const result = await dialog.showOpenDialog(owner, {
      properties: ['openDirectory'],
      title: 'Vyberte složku pro ukládání',
    });
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
  });

  // ── settings:test-folder – ověření přístupnosti složky ───────────────────
  ipcMain.handle('settings:test-folder', (_evt, folderPath) => {
    try {
      if (!folderPath) return { ok: false, error: 'Cesta je prázdná.' };
      if (!fs.existsSync(folderPath)) return { ok: false, error: 'Složka neexistuje.' };
      // Ověření zápisu: zkus vytvořit dočasný soubor
      const tmp = path.join(folderPath, `.pb_write_test_${Date.now()}`);
      fs.writeFileSync(tmp, 'test', 'utf8');
      fs.unlinkSync(tmp);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:find-ips – obnovení seznamu dostupných IPv4 ─────────────────
  ipcMain.handle('settings:find-ips', () => {
    try {
      const candidates = utils().getLocalIpv4CandidatesWithLabels();
      // Vrátíme pole { ip, label } a také plochý seznam ip stringů
      const ips = candidates.map(([ip, label]) => ip);
      const detailed = candidates.map(([ip, label]) => ({ ip, label: `${ip}  (${label})` }));
      return { ok: true, ips, detailed };
    } catch (e) {
      return { ok: false, ips: [], error: e.message };
    }
  });

  // ── settings:test-qr – otevře URL v prohlížeči pro ověření QR ────────────
  ipcMain.handle('settings:test-qr', async (_evt, { ip, port }) => {
    try {
      const { shell } = require('electron');
      const url = `http://${ip}:${port}/`;
      shell.openExternal(url);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:check-updates – manuální kontrola aktualizací ──────────────
  ipcMain.handle('settings:check-updates', async (_evt, dir) => {
    try {
      const result = await updater().scanForUpdates(dir !== undefined ? dir : undefined);
      return { ok: true, ...result };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:install-updates – spustí instalaci a restart ────────────────
  ipcMain.handle('settings:install-updates', async (_evt, dir) => {
    try {
      // checkForUpdates(true) = manuální mód → zobrazí dialog Nainstalovat/Odložit/Zrušit
      const result = await updater().checkForUpdates(true);
      return { ok: true, result };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:restore-backup – obnoví zálohu engine souborů ──────────────
  ipcMain.handle('settings:restore-backup', async () => {
    try {
      const result = cfg().restoreEngineBackup();
      if (result.ok) {
        // Restart po krátké prodlevě
        setTimeout(() => {
          require('electron').app.relaunch();
          require('electron').app.quit();
        }, 2000);
      }
      return result;
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:test-login – ověření přihlašovacích údajů ──────────────────
  ipcMain.handle('settings:test-login', async (_evt, { user, pass }) => {
    try {
      if (!user || !pass) return { ok: false, error: 'Vyplň e-mail i heslo.' };
      const c = cfg().readConfig();
      const result = await supabase().sbLogin(c, user, pass);
      if (result && result.ok) {
        // Ulož přihlašovací údaje do konfigurace
        const updated = cfg().readConfig();
        updated.SB_EMAIL = user;
        updated.SB_PASS  = pass;
        cfg().writeConfig(updated);
        // Informuj hlavní okno o přihlášení
        const mw = getMainWindow ? getMainWindow() : null;
        if (mw && !mw.isDestroyed()) {
          mw.webContents.send('supabase:status', {
            loggedIn: true,
            email:    user,
            userId:   result.userId || '',
          });
        }
      }
      return result || { ok: false, error: 'Přihlášení selhalo.' };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:r2-status – ověření spojení s Cloudflare R2 Workerem ─────────
  ipcMain.handle('settings:r2-status', async () => {
    try {
      // Čerstvý token (sbEnsureToken ho při expiraci obnoví – stejně jako poller).
      let token = null;
      try { token = await supabase().sbEnsureToken(cfg().readConfig()); } catch (_) {}
      if (!token) return { ok: false, status: 'auth' };
      // sub bereme PŘÍMO z tokenu, NE ze STATE.sbUserId. Po obnově session (refresh
      // tokenu) je sbUserId prázdné (naplní se jen při plném loginu) → klíč by neseděl
      // se sub v tokenu → Worker vrací 403 ("token") i když R2 jinak funguje.
      let sub = '';
      try {
        const payload = JSON.parse(Buffer.from(
          token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64'
        ).toString('utf8'));
        sub = payload.sub || '';
      } catch (_) {}
      if (!sub) return { ok: false, status: 'auth' };
      const PB_R2_URL = 'https://photobridge-r2.photobridgesupport.workers.dev';
      const key = `${sub}/__healthcheck__`;
      const resp = await fetch(`${PB_R2_URL}/file?key=${encodeURIComponent(key)}`, {
        headers: { Authorization: `Bearer ${token}` },
        timeout: 6000,
      });
      // 404 = Worker běží + token platí + R2 binding funguje (dotázal se R2, nenašel)
      if (resp.status === 404 || resp.ok) return { ok: true };
      if (resp.status === 401 || resp.status === 403) return { ok: false, status: 'auth' };
      return { ok: false, status: 'err', code: resp.status };
    } catch (e) {
      return { ok: false, status: 'err', error: e.message };
    }
  });

  // ── settings:change-password – změna hesla přes Supabase API ────────────
  ipcMain.handle('settings:change-password', async (_evt, { currentPass, newPass }) => {
    try {
      if (!currentPass) {
        return { ok: false, error: 'Zadej původní heslo.' };
      }
      if (!newPass || newPass.length < 6) {
        return { ok: false, error: 'Heslo musí mít alespoň 6 znaků.' };
      }

      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const u    = utils();
      let email  = (c.SB_EMAIL || '').trim();

      // Po cutover/re-loginu bývá SB_EMAIL v configu prázdný, i když je
      // uživatel přihlášený → vezmi e-mail z aktivní session, případně
      // z access tokenu (JWT).
      if (!email) email = (u.STATE && u.STATE.sbEmail ? u.STATE.sbEmail : '').trim();
      if (!email) {
        const tok = u.STATE && u.STATE.sbAccessToken;
        if (tok) {
          try {
            const payload = JSON.parse(Buffer.from(tok.split('.')[1], 'base64').toString('utf8'));
            email = (payload.email || '').trim();
          } catch (_) {}
        }
      }

      if (!email) {
        return { ok: false, error: 'Nepodařilo se zjistit e-mail přihlášeného účtu. Přihlas se prosím znovu a zkus to.' };
      }

      // ── 1. Ověř původní heslo přes re-login ──────────────────────────────
      const loginResp = await fetch(`${url}/auth/v1/token?grant_type=password`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': anon },
        body:    JSON.stringify({ email, password: currentPass }),
      });
      if (!loginResp.ok) {
        return { ok: false, error: 'Původní heslo je nesprávné.' };
      }
      const loginData = await loginResp.json();
      const accessToken = loginData.access_token || u.STATE?.sbAccessToken;

      if (!accessToken) {
        return { ok: false, error: 'Nepodařilo se získat přístupový token.' };
      }

      // ── 2. Změn heslo ─────────────────────────────────────────────────────
      const resp = await fetch(`${url}/auth/v1/user`, {
        method:  'PUT',
        headers: {
          'Content-Type':  'application/json',
          'apikey':        anon,
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ password: newPass }),
      });

      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        return { ok: false, error: body.msg || body.error_description || `HTTP ${resp.status}` };
      }

      // ── 3. Ulož nové heslo lokálně ────────────────────────────────────────
      const updated = cfg().readConfig();
      updated.SB_EMAIL = email;   // doplň e-mail do configu (po cutover chyběl)
      updated.SB_PASS = newPass;
      cfg().writeConfig(updated);

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });

  // ── settings:reset-password – odešle reset email přes Supabase ───────────
  // ── settings:queue – přehled nenahraných fotek ──────────────────────────
  // scope 'me'  = moje fronta (vidí každý)
  // scope 'all' = fronty všech (jen správce, hlídá si to Edge Funkce)
  ipcMain.handle('settings:queue', async (_evt, { scope } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const resp = await fetch(`${url}/functions/v1/admin-queue`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: anon,
                   Authorization: `Bearer ${token}` },
        body:    JSON.stringify({ scope: scope === 'all' ? 'all' : 'me' }),
      });

      const out = await resp.json().catch(() => null);
      if (!resp.ok || !out || !out.ok) {
        const d = out && out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
        return { ok: false, error: ((out && out.error) || `HTTP ${resp.status}`) + d };
      }
      return out;
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:queue-requeue – vrátit čekající fotky do fronty ────────────
  // Levnější pokus než stahovat k sobě. Pomůže tam, kde zpracování na PC
  // technika selhalo a fotka jen potřebuje další pokus. Když PC neběží,
  // nezmění to nic – pak zbývá stáhnout k sobě.
  //
  // Prakticky se řádek „šťouchne“: nastaví se done=true a hned zpět na false.
  // Tím vznikne nová Realtime událost a pollery se o fotce dozvědí znovu.
  ipcMain.handle('settings:queue-requeue', async (_evt, { ids, polozky } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const list = (Array.isArray(ids) ? ids : []).filter(Boolean);
      if (!list.length) return { ok: false, error: 'Nic k vrácení.' };

      // Nejdřív ověřit, že soubory v úložišti VŮBEC JSOU. Vrátit do fronty
      // fotku, která tam není, znamená, že tam bude viset donekonečna –
      // není co stáhnout. Radši ji rovnou uzavřeme.
      const R2 = 'https://photobridge-r2.photobridgesupport.workers.dev';
      const cesty = Array.isArray(polozky) ? polozky : [];
      const chybejici = [];
      if (cesty.length) {
        for (const p of cesty) {
          try {
            const h = await fetch(`${R2}/file?key=${encodeURIComponent(p.file_path)}`,
              { method: 'HEAD', headers: { Authorization: `Bearer ${token}` } });
            if (h.status === 404) chybejici.push(p.id);
          } catch (_) { /* síťová chyba – radši zkusíme vrátit do fronty */ }
        }
      }

      const patch = async (dil, hodnota) => {
        const r = await fetch(`${url}/rest/v1/pb_queue?id=in.(${dil.join(',')})`, {
          method: 'PATCH',
          headers: { apikey: anon, Authorization: `Bearer ${token}`,
                     'Content-Type': 'application/json', Prefer: 'return=minimal' },
          body: JSON.stringify({ done: hodnota }),
        });
        return r.ok;
      };

      // Chybějící soubory rovnou uzavřít, zbytek vrátit do fronty
      const kVraceni = list.filter(id => !chybejici.includes(id));

      let uzavreno = 0;
      for (let i = 0; i < chybejici.length; i += 100) {
        const dil = chybejici.slice(i, i + 100);
        if (await patch(dil, true)) uzavreno += dil.length;
      }

      let vraceno = 0;
      for (let i = 0; i < kVraceni.length; i += 100) {
        const dil = kVraceni.slice(i, i + 100);
        await patch(dil, true);                        // šťouch
        if (await patch(dil, false)) vraceno += dil.length;
      }

      utils().log('INFO', 'QUEUE',
        `Vráceno do fronty: ${vraceno}`
        + (uzavreno ? `, uzavřeno bez vracení: ${uzavreno} (v úložišti nejsou)` : ''));
      return { ok: true, vraceno, uzavreno };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:queue-download – stáhnout čekající fotky k sobě ────────────
  // Fotka čeká ve frontě, protože PC technika neběží nebo není v síti.
  // Správce si ji stáhne k sobě a zpracuje – UploadScan je společný,
  // takže nezáleží, kdo ji pořídil.
  ipcMain.handle('settings:queue-download', async (_evt, { polozky } = {}) => {
    const fs   = require('fs');
    const path = require('path');
    try {
      const c       = cfg().readConfig();
      const url     = (c.SB_URL  || '').trim();
      const anon    = (c.SB_ANON || '').trim();
      const saveDir = (c.SAVE_DIR || '').trim();
      if (!saveDir || !fs.existsSync(saveDir)) {
        return { ok: false, error: `Cílová složka není dostupná: ${saveDir || '(nenastavena)'}` };
      }

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const R2 = 'https://photobridge-r2.photobridgesupport.workers.dev';
      const list = Array.isArray(polozky) ? polozky : [];
      if (!list.length) return { ok: false, error: 'Nic ke stažení.' };

      let ulozeno = 0;
      let uzavreno = 0;              // soubor v úložišti není → jen odbavit
      const hotoveId = [];
      const chyby = [];

      for (const p of list) {
        try {
          const resp = await fetch(`${R2}/file?key=${encodeURIComponent(p.file_path)}`,
            { headers: { Authorization: `Bearer ${token}` } });

          // 404 = soubor v úložišti není. Buď se už zpracoval, nebo ho někdo
          // stáhl ručně. Držet takový řádek ve frontě nemá smysl – není co
          // stahovat a jen by strašil v přehledu a v ranním e-mailu.
          if (resp.status === 404) {
            if (p.id) hotoveId.push(p.id);
            uzavreno++;
            continue;
          }
          if (!resp.ok) { chyby.push(`${p.file_path}: HTTP ${resp.status}`); continue; }

          const buf = Buffer.from(await resp.arrayBuffer());
          if (!buf.length) { chyby.push(`${p.file_path}: prázdný soubor`); continue; }

          // POZOR: NEUKLÁDAT pod jménem z úložiště.
          // V zakázce musí být SP_4529903A.jpg, ne SP_4529903_1786339080765_001.jpg.
          // Použijeme proto tu samou funkci, kterou používá běžné zpracování –
          // ta vyrobí správné jméno s písmenem podle už uložených fotek,
          // založí podsložku zakázky a případně pošle do editoru.
          const maxMb = Number(c.MAX_IMG_MB) || 3;
          const res = await supabase()._finalizeToDisk(saveDir, p.file_path, buf, maxMb);
          if (!res || !res.outPath) { chyby.push(`${p.file_path}: uložení selhalo`); continue; }

          ulozeno++;
          if (p.id) hotoveId.push(p.id);

          // Uklidit z úložiště – stejně jako to dělá běžné zpracování.
          // AŽ PO ÚSPĚŠNÉM ULOŽENÍ, jinak by se fotka ztratila.
          try {
            await fetch(`${R2}/file?key=${encodeURIComponent(p.file_path)}`,
              { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
          } catch (_) { /* neuklizený soubor je menší zlo než ztracená fotka */ }
        } catch (e) {
          chyby.push(`${p.file_path}: ${e.message}`);
        }
      }

      // Označit jako hotové AŽ po uložení. Jinak by fotka zmizela z fronty,
      // aniž by se kamkoli dostala – přesně chyba, kterou jsme řešili.
      // POZOR: PostgREST u PATCH, který kvůli pravidlům neprojde na žádný
      // řádek, VRÁTÍ ÚSPĚCH. Neodmítne to, jen neudělá nic – aplikace pak
      // hlásí „odbaveno 2", zatímco ve frontě fotky visí dál.
      //
      // POČÍTÁ SE PŘES Content-Range, NE PŘES VRÁCENÉ ŘÁDKY.
      // v3.3.39 používala return=representation, jenže vrácení řádků
      // vyžaduje PRÁVO JE ČÍST – a to správce u cizích záznamů nemá
      // (přehled front proto chodí přes Edge funkci). Zápis prošel, server
      // ale nemohl nic vrátit, a aplikace to spočítala jako neúspěch.
      //
      // count=exact vrací počet OPRAVDU ZMĚNĚNÝCH řádků v hlavičce
      // a na právu ke čtení nezávisí.
      let odbaveno = 0;
      let neodbaveno = 0;
      for (let i = 0; i < hotoveId.length; i += 100) {
        const dil = hotoveId.slice(i, i + 100);
        const r = await fetch(`${url}/rest/v1/pb_queue?id=in.(${dil.join(',')})`, {
          method: 'PATCH',
          headers: { apikey: anon, Authorization: `Bearer ${token}`,
                     'Content-Type': 'application/json',
                     Prefer: 'return=minimal,count=exact' },
          body: JSON.stringify({ done: true }),
        });

        if (!r.ok) {
          neodbaveno += dil.length;
          utils().log('WARN', 'QUEUE', `Odbavení selhalo: HTTP ${r.status}`);
          continue;
        }

        // Hlavička má tvar "0-1/2" nebo "*/2" – za lomítkem je počet
        // změněných řádků.
        const rozsah = r.headers.get('content-range') || '';
        const m = rozsah.match(/\/(\d+)\s*$/);
        const pocet = m ? Number(m[1]) : dil.length;   // bez hlavičky věříme serveru

        odbaveno   += pocet;
        neodbaveno += Math.max(0, dil.length - pocet);
      }

      if (neodbaveno) {
        utils().log('WARN', 'QUEUE',
          `${neodbaveno} fotek se nepodařilo odbavit – nejspíš chybí pravidlo `
          + `pb_queue_admin_update (viz sql_admin_fronta.sql)`);
      }

      utils().log('INFO', 'QUEUE',
        `Staženo správcem: ${ulozeno}/${list.length} do ${saveDir}`
        + (uzavreno ? `, uzavřeno bez stahování: ${uzavreno} (v úložišti nejsou)` : ''));
      return { ok: true, ulozeno, uzavreno, odbaveno, neodbaveno,
               chyby: chyby.slice(0, 20), slozka: saveDir };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ══════════════════════════════════════════════════════════════════════
  //  ZÁCHRANA FOTEK Z R2
  // ══════════════════════════════════════════════════════════════════════
  //  Porovná, co leží v úložišti, s tím, co je ve frontě. Rozliší tři stavy:
  //
  //    chybi   – soubor v R2 je, ale řádek ve frontě vůbec neexistuje
  //              (zápis do fronty selhal – chyba „cannot access sentByMobile“)
  //    hotovo  – řádek má done=true, ale soubor pořád v R2 leží
  //              (označilo se to jako hotové, aniž se fotka uložila)
  //    ceka    – řádek má done=false, fotka se teprve zpracovává
  //
  //  Tyhle tři případy potřebují každý jiné řešení, proto se nesměšují.
  // ══════════════════════════════════════════════════════════════════════

  const R2_WORKER = 'https://photobridge-r2.photobridgesupport.workers.dev';

  /** Vypíše obsah R2 (jen správce – hlídá si to Worker). */
  async function _r2Seznam(token, minHours) {
    const resp = await fetch(
      `${R2_WORKER}/list?limit=5000&min_hours=${Number(minHours) || 0}`,
      { headers: { Authorization: `Bearer ${token}` } });

    const out = await resp.json().catch(() => null);
    if (!resp.ok || !out || !out.ok) {
      throw new Error((out && out.error) || `Worker vrátil HTTP ${resp.status}`
        + (resp.status === 403 ? ' – nasazený Worker možná nemá /list' : ''));
    }
    return out;
  }

  /** Řádky fronty k daným cestám. Vrací mapu file_path → { id, done }. */
  async function _frontaProCesty(url, anon, token, cesty) {
    const mapa = new Map();
    for (let i = 0; i < cesty.length; i += 100) {          // po stovkách, ať URL nepřeteče
      const dil = cesty.slice(i, i + 100);
      const filtr = dil.map(c => `"${c.replace(/"/g, '')}"`).join(',');
      const resp = await fetch(
        `${url}/rest/v1/pb_queue?file_path=in.(${encodeURIComponent(filtr)})&select=id,file_path,done`,
        { headers: { apikey: anon, Authorization: `Bearer ${token}` } });
      if (!resp.ok) continue;
      for (const r of (await resp.json().catch(() => []))) {
        mapa.set(r.file_path, { id: r.id, done: r.done });
      }
    }
    return mapa;
  }

  ipcMain.handle('settings:r2-check', async (_evt, { minHours } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const seznam = await _r2Seznam(token, minHours);
      const cesty  = seznam.objekty.map(o => o.key);
      const fronta = await _frontaProCesty(url, anon, token, cesty);

      const chybi = [], hotovo = [], ceka = [];
      for (const o of seznam.objekty) {
        const r = fronta.get(o.key);
        if (!r)            chybi.push(o);
        else if (r.done)   hotovo.push({ ...o, rowId: r.id });
        else               ceka.push({ ...o, rowId: r.id });
      }

      return {
        ok: true,
        celkem: seznam.pocet, celkem_mb: seznam.celkem_mb,
        chybi, hotovo, ceka,
      };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  /**
   * Stáhne vybrané soubory z R2 rovnou do cílové složky.
   * Obchází frontu úplně – použije se, když ji nechceme čekat nebo když
   * řádky vůbec neexistují. UploadScan je společný, takže nezáleží,
   * kdo fotku pořídil.
   */
  ipcMain.handle('settings:r2-download', async (_evt, { keys, smazat } = {}) => {
    const fs   = require('fs');
    const path = require('path');
    try {
      const c       = cfg().readConfig();
      const saveDir = (c.SAVE_DIR || '').trim();
      if (!saveDir) return { ok: false, error: 'Není nastavená cílová složka.' };
      if (!fs.existsSync(saveDir)) {
        return { ok: false, error: `Cílová složka není dostupná: ${saveDir}` };
      }

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const seznam = Array.isArray(keys) ? keys : [];
      if (!seznam.length) return { ok: false, error: 'Nic k stažení.' };

      let ulozeno = 0, smazano = 0;
      const chyby = [];

      for (const key of seznam) {
        try {
          const resp = await fetch(`${R2_WORKER}/file?key=${encodeURIComponent(key)}`,
            { headers: { Authorization: `Bearer ${token}` } });
          if (!resp.ok) { chyby.push(`${key}: HTTP ${resp.status}`); continue; }

          const buf = Buffer.from(await resp.arrayBuffer());
          if (!buf.length) { chyby.push(`${key}: prázdný soubor`); continue; }

          // Stejně jako u fronty: jméno musí vzniknout přes _finalizeToDisk,
          // jinak by v zakázce byl SP_4529903_1786339080765_001.jpg místo
          // SP_4529903A.jpg a v RTS by to neprošlo.
          const maxMb = Number(c.MAX_IMG_MB) || 3;
          const res = await supabase()._finalizeToDisk(saveDir, key, buf, maxMb);
          if (!res || !res.outPath) { chyby.push(`${key}: uložení selhalo`); continue; }
          ulozeno++;

          // Smazat z R2 AŽ po úspěšném zápisu. Obráceně by se fotka ztratila.
          if (smazat) {
            const d = await fetch(`${R2_WORKER}/file?key=${encodeURIComponent(key)}`,
              { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
            if (d.ok) smazano++;
          }
        } catch (e) {
          chyby.push(`${key}: ${e.message}`);
        }
      }

      utils().log('INFO', 'R2_ZACHRANA',
        `Staženo ${ulozeno}/${seznam.length} do ${saveDir}`
        + (smazano ? `, smazáno z R2: ${smazano}` : '')
        + (chyby.length ? `, chyb: ${chyby.length}` : ''));

      return { ok: true, ulozeno, smazano, chyby: chyby.slice(0, 20), slozka: saveDir };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  /** Vrátí řádky do fronty – zpracují si je PC techniků jako obvykle. */
  ipcMain.handle('settings:r2-requeue', async (_evt, { rowIds } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const ids = (Array.isArray(rowIds) ? rowIds : []).filter(Boolean);
      if (!ids.length) return { ok: false, error: 'Nic k vrácení do fronty.' };

      let vraceno = 0;
      for (let i = 0; i < ids.length; i += 100) {
        const dil = ids.slice(i, i + 100);
        const resp = await fetch(
          `${url}/rest/v1/pb_queue?id=in.(${dil.join(',')})`,
          { method: 'PATCH',
            headers: { apikey: anon, Authorization: `Bearer ${token}`,
                       'Content-Type': 'application/json', Prefer: 'return=minimal' },
            body: JSON.stringify({ done: false }) });
        if (resp.ok) vraceno += dil.length;
      }

      utils().log('INFO', 'R2_ZACHRANA', `Vráceno do fronty: ${vraceno} řádků`);
      return { ok: true, vraceno };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:urgent-signal – vyhlásit okamžitou aktualizaci ─────────────
  // Zapíše verzi do pb_settings.urgent_version. Všechny běžící aplikace to
  // dostanou Realtime push zprávou a nainstalují se během vteřin.
  ipcMain.handle('settings:urgent-signal', async (_evt, { version } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const resp = await fetch(`${url}/functions/v1/admin-queue`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: anon,
                   Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: 'signal', version: String(version || '').trim() }),
      });

      const out = await resp.json().catch(() => null);
      if (!resp.ok || !out || !out.ok) {
        const d = out && out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
        return { ok: false, error: ((out && out.error) || `HTTP ${resp.status}`) + d };
      }
      utils().log('INFO', 'UPDATE', `Vyhlášena aktualizace na ${out.version || '(zrušeno)'}`);
      return out;
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:queue-cleanup – úklid staré fronty ─────────────────────────
  // Maže JEN zpracované záznamy (done=true) starší než zadaný počet dní.
  // Nezpracované se nesahají nikdy – to by byla ztráta fotek.
  // Bez dryRun=false se jen spočítá, kolik by se smazalo.
  ipcMain.handle('settings:queue-cleanup', async (_evt, { days, dryRun } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const resp = await fetch(`${url}/functions/v1/admin-queue`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: anon,
                   Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          action:  'cleanup',
          days:    Number(days) || 90,
          dry_run: dryRun !== false,
        }),
      });

      const out = await resp.json().catch(() => null);
      if (!resp.ok || !out || !out.ok) {
        const d = out && out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
        return { ok: false, error: ((out && out.error) || `HTTP ${resp.status}`) + d };
      }
      if (out.dry_run === false) {
        utils().log('INFO', 'QUEUE', `Úklid fronty: smazáno ${out.smazano} záznamů starších ${out.dnu} dní`);
      }
      return out;
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  /** Vytáhne ID účtu z přihlašovacího tokenu (JWT claim "sub"). */
  function _uidZTokenu(token) {
    try {
      const cast = String(token).split('.')[1];
      if (!cast) return '';
      const json = Buffer.from(cast.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
      return JSON.parse(json).sub || '';
    } catch (_) { return ''; }
  }

  /**
   * Začátek období pro statistiku.
   *
   * U „tohoto týdne" (7 dní) se počítá od PONDĚLÍ, ne od dneška mínus sedm —
   * technik se ptá „kolik jsem tento týden nafotil", ne „za posledních 168
   * hodin". U delších období se odečítá prostě zpětně.
   */
  function _zacatekObdobi(dnu) {
    const d = new Date();
    if (dnu === 7) {
      const den = (d.getDay() + 6) % 7;     // pondělí = 0
      d.setDate(d.getDate() - den);
      d.setHours(0, 0, 0, 0);
      return d;
    }
    d.setDate(d.getDate() - dnu);
    d.setHours(0, 0, 0, 0);
    return d;
  }

  // ── Volání Edge funkce admin-queue ──────────────────────────────────────
  // POJISTKA, KTEROU NELZE VYNECHAT
  // admin-queue neznámou akci NEODMÍTNE – propadne až na výpis fronty a vrátí
  // ok:true se seznamem položek. Kdyby na serveru ležela stará verze funkce,
  // aplikace by si myslela, že správce přidala, a ono by se nestalo nic.
  // Proto se kontroluje, že se v odpovědi vrátila TÁŽ akce, která se poslala.
  async function volejAdminQueue(telo) {
    const c    = cfg().readConfig();
    const url  = (c.SB_URL  || '').trim();
    const anon = (c.SB_ANON || '').trim();
    if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

    const token = await supabase().sbEnsureToken(c);
    if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

    const resp = await fetch(`${url}/functions/v1/admin-queue`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', apikey: anon,
                 Authorization: `Bearer ${token}` },
      body:    JSON.stringify(telo),
    });

    const out = await resp.json().catch(() => null);
    if (!resp.ok || !out || !out.ok) {
      const d = out && out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
      return { ok: false, error: ((out && out.error) || `HTTP ${resp.status}`) + d };
    }

    if (out.action !== telo.action) {
      return { ok: false, stara_funkce: true,
               error: `Edge funkce admin-queue zatím neumí akci „${telo.action}". `
                    + 'Nasaď její novou verzi a nezapomeň po Deploy vypnout '
                    + '„Verify JWT with legacy secret".' };
    }
    return out;
  }

  // ── settings:admins-list – kdo je správce ───────────────────────────────
  ipcMain.handle('settings:admins-list', async () => {
    try { return await volejAdminQueue({ action: 'admins' }); }
    catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:admin-add / admin-remove ───────────────────────────────────
  // Tímhle se rozdává plná moc nad frontami všech techniků, proto se to
  // zapisuje do logu i tady, ne jen na serveru.
  ipcMain.handle('settings:admin-add', async (_evt, { email } = {}) => {
    try {
      const out = await volejAdminQueue({ action: 'admin-add', email });
      if (out.ok && out.zmeneno) utils().log('INFO', 'ADMIN', `Přidán správce: ${email}`);
      return out;
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  ipcMain.handle('settings:admin-remove', async (_evt, { email } = {}) => {
    try {
      const out = await volejAdminQueue({ action: 'admin-remove', email });
      if (out.ok && out.zmeneno) utils().log('INFO', 'ADMIN', `Odebrán správce: ${email}`);
      return out;
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:cleanup-config – nastavení automatického úklidu ────────────
  // Ukládá se CENTRÁLNĚ do pb_settings, ne do config.json. Do v3.3.8 si každé
  // správcovské PC vedlo vlastní počítání a hranice 90 dní byla natvrdo
  // v kódu, takže výběr v seznamu „Starší než" se na automatický úklid
  // vůbec neprojevil.
  ipcMain.handle('settings:cleanup-config', async (_evt, { days, enabled } = {}) => {
    try {
      const out = await volejAdminQueue({ action: 'cleanup-config', days, enabled });
      if (out.ok) {
        utils().log('INFO', 'QUEUE',
          `Automatický úklid: ${out.zapnuto ? `zapnut, hranice ${out.dnu} dní` : 'vypnut'}`);
      }
      return out;
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:zalohy – seznam a otevření složky ─────────────────────────
  ipcMain.handle('settings:zalohy', async (_evt, { akce } = {}) => {
    try {
      const z = require('./denni-zaloha');
      if (akce === 'otevrit') return z.otevriSlozku();
      if (akce === 'zalohovat') {
        // Ruční vyvolání ignoruje pravidlo „jednou denně" jen tehdy, když
        // dnešní záloha ještě není – jinak by se přepisoval stav PŘED
        // aktualizací stavem PO ní, a záloha by ztratila smysl.
        const r = z.zalohujPokudTreba();
        return r.ok ? { ok: true, ...r } : { ok: false, error: r.duvod };
      }
      return { ok: true, seznam: z.seznam(), maDnesni: z.maDnesniZalohu() };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:zakazane-verze – čtení a zápis seznamu ────────────────────
  //
  // Zapisuje se do pb_settings.zakazane_verze, odkud si to počítače
  // vyzvednou Realtime kanálem a uloží lokálně. Platí to pak i bez sítě.
  ipcMain.handle('settings:zakazane-verze', async (_evt, { hodnota } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      // Bez parametru jen čteme.
      if (hodnota === undefined) {
        const r = await fetch(`${url}/rest/v1/pb_settings?key=eq.zakazane_verze&select=value`, {
          headers: { apikey: anon, Authorization: `Bearer ${token}`, Accept: 'application/json' },
        });
        if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
        const rows = await r.json();
        return { ok: true, hodnota: (rows && rows[0] && rows[0].value) || '' };
      }

      const r = await fetch(`${url}/rest/v1/pb_settings?key=eq.zakazane_verze`, {
        method: 'PATCH',
        headers: {
          apikey: anon, Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json', Prefer: 'return=minimal',
        },
        body: JSON.stringify({ value: String(hodnota || '').trim() }),
      });

      if (!r.ok) {
        return { ok: false, error: r.status === 403
          ? 'Chybí oprávnění – spusť sql_zakazane_verze.sql v Supabase.'
          : `HTTP ${r.status}` };
      }
      return { ok: true };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:verze-dotaz – zeptat se počítačů, co běží ─────────────────
  //
  // Zapíše časovou značku do pb_settings.verze_dotaz. Všechny běžící
  // aplikace to dostanou Realtime kanálem, na kterém už visí, a zapíšou
  // svůj řádek do pb_verze.
  //
  // ZÁMĚRNĚ RUČNĚ, ne pravidelně. Jedno kliknutí = jeden zápis správce
  // + jeden od každého běžícího počítače. Kdyby se to dělalo automaticky
  // každou minutu, byla by to zbytečná zátěž kvůli údaji, který nikdo
  // většinu času nepotřebuje.
  ipcMain.handle('settings:verze-dotaz', async () => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const resp = await fetch(`${url}/rest/v1/pb_settings?key=eq.verze_dotaz`, {
        method: 'PATCH',
        headers: {
          apikey: anon, Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json', Prefer: 'return=minimal',
        },
        body: JSON.stringify({ value: String(Date.now()) }),
      });

      if (!resp.ok) {
        const t = await resp.text();
        // 403 = chybí pravidlo v databázi, ne chyba aplikace.
        return { ok: false, error: resp.status === 403
          ? 'Chybí oprávnění – spusť sql_prehled_verzi.sql v Supabase.'
          : `HTTP ${resp.status} ${t.slice(0, 120)}` };
      }
      return { ok: true };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:verze-prehled – kdo se ozval ──────────────────────────────
  ipcMain.handle('settings:verze-prehled', async () => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      const resp = await fetch(
        `${url}/rest/v1/pb_verze?select=email,hostname,verze,os,kdy&order=kdy.desc&limit=200`,
        { headers: { apikey: anon, Authorization: `Bearer ${token}`, Accept: 'application/json' } });

      if (!resp.ok) {
        return { ok: false, error: resp.status === 403 || resp.status === 401
          ? 'Přehled vidí jen správce.'
          : `HTTP ${resp.status}` };
      }
      return { ok: true, radky: await resp.json() };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:my-stats – kolik toho technik nafotil ──────────────────────
  //
  // ZÁMĚRNĚ PŘES REST, NE PŘES EDGE FUNKCI.
  // Edge funkce se počítají do limitu (500 tis. volání měsíčně), REST dotazy
  // ne — platí se u nich jen za přenesená data, a tady jde o pár kilobajtů.
  // Při osmi technicích, kteří si přehled otevřou párkrát denně, je to nula.
  //
  // Fotky se navíc filtrují na vlastní účet, takže technik vidí jen své.
  ipcMain.handle('settings:my-stats', async (_evt, { days } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const token = await supabase().sbEnsureToken(c);
      if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

      // ID účtu se čte přímo z tokenu (claim "sub"). supabase.js ho neexportuje
      // a přibalovat kvůli tomu celý modul do balíčku by bylo zbytečné riziko.
      const uid = _uidZTokenu(token);
      if (!uid) return { ok: false, error: 'Nepodařilo se zjistit účet.' };

      const dnu = Math.max(1, Math.min(365, Number(days) || 7));
      const od  = _zacatekObdobi(dnu);

      // Bereme jen to, co je potřeba k počítání — ne celé řádky.
      const dotaz = `${url}/rest/v1/pb_queue`
        + `?user_id=eq.${encodeURIComponent(uid)}`
        + `&created_at=gte.${encodeURIComponent(od.toISOString())}`
        + `&select=file_path,done,created_at&limit=5000`;

      const resp = await fetch(dotaz, {
        headers: { apikey: anon, Authorization: `Bearer ${token}`, Accept: 'application/json' },
      });
      if (!resp.ok) return { ok: false, error: `HTTP ${resp.status}` };

      const rows = await resp.json();
      if (!Array.isArray(rows)) return { ok: false, error: 'Neočekávaná odpověď' };

      const typy = {};
      let ceka = 0;
      for (const r of rows) {
        if (r.done === false) ceka++;
        const jmeno = String(r.file_path || '').split('/').pop() || '';
        const m = jmeno.match(/^([A-Z]+)_\d{6,}/);
        const typ = m ? m[1] : 'ostatní';
        typy[typ] = (typy[typ] || 0) + 1;
      }

      return {
        ok: true, dnu, celkem: rows.length, ceka,
        od: od.toISOString(),
        typy: Object.entries(typy)
          .map(([typ, pocet]) => ({ typ, pocet }))
          .sort((a, b) => (a.typ === 'ostatní') - (b.typ === 'ostatní') || b.pocet - a.pocet),
      };
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:summary – souhrn provozu za posledních N dní ───────────────
  ipcMain.handle('settings:summary', async (_evt, { days } = {}) => {
    try { return await volejAdminQueue({ action: 'summary', days: days || 7 }); }
    catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:rts-mode – centrální režim odesílání ───────────────────────
  // Bez parametru čte, s parametrem zapisuje. Zápis jde přes Edge funkci,
  // protože technici do pb_settings zapisovat nesmí.
  //
  // POZOR: přepnutí platí pro CELOU FIRMU a projeví se během vteřin, protože
  // aplikace poslouchají Realtime kanál na pb_settings.
  ipcMain.handle('settings:rts-mode', async (_evt, { mode } = {}) => {
    try {
      const out = await volejAdminQueue(
        mode === undefined ? { action: 'rts-mode' } : { action: 'rts-mode', mode });
      if (out.ok && mode !== undefined) {
        utils().log('INFO', 'RTS_REZIM', `Režim přepnut centrálně na: ${mode}`);
      }
      return out;
    } catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:rts-mode-local – co platí na tomhle počítači ───────────────
  // Aby Nastavení poznalo, jestli má lokální seznam zašednout.
  ipcMain.handle('settings:rts-mode-local', async () => {
    try { return { ok: true, ...require('./api-upload').stavRizeni() }; }
    catch (e) { return { ok: false, error: String(e.message || e) }; }
  });

  // ── settings:queue-retry – pobídnout frontu ke zpracování ───────────────
  ipcMain.handle('settings:queue-retry', async () => {
    try {
      const c = cfg().readConfig();
      const saveDir = (c.SAVE_DIR || '').trim();
      if (!saveDir) return { ok: false, error: 'Není nastavená cílová složka.' };

      supabase().stopSbPoller?.();
      supabase().startSbPoller?.(c, saveDir);
      utils().log('INFO', 'QUEUE', 'Fronta znovu spuštěna na žádost uživatele');
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:admin-status – je přihlášený technik správce? ──────────────
  // ZÁMĚRNĚ se to neodvozuje z PINu. Konfigurace je lokální, takže by si
  // technik na svém PC nastavil vlastní PIN a byl uvnitř. Seznam správců
  // je centrálně v pb_settings.admin_emails; od v3.3.9 se mění v Admin
  // centru (přes Edge funkci), dřív se musel upravovat ručně v SQL.
  ipcMain.handle('settings:admin-status', async () => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      const pinSet = Boolean(String(c.ADMIN_PIN || '').trim());

      const email = String(utils().STATE?.sbEmail || c.SB_EMAIL || '').trim().toLowerCase();
      if (!url || !anon || !email) return { ok: true, isAdmin: false, pinSet, email };

      // Čteme přihlašovacím tokenem – seznam správců není veřejný
      let token = anon;
      try { token = (await supabase().sbEnsureToken(c)) || anon; } catch (_) {}

      const resp = await fetch(
        `${url}/rest/v1/pb_settings?key=eq.admin_emails&select=value`,
        { headers: { apikey: anon, Authorization: `Bearer ${token}` } });

      if (!resp.ok) return { ok: true, isAdmin: false, pinSet, email };

      const rows = await resp.json().catch(() => []);
      const list = String(rows?.[0]?.value || '')
        .split(',').map(x => x.trim().toLowerCase()).filter(Boolean);

      const isAdmin = list.includes(email);

      // Zapamatovat – denní záloha se dělá při startu, tedy dřív, než se
      // dá kdokoli zeptat serveru. Bez zapamatování by se po restartu
      // bez sítě nezálohovalo.
      try {
        const cm = cfg();
        if (String(cm.readConfig().JE_SPRAVCE) !== String(isAdmin)) {
          cm.writeConfig(Object.assign({}, cm.readConfig(),
            { JE_SPRAVCE: isAdmin ? 'true' : 'false' }));
        }
      } catch (_) {}

      return { ok: true, isAdmin, pinSet, email };
    } catch (e) {
      return { ok: false, error: String(e.message || e), isAdmin: false };
    }
  });

  // ── settings:verify-account – ověření hesla k účtu ──────────────────────
  // Používá se při obnově zapomenutého PINu. Kdo se umí přihlásit, je
  // oprávněný odemknout administrátorská pole.
  ipcMain.handle('settings:verify-account', async (_evt, { email, password } = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };
      if (!email || !password) return { ok: false, error: 'Chybí e-mail nebo heslo.' };

      const resp = await fetch(`${url}/auth/v1/token?grant_type=password`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: anon },
        body:    JSON.stringify({ email: String(email).trim(), password }),
      });
      if (!resp.ok) return { ok: false, error: 'Nesprávný e-mail nebo heslo' };

      utils().log('INFO', 'ADMIN', `PIN odemčen heslem účtu: ${email}`);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  // ── settings:delete-account – smazání vlastního účtu ────────────────────
  // Dvoukrokové: bez confirm vrátí přehled nenahraných fotek, teprve
  // s confirm maže. Vlastní mazání dělá Edge Funkce, protože potřebuje
  // klíč service_role – ten v aplikaci není a být nemá.
  ipcMain.handle('settings:delete-account', async (_evt, opts = {}) => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();
      if (!url || !anon) return { ok: false, error: 'Supabase není nastaven.' };

      const body = {
        email:        String(opts.email || '').trim(),
        password:     String(opts.password || ''),
        confirm:      opts.confirm === true,
        delete_queue: opts.deleteQueue === true,
      };
      if (!body.email)    return { ok: false, error: 'Zadej e-mail.' };
      if (!body.password) return { ok: false, error: 'Zadej heslo.' };

      const resp = await fetch(`${url}/functions/v1/delete-account`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', apikey: anon,
                   Authorization: `Bearer ${anon}` },
        body:    JSON.stringify(body),
      });

      const out = await resp.json().catch(() => null);
      if (!resp.ok || !out || !out.ok) {
        const detail = out && out.detail ? ` – ${String(out.detail).slice(0, 150)}` : '';
        return { ok: false, error: ((out && out.error) || `HTTP ${resp.status}`) + detail };
      }

      if (out.stage === 'deleted') {
        utils().log('INFO', 'ACCOUNT', `Účet smazán: ${out.email}`);
        try { require('./supabase').sbLogout && require('./supabase').sbLogout(); } catch (_) {}
      }
      return out;
    } catch (e) {
      return { ok: false, error: String(e.message || e) };
    }
  });

  ipcMain.handle('settings:reset-password', async () => {
    try {
      const c    = cfg().readConfig();
      const url  = (c.SB_URL  || '').trim();
      const anon = (c.SB_ANON || '').trim();

      if (!url || !anon) {
        return { ok: false, error: 'Supabase URL nebo klíč není nastaven.' };
      }

      // Zkus email z JWT tokenu (přihlášený uživatel) → fallback na config
      let email = '';
      try {
        const token = utils().STATE?.sbAccessToken;
        if (token) {
          const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString('utf8'));
          email = payload.email || '';
        }
      } catch (_) {}

      if (!email) email = (c.SB_EMAIL || '').trim();

      if (!email) {
        return { ok: false, error: 'Nepodařilo se zjistit email. Zadej ho v poli E-mail a ulož.' };
      }

      const resp = await fetch(`${url}/auth/v1/recover`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': anon },
        body:    JSON.stringify({ email }),
      });

      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        return { ok: false, error: body.msg || body.error_description || `HTTP ${resp.status}` };
      }

      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  });
}

// ══════════════════════════════════════════════════════════════
// EXPORT
// ══════════════════════════════════════════════════════════════

module.exports = {
  openSettingsWindow,
  registerIpcHandlers,
  getSettingsWindow: () => _win,
};
