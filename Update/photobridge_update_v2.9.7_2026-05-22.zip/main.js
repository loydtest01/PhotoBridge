'use strict';
// ============================================================
// PhotoBridge – Electron main process
// main.js – vstupní bod aplikace
// Odpovídá: Python photobridge.py řádky 1–345 (bootstrap, konstanty, shutdown)
// ============================================================

const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, shell, dialog, Notification } = require('electron');
const path  = require('path');
const fs    = require('fs');
const os    = require('os');

// ── Vývojový mód ─────────────────────────────────────────────────────────────
const IS_DEV = process.argv.includes('--dev') || !app.isPackaged;

// ── Konstanty aplikace ────────────────────────────────────────────────────────
// Odpovídá: APP_NAME, APP_VERSION, CONFIG_NAME, STATE_NAME atd. v Python kódu
const APP_NAME    = 'PhotoBridge';
const APP_VERSION = app.getVersion(); // čte z package.json – vždy aktuální

// Složky pro data uživatele (ekvivalent CWD v Python verzi)
const USER_DATA_DIR  = app.getPath('userData');          // %APPDATA%/PhotoBridge
const LOGS_DIR       = path.join(USER_DATA_DIR, 'logs');
const BACKUP_DIR     = path.join(USER_DATA_DIR, 'backups');
const PAINT_TEMP_DIR = path.join(__dirname, 'paint_temp');  // kořen projektu

// Soubory
const CONFIG_FILE     = path.join(USER_DATA_DIR, 'config.json');
const STATE_FILE      = path.join(USER_DATA_DIR, 'state.json');
const CRASH_FLAG_FILE = path.join(USER_DATA_DIR, 'crash_flag.txt');

// Složky assets (ikony, HTML stránky) – relativní k main.js
const ASSETS_DIR   = path.join(__dirname, 'assets');
const RENDERER_DIR = path.join(__dirname, 'src', 'renderer');

// ── Složky: vytvoř pokud neexistují ──────────────────────────────────────────
for (const dir of [USER_DATA_DIR, LOGS_DIR, BACKUP_DIR, PAINT_TEMP_DIR]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// ── Crash detection ───────────────────────────────────────────────────────────
// Pokud crash_flag.txt existuje při startu → předchozí spuštění skončilo pádem
const hadCrash = fs.existsSync(CRASH_FLAG_FILE);

// Zapíše příznak (smazán při čistém ukončení nebo systémovém shutdown)
function writeCrashFlag() {
  try {
    fs.writeFileSync(CRASH_FLAG_FILE, new Date().toISOString(), 'utf8');
  } catch (e) {
    console.error('Nelze zapsat crash_flag:', e.message);
  }
}

function removeCrashFlag() {
  try {
    if (fs.existsSync(CRASH_FLAG_FILE)) {
      fs.unlinkSync(CRASH_FLAG_FILE);
    }
  } catch (e) {
    console.error('Nelze smazat crash_flag:', e.message);
  }
}

// ── Globální reference (prevence GC) ─────────────────────────────────────────
let mainWindow   = null;   // Hlavní okno aplikace
let tray         = null;   // Systémová tray ikona
let isQuitting   = false;  // true = uživatel zvolil ukončení (ne jen zavření okna)

// ── Lazy import modulů backendu ───────────────────────────────────────────────
// Moduly se načtou až při potřebě (rychlejší start)
let configModule  = null;
let utilsModule   = null;
let serverModule  = null;
let supabaseModule = null;
let paintModule   = null;
let updaterModule = null;

function getConfig()   { return configModule  || (configModule  = require('./src/main/config'));   }
function getUtils()    { return utilsModule   || (utilsModule   = require('./src/main/utils'));    }
function getServer()   { return serverModule  || (serverModule  = require('./src/main/server'));   }
function getSupabase() { return supabaseModule || (supabaseModule = require('./src/main/supabase')); }
function getPaint()    { return paintModule   || (paintModule   = require('./src/main/paint'));    }
function getUpdater()  { return updaterModule || (updaterModule = require('./src/main/updater'));  }
// ── Fáze 9: Tray menu + Phase 9 IPC handlery ─────────────────────────────────
let mainTrayModule = null;
function getMainTray() { return mainTrayModule || (mainTrayModule = require('./src/main/main-tray')); }

// ── Fáze 11: Crash detection + DevTools ──────────────────────────────────────
let crashModule   = null;
let devtoolsModule = null;
function getCrash()    { return crashModule    || (crashModule    = require('./src/main/crash'));    }
function getDevtools() { return devtoolsModule || (devtoolsModule = require('./src/main/devtools')); }

// ── Nastavení: samostatné okno ────────────────────────────────────────────────
let settingsWindowModule = null;
function getSettingsWindow() {
  return settingsWindowModule || (settingsWindowModule = require('./src/main/settings-window'));
}

// ── Upload: samostatné okno ───────────────────────────────────────────────────
let uploadWindowModule = null;
function getUploadWindow() {
  return uploadWindowModule || (uploadWindowModule = require('./src/main/upload-window'));
}

// ── Nestažené zakázky: samostatné okno ───────────────────────────────────────
let pendingWindowModule = null;
function getPendingWindow() {
  return pendingWindowModule || (pendingWindowModule = require('./src/main/pending-window'));
}

let webAppQrModule = null;
function getWebAppQr() {
  return webAppQrModule || (webAppQrModule = require('./src/main/webapp-qr-window'));
}

let tourWindowModule = null;
function getTourWindow() {
  return tourWindowModule || (tourWindowModule = require('./src/main/tour-window'));
}

let mobilePreviewModule = null;
function getMobilePreview() {
  return mobilePreviewModule || (mobilePreviewModule = require('./src/main/mobile-preview-window'));
}

let loginWindowModule = null;
function getLoginWindow() {
  return loginWindowModule || (loginWindowModule = require('./src/main/login-window'));
}

// ── Záloha / obnova + diagnostika ─────────────────────────────────────────────
let backupModule = null;
let diagModule   = null;
function getBackup() { return backupModule || (backupModule = require('./src/main/backup')); }
function getDiag()   { return diagModule   || (diagModule   = require('./src/main/diag'));   }


// ── Jediná instance aplikace ──────────────────────────────────────────────────
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  // Jiná instance již běží → zobraz ji a ukonči tuto
  app.quit();
  process.exit(0);
}

app.on('second-instance', () => {
  // Někdo se pokusil spustit druhou instanci → obnov hlavní okno
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  }
});

// ── Popup "Aktualizace dokončena" ─────────────────────────────────────────────
let _updateDoneWin = null;

function showUpdateDoneWindow(newVersion, changelog = null) {
  if (_updateDoneWin && !_updateDoneWin.isDestroyed()) return;

  const { screen } = require('electron');
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  _updateDoneWin = new BrowserWindow({
    width:           400,
    height:          340,
    x:               width  - 416,
    y:               height - 360,
    resizable:       true,
    maximizable:     false,
    minimizable:     false,
    fullscreenable:  false,
    alwaysOnTop:     true,
    frame:           true,
    autoHideMenuBar: true,
    title:           'PhotoBridge – Aktualizace dokončena',
    icon:            path.join(ASSETS_DIR, 'icons', 'icon.ico'),
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
      devTools:         false,
    },
    show: false,
  });

  // IPC – vrátí data pro popup
  const { ipcMain } = require('electron');
  const _handleGetInfo = () => {
    const cfg     = getConfig().readConfig();
    const inTray  = cfg.MINIMIZE_ON_START === 'true' || cfg.MINIMIZE_TO === 'tray';
    return {
      version:   newVersion || APP_VERSION,
      inTray,
      sawDir:    cfg.SAW_DIR || '',
      changelog: changelog || null,
    };
  };
  const _handleClose = () => {
    if (_updateDoneWin && !_updateDoneWin.isDestroyed()) _updateDoneWin.close();
    return { ok: true };
  };

  // Použij once aby se handlery neregistrovaly vícekrát
  ipcMain.handleOnce('update-done:get-info', _handleGetInfo);
  ipcMain.handleOnce('update-done:close',    _handleClose);

  _updateDoneWin.loadFile(path.join(RENDERER_DIR, 'update-done.html'));
  _updateDoneWin.once('ready-to-show', () => {
    if (_updateDoneWin && !_updateDoneWin.isDestroyed()) _updateDoneWin.show();
  });
  _updateDoneWin.on('closed', () => { _updateDoneWin = null; });
}

// ── Vytvoření hlavního okna ───────────────────────────────────────────────────
function createMainWindow() {
  // Načti uložené rozměry/pozici z konfigurace
  const cfg = getConfig().readConfig();
  const winW = parseInt(cfg.WIN_W, 10) || 520;
  const winH = parseInt(cfg.WIN_H, 10) || 420;
  const winX = cfg.WIN_X ? parseInt(cfg.WIN_X, 10) : undefined;
  const winY = cfg.WIN_Y ? parseInt(cfg.WIN_Y, 10) : undefined;

  const windowOptions = {
    width:  winW,
    height: winH,
    minWidth:  400,
    minHeight: 320,
    title: APP_NAME,
    icon: path.join(ASSETS_DIR, 'icons', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,    // bezpečnostní sandbox
      nodeIntegration: false,    // renderer NESMÍ mít přímý přístup k Node.js
      sandbox: false,            // preload.js potřebuje require()
      devTools: IS_DEV,
    },
    show: false,                 // zobrazíme až po 'ready-to-show' (bez bliknutí)
    backgroundColor: '#1a1a2e',
    autoHideMenuBar: true,       // skrýt menu lištu (Alt ji zobrazí)
  };

  // Obnov pozici okna
  if (winX !== undefined && winY !== undefined) {
    windowOptions.x = winX;
    windowOptions.y = winY;
  }

  mainWindow = new BrowserWindow(windowOptions);

  // Načti hlavní HTML stránku
  mainWindow.loadFile(path.join(RENDERER_DIR, 'index.html'));

  // DEBUG: zachyť JS chyby z rendereru a vypiš do PowerShell konzole
  mainWindow.webContents.on('console-message', (_evt, level, message, line, sourceId) => {
    if (level >= 2) { // 2=warning, 3=error
      console.error(`[RENDERER ${level === 3 ? 'ERROR' : 'WARN'}] ${message}  (${sourceId}:${line})`);
    }
  });
  mainWindow.webContents.on('render-process-gone', (_evt, details) => {
    console.error('[RENDERER CRASHED]', JSON.stringify(details));
  });
  mainWindow.webContents.on('did-fail-load', (_evt, code, desc, url) => {
    console.error(`[LOAD FAILED] ${code} ${desc} – ${url}`);
  });

  // Zobraz okno až je připraveno (bez bílého bliknutí)
  mainWindow.once('ready-to-show', () => {
    if (!cfg.MINIMIZE_ON_START || cfg.MINIMIZE_ON_START === 'false') {
      mainWindow.show();
    }
    // Pokud předchozí spuštění skončilo pádem → zobraz crash dialog
    if (hadCrash) {
      mainWindow.webContents.send('ipc:crash-detected', {
        flagFile: CRASH_FLAG_FILE,
        message:  'Předchozí spuštění aplikace skončilo neočekávaně.',
      });
    }
  });

  // Uloži pozici/rozměr okna při pohybu/resize
  mainWindow.on('resized', saveWindowBounds);
  mainWindow.on('moved',   saveWindowBounds);

  // Zachycení pokusu o zavření okna
  // Logika tray/float/panel je v main-tray.js setupMinimizeToTray()
  // Zde jen synchronizujeme isQuitting flag pro skutečný quit
  mainWindow.on('close', () => {
    // Pokud close handler v main-tray.js neprovedl preventDefault(),
    // znamená to skutečný quit → zajisti čistý shutdown
    if (!isQuitting) {
      isQuitting = true;
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // DevTools v debug módu
  if (IS_DEV) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  return mainWindow;
}

// ── Uložení rozměrů a pozice okna ────────────────────────────────────────────
function saveWindowBounds() {
  if (!mainWindow || mainWindow.isMinimized()) return;
  try {
    const bounds = mainWindow.getBounds();
    const cfg = getConfig().readConfig();
    cfg.WIN_W = String(bounds.width);
    cfg.WIN_H = String(bounds.height);
    cfg.WIN_X = String(bounds.x);
    cfg.WIN_Y = String(bounds.y);
    getConfig().writeConfig(cfg);
  } catch (e) {
    console.error('saveWindowBounds chyba:', e.message);
  }
}

// ── Tray ikona ────────────────────────────────────────────────────────────────
function createTray() {
  const iconPath = path.join(ASSETS_DIR, 'icons', 'tray.ico');
  const fallback = path.join(ASSETS_DIR, 'icons', 'icon.ico');
  const iconFile = fs.existsSync(iconPath) ? iconPath : fallback;

  try {
    tray = new Tray(iconFile);
    tray.setToolTip(APP_NAME);
    updateTrayMenu();

    // Klik na tray ikonu (levé tlačítko) → zobraz/skryj okno
    tray.on('click', () => toggleMainWindow());
  } catch (e) {
    console.error('Nelze vytvořit tray ikonu:', e.message);
    tray = null;
  }
}

// Sestaví a nastaví kontextové menu tray ikony
// (Plné menu implementuje Fáze 9 – zatím základní kostra)
function updateTrayMenu(extraItems = []) {
  if (!tray) return;

  const menuTemplate = [
    {
      label: `${APP_NAME} ${APP_VERSION}`,
      enabled: false,
    },
    { type: 'separator' },
    {
      label: 'Zobrazit',
      click: () => showMainWindow(),
    },
    ...extraItems,
    { type: 'separator' },
    {
      label: 'Ukončit',
      click: () => quitApp(),
    },
  ];

  const contextMenu = Menu.buildFromTemplate(menuTemplate);
  tray.setContextMenu(contextMenu);
}

// ── Pomocné funkce pro okno ───────────────────────────────────────────────────
function showMainWindow() {
  if (!mainWindow) {
    createMainWindow();
    return;
  }
  mainWindow.show();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.focus();
}

function toggleMainWindow() {
  if (!mainWindow) {
    createMainWindow();
    return;
  }
  if (mainWindow.isVisible() && !mainWindow.isMinimized()) {
    mainWindow.hide();
  } else {
    showMainWindow();
  }
}

// ── Čisté ukončení aplikace ───────────────────────────────────────────────────
// Ekvivalent _on_closing() + čistého ukončení v Python verzi
async function quitApp() {
  isQuitting = true;
  app.isQuitting = true;  // flag pro main-tray.js close handler
  getUtils().log('INFO', 'Ukončení aplikace', 'quitApp() zavoláno');

  // Zruš plovoucí okno
  try { require('./src/main/float-window').destroyFloat(); } catch (_) {}

  // Zastav backend služby
  try { await getServer().stopServer();   } catch (_) {}
  try { getSupabase().stopSbPoller();     } catch (_) {}
  try { getPaint().stopMonitoring();      } catch (_) {}

  // Smaž crash flag → čisté ukončení, není pád
  removeCrashFlag();

  // Zruš tray ikonu
  if (tray) {
    tray.destroy();
    tray = null;
  }

  app.quit();
}

// ── Zpracování nekritických výjimek ──────────────────────────────────────────
process.on('uncaughtException', (error) => {
  console.error('uncaughtException:', error);
  getUtils().log('ERROR', 'uncaughtException', error.stack || error.message);
  // crash_flag.txt zůstane → příští spuštění ukáže crash dialog
});

process.on('unhandledRejection', (reason) => {
  console.error('unhandledRejection:', reason);
  getUtils().log('ERROR', 'unhandledRejection', String(reason));
});

// ── Životní cyklus Electron app ───────────────────────────────────────────────
app.whenReady().then(async () => {
  // Zapiš crash flag hned po startu (smazán při čistém ukončení)
  writeCrashFlag();

  // ── Detekce špatné aktualizace ─────────────────────────────────────────────
  // crash_flag + update_pending zároveň = app nenastartovala po aktualizaci
  const _backup       = getBackup();
  const updatePending = _backup.getUpdatePending();
  const hadBadUpdate  = hadCrash && !!updatePending;

  if (hadBadUpdate) {
    getUtils().log('WARN', 'startup', `Špatná aktualizace detekována (pending: ${updatePending?.newVersion})`);
  } else if (updatePending && !hadCrash) {
    // Aktualizace proběhla OK → smaž příznak
    _backup.clearUpdatePending();
    getUtils().log('INFO', 'startup', `Aktualizace na v${updatePending.newVersion} proběhla OK`);
    // Zobraz popup "Aktualizace dokončena" po načtení okna
    setTimeout(() => showUpdateDoneWindow(updatePending.newVersion, updatePending.changelog || null), 1200);
  }

  getUtils().log('INFO', 'App start', `${APP_NAME} v${APP_VERSION} – pid=${process.pid}`);

  // Inicializuj konfiguraci (vytvoří výchozí pokud neexistuje)
  getConfig().initConfig();

  // ── Autostart se systémem + zástupce na ploše ────────────────────────────
  // Podle configu (default zapnuto): zajisti autostart v registru a
  // vytvoř zástupce na ploše, pokud tam ještě není. Bezpečné – chyba
  // jen zaloguje a nijak nebrání startu aplikace.
  try {
    const _cfg  = getConfig().readConfig();
    const _u    = getUtils();
    const _exe  = process.execPath;

    if (String(_cfg.START_WITH_WINDOWS) === 'true') {
      _u.setStartWithWindows(true, _exe);
    } else {
      _u.setStartWithWindows(false, _exe);
    }

    // Zástupce na ploše – vytvoř jen jednou (pak si to pamatuje v configu)
    if (String(_cfg.DESKTOP_SHORTCUT) !== 'true') {
      const made = _u.ensureDesktopShortcut(_exe);
      if (made) {
        try {
          const c2 = getConfig().readConfig();
          c2.DESKTOP_SHORTCUT = 'true';
          getConfig().writeConfig(c2);
        } catch (_) {}
      }
    }
  } catch (e) {
    getUtils().log('WARN', 'autostart/shortcut init selhal', e.message);
  }

  // Vytvoř hlavní okno
  createMainWindow();

  // Vytvoř tray ikonu – vždy, aby bylo možné přepínat MINIMIZE_TO bez restartu
  // (main-tray.js si sám řídí viditelnost dle konfigurace)
  createTray();

  // Spusť auto-updater check (tichý, na pozadí)
  try {
    getUpdater().scheduleUpdateCheck();
  } catch (e) {
    getUtils().log('WARN', 'Updater init selhal', e.message);
  }

  // ── Registrace IPC handlerů všech modulů ─────────────────────────────────
  try { getUtils().registerIpcHandlers();    } catch (e) { console.error('utils IPC selhal:', e.message); }
  try { getServer().registerIpcHandlers();   } catch (e) { console.error('server IPC selhal:', e.message); }
  try { getSupabase().registerIpcHandlers(); } catch (e) { console.error('supabase IPC selhal:', e.message); }

  // ── Obnova Supabase session po restartu (refresh token ze state.json) ────
  // Technik zůstane přihlášen i po restartu. Odhlášení POUZE manuálním klikem.
  // Po obnovení session se POLLER AUTOMATICKY SPUSTÍ a běží trvale na pozadí.
  // Tím odpadá potřeba klikat na "Spustit příjem" – fotky se stahují samy.
  // Pokud při startu selže (síť, token), pojistka v _ensurePollerRunning()
  // se ho pokusí znovu spustit každých 30 sekund.
  //
  // DŮLEŽITÉ: čekáme na did-finish-load aby renderer stihl zaregistrovat
  // IPC listenery. Bez toho by supabase:status event přišel příliš brzy
  // (renderer ještě neběží) a ztratil by se → "Připojuji k Supabase" natrvalo.
  mainWindow.webContents.once('did-finish-load', () => {
  try {
    const cfg = getConfig().readConfig();
    getSupabase().sbRestoreSession(cfg).then(async (restored) => {
      if (restored && mainWindow && !mainWindow.isDestroyed()) {
        // Informuj renderer že session byla obnovena
        mainWindow.webContents.send('supabase:status', {
          loggedIn:    true,
          email:       getUtils().STATE.sbEmail || '',
          userId:      getUtils().STATE.sbUserId || '',
          accountType: getUtils().STATE.sbAccountType || 'business',
        });
        getUtils().log('INFO', 'startup', `Supabase session obnovena: ${getUtils().STATE.sbEmail}`);

        // Pokud SAVE_DIR není nastavena, zeptej se uživatele
        // (krátká prodleva, aby se hlavní okno stihlo zobrazit a renderer
        // navázat onMain('app:request-ensure-save-dir') listener)
        const saveDir = cfg.SAVE_DIR || '';
        if (!saveDir) {
          setTimeout(() => {
            try {
              if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.webContents.send('app:request-ensure-save-dir');
              }
            } catch (_) {}
          }, 1500);
        } else {
          // Auto-start polleru po obnovení session (jen když máme SAVE_DIR)
          if ((cfg.SB_URL || '').trim()) {
            getSupabase().startSbPoller(cfg, saveDir);
          }
        }
      }
      // Aktivuj pojistku, která drží poller permanentně živý
      _startPollerKeepalive();
    }).catch(() => { _startPollerKeepalive(); });
  } catch (e) {
    getUtils().log('WARN', 'startup sbRestoreSession', e.message);
    _startPollerKeepalive();
  }
  }); // end did-finish-load

  // ── Pojistka: každých 30 s zkontroluj, zda poller běží. Pokud ne ──
  //    a uživatel je přihlášen + má SAVE_DIR, znovu spusť. Tím má aplikace
  //    "trvalý příjem" – uživatel nemusí nikdy klikat na Spustit. ─────
  function _startPollerKeepalive() {
    setInterval(() => {
      try {
        const sb = getSupabase();
        if (!sb || typeof sb.isSbPollerRunning !== 'function') return;
        if (sb.isSbPollerRunning()) return; // všechno OK
        const utils = getUtils();
        if (!utils.STATE.sbAccessToken && !utils.STATE.sbRefreshToken) return; // nepřihlášen
        const cfg2 = getConfig().readConfig();
        const saveDir2 = cfg2.SAVE_DIR || '';
        if (!saveDir2 || !(cfg2.SB_URL || '').trim()) return;
        utils.log('INFO', 'POLLER_KEEPALIVE', 'Poller neběží – znovu spouštím');
        sb.startSbPoller(cfg2, saveDir2);
      } catch (_) { /* nevadí */ }
    }, 30_000);
  }

  // ── Fáze 9: Registrace plného tray menu + Phase 9 IPC handlerů ──────────
  try {
    const trayMod = getMainTray();
    if (tray) trayMod.setupTray(mainWindow, tray);
    trayMod.registerPhase9IpcHandlers(mainWindow);
    // Nastaví minimize handler (tray / float / panel) – musí být PO setupTray
    trayMod.setupMinimizeToTray(mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'Phase9 init selhal', e.message);
  }

  // ── Float window IPC handlery ─────────────────────────────────────────
  try {
    const floatMod = require('./src/main/float-window');
    floatMod.registerIpcHandlers(
      () => mainWindow,
      () => getConfig().readConfig(),
      (cfg) => getConfig().writeConfig(cfg),
      () => quitApp()
    );
  } catch (e) {
    getUtils().log('WARN', 'float-window IPC init selhal', e.message);
  }

  // ── SP_ post-processing: soubory z local serveru s typem SP → Paint fronta ─
  // server.js posílá 'server:upload-received' do rendereru; my ho zde zachytíme
  // přes ipcMain a zkontrolujeme zda soubor je SP_ → zařadíme do paint fronty
  try {
    const { ipcMain: _ipc } = require('electron');
    // Listener na interní event z server.js (poslaný přes BrowserWindow.send)
    // Hookujeme se na webContents message který server.js pošle renderu
    mainWindow.webContents.on('ipc-message', () => {}); // no-op (placeholder)

    // Skutečný hook: server.js volá BrowserWindow.send('server:upload-received', data)
    // Zachytíme to tak, že zaregistrujeme listener na mainWindow webContents
    const _origSend = mainWindow.webContents.send.bind(mainWindow.webContents);
    mainWindow.webContents.send = function(channel, ...args) {
      // Zavolej původní send
      _origSend(channel, ...args);

      // Post-process SP_ soubory z local server uploadu
      if (channel === 'server:upload-received') {
        const data = args[0];

        // ── Float fix: když je hlavní okno skryté (float mód), renderer je
        //    throttlován Chromiem a neodešle ipc('upload:open').
        //    Otevřeme upload okno přímo z main procesu. ──────────────────────
        if (!mainWindow.isVisible() && data && Array.isArray(data.files) && data.files.length) {
          try {
            const srv = (() => { try { return require('./src/main/server'); } catch(_) { return null; } })();
            const job = data.job || (srv && srv.getState && srv.getState().tokenJob) || '';
            getUploadWindow().openUploadWindow(null, data.files, job);
            getUtils().log('INFO', 'Float: upload okno otevřeno přímo (renderer throttlován)', `job=${job}`);
          } catch (floatErr) {
            getUtils().log('WARN', 'Float: upload:open selhal', String(floatErr.message));
          }
        }

        if (data && Array.isArray(data.files)) {
          const paint = (() => { try { return require('./src/main/paint'); } catch(_) { return null; } })();
          if (paint && paint.createPaintTempCopy) {
            for (const f of data.files) {
              const fname = (f.name || f.path || '').toUpperCase();
              const isSP  = fname.startsWith('SP_') || /^SP[_\-]/i.test(path.basename(f.path || f.name || ''));
              if (isSP && f.path && fs.existsSync(f.path)) {
                const finalPath = f.path; // soubor je už v saveDir
                const content   = fs.readFileSync(finalPath);
                // Smaž původní soubor a nechej paint.js vytvořit temp kopii
                try { fs.unlinkSync(finalPath); } catch(_) {}
                paint.createPaintTempCopy(finalPath, content).catch(() => {});
                getUtils().log('INFO', 'SP_ → paint queue (local)', path.basename(finalPath));
              }
            }
          }
        }
      }
    };
  } catch (e) {
    getUtils().log('WARN', 'SP_ paint hook selhal', e.message);
  }

  // ── Fáze 11: Crash detection + DevTools ──────────────────────────────────
  try {
    getCrash().registerIpcHandlers(mainWindow);
    getDevtools().registerIpcHandlers(mainWindow);
    getCrash().registerCrashHandler();   // ← aktivuje crash dialog při uncaughtException
  } catch (e) {
    getUtils().log('WARN', 'Phase11 init selhal', e.message);
  }

  // ── Nastavení: samostatné okno – registrace IPC handlerů ─────────────────
  try {
    getSettingsWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'settings-window IPC init selhal', e.message);
  }

  // ── Záloha / obnova + diagnostika – registrace IPC handlerů ──────────────
  try {
    getBackup().registerIpc();
    getDiag().registerIpc(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'backup/diag IPC init selhal', e.message);
  }

  // Pokud špatná aktualizace + záloha existuje → zobraz restore okno
  if (hadBadUpdate && getBackup().hasBackup()) {
    setTimeout(() => {
      try { getBackup().showRestoreWindow({ isBadUpdate: true }); } catch (e) {
        getUtils().log('ERROR', 'showRestoreWindow selhal', e.message);
      }
    }, 1000);
  }

  // ── Upload: samostatné okno – registrace IPC handlerů ────────────────────
  try {
    getUploadWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'upload-window IPC init selhal', e.message);
  }

  // ── Nestažené zakázky: okno – registrace IPC handlerů ────────────────────
  try {
    getPendingWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'pending-window IPC init selhal', e.message);
  }

  // ── Web App QR okno – registrace IPC handlerů ─────────────────────────────
  try {
    getWebAppQr().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'webapp-qr-window IPC init selhal', e.message);
  }

  // ── Tour okno – registrace IPC handlerů ───────────────────────────────────
  try {
    getTourWindow().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'tour-window IPC init selhal', e.message);
  }

  // ── Mobile Preview okno – registrace IPC handlerů ─────────────────────────
  try {
    getMobilePreview().registerIpcHandlers(() => mainWindow);
  } catch (e) {
    getUtils().log('WARN', 'mobile-preview-window IPC init selhal', e.message);
  }

  // ── Login okno – registrace IPC handlerů ──────────────────────────────────
  try {
    getLoginWindow().registerIpcHandlers();
  } catch (e) {
    getUtils().log('WARN', 'login-window IPC init selhal', e.message);
  }

  // ── DevTools log hook: přesměruj utils.log() → devtools buffer ──────────
  // Musí být PO registraci IPC handlerů, ale PŘED dalším logováním
  try {
    const devtools = getDevtools();
    getUtils().addLogHook((level, msg) => {
      try { devtools.addLog(level, msg); } catch (_) {}
    });
    getUtils().log('INFO', 'DevTools', 'Log hook aktivní – všechny logy jdou do DevTools bufferu');
  } catch (e) {
    console.error('DevTools hook registrace selhala:', e.message);
  }

  // ── F12 globální zkratka → otevři DevTools konzoli ─────────────────────
  try {
    const { globalShortcut } = require('electron');
    globalShortcut.register('F12', () => {
      try { getDevtools().openDevToolsWindow(mainWindow); } catch (_) {}
    });
  } catch (_) {}

  // ── Aliasy kanálů – app.js používá kratší názvy ──────────────────────────
  // config:get (app.js) → ipc:config:get (main.js)
  ipcMain.handle('config:get', () => getConfig().readConfig());

  // app:getState – init() rendereru potřebuje kompletní stav aplikace
  ipcMain.handle('app:getState', () => {
    const cfg   = getConfig().readConfig();
    const utils = getUtils();
    const sb    = getSupabase ? getSupabase() : null;
    const srv   = getServer   ? getServer()   : null;
    return {
      theme:         utils.computeEffectiveTheme(cfg),
      serverRunning: srv?.isRunning?.() ?? false,
      ip:            utils.getLocalIP(),
      port:          parseInt(cfg.PORT, 10) || 5000,
      stats:         {
        total:    utils.STATE.totalUploadCount || 0,
        session:  utils.STATE.uploadCount      || 0,
        jobCount: 0,
      },
      jobHistory:   utils.getJobHistory(),
      sbLoggedIn:   Boolean(utils.STATE.sbAccessToken),
      sbEmail:      utils.STATE.sbEmail       || '',
      sbAccountType: utils.STATE.sbAccountType || 'business',
      pollerJob:    utils.STATE.pollerJob || null,
      pollerRunning: sb?.isSbPollerRunning?.() ?? false,
      vercelMode:   Boolean((cfg.VERCEL_URL || '').trim()),
    };
  });

  // qr:generate – vygeneruje QR odkazující na mobilní webapp s předvyplněnou zakázkou.
  // URL formát: https://loydtest01.github.io/PhotoBridge/?job=ZAKAZKA
  // Mobil otevře webapp, sám rozpozná `?job=` parametr a předvyplní ho.
  // Fotky chodí přímo na Supabase (pod účtem mobilu), poller v PC je stáhne.
  ipcMain.handle('qr:generate', async (_e, { job }) => {
    try {
      const cfg     = getConfig().readConfig();
      const ghPages = (cfg.GITHUB_PAGES_URL || 'https://loydtest01.github.io/PhotoBridge/').trim().replace(/\/$/, '');
      // URL = mobilní webapp + zakázka jako query parametr
      const url     = `${ghPages}/?job=${encodeURIComponent(job || '')}`;

      // Vygeneruj QR matici
      let qrData;
      try {
        const QRCode = require('qrcode');
        const qr     = QRCode.create(url, { errorCorrectionLevel: cfg.QR_EC_LEVEL || 'H' });
        const size   = qr.modules.size;
        const data   = qr.modules.data;
        const matrix = [];
        for (let r = 0; r < size; r++) {
          const row = [];
          for (let c = 0; c < size; c++) {
            row.push(data[r * size + c] ? 1 : 0);
          }
          matrix.push(row);
        }
        // Barvy z konfigurace
        const fillRgb = (cfg.QR_FILL_COLOR || '0,0,0').split(',').map(n => parseInt(n, 10));
        const bgRgb   = (cfg.QR_BG_COLOR   || '255,255,255').split(',').map(n => parseInt(n, 10));
        const toHex   = ([r, g, b]) => '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
        qrData = {
          type:      'matrix',
          matrix,
          fillColor: toHex(fillRgb),
          bgColor:   toHex(bgRgb),
        };
      } catch (qrErr) {
        getUtils().log('WARN', 'qr:generate – qrcode lib selhala, posílám URL', qrErr.message);
        qrData = { type: 'url', url };
      }

      // Odpočet timeru: QR_TIMEOUT_MINUTES (0 = vypnuto), fallback TOKEN_MINUTES
      const qrTimeoutMin = parseInt(cfg.QR_TIMEOUT_MINUTES || '0', 10);
      const tokenMin     = parseInt(cfg.TOKEN_MINUTES       || '480', 10);
      const timerMins    = qrTimeoutMin > 0 ? qrTimeoutMin : tokenMin;
      const expiresAt    = Date.now() + timerMins * 60 * 1000;

      return { url, qrData, token: null /* legacy field, supabase mode netoken */, expiresAt, tokenMinutes: timerMins };
    } catch (e) {
      getUtils().log('ERROR', 'qr:generate', e.message);
      return { error: e.message };
    }
  });

  // settings:open – otvírá nastavení jako samostatné BrowserWindow
  // (registrace je v getSettingsWindow().registerIpcHandlers() výše;
  //  tento fallback zůstává pro zpětnou kompatibilitu s old app.js inline modálem)
  ipcMain.handle('help:open', () => {
    require('electron').shell.openPath(path.join(__dirname, 'templates', 'navod.html'));
  });

  // Vrátí seznam lokálních IPv4 adres (pro settings dialog)
  ipcMain.handle('utils:get-local-ips', () => {
    try {
      return getUtils().getLocalIpv4CandidatesWithLabels().map(([ip, label]) => `${ip}  (${label})`);
    } catch (_) {
      return [];
    }
  });

  // Záložní QR encoder – pokud main v qr:generate neposlal matici
  ipcMain.handle('qr:encode-matrix', (_e, { text }) => {
    try {
      const QRCode = require('qrcode');
      const qr = QRCode.create(text, { errorCorrectionLevel: 'H' });
      const size = qr.modules.size;
      const data = qr.modules.data;
      const matrix = [];
      for (let r = 0; r < size; r++) {
        const row = [];
        for (let c = 0; c < size; c++) row.push(data[r * size + c] ? 1 : 0);
        matrix.push(row);
      }
      return { matrix };
    } catch (e) {
      return { error: e.message };
    }
  });

  // devtools:open → handled via ipcMain.on in src/main/devtools.js registerIpcHandlers()
});

// macOS: znovu vytvoř okno při kliknutí na ikonu v Docku
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createMainWindow();
  }
});

// Windows/Linux: ukončí se když jsou všechna okna zavřená
// (pokud IS_TRAY, okna se skrývají místo zavírání → event se nezpracuje)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Pokud MINIMIZE_TO=tray, okno se jen schovává → aplikace pokračuje v tray
    // Pokud MINIMIZE_TO=float nebo panel, ukončíme
    const cfg2       = getConfig ? getConfig().readConfig() : {};
    const minimizeTo = (cfg2.MINIMIZE_TO || 'panel').toLowerCase();
    if (minimizeTo !== 'tray') {
      quitApp();
    }
  }
});

// Před ukončením: čistý shutdown
app.on('before-quit', () => {
  isQuitting = true;
  app.isQuitting = true;
  removeCrashFlag();
  try { require('./src/main/float-window').destroyFloat(); } catch (_) {}
  // OPRAVA: nemaž update_pending.json pokud quit = restart po aktualizaci.
  // updater.js nastaví _updateQuitPending = true těsně před app.quit().
  // update_pending.json se smaže při dalším startu pokud app nastartuje OK.
  try {
    if (!getUpdater().isUpdateQuitPending()) {
      getBackup().clearUpdatePending();
    }
  } catch (_) {}
});

app.on('will-quit', () => {
  removeCrashFlag();
});

// ── IPC kanály – hlavní (kostra, implementace v dalších fázích) ───────────────
// Každý kanál odpovídá určité funkci aplikace.
// Konvence pojmenování: 'ipc:akce' nebo 'ipc:modul:akce'

// ── APP INFO ──────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:app-info', () => ({
  name:     APP_NAME,
  version:  APP_VERSION,
  isDev:    IS_DEV,
  userData: USER_DATA_DIR,
  platform: process.platform,
}));

// ── OKNO ──────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:window:minimize', () => mainWindow?.minimize());
ipcMain.handle('ipc:window:close',    () => { isQuitting = true; mainWindow?.close(); });
ipcMain.handle('ipc:window:quit',     () => quitApp());
ipcMain.handle('ipc:window:show',     () => showMainWindow());

// ── KONFIGURACE ───────────────────────────────────────────────────────────────
ipcMain.handle('ipc:config:get', () => getConfig().readConfig());

ipcMain.handle('ipc:config:set', (_event, partial) => {
  const cfgBefore = getConfig().readConfig();
  const oldSaveDir = (cfgBefore.SAVE_DIR || '').trim();

  const cfg = { ...cfgBefore };
  Object.assign(cfg, partial);
  getConfig().writeConfig(cfg);

  // Rozešli změnu VŠEM oknům, ať hned přepnou motiv a další nastavení.
  // Bez toho hlavní okno (běží pořád) zůstane ve starém tématu, zatímco
  // čerstvě otevřená okna už mají nové → nekonzistentní vzhled.
  try {
    const { BrowserWindow } = require('electron');
    for (const w of BrowserWindow.getAllWindows()) {
      if (!w.isDestroyed()) {
        w.webContents.send('config:changed', cfg);
      }
    }
  } catch (_) {}

  // Pokud se změnila SAVE_DIR a poller běží, restartujeme ho s novou cestou.
  // Bez toho by poller pokračoval ukládat do staré složky (bug: vždy M:\UploadScan).
  const newSaveDir = (cfg.SAVE_DIR || '').trim();
  if (newSaveDir && newSaveDir !== oldSaveDir) {
    try {
      const sb = getSupabase();
      const utils = getUtils();
      if (sb && utils && utils.STATE && utils.STATE.sbAccessToken) {
        sb.stopSbPoller();
        sb.startSbPoller(getConfig().readConfig(), newSaveDir);
        utils.log('INFO', 'ipc:config:set', `SAVE_DIR změněna → poller restartován: ${newSaveDir}`);
      }
    } catch (e) {
      getUtils().log('WARN', 'ipc:config:set', `Restart polleru selhal: ${e.message}`);
    }
  }

  return { ok: true };
});

// ── SERVER (LOCAL) – VYPNUTO ─────────────────────────────────────────────────
// Aplikace běží POUZE přes Supabase. Lokální HTTP server na LAN je vyřazen.
// IPC handlery vrací ok:true ale nic nedělají (zpětná kompatibilita s old UI).
ipcMain.handle('ipc:server:start', async () => {
  getUtils().log('INFO', 'ipc:server:start', 'IGNOROVÁNO – lokální server je vypnutý (Supabase-only mód)');
  mainWindow?.webContents.send('ipc:server:status', { running: false });
  return { ok: true, disabled: true };
});

ipcMain.handle('ipc:server:stop', async () => {
  // Pokud by server byl náhodou spuštěný, zastavme ho
  try { await getServer().stopServer?.(); } catch {}
  mainWindow?.webContents.send('ipc:server:status', { running: false });
  return { ok: true };
});

ipcMain.handle('ipc:server:status', () => ({ running: false }));

// ── SUPABASE ──────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:sb:login', async (_event, { email, password }) => {
  try {
    return await getSupabase().sbLogin(email, password);
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ipc:sb:logout', async () => {
  try {
    return await getSupabase().sbLogout();
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ipc:sb:poller:start', () => {
  const cfg     = getConfig().readConfig();
  const saveDir = cfg.SAVE_DIR || '';
  getSupabase().startSbPoller(cfg, saveDir);
});
ipcMain.handle('ipc:sb:poller:stop',  () => getSupabase().stopSbPoller());

// ── PAINT MONITORING ──────────────────────────────────────────────────────────
ipcMain.handle('ipc:paint:start', () => getPaint().startMonitoring());
ipcMain.handle('ipc:paint:stop',  () => getPaint().stopMonitoring());

// ── AKTUALIZACE ───────────────────────────────────────────────────────────────
ipcMain.handle('ipc:update:check', async () => {
  try {
    return await getUpdater().checkForUpdates();
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ── LOG ───────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:log', (_event, { level, context, message }) => {
  getUtils().log(level || 'INFO', context || 'renderer', message);
});

// ── CRASH ─────────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:crash:info', () => ({
  hadCrash,
  flagFile: CRASH_FLAG_FILE,
}));

ipcMain.handle('ipc:crash:clear', () => {
  removeCrashFlag();
  return { ok: true };
});

// ── OTEVŘENÍ SLOŽKY ───────────────────────────────────────────────────────────
// ── WALLPAPER SLOŽKA ─────────────────────────────────────────────────────────
ipcMain.handle('ipc:wallpaper:open-user-folder', () => {
  // Složka wallpapers/user relativně ke __dirname (root projektu)
  const wallpaperUserDir = path.join(__dirname, 'wallpapers', 'user');
  // Vytvoř složky pokud neexistují (dark + light)
  for (const sub of ['dark', 'light']) {
    const d = path.join(wallpaperUserDir, sub);
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  }
  shell.openPath(wallpaperUserDir);
});

ipcMain.handle('ipc:shell:open-folder', (_event, folderPath) => {
  shell.openPath(folderPath);
});

ipcMain.handle('ipc:shell:open-url', (_event, url) => {
  shell.openExternal(url);
});

// ── VÝBĚR SLOŽKY (dialog) ─────────────────────────────────────────────────────
ipcMain.handle('ipc:dialog:select-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
    title: 'Vyberte složku',
  });
  if (result.canceled || !result.filePaths.length) return null;
  return result.filePaths[0];
});

// ── POKUD SAVE_DIR NENÍ NASTAVENA: PŘÁTELSKÝ DIALOG + FOLDER PICKER ──────────
// Renderer to volá ihned po přihlášení (a po obnovení session při startu).
// 1) Pokud cesta je v configu nastavena, vrátí { ok: true, alreadySet: true }.
// 2) Jinak zobrazí messageBox „kam ukládat fotky?" → uživatel klikne Vybrat.
// 3) Otevře nativní folder picker. Uživatel vybere složku → uloží se do configu.
// 4) Pokud uživatel zruší, vrátí { ok: false, canceled: true } – renderer
//    může zopakovat při dalším pokusu poslat fotku.
ipcMain.handle('app:ensure-save-dir', async () => {
  const cfgMod = getConfig();
  const cfg    = cfgMod.readConfig();
  const cur    = (cfg.SAVE_DIR || '').trim();

  // 1) Už je nastaveno – nic nedělej
  if (cur) {
    try {
      const fs = require('fs');
      // Drobná kontrola, že složka stále existuje – pokud byla smazána,
      // znovu se zeptáme.
      if (fs.existsSync(cur) && fs.statSync(cur).isDirectory()) {
        return { ok: true, alreadySet: true, path: cur };
      }
      getUtils().log('WARN', 'ensure-save-dir', `SAVE_DIR ${cur} neexistuje – ptám se znovu`);
    } catch (_) { /* pokračuj na výběr */ }
  }

  // 2) Zobraz vysvětlující messageBox
  const msgRes = await dialog.showMessageBox(mainWindow, {
    type:    'info',
    buttons: ['Vybrat složku', 'Později'],
    defaultId: 0,
    cancelId:  1,
    title:   'PhotoBridge – kam ukládat fotky?',
    message: 'Ještě nemáš zvolenou složku pro stažené fotky.',
    detail:  'Vyber prosím složku, kam se mají ukládat fotky stažené ze Supabase ' +
             'a ze schránky/PrintScreen. Můžeš to později změnit v Nastavení → ' +
             'Složka pro fotky.',
  });

  if (msgRes.response === 1) {
    // „Později" – nic neukládáme, vrátíme canceled
    return { ok: false, canceled: true };
  }

  // 3) Folder picker
  const pick = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory', 'createDirectory'],
    title: 'Vyberte složku pro ukládání fotek',
    buttonLabel: 'Použít tuto složku',
  });

  if (pick.canceled || !pick.filePaths.length) {
    return { ok: false, canceled: true };
  }

  const chosen = pick.filePaths[0];

  // 4) Uložit do configu
  try {
    cfg.SAVE_DIR = chosen;
    cfgMod.writeConfig(cfg);
    getUtils().log('INFO', 'ensure-save-dir', `SAVE_DIR nastavena: ${chosen}`);
  } catch (e) {
    getUtils().log('ERROR', 'ensure-save-dir', e.message);
    return { ok: false, error: e.message };
  }

  // Informuj všechna okna o změně configu
  try {
    BrowserWindow.getAllWindows().forEach(w => {
      if (!w.isDestroyed()) w.webContents.send('config:changed', { SAVE_DIR: chosen });
    });
  } catch (_) {}

  // Po nastavení složky restartuj poller, aby fotky ze fronty mohly začít stahovat
  try {
    const sb = getSupabase();
    if (sb && sb.startSbPoller && getUtils().STATE.sbAccessToken) {
      sb.startSbPoller(cfgMod.readConfig(), chosen);
    }
  } catch (_) {}

  return { ok: true, path: chosen };
});


// ── VÝBĚR SOUBORŮ (dialog) ────────────────────────────────────────────────────
ipcMain.handle('ipc:dialog:select-files', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    title: 'Vyberte soubory',
    filters: [
      { name: 'Obrázky a videa', extensions: ['png','jpg','jpeg','webp','mp4','mov','pdf'] },
      { name: 'Všechny soubory', extensions: ['*'] },
    ],
  });
  if (result.canceled || !result.filePaths.length) return [];
  return result.filePaths;
});

// ── TRAY MENU UPDATE ──────────────────────────────────────────────────────────
// Renderer může požádat o aktualizaci tray menu (např. po změně stavu serveru)
ipcMain.handle('ipc:tray:update', (_event, extraItems) => {
  updateTrayMenu(extraItems || []);
  return { ok: true };
});

// ── NOTIFIKACE ────────────────────────────────────────────────────────────────
ipcMain.handle('ipc:notify', (_event, { title, body }) => {
  if (Notification.isSupported()) {
    new Notification({ title: title || APP_NAME, body }).show();
  }
});

// ── Onboarding tour – spustí průvodce v hlavním okně ─────────────────────────
ipcMain.handle('tour:request', () => {
  mainWindow?.webContents.send('tour:start');
});


// ── Export konstant pro ostatní main moduly ───────────────────────────────────
module.exports = {
  APP_NAME,
  APP_VERSION,
  USER_DATA_DIR,
  LOGS_DIR,
  BACKUP_DIR,
  PAINT_TEMP_DIR,
  CONFIG_FILE,
  STATE_FILE,
  CRASH_FLAG_FILE,
  ASSETS_DIR,
  RENDERER_DIR,
  IS_DEV,
  getMainWindow: () => mainWindow,
  getTray:       () => tray,
  updateTrayMenu,
  quitApp,
};
