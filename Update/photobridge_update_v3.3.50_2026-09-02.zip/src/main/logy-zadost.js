'use strict';
// ============================================================================
//  PhotoBridge – src/main/logy-zadost.js
//
//  VYŽÁDÁNÍ LOGŮ OD TECHNIKA
//
//  Správce v Admin centru vybere účet, počet dní a úroveň. Technikovi
//  vyskočí okno „Správce žádá o zaslání logů" s tlačítky Ano / Ne.
//
//  BEZ POTVRZENÍ SE NEODEŠLE NIC. Sbírat logy potají by bylo sledování –
//  a technici by na to stejně přišli. Jedno kliknutí je i tak méně práce
//  než hledat soubor v AppData a posílat ho e-mailem.
//
//  POSÍLAJÍ SE JEN VAROVÁNÍ A CHYBY (pokud správce nechce jinak). Běžný
//  provoz je u všech stejný a jen by nafoukl objem – z tříhodinového logu
//  bývá 7 varování a 3 000 řádků běžného provozu.
// ============================================================================

const fs   = require('fs');
const path = require('path');

const INTERVAL_MS = 90000;      // jak často se ptáme na žádost
const MAX_ZNAKU   = 400000;     // strop, ať se neposílají megabajty

let _timer = null;
let _resim = false;             // právě se ptáme technika – nesmí se ptát znovu

function _cfg() { return require('./config'); }
function _log(u, z) { try { require('./utils').log(u, 'LOGY', z); } catch (_) {} }

function _mujEmail() {
    try { return String(require('./utils').STATE.sbEmail || '').trim(); }
    catch (_) { return ''; }
}

/** Složka s logy aplikace. */
function _slozkaLogu() {
    const { app } = require('electron');
    return path.join(app.getPath('userData'), 'logs');
}

/**
 * Posbírá řádky z logů za posledních N dní.
 *
 * @param {number} dnu     kolik dní zpět
 * @param {string} uroven  'WARN' = jen varování a chyby, 'INFO' = vše
 */
function posbirej(dnu, uroven) {
    const dir = _slozkaLogu();
    if (!fs.existsSync(dir)) return { text: '(složka s logy neexistuje)', radku: 0 };

    const hranice = Date.now() - Math.max(1, dnu) * 86400000;
    const jenChyby = String(uroven || 'WARN').toUpperCase() !== 'INFO';

    const soubory = fs.readdirSync(dir)
        .filter(f => /^\d{4}-\d{2}-\d{2}.*\.log$/.test(f))
        .filter(f => {
            const m = f.match(/^(\d{4})-(\d{2})-(\d{2})/);
            if (!m) return false;
            return new Date(+m[1], +m[2] - 1, +m[3]).getTime() >= hranice - 86400000;
        })
        .sort();

    const kusy = [];
    let radku = 0;

    for (const f of soubory) {
        let obsah = '';
        try { obsah = fs.readFileSync(path.join(dir, f), 'utf8'); } catch (_) { continue; }

        const radky = obsah.split(/\r?\n/).filter(r => {
            if (!r.trim()) return false;
            return jenChyby ? /\b(WARN|ERROR)\b/.test(r) : true;
        });

        if (!radky.length) continue;
        kusy.push(`===== ${f} (${radky.length} řádků) =====`);
        kusy.push(...radky);
        radku += radky.length;
    }

    let text = kusy.join('\n');
    if (!text) text = `(za posledních ${dnu} dní nic ${jenChyby ? 'k hlášení' : ''})`;

    // Když je toho moc, posíláme KONEC – tam je to, co se dělo naposledy.
    if (text.length > MAX_ZNAKU) {
        text = '(zkráceno – posílá se posledních ' + MAX_ZNAKU + ' znaků)\n\n'
             + text.slice(-MAX_ZNAKU);
    }
    return { text, radku };
}

async function _zkontrolujZadost() {
    if (_resim) return;

    const cfg  = _cfg().readConfig();
    const url  = String(cfg.SB_URL  || '').trim();
    const anon = String(cfg.SB_ANON || '').trim();
    const mail = _mujEmail();
    if (!url || !anon || !mail) return;

    const token = await require('./supabase').sbEnsureToken(cfg);
    if (!token) return;

    const dotaz = `${url}/rest/v1/pb_log_zadosti`
        + `?pro_email=eq.${encodeURIComponent(mail)}`
        + `&stav=eq.ceka&order=id.desc&limit=1`;

    const resp = await fetch(dotaz, {
        headers: { apikey: anon, Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
    if (!resp.ok) return;

    const [zadost] = await resp.json();
    if (!zadost) return;

    _resim = true;
    _log('INFO', `Žádost o logy od ${zadost.od_koho || 'správce'} (${zadost.dnu} dní, ${zadost.uroven})`);
    try {
        await require('./logy-okno').zeptejSe(zadost);
    } finally {
        _resim = false;
    }
}

/** Odešle logy a označí žádost za vyřízenou. */
async function odesli(zadost) {
    const cfg  = _cfg().readConfig();
    const url  = String(cfg.SB_URL  || '').trim();
    const anon = String(cfg.SB_ANON || '').trim();
    const token = await require('./supabase').sbEnsureToken(cfg);
    if (!token) return { ok: false, error: 'Nejsi přihlášen.' };

    const { text, radku } = posbirej(zadost.dnu, zadost.uroven);

    const r = await fetch(`${url}/rest/v1/pb_logy`, {
        method: 'POST',
        headers: { apikey: anon, Authorization: `Bearer ${token}`,
                   'Content-Type': 'application/json', Prefer: 'return=minimal' },
        body: JSON.stringify({
            zadost_id: zadost.id, email: _mujEmail(), obsah: text, radku,
        }),
    });
    if (!r.ok) {
        const d = await r.text().catch(() => '');
        _log('WARN', `Odeslání logů selhalo: HTTP ${r.status} ${d.slice(0, 150)}`);
        return { ok: false, error: `HTTP ${r.status}` };
    }

    await _oznac(zadost.id, 'odeslano');
    _log('INFO', `Logy odeslány (${radku} řádků)`);
    return { ok: true, radku };
}

async function odmitni(zadost) {
    await _oznac(zadost.id, 'odmitnuto');
    _log('INFO', 'Odeslání logů odmítnuto technikem');
    return { ok: true };
}

async function _oznac(id, stav) {
    try {
        const cfg  = _cfg().readConfig();
        const url  = String(cfg.SB_URL  || '').trim();
        const anon = String(cfg.SB_ANON || '').trim();
        const token = await require('./supabase').sbEnsureToken(cfg);
        await fetch(`${url}/rest/v1/pb_log_zadosti?id=eq.${id}`, {
            method: 'PATCH',
            headers: { apikey: anon, Authorization: `Bearer ${token}`,
                       'Content-Type': 'application/json', Prefer: 'return=minimal' },
            body: JSON.stringify({ stav }),
        });
    } catch (e) { _log('WARN', `Označení žádosti selhalo: ${e.message}`); }
}

function start() {
    if (_timer) return;
    _timer = setInterval(() => {
        _zkontrolujZadost().catch(e => _log('INFO', `Dotaz na žádost selhal: ${e.message}`));
    }, INTERVAL_MS);
    if (_timer.unref) _timer.unref();
    // Hned po startu taky – žádost mohla přijít, když aplikace neběžela.
    setTimeout(() => { _zkontrolujZadost().catch(() => {}); }, 20000);
    _log('INFO', 'Hlídání žádostí o logy spuštěno');
}

function stop() { if (_timer) { clearInterval(_timer); _timer = null; } }

module.exports = { start, stop, posbirej, odesli, odmitni };
