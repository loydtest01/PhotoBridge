'use strict';
// ============================================================================
//  PhotoBridge – src/main/logy-okno.js
//
//  Okno s dotazem „Správce žádá o zaslání logů. Odeslat?"
//  Zobrazí se nad ostatními, ale NEPŘEVEZME zaměření – technik může dál
//  pracovat a odpovědět, až se mu to hodí.
// ============================================================================

const { BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const fs   = require('fs');

let _win = null;
let _zadost = null;

const SIROKE = 340;
const VYSOKE = 260;

function _log(u, z) { try { require('./utils').log(u, 'LOGY', z); } catch (_) {} }

function zeptejSe(zadost) {
    return new Promise((resolve) => {
        if (_win && !_win.isDestroyed()) { resolve(); return; }
        _zadost = zadost;

        const b = screen.getPrimaryDisplay().workArea;
        _win = new BrowserWindow({
            width: SIROKE, height: VYSOKE,
            x: b.x + b.width - SIROKE - 24,
            y: b.y + b.height - VYSOKE - 24,
            frame: false, transparent: true, resizable: false,
            skipTaskbar: false, alwaysOnTop: true, hasShadow: false,
            roundedCorners: false, focusable: false,
            webPreferences: {
                preload: path.join(__dirname, '..', '..', 'preload.js'),
                contextIsolation: true, nodeIntegration: false, sandbox: false,
            },
            show: false,
        });
        _win.setAlwaysOnTop(true, 'screen-saver');

        const html = path.join(__dirname, '..', 'renderer', 'logy.html');
        if (!fs.existsSync(html)) { _log('ERROR', 'logy.html chybí'); resolve(); return; }
        _win.loadFile(html);

        _win.webContents.once('did-finish-load', () => {
            try { _win.webContents.send('logy:zadost', _zadost); } catch (_) {}
            _win.showInactive();
        });

        _win.on('closed', () => { _win = null; _zadost = null; resolve(); });
    });
}

function zavri() {
    if (_win && !_win.isDestroyed()) _win.close();
    _win = null;
}

function registerIpcHandlers() {
    ipcMain.handle('logy:odeslat', async () => {
        if (!_zadost) return { ok: false, error: 'Žádost už neplatí.' };
        return require('./logy-zadost').odesli(_zadost);
    });

    ipcMain.handle('logy:odmitnout', async () => {
        if (_zadost) await require('./logy-zadost').odmitni(_zadost);
        return { ok: true };
    });

    ipcMain.handle('logy:zavrit', () => { zavri(); return { ok: true }; });

    _log('INFO', 'IPC handlery zaregistrovány');
}

module.exports = { zeptejSe, zavri, registerIpcHandlers };
